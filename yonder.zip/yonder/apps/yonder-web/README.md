# yonder-web

## Available Scripts

In the project directory, you can run:

## Development

Add the following to a .env file

```ini
PORT=3001
REACT_APP_FIREBASE_API_KEY=(key)
REACT_APP_FIREBASE_PROJECT_ID=(id)
REACT_APP_FIREBASE_APP_ID=(0:0:0:0 id)
REACT_APP_YONDER_API_URL=http://localhost:4000/api
REACT_APP_FILESTACK_API_KEY=(key)
REACT_APP_GMAPS_API_KEY=(key)
```

Run 'yarn start'

tickle ci build
