import React from "react";

import { Router, Route, Switch, RouteProps } from "react-router-dom";
import { history } from "./history";

//import LayoutHostProperty from "./layouts/HostProperty";
import LayoutUserProfile from "./layouts/Settings/UserProfile";
import { LayoutPageNotFound } from "./layouts/PageNotFound";
import { LayoutHome } from "./layouts/Home";
import { HostRouteNormal as LayoutNewHost, HostRouteMgmt as LayoutNewMgmt } from "./layouts/NewHost";
import { LayoutSupport } from "./layouts/Support";
import { AdminDashboard } from "./layouts/AdminDashboard";
//import { LayoutTest } from "./layouts/Test";

import {
    //HostDashboardIndex as LayoutHostInbox,
    //HostDashboardReservations as LayoutHostReservations,
    HostDashboardListings as LayoutHostListings,
    //HostDashboardCalendar as LayoutHostCalendar,
    HostDashboardAddProperty as LayoutHostAddProperty,
    HostDashboardAddActivity as LayoutHostAddActivity
} from "./layouts/HostDashboard";
import { AccountSettings, MyBusiness } from "./layouts/Settings";
import { ModalConductor } from "./components";

const routes: RouteProps[] = [
    /*{
        path: "/dash/inbox",
        component: LayoutHostInbox
    },
    {
        path: "/dash/reservations",
        component: LayoutHostReservations
    },*/
    {
        path: "/dash/listings/stays/:id*",
        component: LayoutHostAddProperty
    },
    {
        path: "/dash/listings/activities/:id*",
        component: LayoutHostAddActivity
    },
    {
        path: "/dash/listings",
        component: LayoutHostListings
    },
    /*{
        path: "/dash/calendar",
        component: LayoutHostCalendar
    },*/
    {
        path: "/dash",
        component: LayoutHostListings
    },
    {
        path: "/admin*",
        component: AdminDashboard
    },
    {
        path: "/new-host",
        component: LayoutNewHost
    },
    {
        path: "/new-mgmt",
        component: LayoutNewMgmt
    },
    {
        path: "/profile",
        component: LayoutUserProfile
    },
    {
        path: "/account",
        component: AccountSettings
    },
    {
        path: "/support",
        component: LayoutSupport
    },
    {
        path: "/my-business",
        component: MyBusiness
    },
    /*{
        path: "/listing/:id",
        component: LayoutHostProperty
    },*/
    {
        path: "/",
        component: LayoutHome
    },
    {
        path: "*",
        component: LayoutPageNotFound
    }
];

export default () => {
    const routeMap = routes.map((route, i) => {
        return <Route key={i} {...route} exact />;
    });

    return (
        <Router history={history}>
            <Switch>{routeMap}</Switch>
            <ModalConductor />
        </Router>
    );
};
