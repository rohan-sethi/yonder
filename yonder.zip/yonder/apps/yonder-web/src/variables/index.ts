import { math } from "polished";

export const color = {
    // new
    yonderGreen: "#588105",
    //
    primary: "#6aa84e",
    primaryDark: "#559438",
    //
    fireBrick: "#ab0707",
    pureWhite: "#ffffff",
    coconut: "#f9f9f9",
    fog: "#f3f3f3",
    metal: "#969696",
    charcoal: "#737373",
    blackInk: "#212121",

    pastelBlue: "#84c2d5",
    grass: "#75c19c",

    wintersGray: "#a6aaa9",
    wintersGrayLight: "#d6d8d8",

    indicatorOrange: "#bf6820",
    indicatorYellow: "#ecc939",
    indicatorBlue: "#2386c9",

    // No "real" color definitions for these yet?
    dark: "#515f5f",

    grayDark: "#899392",

    gray: "#dcdcdc"
};

export const thin = "0.125rem";
export const veryThin = "0.075rem";

// Fonts
const _cabin = "'Cabin', sans-serif";
const _nunitoSans = "'Nunito Sans', sans-serif";
const _caveat = "'Caveat', cursive";
export const fontFamily = {
    nunitoSans: _nunitoSans,
    cabin: _cabin,
    script: _caveat
};

//
export const layoutSpacing = "0.5rem";

export const html = {
    fontSize: 16, // in pixels
    fontSizeHD: "0.95vw",
    lineHeight: "1.5"
};

// Font sizes
export const fontSize = "1rem";
export const fontSizeSm = "0.5rem";
export const fontSizeLg = "1.5rem";
//
export const lineHeight = "1.5rem";

// Responsive breakpoints
const _sizeBase = "1rem";
export const size = {
    xs: math(`${_sizeBase} * 30`),
    sm: math(`${_sizeBase} * 60`),
    md: math(`${_sizeBase} * 72`),
    lg: math(`${_sizeBase} * 80`),
    hd: math(`${_sizeBase} * 120`)
};

//
export const scrollbarWidth = () => {
    return "17px";
};
