import { keyframes } from "styled-components";

export const expandWidth = (lastWidth: number, currentWidth: number) => keyframes`
    from {
        width: ${lastWidth}%;
    }
    to {
        width: ${currentWidth}%;
    }
 `;
