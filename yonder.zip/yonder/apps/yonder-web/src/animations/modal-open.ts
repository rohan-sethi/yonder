import { keyframes } from "styled-components";

export const modalOpen = keyframes`
    from {
        opacity: 0;
        transform: scale3d(0.75,0.75,1);
    }
    to {
        opacity: 1;
        transform: scale3d(1,1,1);
    }
`;
