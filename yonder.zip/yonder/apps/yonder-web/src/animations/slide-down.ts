import { keyframes } from "styled-components";

export const slideDown = keyframes`
    from {
        top: 0;
    }
    to {
        top: 100vh;
    }
`;
