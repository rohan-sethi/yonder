import { keyframes } from "styled-components";

export const slideUp = keyframes`
    from {
        top: 100vh;
    }
    to {
        top: 0;
    }
`;
