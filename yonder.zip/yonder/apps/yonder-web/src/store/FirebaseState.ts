import { observable, action } from "mobx";
import {
    User,
    yonderPost,
    yonderGet,
    Organization,
    yonderPut,
    yonderPatch,
    ID,
    Property,
    yonderAuthenticate,
    Activity,
    InviteRequest,
    yonderDelete,
    UserPermissions,
    HostTypes
} from "@yonder/db";

import { firebaseInstance, IFirebase, FirebaseUser, FirebaseFormRoute, reEmail } from "../components";

export interface IFirebaseState {
    firebase: IFirebase;
    authUser?: FirebaseUser;
    dbUser: User;
    dbOrganization: Organization;
    organizationStays: Partial<Property>[];
    organizationActivities: Partial<Activity>[];
    organizationUsers: Partial<User>[];
    stayAdded: boolean;
    activityAdded: boolean;
    isSignedIn: boolean;
    isSaving: boolean;
    formRoute: FirebaseFormRoute;
    stayLoggedIn: boolean;
    firebaseInitialized: boolean;
    submissionRoute: HostTypes;

    signUpUserViaEmail(firstName: string, lastName: string, email: string, password: string): Promise<void>;
    setUser(user: firebase.User): void;
    updateUserProfile(profile: Partial<User>): void;
    saveUserProfile(profile?: Partial<User>): Promise<ID>;
    toggleStayLoggedIn(): void;
    updateOrganization(org: Partial<Organization>): void;
    saveOrganization(org?: Partial<Organization>): Promise<ID>;
    setRoute(route: FirebaseFormRoute): void;
    createInviteLink(email: string): Promise<InviteRequest | void>;
    redeemInviteLink(id: ID): void;
    refreshStaysActivities(force?: boolean): Promise<void>;
    refreshOrganization(): Promise<void>;

    refreshUsers(): Promise<void>;

    setSubmissionRoute(route: HostTypes): void;
}

class FirebaseState implements IFirebaseState {
    @observable firebase: IFirebase = firebaseInstance;
    @observable dbUser: User = new User();
    @observable dbOrganization: Organization = new Organization();
    @observable organizationStays: Partial<Property>[] = [];
    @observable organizationActivities: Partial<Activity>[] = [];
    @observable organizationUsers: Partial<User>[] = [];

    // start these as true to always refresh
    @observable stayAdded: boolean = true;
    @observable activityAdded: boolean = true;

    @observable authUser?: FirebaseUser = undefined;
    @observable isSignedIn: boolean = false;
    @observable formRoute = FirebaseFormRoute.SignIn;
    @observable isSaving: boolean = false;
    @observable stayLoggedIn: boolean = true;
    @observable firebaseInitialized: boolean = false;
    @observable submissionRoute: HostTypes = HostTypes.Normal;

    @action.bound
    updateUserProfile = (profile: Partial<User>) => {
        this.dbUser = {
            ...this.dbUser,
            ...profile
        };
    };

    @action.bound
    saveUserProfile = async (profile?: Partial<User>): Promise<ID> => {
        this.isSaving = true;

        if (profile) {
            this.updateUserProfile(profile);
        }

        try {
            let res = await yonderPatch(`/users/${this.dbUser.id}`, {
                ...this.dbUser,
                email: undefined
            });
            this.dbUser.id = res.id;
            this.isSaving = false;
            return res.id;
        } catch (err) {
            //this.firebase.doSignOut();
            this.isSaving = false;
            throw new Error(err);
        }
    };

    @action.bound
    setUser = async (user: firebase.User | null) => {
        if (!!user) {
            const { displayName, email, emailVerified, isAnonymous, uid, providerData } = user;
            let firstName: string | undefined, lastName: string | undefined, displayInitials: string | undefined;
            let names: string[] = [];

            if (displayName) {
                names = displayName.split(" ");
            }

            if (names.length >= 2) {
                firstName = names[0];
                lastName = names[1];
            }

            if (firstName && firstName.length > 0 && lastName && lastName.length > 0) {
                displayInitials = firstName[0] + lastName[0];
            } else {
                if (email && email.length >= 1) {
                    displayInitials = email[0];
                } else {
                    displayInitials = "Y";
                }
            }

            try {
                const token = await user.getIdToken(true);
                yonderAuthenticate(token);
            } catch (err) {
                this.firebase.doSignOut();
                console.log(err);
                throw new Error("Error getting the user's auth token. Halting login.");
            }

            firstName = firstName || this.dbUser.firstName;
            lastName = lastName || this.dbUser.lastName;

            // otherwise set via signUpUserViaEmail if signing in for the first time
            this.dbUser.firstName = firstName;
            this.dbUser.lastName = lastName;
            this.dbUser.hostType = this.submissionRoute;

            this.dbUser.email = email || providerData[0]!.email || "undefined"; // Should reject if email doesn't exist (shouldn't even get here)

            if (this.dbUser.email === "undefined") {
                this.firebase.doSignOut();
                throw new Error("Error getting the user's email. Halting login.");
            }

            if (this.dbUser.id === undefined) {
                await this.initUser();
            }

            if (this.dbUser.organizationId) {
                this.dbOrganization.id = this.dbUser.organizationId;
                await this.initOrganization();
            }

            if (!this.dbUser.permissions) {
                this.saveUserProfile({
                    firstName,
                    lastName,
                    permissions: UserPermissions.Basic
                });
            } else if (this.dbUser.permissions === UserPermissions.Invited) {
                // User has logged in for the first time as an invited host
                this.saveUserProfile({
                    firstName,
                    lastName,
                    permissions: UserPermissions.Host
                });
            }

            this.refreshStaysActivities(true);
            this.refreshUsers();

            this.authUser = {
                displayName: displayName || undefined,
                displayInitials: displayInitials.toUpperCase(),
                emailVerified,
                // photoURL: photoURL || undefined,
                isAnonymous,
                uid,
                providerData
            };
            this.isSignedIn = true;
        } else {
            this.authUser = undefined;
            this.dbUser = new User();
            this.dbOrganization = new Organization();
            this.isSignedIn = false;
        }
        this.firebaseInitialized = true;
    };

    @action.bound
    signUpUserViaEmail = async (firstName: string, lastName: string, email: string, password: string) => {
        // Set the first name & last name BEFORE the firebase sign-in call.
        // This ensures dbUser.firstName & dbUser.lastName are defined
        this.updateUserProfile({
            firstName,
            lastName
        });

        // Now we can sign into firebase
        try {
            let result = await this.firebase.doCreateUserWithEmailAndPassword(email, password);

            // Set the display name in Firebase
            await (result.user as firebase.User).updateProfile({
                displayName: `${firstName} ${lastName}`
            });
        } catch (err) {
            throw err;
        }
    };

    @action.bound
    toggleStayLoggedIn = () => {
        this.stayLoggedIn = !this.stayLoggedIn;
        this.firebase.setStayLoggedIn(this.stayLoggedIn);
    };

    @action.bound
    updateOrganization = (org: Partial<Organization>) => {
        this.dbOrganization = {
            ...this.dbOrganization,
            ...org
        };
    };

    @action.bound
    saveOrganization = async (org?: Partial<Organization>): Promise<ID> => {
        this.isSaving = true;
        if (org) {
            this.updateOrganization(org);
        }

        try {
            let res = await yonderPut("/organizations", this.dbOrganization);
            this.dbOrganization.id = res.id;
            this.isSaving = false;
            return res.id;
        } catch (err) {
            console.log(err);
            this.firebase.doSignOut();
            this.isSaving = false;
            throw new Error(err);
        }
    };

    @action.bound
    setRoute = (route: FirebaseFormRoute) => {
        this.formRoute = route;
    };

    @action.bound
    createInviteLink = async (email: string): Promise<InviteRequest | void> => {
        if (!reEmail.test(email)) {
            console.log(`Invalid email: ${email}`);
            return;
        }
        try {
            let result = await yonderPost("/invite", {
                email
            });
            return result;
        } catch (err) {
            console.log(err);
        }
    };

    @action.bound
    redeemInviteLink = async (id: ID) => {
        try {
            await yonderDelete(`/invite/${id}`); // we don't need the result
        } catch (err) {
            console.log(err);
        }
    };

    // ============================================================================
    @action.bound
    refreshStaysActivities = async (force: boolean = false) => {
        if (this.dbOrganization.id === undefined) return;

        if (this.stayAdded || force) {
            try {
                let listings = await yonderGet("/host/listings");
                this.organizationStays = listings.properties;
                this.organizationActivities = listings.activities;
                this.stayAdded = false;
            } catch (err) {
                console.log(err);
                this.stayAdded = false;
            }
        }
    };

    @action.bound
    refreshOrganization = async () => {
        if (!this.dbUser.organizationId) throw new Error();

        try {
            let res = await yonderGet(`/organizations/${this.dbUser.organizationId}`);
            this.dbOrganization = {
                ...new Organization(),
                ...res
            };
        } catch (err) {
            console.log(err);
        }
    };

    // ============================================================================
    @action.bound
    refreshUsers = async () => {
        if (this.dbOrganization.id === undefined) return;

        try {
            let res = await yonderGet(`/organizations/users`);
            this.organizationUsers = res;
        } catch (err) {
            console.log(err);
        }
    };

    @action.bound
    setSubmissionRoute = (route: HostTypes) => {
        this.submissionRoute = route;
    };
    // ============================================================================

    private initUser = async () => {
        try {
            let res = await yonderGet("/users/info/me");
            this.dbUser = {
                ...new User(),
                ...res
            };
        } catch (err) {
            try {
                let res = await yonderPost(`/users`, this.dbUser);
                this.dbUser = res;
            } catch (err) {
                this.firebase.doSignOut();
                console.log(err);
            }
        }
    };

    private initOrganization = async () => {
        try {
            await this.refreshOrganization();
        } catch (err) {
            try {
                let res = await yonderPatch(`/organizations`, this.dbOrganization);
                this.dbOrganization = {
                    ...new Organization(),
                    ...res
                };
                this.dbUser.organizationId = res.id;
            } catch (err) {
                this.firebase.doSignOut();
                throw new Error(err);
            }
        }
    };

    constructor() {
        this.firebase.auth.onAuthStateChanged(this.setUser);

        // TODO: This should be a different function, NOT setUser. -- causes big bug
        //this.firebase.auth.onIdTokenChanged(this.setUser);
    }
}

export const firebaseState = new FirebaseState();
