import { observable, action } from "mobx";
import { IFirebase } from "../components";

export interface IUserPhotoUploadState {
    file: File;
    uploadProgress: object;
    uploadFile: (file: File, firebase: IFirebase, onUpload: UploadCallback) => void;
    setProgress: (file: File, percentage: number, url?: string) => void;
    sendRequest: (file: File, firebase: IFirebase, onUpload: UploadCallback) => void;
}
export type UploadCallback = (url: string) => void;

class UserPhotoUploadState implements IUserPhotoUploadState {
    @observable file!: File;
    @observable uploadProgress: object = {};

    @action.bound
    uploadFile = async (file: File, firebase: IFirebase, onUpload: UploadCallback) => {
        this.file = file;
        this.uploadProgress = {};

        try {
            this.sendRequest(file, firebase, onUpload);
        } catch (err) {
            throw err;
        }
    };

    @action.bound
    setProgress = (file: File, percentage: number, url?: string) => {
        this.uploadProgress[file.name] = {
            percentage,
            url
        };
    };

    @action.bound
    sendRequest = async (file: File, firebase: IFirebase, onUpload: UploadCallback) => {
        firebase.doUserPhotoImageUpload(
            file,
            (percentage: number) => {
                this.setProgress(file, percentage);
            },
            async (url: string) => {
                await this.setProgress(file, 100, url);
                await onUpload(url);
            },
            (err: Error) => {
                this.setProgress(file, 0);
                console.log(err);
            }
        );
    };
}

export const userPhotoUploadState = new UserPhotoUploadState();
