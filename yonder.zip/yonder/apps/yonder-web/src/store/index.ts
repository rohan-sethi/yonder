import { navigationState, INavigationState } from "./NavigationState";
import { contentModalState, IContentModalState } from "./ContentModalState";
import { firebaseState, IFirebaseState } from "./FirebaseState";
import { hostDashboardState, IHostDashboardState } from "./HostDashboardState";
import { addPropertyState, IAddPropertyState } from "./AddPropertyState";
import { listingPhotoUploadState, IListingPhotoUploadState } from "./ListingPhotoUploadState";
import { paymentMethodState, IPaymentMethodState } from "./PaymentMethodState";
import { adminState, IAdminState } from "./AdminState";
import { hostApprovalSubmissionState, IHostApprovalSubmissionState } from "./HostApprovalSubmissionState";
import { userPhotoUploadState, IUserPhotoUploadState } from "./UserPhotoUploadState";
import { addActivityState, IAddActivityState } from "./AddActivityState";

export type INavigationStore = {
    navigationState?: INavigationState;
};

export type IContentModalStore = {
    contentModalState?: IContentModalState;
};

export type IFirebaseStore = {
    firebaseState?: IFirebaseState;
};

export type IAdminStore = {
    adminState?: IAdminState;
}

export type IHostDashboardStore = {
    hostDashboardState?: IHostDashboardState;
};

export type IAddPropertyStore = {
    addPropertyState?: IAddPropertyState;
};

export type IListingPhotoUploadStore = {
    listingPhotoUploadState?: IListingPhotoUploadState;
};

export type IPaymentMethodStore = {
    paymentMethodState?: IPaymentMethodState;
};

export type IHostApprovalSubmissionStore = {
    hostApprovalSubmissionState?: IHostApprovalSubmissionState;
};

export type IUserPhotoUploadStore = {
    userPhotoUploadState?: IUserPhotoUploadState;
};

export type IAddActivityStore = {
    addActivityState?: IAddActivityState;
};

export type IStore = INavigationStore &
    IContentModalStore &
    IFirebaseStore &
    IAdminState &
    IHostDashboardStore &
    IAddPropertyStore &
    IListingPhotoUploadStore &
    IPaymentMethodStore &
    IHostApprovalSubmissionStore &
    IUserPhotoUploadStore &
    IAddActivityStore;

export default {
    navigationState,
    contentModalState,
    firebaseState,
    adminState,
    hostDashboardState,
    addPropertyState,
    listingPhotoUploadState,
    paymentMethodState,
    hostApprovalSubmissionState,
    userPhotoUploadState,
    addActivityState
};
