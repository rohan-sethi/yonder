import { observable, action } from "mobx";
import {
    yonderPut,
    Amenities,
    Keywords,
    ImageAsset,
    yonderGet,
    ID,
    yonderDelete,
    yonderPost,
    Activity,
    ExperienceCategories,
    ActivityTypes,
    SectionProgress,
    ListingProgress,
    ActivityItinerary,
    yonderPatch,
    User
} from "@yonder/db";

import { addToArray, removeFromArray, removeIndexFromArray, removeLastFromArray } from "../functions";
import content, { AddActivityOptions } from "../layouts/HostDashboard/AddActivity/_content";
import { IFirebase } from "../components";
import { history } from "../history";
import { ImageAssetMap } from "./AddPropertyState";
import { debounce } from "lodash";

export interface IAddActivityState {
    options: AddActivityOptions;
    activity: Activity;
    hosts: Partial<User>[];
    dbPhotos: ImageAsset[];
    dbPhotosMap: ImageAssetMap;
    isLoading: boolean;
    isSaving: boolean;

    saveNextRoute: (key: string, nextRoute: string) => void;
    nextSection: () => void;
    createOrLoadActivity: (id?: ID) => Promise<ID | undefined>;
    updateActivity: (activity?: Partial<Activity>) => void;
    saveActivity: () => Promise<ID>;

    fetchHosts(): Promise<void>;

    fetchPhotos(): Promise<void>;
    addPendingPhoto(pendingFile: File): void;
    addPhoto(uploadedFile: File, uuid: string, url: string): Promise<string>;
    getPhoto(photoId: ID): ImageAsset | null;
    setPhotoCaption: (photo: ImageAsset) => void;
    deletePhoto(photo: ImageAsset, firebase: IFirebase): Promise<boolean>;
    getListingComplete(): boolean;
    setSectionComplete(): void;
    setListingInReview(): void;

    addGalleryPhoto: (id: ID) => boolean;
    removeGalleryPhoto: (id: ID) => boolean;

    addAmenity: (newAmenity: Amenities) => boolean;
    removeAmenity: (newAmenity: Amenities) => boolean;

    addKeyword: (newKeyword: Keywords) => boolean;
    removeKeyword: (newKeyword: Keywords) => boolean;

    addExperienceCategory: (item: ExperienceCategories) => boolean;
    removeExperienceCategory: (item: ExperienceCategories) => boolean;

    addActivityRule: (newRule: string) => boolean;
    removeActivityRuleIndex: (index: number) => boolean;
    removeLastActivityRule: () => void;

    addActivityType: (newActivityType: ActivityTypes) => boolean;
    removeActivityType: (newActivityType: ActivityTypes) => boolean;

    addItineraryItem: () => void;
    removeItineraryItem: () => void;

    addKeyThingToKnow: (newOption: string) => boolean;
    removeKeyThingToKnowIndex: (index: number) => boolean;
    removeLastKeyThingToKnow: () => void;
}

class AddActivityState implements IAddActivityState {
    @observable options: AddActivityOptions = content;
    @observable activity: Activity = new Activity();
    @observable hosts: Partial<User>[] = [];
    @observable dbPhotos: ImageAsset[] = [];
    @observable dbPhotosMap: ImageAssetMap = {};
    @observable isLoading: boolean = false;
    @observable isSaving: boolean = false;

    //
    private sectionKey: string = "";
    private nextSectionRoute: string = "";

    //
    @action.bound
    saveNextRoute = (key: string, nextRoute: string): void => {
        this.sectionKey = key;
        this.nextSectionRoute = nextRoute;
    };

    @action.bound
    nextSection = (): void => {
        history.push(this.nextSectionRoute);
    };

    @action.bound
    createOrLoadActivity = async (id?: ID): Promise<ID | undefined> => {
        this.isLoading = true;
        this.activity = new Activity();

        let retId = id;
        try {
            if (id) {
                const res = await yonderGet(`/activities/${id}`);
                this.activity = {
                    ...this.activity,
                    ...res
                };
                await this.fetchPhotos();
            } else {
                retId = await this.saveActivity();
            }
            await this.fetchHosts();
        } catch (err) {
            console.log(err);
        } finally {
            this.isLoading = false;
            return retId;
        }
    };

    @action.bound
    updateActivity = (activity?: Partial<Activity>): void => {
        this.activity = {
            ...this.activity,
            ...activity
        };
    };

    @action.bound
    saveActivity = async () => {
        this.isSaving = true;

        try {
            const res = await yonderPut("/activities", this.activity);
            this.activity.id = res.id;
            return res.id;
        } catch (err) {
            console.log(err);
        } finally {
            this.isSaving = false;
            return this.activity.id!;
        }
    };

    @action.bound
    fetchHosts = async () => {
        try {
            if (this.activity.id === undefined) {
                throw new Error("activity id cannot be undefined");
            }
            let res: Partial<User>[] = await yonderGet(`/activities/${this.activity.id}/users`);
            this.hosts = res;
        } catch (err) {
            console.log(err);
        }
    };

    @action.bound
    fetchPhotos = async () => {
        try {
            if (this.activity.id === undefined) {
                throw new Error("activity id cannot be undefined");
            }
            const res = await yonderGet(`/activities/${this.activity.id}/assets`);
            this.dbPhotosMap = {};
            this.dbPhotos = res;
            for (let asset of this.dbPhotos) {
                this.dbPhotosMap[asset.id!] = asset;
            }
        } catch (err) {
            console.log(err);
        }
    };

    @action.bound
    addPendingPhoto = (pendingFile: File): void => {
        const { name, size } = pendingFile;
        const photo: ImageAsset = {
            name,
            size,
            file: name
        };
        this.dbPhotos.push(photo);
    };

    @action.bound
    addPhoto = async (uploadedFile: File, uuid: string, url: string) => {
        try {
            const { name, size } = uploadedFile;
            const photo: ImageAsset = await yonderPost(`/activities/${this.activity.id}/assets`, {
                name,
                size,
                uuid,
                file: url
            });
            // Check if there's a pending photo
            let filtered = this.dbPhotos.filter(
                (asset) => asset.name === name && asset.size === size && asset.id === undefined
            );
            if (filtered.length > 0) {
                // Update pending photo
                removeFromArray(this.dbPhotos, filtered[0], this.updateActivity);
            }
            // Add new photo
            this.dbPhotos.push(photo);
            this.dbPhotosMap[photo.id!] = photo;
            return photo.id!;
        } catch (err) {
            throw err;
        }
    };

    @action.bound
    getPhoto = (photoId: ID): ImageAsset | null => {
        if (this.dbPhotosMap[photoId]) {
            return this.dbPhotosMap[photoId];
        }
        return null;
    };

    @action.bound
    setPhotoCaption = debounce(async (photo: ImageAsset) => {
        try {
            await yonderPatch(`/activities/${this.activity.id}/assets/${photo.id}`, {
                caption: photo.caption
            });
        } catch (err) {
            console.log(err);
        }
    }, 1000);

    @action.bound
    deletePhoto = async (photo: ImageAsset, firebase: IFirebase): Promise<boolean> => {
        try {
            delete this.dbPhotosMap[photo.id!];
            // photo could be a copy, so we need to get the correct object from dbPhotos
            let filtered = this.dbPhotos.filter((asset: ImageAsset) => asset.id === photo.id);
            removeFromArray(this.dbPhotos, filtered[0], this.updateActivity);

            // Do the rest of the delete
            await yonderDelete(`/activities/${this.activity.id}/assets/${photo.id}`);
            return true;
        } catch (err) {
            console.log(err);
            return false;
        }
    };

    @action.bound
    getListingComplete = (): boolean => {
        const sectionProgress: string[] = Object.values(this.activity.sectionProgress);
        let ret = false;

        // -1 subtracts "finish"
        if (sectionProgress.length >= this.options.length - 1) {
            ret = true;
            sectionProgress.forEach((value) => {
                if (value !== SectionProgress.Complete) {
                    ret = false;
                }
            });
        }

        return ret;
    };

    @action.bound
    setSectionComplete = () => {
        if (this.sectionKey === "" || this.sectionKey === "finish") return;

        this.activity.sectionProgress[this.sectionKey] = SectionProgress.Complete;
        this.updateActivity();
    };

    @action.bound
    setListingInReview = () => {
        //if (!this.getListingComplete()) return;

        this.activity.listingProgress = ListingProgress.InReview;
        this.updateActivity();
    };

    //================================================================

    @action.bound
    addGalleryPhoto = (id: ID): boolean => addToArray(this.activity.galleryPhotos, id, this.updateActivity);

    @action.bound
    removeGalleryPhoto = (id: ID): boolean => removeFromArray(this.activity.galleryPhotos, id, this.updateActivity);

    //================================================================

    //TO-DO: finalize wording on amenity and keyword for activities
    @action.bound
    addAmenity = (amenity: Amenities): boolean => addToArray(this.activity.amenities, amenity, this.updateActivity);

    @action.bound
    removeAmenity = (amenity: Amenities): boolean =>
        removeFromArray(this.activity.amenities, amenity, this.updateActivity);

    //================================================================

    @action.bound
    addKeyword = (keyword: Keywords): boolean => addToArray(this.activity.keywords, keyword, this.updateActivity);

    @action.bound
    removeKeyword = (keyword: Keywords): boolean =>
        removeFromArray(this.activity.keywords, keyword, this.updateActivity);

    //================================================================

    @action.bound
    addExperienceCategory = (item: ExperienceCategories): boolean =>
        addToArray(this.activity.experienceCategories, item, this.updateActivity);

    @action.bound
    removeExperienceCategory = (item: ExperienceCategories) =>
        removeFromArray(this.activity.experienceCategories, item, this.updateActivity);

    //================================================================

    @action.bound
    addActivityRule = (rule: string): boolean =>
        addToArray(this.activity.activityRules, rule, this.updateActivity, true);

    @action.bound
    removeActivityRuleIndex = (index: number): boolean =>
        removeIndexFromArray(this.activity.activityRules, index, this.updateActivity);

    @action.bound
    removeLastActivityRule = () => removeLastFromArray(this.activity.activityRules);

    //================================================================

    @action.bound
    addActivityType = (type: ActivityTypes): boolean =>
        addToArray(this.activity.activityTypes, type, this.updateActivity);

    @action.bound
    removeActivityType = (type: ActivityTypes): boolean =>
        removeFromArray(this.activity.activityTypes, type, this.updateActivity);

    //================================================================

    @action.bound
    addItineraryItem = () => {
        const itineraryItem = new ActivityItinerary();
        addToArray(this.activity.itinerary, itineraryItem, this.updateActivity);
    };

    @action.bound
    removeItineraryItem = () => removeLastFromArray(this.activity.itinerary);

    // ========================================================================

    @action.bound
    addKeyThingToKnow = (newOption: string): boolean =>
        addToArray(this.activity.keyThingsToKnow, newOption, this.updateActivity, true);

    @action.bound
    removeKeyThingToKnowIndex = (index: number): boolean =>
        removeIndexFromArray(this.activity.keyThingsToKnow, index, this.updateActivity);

    @action.bound
    removeLastKeyThingToKnow = () => removeLastFromArray(this.activity.keyThingsToKnow);
}

export const addActivityState = new AddActivityState();
