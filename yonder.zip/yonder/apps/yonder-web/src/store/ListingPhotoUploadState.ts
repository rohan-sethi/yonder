import { observable, action } from "mobx";
import { IFirebase } from "../components";

export interface IListingPhotoUploadState {
    files: File[];
    uploadProgress: object;
    uploadFiles: (files: File[], firebase: IFirebase, onUpload: UploadCallback) => Promise<void>;
    setProgress: (file: File, percentage: number, url?: string) => void;
    sendRequest: (file: File, firebase: IFirebase, onUpload: UploadCallback) => Promise<void>;
}

export type UploadCallback = (file: File, url: string, uuid: string) => void;

class ListingPhotoUploadState implements IListingPhotoUploadState {
    @observable files: File[] = [];
    @observable uploadProgress: object = {};

    @action.bound
    uploadFiles = async (files: File[], firebase: IFirebase, onUpload: UploadCallback) => {
        this.files = files;
        this.uploadProgress = {};

        const promises: any[] = [];
        files.forEach((file) => {
            promises.push(this.sendRequest(file, firebase, onUpload));
        });

        try {
            await Promise.all(promises);
        } catch (err) {
            throw err;
        }
    };

    @action.bound
    setProgress = (file: File, percentage: number, url?: string) => {
        this.uploadProgress[file.name] = {
            percentage,
            url
        };
    };

    @action.bound
    sendRequest = async (file: File, firebase: IFirebase, onUpload: UploadCallback) => {
        firebase.doListingImageUpload(
            file,
            (percentage: number) => {
                this.setProgress(file, percentage);
            },
            async (url: string, uuid: string) => {
                this.setProgress(file, 100, url);
                onUpload(file, url, uuid);

                let fileIndex = this.files.indexOf(file);
                this.files.splice(fileIndex, 1);
            },
            (err: Error) => {
                this.setProgress(file, 0);
                console.log(err);
            }
        );
    };
}

export const listingPhotoUploadState = new ListingPhotoUploadState();
