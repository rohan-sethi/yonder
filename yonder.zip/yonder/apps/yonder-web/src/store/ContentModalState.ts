import { observable, action } from "mobx";

export interface IContentModalState {
    isOpen: boolean;
    iframe: boolean;
    video: boolean;
    dialog: boolean;
    url: string;
    header: string;
    body: string | JSX.Element;
    cancelButton: string;
    confirmButton: string;
    closeCallback: () => void;
    setHeader: (header: string) => void;
    open: (header: string, body: string | JSX.Element) => void;
    openIFrame: (url: string) => void;
    openVideo: (url: string) => void;
    openVideoIFrame: (url: string) => void;
    openDialog: (
        message: string | JSX.Element,
        cancelButton: string,
        confirmButton: string,
        confirmCallback?: () => void,
        cancelCallback?: () => void
    ) => void;
    dialogConfirmCallback: () => void;
    dialogCancelCallback: () => void;

    close: () => void;
    setCloseCallback: (callback: () => void) => void;
}

class ContentModalState implements IContentModalState {
    @observable
    isOpen: boolean = false;

    @observable
    iframe: boolean = false;

    @observable
    video: boolean = false;

    @observable
    dialog: boolean = false;

    @observable
    url: string = "";

    @observable
    header: string = "";

    @observable
    body: string | JSX.Element = "";

    @observable
    message: string = "";

    @observable
    cancelButton: string = "";

    @observable
    confirmButton: string = "";

    @observable
    closeCallback = () => {};

    @observable
    dialogConfirmCallback = () => {};

    @observable
    dialogCancelCallback = () => {};

    @action.bound
    setHeader = (header: string) => {
        this.header = header;
    };

    @action.bound
    open = (header: string, body: string | JSX.Element) => {
        this.isOpen = true;
        this.header = header;
        this.body = body;
    };

    @action.bound
    openIFrame = (url: string) => {
        this.isOpen = true;
        this.iframe = true;
        this.url = url;
    };

    @action.bound
    openVideo = (url: string) => {
        this.isOpen = true;
        this.video = true;
        this.url = url;
    };

    @action.bound
    openVideoIFrame = (url: string) => {
        this.isOpen = true;
        this.video = true;
        this.iframe = true;
        this.url = url;
    };

    @action.bound
    openDialog = (
        message: string | JSX.Element,
        cancelButton: string,
        confirmButton: string,
        confirmCallback?: () => void,
        cancelCallback?: () => void
    ) => {
        this.isOpen = true;
        this.dialog = true;
        this.body = message;
        this.cancelButton = cancelButton;
        this.confirmButton = confirmButton;

        if (confirmCallback) {
            this.dialogConfirmCallback = confirmCallback;
        }

        if (cancelCallback) {
            this.dialogCancelCallback = cancelCallback;
        }
    };

    @action.bound
    close = () => {
        this.isOpen = false;
        this.iframe = false;
        this.video = false;
        this.dialog = false;
        this.dialogConfirmCallback = () => {};
        this.dialogCancelCallback = () => {};
        this.header = "";
        this.body = "";
    };

    @action.bound
    setCloseCallback = (callback: () => void) => {
        this.closeCallback = callback;
    };
}

export const contentModalState = new ContentModalState();
