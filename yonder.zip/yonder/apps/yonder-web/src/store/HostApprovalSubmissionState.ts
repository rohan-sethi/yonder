import { observable, action } from "mobx";
import {
    HostApprovalSubmission,
    yonderPut,
    yonderGet,
    ID,
    OrganizationCertificates,
    ActivityTypes,
    HostApprovalSubmissionProgress,
    SustainabilityEfforts,
    ImageAsset,
    yonderPost,
    yonderDelete,
    PropertyManagementHost,
    Organization
} from "@yonder/db";
import { addToArray, removeFromArray, removeIndexFromArray, removeLastFromArray } from "../functions";
import { IFirebase } from "../components";
import { ImageAssetMap } from "./AddPropertyState";

export interface IHostApprovalSubmissionState {
    dbHostApprovalSubmission: HostApprovalSubmission;
    dbPhotos: ImageAsset[];
    dbPhotosMap: ImageAssetMap;
    isLoading: boolean;
    isSaving: boolean;
    showMakingProgress: boolean;
    photosInitialized: boolean;

    createOrLoadApproval(
        saveOrganization: (org?: Partial<Organization>) => Promise<ID>,
        id?: ID,
        submissionProgress?: HostApprovalSubmissionProgress,
        mgmt?: boolean
    ): Promise<void>;
    updateHostApprovalSubmission(profile?: Partial<HostApprovalSubmission>): void;
    updatePropertyManagementHostApprovalSubmission(updates?: Partial<PropertyManagementHost>): void;
    saveHostApprovalSubmission(profile?: Partial<HostApprovalSubmission>): Promise<ID>;

    fetchPhotos(): Promise<void>;
    addPendingPhoto(pendingFile: File): void;
    addPhoto(uploadedFile: File, uuid: string, url: string): Promise<string>;
    getPhoto(photoId: ID): ImageAsset | null;
    deletePhoto(photo: ImageAsset, firebase: IFirebase): Promise<boolean>;

    addGalleryPhoto: (id: ID) => boolean;
    removeGalleryPhoto: (id: ID) => boolean;

    addActivity: (newActivity: ActivityTypes) => boolean;
    removeActivity: (newActivity: ActivityTypes) => boolean;
    addCertificate: (newCertificate: OrganizationCertificates) => boolean;
    removeCertificate: (newCertificate: OrganizationCertificates) => boolean;
    addSustainabilityEffort: (newEffort: SustainabilityEfforts) => boolean;
    removeSustainabilityEffort: (newEffort: SustainabilityEfforts) => boolean;
    setMakingProgress: (value: boolean) => void;

    addOtherCertificate: (newCertificate: string) => boolean;
    removeOtherCertificateIndex: (index: number) => boolean;
    removeLastOtherCertificate: () => void;

    addOtherSustainabilityEffort: (newEffort: string) => boolean;
    removeOtherSustainabilityEffortIndex: (index: number) => boolean;
    removeLastOtherSustainabilityEffort: () => void;
}

class HostApprovalSubmissionState implements IHostApprovalSubmissionState {
    @observable dbHostApprovalSubmission: HostApprovalSubmission = new HostApprovalSubmission();
    @observable dbPhotos: ImageAsset[] = [];
    @observable dbPhotosMap: ImageAssetMap = {};
    @observable isLoading: boolean = false;
    @observable isSaving: boolean = false;
    @observable showMakingProgress: boolean = false;
    @observable photosInitialized: boolean = false;

    @action.bound
    createOrLoadApproval = async (
        saveOrganization: (org?: Partial<Organization>) => Promise<ID>,
        id?: ID,
        submissionProgress?: HostApprovalSubmissionProgress,
        mgmt: boolean = false
    ): Promise<void> => {
        this.isLoading = true;
        this.dbHostApprovalSubmission = new HostApprovalSubmission();
        if (mgmt) {
            this.dbHostApprovalSubmission.propertyManagementHost = new PropertyManagementHost();
        }

        try {
            if (id) {
                const res = await yonderGet(`/host-approval-submissions/${id}`);
                this.dbHostApprovalSubmission = {
                    ...this.dbHostApprovalSubmission,
                    ...res
                };
                this.checkMakingProgressState(submissionProgress);
                await this.fetchPhotos();
            } else {
                const outId = await this.saveHostApprovalSubmission();
                await saveOrganization({
                    approvalSubmissionId: outId
                });
            }
        } catch (err) {
            console.log(err);
        } finally {
            this.isLoading = false;
        }
    };

    @action.bound
    updateHostApprovalSubmission = (profile?: Partial<HostApprovalSubmission>) => {
        this.dbHostApprovalSubmission = {
            ...this.dbHostApprovalSubmission,
            ...profile
        };
    };

    @action.bound
    updatePropertyManagementHostApprovalSubmission = (updates?: Partial<PropertyManagementHost>) => {
        let { propertyManagementHost } = this.dbHostApprovalSubmission;
        if (propertyManagementHost !== undefined) {
            propertyManagementHost = {
                ...propertyManagementHost,
                ...updates
            };

            // This triggers the actual mobx update
            this.updateHostApprovalSubmission({
                propertyManagementHost
            });
        }
    };

    @action.bound
    saveHostApprovalSubmission = async (data?: Partial<HostApprovalSubmission>): Promise<ID> => {
        this.isSaving = true;

        if (data) {
            this.updateHostApprovalSubmission(data);
        }

        try {
            let res = await yonderPut(`/host-approval-submissions`, this.dbHostApprovalSubmission);
            this.dbHostApprovalSubmission.id = res.id;
            this.isSaving = false;
            return res.id;
        } catch (err) {
            console.log(err);
            this.isSaving = false;
            throw new Error(err);
        }
    };

    @action.bound
    fetchPhotos = async () => {
        try {
            const res = await yonderGet(`/host-approval-submissions/${this.dbHostApprovalSubmission.id}/assets`);
            this.dbPhotosMap = {};
            this.dbPhotos = res;
            for (let asset of this.dbPhotos) {
                this.dbPhotosMap[asset.id!] = asset;
            }
            this.photosInitialized = true;
        } catch (err) {
            console.log(err);
        }
    };

    @action.bound
    addPendingPhoto = (pendingFile: File): void => {
        const { name, size } = pendingFile;
        const photo: ImageAsset = {
            name,
            size,
            file: name
        };
        this.dbPhotos.push(photo);
    };

    @action.bound
    addPhoto = async (uploadedFile: File, uuid: string, url: string) => {
        try {
            const { name, size } = uploadedFile;
            const photo: ImageAsset = await yonderPost(
                `/host-approval-submissions/${this.dbHostApprovalSubmission.id}/assets`,
                {
                    name,
                    size,
                    uuid,
                    file: url
                }
            );
            // Check if there's a pending photo
            let filtered = this.dbPhotos.filter(
                (asset) => asset.name === name && asset.size === size && asset.id === undefined
            );
            if (filtered.length > 0) {
                // Remove pending photo
                removeFromArray(this.dbPhotos, filtered[0], this.updateHostApprovalSubmission);
            }
            // Add new photo
            this.dbPhotos.push(photo);
            this.dbPhotosMap[photo.id!] = photo;
            return photo.id!;
        } catch (err) {
            throw err;
        }
    };

    @action.bound
    getPhoto = (photoId: ID): ImageAsset | null => {
        if (this.dbPhotosMap[photoId]) {
            return this.dbPhotosMap[photoId];
        }
        return null;
    };

    @action.bound
    deletePhoto = async (photo: ImageAsset, firebase: IFirebase): Promise<boolean> => {
        try {
            delete this.dbPhotosMap[photo.id!];
            // photo could be a copy, so we need to get the correct object from dbPhotos
            let filtered = this.dbPhotos.filter((asset: ImageAsset) => asset.id === photo.id);
            removeFromArray(this.dbPhotos, filtered[0], this.updateHostApprovalSubmission);

            // Do the rest of the delete
            await yonderDelete(`/host-approval-submissions/${this.dbHostApprovalSubmission.id}/assets/${photo.id}`);
            return true;
        } catch (err) {
            console.log(err);
            return false;
        }
    };

    //================================================================

    @action.bound
    addGalleryPhoto = (id: ID): boolean =>
        addToArray(this.dbHostApprovalSubmission.samplePhotos, id, this.updateHostApprovalSubmission);

    @action.bound
    removeGalleryPhoto = (id: ID): boolean =>
        removeFromArray(this.dbHostApprovalSubmission.samplePhotos, id, this.updateHostApprovalSubmission);

    //================================================================

    @action.bound
    addActivity = (activity: ActivityTypes): boolean =>
        addToArray(this.dbHostApprovalSubmission.activities, activity, this.updateHostApprovalSubmission);

    @action.bound
    removeActivity = (activity: ActivityTypes): boolean =>
        removeFromArray(this.dbHostApprovalSubmission.activities, activity, this.updateHostApprovalSubmission);

    //================================================================

    @action.bound
    addCertificate = (certificate: OrganizationCertificates): boolean =>
        addToArray(this.dbHostApprovalSubmission.certificates, certificate, this.updateHostApprovalSubmission);

    @action.bound
    removeCertificate = (certificate: OrganizationCertificates): boolean =>
        removeFromArray(this.dbHostApprovalSubmission.certificates, certificate, this.updateHostApprovalSubmission);

    //================================================================

    @action.bound
    addSustainabilityEffort = (newEffort: SustainabilityEfforts): boolean =>
        addToArray(this.dbHostApprovalSubmission.sustainabilityEfforts, newEffort, this.updateHostApprovalSubmission);

    @action.bound
    removeSustainabilityEffort = (newEffort: SustainabilityEfforts): boolean =>
        removeFromArray(
            this.dbHostApprovalSubmission.sustainabilityEfforts,
            newEffort,
            this.updateHostApprovalSubmission
        );

    //================================================================

    @action.bound
    setMakingProgress = (value: boolean) => {
        this.showMakingProgress = value;
    };

    @action.bound
    addOtherCertificate = (newCertificate: string): boolean =>
        addToArray(
            this.dbHostApprovalSubmission.otherCertificates,
            newCertificate,
            this.updateHostApprovalSubmission,
            true
        );

    @action.bound
    removeOtherCertificateIndex = (index: number): boolean =>
        removeIndexFromArray(this.dbHostApprovalSubmission.otherCertificates, index, this.updateHostApprovalSubmission);

    @action.bound
    removeLastOtherCertificate = () => removeLastFromArray(this.dbHostApprovalSubmission.otherCertificates);

    @action.bound
    removeLastPropertyRule = () => removeLastFromArray(this.dbHostApprovalSubmission.otherCertificates);

    //================================================================

    @action.bound
    addOtherSustainabilityEffort = (newEffort: string): boolean =>
        addToArray(
            this.dbHostApprovalSubmission.otherSustainabilityEfforts,
            newEffort,
            this.updateHostApprovalSubmission,
            true
        );

    @action.bound
    removeOtherSustainabilityEffortIndex = (index: number) =>
        removeIndexFromArray(
            this.dbHostApprovalSubmission.otherSustainabilityEfforts,
            index,
            this.updateHostApprovalSubmission
        );

    @action.bound
    removeLastOtherSustainabilityEffort = () =>
        removeLastFromArray(this.dbHostApprovalSubmission.otherSustainabilityEfforts);

    //================================================================

    private checkMakingProgressState = (submissionProgress?: HostApprovalSubmissionProgress) => {
        const page1 = submissionProgress === HostApprovalSubmissionProgress.ExperienceCategory;
        const page2 = submissionProgress === HostApprovalSubmissionProgress.OvernightStays;
        const page3 = submissionProgress === HostApprovalSubmissionProgress.Activities;
        const page4 = submissionProgress === HostApprovalSubmissionProgress.Location;
        const page5 = submissionProgress === HostApprovalSubmissionProgress.Description;
        const page6 = submissionProgress === HostApprovalSubmissionProgress.Certificate;

        this.setMakingProgress(page1 || page2 || page3 || page4 || page5 || page6);
    };
}

export const hostApprovalSubmissionState = new HostApprovalSubmissionState();
