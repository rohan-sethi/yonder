import { observable, action } from "mobx";
import { PaymentMethod, yonderGet, yonderPost, yonderDelete } from "@yonder/db";

export interface IPaymentMethodState {
    cards: PaymentMethod[];
    getPaymentMethods(userId?: string): void;
    createPaymentMethod(stripeToken: string, stripePayload: any): void;
    deletePaymentMethod(cardId?: string): void;
}

class PaymentMethodState implements IPaymentMethodState {
    @observable
    cards: PaymentMethod[] = [];

    @action.bound
    getPaymentMethods = async () => {
        let paymentMethods = await yonderGet(`/pay/methods`);
        this.cards = paymentMethods;
    };

    @action.bound
    createPaymentMethod = async (stripeToken: string, stripePayload: any) => {
        await yonderPost(`/pay/methods`, {
            method: "cc",
            fingerprint: "",
            ccExpireYear: stripePayload.token!.card!.exp_year,
            ccLastDigits: stripePayload.token!.card!.last4,
            stripeToken: stripeToken,
            ccType: stripePayload.token!.card!.funding,
            isPrimary: false,
            ccExpireMonth: stripePayload.token!.card!.exp_month,
            ccName: stripePayload.token!.card!.brand
        });
        this.getPaymentMethods();
    };

    @action.bound
    deletePaymentMethod = async (cardId?: string) => {
        await yonderDelete(`/pay/methods/${cardId}`);
        this.getPaymentMethods();
    };
}
export const paymentMethodState = new PaymentMethodState();
