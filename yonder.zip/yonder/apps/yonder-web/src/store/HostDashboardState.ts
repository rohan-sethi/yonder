import { observable, action } from "mobx";

import { Props as IInboxConversation } from "../components/Inbox/InboxSidePanel/InboxConversation";
import content from "../layouts/HostDashboard/Inbox/_content";

export interface IHostDashboardState {
    unreadCount: number;
    inboxConversations: IInboxConversation[];
    currentConversation: string;
    setRead: (conversationId: number) => void;
    onConversationClick: (conversationId: number) => void;
}

class HostDashboardState implements IHostDashboardState {
    @observable unreadCount: number = 0;
    @observable inboxConversations: IInboxConversation[] = [];
    @observable currentConversation: string = ""; // stub

    @action.bound
    setRead = (conversationId: number): void => {
        if (this.inboxConversations[conversationId].unread) {
            this.inboxConversations[conversationId].unread = false;
            this.unreadCount--;
        }
    };

    @action.bound
    onConversationClick = (conversationId: number): void => {
        this.currentConversation = this.inboxConversations[conversationId].lastMessage;
        this.setRead(conversationId);
    };

    // ========================================================================

    @action.bound
    getUnreadCount = () => {
        let count = 0;
        this.inboxConversations.forEach((convo: IInboxConversation, i: number) => {
            if (convo.unread) count++;
        });
        return count;
    };

    constructor() {
        this.inboxConversations = content.conversations;
        this.unreadCount = this.getUnreadCount();
    }
}

export const hostDashboardState = new HostDashboardState();
