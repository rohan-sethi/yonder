import { observable, action } from "mobx";

export interface INavigationState {
    menuShown: boolean;
    toggleMenu: () => void;
    setMenuShown: (isShown: boolean) => void;
}

class NavigationState implements INavigationState {
    @observable menuShown: boolean = false;

    @action.bound
    toggleMenu = () => {
        this.menuShown = !this.menuShown;
    };

    @action.bound
    setMenuShown = (isShown: boolean) => {
        this.menuShown = isShown;
    };
}

export const navigationState = new NavigationState();
