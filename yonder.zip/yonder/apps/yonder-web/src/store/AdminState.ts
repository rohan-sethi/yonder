import { observable, action } from "mobx";
import { cloneDeep } from "lodash";
import {
    yonderGet,
    yonderPut,
    User,
    Organization,
    HostApprovalSubmission,
    HostApprovalSubmissionProgress,
    Activity,
    Property,
    yonderPost,
    yonderPatch,
    ID,
    yonderDelete,
    UserPermissions
} from "@yonder/db";

type AdminStats = {
    usersCount: number;
    orgsCount: number;
    subsCount: number;
};

type KeyMap<T> = {
    [key: string]: T;
};

export interface IAdminState {
    isSaving: boolean;

    addProperty(org: Organization): Promise<void>;
    updateSaveProperty(id: ID, property: Partial<Property>): Promise<void>;
    deleteProperty(id: ID): Promise<void>;
    duplicateProperty(orgId: ID, stayId: ID): Promise<void>;

    addActivity(org: Organization): Promise<void>;
    updateSaveActivity(id: ID, activity: Partial<Activity>): Promise<void>;
    deleteActivity(id: ID): Promise<void>;
    duplicateActivity(orgId: ID, activityId: ID): Promise<void>;

    deleteUser(id: ID): Promise<void>;
    deleteOrganization(id: ID): Promise<void>;

    getOverviewStats(): Promise<void>;
    getUsers(): Promise<void>;
    getOrganizations(): Promise<void>;
    getSubmissions(): Promise<void>;
    updateOrganizationStatus(organizationId: string, status: HostApprovalSubmissionProgress): void;
    getListings(): Promise<void>;

    stats: AdminStats;

    users: User[];
    userById: KeyMap<User>;
    usersLoaded: boolean;

    organizations: Organization[];
    organizationById: KeyMap<Organization>;
    adminOrganizations: ID[];
    organizationsLoaded: boolean;

    submissions: HostApprovalSubmission[];
    submissionById: KeyMap<HostApprovalSubmission>;
    submissionsLoaded: boolean;

    stays: Property[];
    staysById: KeyMap<Property>;
    staysLoaded: boolean;

    activities: Activity[];
    activitiesById: KeyMap<Activity>;
    activitiesLoaded: boolean;
}

class AdminState implements IAdminState {
    @observable
    stats: AdminStats = {
        usersCount: 0,
        orgsCount: 0,
        subsCount: 0
    };

    @observable
    users: User[] = [];

    @observable
    userById: KeyMap<User> = {};

    @observable
    organizations: Organization[] = [];

    @observable
    usersLoaded: boolean = false;

    @observable
    organizationById: KeyMap<Organization> = {};

    @observable
    adminOrganizations: ID[] = [];

    @observable
    organizationsLoaded: boolean = false;

    @observable
    submissions: HostApprovalSubmission[] = [];

    @observable
    submissionById: KeyMap<HostApprovalSubmission> = {};

    @observable
    submissionsLoaded: boolean = false;

    @observable
    isSaving: boolean = false;

    @observable
    stays: Property[] = [];

    @observable
    staysById: KeyMap<Property> = {};

    @observable
    staysLoaded: boolean = false;

    @observable
    activities: Activity[] = [];

    @observable
    activitiesById: KeyMap<Activity> = {};

    @observable
    activitiesLoaded: boolean = false;

    @action.bound
    addProperty = async (org: Organization) => {
        try {
            let newProperty = new Property();
            const res: Property = await yonderPost(`/properties?orgId=${org.id}`, newProperty);
            console.log(res.id);

            await this.getOrganizations();
            await this.getListings();
        } catch (err) {
            alert(err);
        }
    };

    @action.bound
    addActivity = async (org: Organization) => {
        try {
            let newActivity = new Activity();
            const res: Activity = await yonderPost(`/activities?orgId=${org.id}`, newActivity);
            console.log(res.id);

            await this.getOrganizations();
            await this.getListings();
        } catch (err) {
            alert(err);
        }
    };

    @action.bound
    updateSaveProperty = async (id: ID, property: Partial<Property>) => {
        try {
            await yonderPatch(`/properties/${id}`, property);
        } catch (err) {
            console.log(err);
        }
    };

    @action.bound
    updateSaveActivity = async (id: ID, activity: Partial<Activity>) => {
        try {
            await yonderPatch(`/activities/${id}`, activity);
        } catch (err) {
            console.log(err);
        }
    };

    @action.bound
    deleteProperty = async (id: ID) => {
        try {
            await yonderDelete(`/properties/${id}`);
            await this.getOrganizations();
        } catch (err) {
            console.log(err);
        }
    };

    @action.bound
    deleteActivity = async (id: ID) => {
        try {
            await yonderDelete(`/activities/${id}`);
            await this.getOrganizations();
        } catch (err) {
            console.log(err);
        }
    };

    @action.bound
    duplicateProperty = async (orgId: ID, stayId: ID) => {
        try {
            const stay: Property = await yonderGet(`/properties/${stayId}`);

            let propertyClone: Property = cloneDeep(stay);
            propertyClone.name = propertyClone.name ? `(Clone) ${propertyClone.name}` : "(Clone) New Property";

            const res: Property = await yonderPost(`/properties?orgId=${orgId}`, propertyClone);
            console.log(res.id);

            await this.getOrganizations();
            await this.getListings();
        } catch (err) {
            alert(err);
        }
    };

    @action.bound
    duplicateActivity = async (orgId: ID, activityId: ID) => {
        try {
            const activity: Activity = await yonderGet(`/activities/${activityId}`);

            let activityClone: Activity = cloneDeep(activity);
            activityClone.name = activityClone.name ? `(Clone) ${activityClone.name}` : "(Clone) New Activity";

            const res: Property = await yonderPost(`/activities?orgId=${orgId}`, activityClone);
            console.log(res.id);

            await this.getOrganizations();
            await this.getListings();
        } catch (err) {
            alert(err);
        }
    };

    @action.bound
    deleteUser = async (id: ID) => {
        try {
            await yonderDelete(`/ap/users/${id}`);
            await this.getUsers();
        } catch (err) {
            console.log(err);
        }
    };

    @action.bound
    deleteOrganization = async (id: ID) => {
        try {
            await yonderDelete(`/ap/orgs/${id}`);
            await this.getOrganizations();
        } catch (err) {
            console.log(err);
        }
    };

    @action.bound
    getListings = async () => {
        this.staysLoaded = false;
        this.activitiesLoaded = false;
        try {
            let allListings = await yonderGet(`/ap/listings`);

            this.stays = allListings.stays;
            this.stays.forEach((stay) => {
                this.staysById[stay.id!] = stay;
            });

            this.activities = allListings.activities;
            this.activities.forEach((activity) => {
                this.activitiesById[activity.id!] = activity;
            });
        } catch (err) {
            console.log(err);
        } finally {
            this.staysLoaded = true;
            this.activitiesLoaded = true;
        }
    };

    @action.bound
    getOverviewStats = async () => {
        try {
            let stats = await yonderGet(`/ap/stats`);
            this.stats = stats;
        } catch (err) {
            console.log(err);
        }
    };

    @action.bound
    getUsers = async () => {
        this.usersLoaded = false;
        try {
            let users = await yonderGet(`/ap/users`);
            this.users = users;
            this.userById = {};
            this.users.forEach((user) => {
                this.userById[user.id!] = user;
            });

            this.adminOrganizations = [];
            this.users
                .filter((user: User) => user.permissions === UserPermissions.Admin)
                .forEach((user: User) => {
                    if (user.organizationId) {
                        let id = user.organizationId;
                        this.adminOrganizations.push(id);
                    }
                });
        } catch (err) {
            console.log(err);
        } finally {
            this.usersLoaded = true;
        }
    };

    @action.bound
    getOrganizations = async () => {
        this.organizationsLoaded = false;
        try {
            let orgs = await yonderGet(`/ap/orgs`);
            this.organizations = orgs;

            orgs.forEach((org) => {
                this.organizationById[org.id] = org;
            });
        } catch (err) {
            console.log(err);
        } finally {
            this.organizationsLoaded = true;
        }
    };

    @action.bound
    getSubmissions = async () => {
        this.submissionsLoaded = false;
        try {
            let subs = await yonderGet(`/ap/subs`);
            this.submissions = subs;

            subs.forEach((sub) => {
                this.submissionById[sub.id] = sub;
            });
        } catch (err) {
            console.log(err);
        } finally {
            this.submissionsLoaded = true;
        }
    };

    @action.bound
    updateOrganizationStatus = async (organizationId: string, status: HostApprovalSubmissionProgress) => {
        const name = this.organizationById[organizationId].name;
        this.isSaving = true;

        this.organizationById[organizationId].approvalSubmissionProgress = status;

        try {
            let res = await yonderPut(`/ap/orgs/${organizationId}/status`, {
                name,
                approvalSubmissionProgress: status
            });

            this.isSaving = false;

            await this.getOrganizations();
            await this.getSubmissions();

            return res.id;
        } catch (err) {
            console.log(err);
            this.isSaving = false;
            throw new Error(err);
        }
    };
}
export const adminState = new AdminState();
