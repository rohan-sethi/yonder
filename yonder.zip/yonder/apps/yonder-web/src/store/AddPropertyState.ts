import { observable, action } from "mobx";
import {
    Property,
    yonderPut,
    Amenities,
    Keywords,
    ImageAsset,
    yonderGet,
    ID,
    yonderDelete,
    yonderPost,
    ExperienceCategories,
    PropertyBedroom,
    SectionProgress,
    ListingProgress,
    yonderPatch,
    User,
    Activity,
    OrganizationCertificates,
    SustainabilityEfforts
} from "@yonder/db";

import { addToArray, removeFromArray, removeLastFromArray, removeIndexFromArray } from "../functions";
import content, { AddPropertyOptions } from "../layouts/HostDashboard/AddProperty/_content";
import { IFirebase } from "../components";
import { history } from "../history";
import { debounce } from "lodash";

export type ImageAssetMap = { [id: string]: ImageAsset };

export interface IAddPropertyState {
    options: AddPropertyOptions;
    property: Property;
    hosts: Partial<User>[];
    activities: Partial<Activity>[];
    dbPhotos: ImageAsset[];
    dbPhotosMap: ImageAssetMap;
    isLoading: boolean;
    isSaving: boolean;

    saveNextRoute: (key: string, nextRoute: string) => void;
    nextSection: () => void;
    createOrLoadProperty: (id?: ID) => Promise<ID | undefined>;
    updateProperty: (property?: Partial<Property>) => void;
    saveProperty: () => Promise<ID>;

    fetchHosts(id?: ID): Promise<void>;
    fetchActivities(id?: ID): Promise<void>;
    createNewActivity(): Promise<ID | undefined>;

    fetchPhotos(): Promise<void>;
    addPendingPhoto(pendingFile: File): void;
    addPhoto(uploadedFile: File, uuid: string, url: string): Promise<string>;
    getPhoto(photoId: ID): ImageAsset | null;
    setPhotoCaption: (photo: ImageAsset) => void;
    deletePhoto(photo: ImageAsset, firebase: IFirebase): Promise<boolean>;
    getListingComplete(): boolean;
    setSectionComplete(): void;
    setListingInReview(): void;

    addGalleryPhoto: (id: ID) => boolean;
    removeGalleryPhoto: (id: ID) => boolean;

    addAmenity: (item: Amenities) => boolean;
    removeAmenity: (item: Amenities) => boolean;

    addKeyword: (item: Keywords) => boolean;
    removeKeyword: (item: Keywords) => boolean;

    addExperienceCategory: (item: ExperienceCategories) => boolean;
    removeExperienceCategory: (item: ExperienceCategories) => boolean;

    addPropertyRule: (newRule: string) => boolean;
    removePropertyRuleIndex: (index: number) => boolean;
    removeLastPropertyRule: () => void;

    addActivityAvailable: (activityId: ID) => boolean;
    removeActivityAvailable: (activityId: ID) => boolean;

    addPropertyBedroom: () => void;
    removePropertyBedroom: (index: number) => boolean;
    addBedroomBed: (bedroom: PropertyBedroom) => void;
    removeBedroomBed: (index: number) => boolean;

    addCommonSpaceRoom: () => void;
    removeCommonSpaceRoom: (index: number) => boolean;
    addCommonSpaceBed: (room: PropertyBedroom) => void;
    removeCommonSpaceBed: (index: number) => boolean;

    addTransportationOption: (newOption: string) => boolean;
    removeTransportationOptionIndex: (index: number) => boolean;
    removeLastTransportationOption: () => void;

    addRestaurantOption: (newOption: string) => boolean;
    removeRestaurantOptionIndex: (index: number) => boolean;
    removeLastRestaurantOption: () => void;

    addOnSiteActivityOption: (newOption: string) => boolean;
    removeOnSiteActivityOptionIndex: (index: number) => boolean;
    removeLastOnSiteActivityOption: () => void;

    addOffSiteActivityOption: (newOption: string) => boolean;
    removeOffSiteActivityOptionIndex: (index: number) => boolean;
    removeLastOffSiteActivityOption: () => void;

    addFootwearRecommendationOption: (newOption: string) => boolean;
    removeFootwearRecommendationOptionIndex: (index: number) => boolean;
    removeLastFootwearRecommendationOption: () => void;

    addKeyThingToKnow: (newOption: string) => boolean;
    removeKeyThingToKnowIndex: (index: number) => boolean;
    removeLastKeyThingToKnow: () => void;

    addCertificate: (newCertificate: OrganizationCertificates) => boolean;
    removeCertificate: (newCertificate: OrganizationCertificates) => boolean;

    addSustainabilityEffort: (newEffort: SustainabilityEfforts) => boolean;
    removeSustainabilityEffort: (newEffort: SustainabilityEfforts) => boolean;

    addOtherCertificate: (newCertificate: string) => boolean;
    removeOtherCertificateIndex: (index: number) => boolean;
    removeLastOtherCertificate: () => void;

    addOtherSustainabilityEffort: (newEffort: string) => boolean;
    removeOtherSustainabilityEffortIndex: (index: number) => boolean;
    removeLastOtherSustainabilityEffort: () => void;
}

class AddPropertyState implements IAddPropertyState {
    @observable options: AddPropertyOptions = content;
    @observable property: Property = new Property();
    @observable hosts: Partial<User>[] = [];
    @observable activities: Partial<Activity>[] = [];
    @observable dbPhotos: ImageAsset[] = [];
    @observable dbPhotosMap: ImageAssetMap = {};
    @observable isLoading: boolean = false;
    @observable isSaving: boolean = false;

    //
    private sectionKey: string = "";
    private nextSectionRoute: string = "";

    //
    @action.bound
    saveNextRoute = (key: string, nextRoute: string): void => {
        this.sectionKey = key;
        this.nextSectionRoute = nextRoute;
    };

    @action.bound
    nextSection = (): void => {
        history.push(this.nextSectionRoute);
    };

    @action.bound
    createOrLoadProperty = async (id?: ID): Promise<ID | undefined> => {
        this.isLoading = true;
        this.property = new Property();

        let retId = id;
        try {
            if (id) {
                const res = await yonderGet(`/properties/${id}`);
                this.property = {
                    ...this.property,
                    ...res
                };
                await this.fetchPhotos();
            } else {
                retId = await this.saveProperty();
            }
            await this.fetchHosts();
            await this.fetchActivities();
        } catch (err) {
            console.log(err);
        } finally {
            this.isLoading = false;
            return retId;
        }
    };

    @action.bound
    updateProperty = (property?: Partial<Property>): void => {
        this.property = {
            ...this.property,
            ...property
        };
    };

    @action.bound
    saveProperty = async () => {
        this.isSaving = true;

        try {
            const res = await yonderPut("/properties", this.property);
            this.property.id = res.id;
        } catch (err) {
            console.log(err);
        } finally {
            this.isSaving = false;
            return this.property.id!;
        }
    };

    @action.bound
    fetchHosts = async () => {
        try {
            if (this.property.id === undefined) {
                throw new Error("property id cannot be undefined");
            }
            let res: Partial<User>[] = await yonderGet(`/properties/${this.property.id}/users`);
            this.hosts = res;
        } catch (err) {
            console.log(err);
        }
    };

    @action.bound
    fetchActivities = async () => {
        try {
            if (this.property.id === undefined) {
                throw new Error("property id cannot be undefined");
            }
            let res: Partial<Activity>[] = await yonderGet(`/properties/${this.property.id}/activities`);
            this.activities = res;
        } catch (err) {
            console.log(err);
        }
    };

    @action.bound
    createNewActivity = async (): Promise<ID | undefined> => {
        let retId: ID | undefined = undefined;
        try {
            let activity = new Activity();
            let res: Activity = await yonderPost(`/properties/${this.property.id}/activities`, activity);
            retId = res.id;
        } catch (err) {
            console.log(err);
        } finally {
            return retId;
        }
    };

    @action.bound
    fetchPhotos = async () => {
        try {
            if (this.property.id === undefined) {
                throw new Error("property id cannot be undefined");
            }
            const res = await yonderGet(`/properties/${this.property.id}/assets`);
            this.dbPhotosMap = {};
            this.dbPhotos = res;
            for (let asset of this.dbPhotos) {
                this.dbPhotosMap[asset.id!] = asset;
            }
        } catch (err) {
            console.log(err);
        }
    };

    @action.bound
    addPendingPhoto = (pendingFile: File): void => {
        const { name, size } = pendingFile;
        const photo: ImageAsset = {
            name,
            size,
            file: name
        };
        this.dbPhotos.push(photo);
    };

    @action.bound
    addPhoto = async (uploadedFile: File, uuid: string, url: string) => {
        try {
            const { name, size } = uploadedFile;
            const photo: ImageAsset = await yonderPost(`/properties/${this.property.id}/assets`, {
                name,
                size,
                uuid,
                file: url
            });
            // Check if there's a pending photo
            let filtered = this.dbPhotos.filter(
                (asset) => asset.name === name && asset.size === size && asset.id === undefined
            );
            if (filtered.length > 0) {
                // Remove pending photo
                removeFromArray(this.dbPhotos, filtered[0], this.updateProperty);
            }
            // Add new photo
            this.dbPhotos.push(photo);
            this.dbPhotosMap[photo.id!] = photo;
            return photo.id!;
        } catch (err) {
            throw err;
        }
    };

    @action.bound
    getPhoto = (photoId: ID): ImageAsset | null => {
        if (this.dbPhotosMap[photoId]) {
            return this.dbPhotosMap[photoId];
        }
        return null;
    };

    @action.bound
    setPhotoCaption = debounce(async (photo: ImageAsset) => {
        try {
            await yonderPatch(`/properties/${this.property.id}/assets/${photo.id}`, {
                caption: photo.caption
            });
        } catch (err) {
            console.log(err);
        }
    }, 1000);

    @action.bound
    deletePhoto = async (photo: ImageAsset, firebase: IFirebase): Promise<boolean> => {
        try {
            delete this.dbPhotosMap[photo.id!];
            // photo could be a copy, so we need to get the correct object from dbPhotos
            let filtered = this.dbPhotos.filter((asset: ImageAsset) => asset.id === photo.id);
            removeFromArray(this.dbPhotos, filtered[0], this.updateProperty);

            // Do the rest of the delete
            await yonderDelete(`/properties/${this.property.id}/assets/${photo.id}`);
            return true;
        } catch (err) {
            console.log(err);
            return false;
        }
    };

    @action.bound
    getListingComplete = (): boolean => {
        const sectionProgress: string[] = Object.values(this.property.sectionProgress);
        let ret = false;

        // -1 subtracts "finish"
        if (sectionProgress.length >= this.options.length - 1) {
            ret = true;
            sectionProgress.forEach((value) => {
                if (value !== SectionProgress.Complete) {
                    ret = false;
                }
            });
        }

        return ret;
    };

    @action.bound
    setSectionComplete = () => {
        if (this.sectionKey === "" || this.sectionKey === "finish") return;

        this.property.sectionProgress[this.sectionKey] = SectionProgress.Complete;
        this.updateProperty();
    };

    @action.bound
    setListingInReview = () => {
        //if (!this.getListingComplete()) return;

        this.property.listingProgress = ListingProgress.InReview;
        this.updateProperty();
    };

    //================================================================

    @action.bound
    addGalleryPhoto = (id: ID): boolean => addToArray(this.property.galleryPhotos, id, this.updateProperty);

    @action.bound
    removeGalleryPhoto = (id: ID): boolean => removeFromArray(this.property.galleryPhotos, id, this.updateProperty);

    //================================================================

    @action.bound
    addAmenity = (item: Amenities): boolean => addToArray(this.property.amenities, item, this.updateProperty);

    @action.bound
    removeAmenity = (item: Amenities): boolean => removeFromArray(this.property.amenities, item, this.updateProperty);

    //================================================================

    @action.bound
    addKeyword = (item: Keywords): boolean => addToArray(this.property.keywords, item, this.updateProperty);

    @action.bound
    removeKeyword = (item: Keywords): boolean => removeFromArray(this.property.keywords, item, this.updateProperty);

    //================================================================

    @action.bound
    addExperienceCategory = (item: ExperienceCategories): boolean =>
        addToArray(this.property.experienceCategories, item, this.updateProperty);

    @action.bound
    removeExperienceCategory = (item: ExperienceCategories): boolean =>
        removeFromArray(this.property.experienceCategories, item, this.updateProperty);

    //================================================================

    @action.bound
    addPropertyRule = (rule: string): boolean =>
        addToArray(this.property.propertyRules, rule, this.updateProperty, true);

    @action.bound
    removePropertyRuleIndex = (index: number): boolean =>
        removeIndexFromArray(this.property.propertyRules, index, this.updateProperty);

    @action.bound
    removeLastPropertyRule = () => removeLastFromArray(this.property.propertyRules);

    //================================================================

    @action.bound
    addActivityAvailable = (id: ID): boolean => addToArray(this.property.activitiesAvailable, id, this.updateProperty);

    @action.bound
    removeActivityAvailable = (id: ID): boolean =>
        removeFromArray(this.property.activitiesAvailable, id, this.updateProperty);

    //================================================================

    @action.bound
    addPropertyBedroom = () => {
        const bedroom = new PropertyBedroom();
        this.addBedroomBed(bedroom);
        return addToArray(this.property.bedrooms, bedroom, this.updateProperty);
    };

    @action.bound
    removePropertyBedroom = (index: number): boolean =>
        removeIndexFromArray(this.property.bedrooms, index, this.updateProperty);

    @action.bound
    addBedroomBed = (bedroom: PropertyBedroom) => {
        return addToArray(bedroom.bedTypes, undefined, this.updateProperty, true);
    };

    @action.bound
    removeBedroomBed = (index: number) => removeLastFromArray(this.property.bedrooms[index].bedTypes);

    //================================================================

    @action.bound
    addCommonSpaceRoom = () => {
        const bedroom = new PropertyBedroom();
        this.addBedroomBed(bedroom);
        return addToArray(this.property.commonSpaceRooms, bedroom, this.updateProperty);
    };

    @action.bound
    removeCommonSpaceRoom = (index: number): boolean =>
        removeIndexFromArray(this.property.commonSpaceRooms, index, this.updateProperty);

    @action.bound
    addCommonSpaceBed = (room: PropertyBedroom) => {
        return addToArray(room.bedTypes, undefined, this.updateProperty, true);
    };

    @action.bound
    removeCommonSpaceBed = (index: number) => removeLastFromArray(this.property.commonSpaceRooms[index].bedTypes);

    //================================================================

    @action.bound
    addTransportationOption = (newOption: string): boolean =>
        addToArray(this.property.transportationOptions, newOption, this.updateProperty, true);

    @action.bound
    removeTransportationOptionIndex = (index: number): boolean =>
        removeIndexFromArray(this.property.transportationOptions, index, this.updateProperty);

    @action.bound
    removeLastTransportationOption = () => removeLastFromArray(this.property.transportationOptions);

    //================================================================

    @action.bound
    addRestaurantOption = (newOption: string): boolean =>
        addToArray(this.property.suggestedRestaurantsNearby, newOption, this.updateProperty, true);

    @action.bound
    removeRestaurantOptionIndex = (index: number): boolean =>
        removeIndexFromArray(this.property.suggestedRestaurantsNearby, index, this.updateProperty);

    @action.bound
    removeLastRestaurantOption = () => removeLastFromArray(this.property.suggestedRestaurantsNearby);

    //================================================================
    @action.bound
    addOnSiteActivityOption = (newOption: string): boolean =>
        addToArray(this.property.recommendedThingsToDoOnProperty, newOption, this.updateProperty, true);

    @action.bound
    removeOnSiteActivityOptionIndex = (index: number): boolean =>
        removeIndexFromArray(this.property.recommendedThingsToDoOnProperty, index, this.updateProperty);

    @action.bound
    removeLastOnSiteActivityOption = () => removeLastFromArray(this.property.recommendedThingsToDoOnProperty);

    //================================================================

    @action.bound
    addOffSiteActivityOption = (newOption: string): boolean =>
        addToArray(this.property.recommendedThingsToDoOffProperty, newOption, this.updateProperty, true);

    @action.bound
    removeOffSiteActivityOptionIndex = (index: number): boolean =>
        removeIndexFromArray(this.property.recommendedThingsToDoOffProperty, index, this.updateProperty);

    @action.bound
    removeLastOffSiteActivityOption = () => removeLastFromArray(this.property.recommendedThingsToDoOffProperty);

    //================================================================

    @action.bound
    addFootwearRecommendationOption = (newOption: string): boolean =>
        addToArray(this.property.footwearRecommendations, newOption, this.updateProperty, true);

    @action.bound
    removeFootwearRecommendationOptionIndex = (index: number): boolean =>
        removeIndexFromArray(this.property.footwearRecommendations, index, this.updateProperty);

    @action.bound
    removeLastFootwearRecommendationOption = () => removeLastFromArray(this.property.footwearRecommendations);

    //================================================================

    @action.bound
    addKeyThingToKnow = (newOption: string): boolean =>
        addToArray(this.property.keyThingsToKnow, newOption, this.updateProperty, true);

    @action.bound
    removeKeyThingToKnowIndex = (index: number): boolean =>
        removeIndexFromArray(this.property.keyThingsToKnow, index, this.updateProperty);

    @action.bound
    removeLastKeyThingToKnow = () => removeLastFromArray(this.property.keyThingsToKnow);

    // ========================================================================

    @action.bound
    addCertificate = (certificate: OrganizationCertificates): boolean =>
        addToArray(this.property.certificates, certificate, this.updateProperty);

    @action.bound
    removeCertificate = (certificate: OrganizationCertificates): boolean =>
        removeFromArray(this.property.certificates, certificate, this.updateProperty);

    // ========================================================================

    @action.bound
    addSustainabilityEffort = (newEffort: SustainabilityEfforts): boolean =>
        addToArray(this.property.sustainabilityEfforts, newEffort, this.updateProperty);

    @action.bound
    removeSustainabilityEffort = (newEffort: SustainabilityEfforts): boolean =>
        removeFromArray(this.property.sustainabilityEfforts, newEffort, this.updateProperty);

    // ========================================================================

    @action.bound
    addOtherCertificate = (newCertificate: string): boolean =>
        addToArray(this.property.otherCertificates, newCertificate, this.updateProperty, true);

    @action.bound
    removeOtherCertificateIndex = (index: number): boolean =>
        removeIndexFromArray(this.property.otherCertificates, index, this.updateProperty);

    @action.bound
    removeLastOtherCertificate = () => removeLastFromArray(this.property.otherCertificates);

    // ========================================================================

    @action.bound
    addOtherSustainabilityEffort = (newEffort: string): boolean =>
        addToArray(this.property.otherSustainabilityEfforts, newEffort, this.updateProperty, true);

    @action.bound
    removeOtherSustainabilityEffortIndex = (index: number) =>
        removeIndexFromArray(this.property.otherSustainabilityEfforts, index, this.updateProperty);

    @action.bound
    removeLastOtherSustainabilityEffort = () => removeLastFromArray(this.property.otherSustainabilityEfforts);

    // ========================================================================
}

export const addPropertyState = new AddPropertyState();
