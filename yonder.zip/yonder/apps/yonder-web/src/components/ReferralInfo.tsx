import React from "react";
import styled from "styled-components";

import { ContentBlock, ExternalLink } from ".";

export const ReferralInfo = () => {
    return (
        <StyledReferralInfo>
            <ContentBlock
                header={
                    <>
                        Refer your host friends,
                        <br />
                        get booking fees waived!
                    </>
                }
                url="/img/icon-chatboxes.svg"
                alt="chatbox icon"
                body="Tell your host friends about Yonder. You can refer up to 6 friends. Make sure they include your full name at sign-up."
            />
            <ContentBlock
                url="/img/icon-money.svg"
                alt="money icon"
                body={
                    <>
                        Receive 2 months of all booking fees waived for each sign up, applicable to all listings. <br />
                        For 6 friends, that's an entire year of waived fees!
                    </>
                }
            />

            <p>
                <ExternalLink
                    to="https://help.yonder.com/hc/en-us/articles/360035468493-Yonder-Host-Referral-Promotion"
                    target="_blank"
                    rel="noopener noreferrer"
                    label="Read full details"
                />
            </p>
        </StyledReferralInfo>
    );
};

const StyledReferralInfo = styled.div`
    max-width: 34rem;
    margin: 0;
    padding: 0;

    h2 {
        margin-bottom: 3rem;
    }

    img {
        margin-bottom: 1rem;
    }

    p {
        text-align: center;
        margin-bottom: 3rem;
    }

    @media only screen and (min-width: 40rem) {
        margin: 3rem auto 2rem;
        padding: 0 6rem;
    }
`;
