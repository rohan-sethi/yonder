import React from "react";
import styled from "styled-components";
import { IEditNavigationOption } from "./index";
import { fontFamily } from "../../variables";

type Props = {
    currentOption: IEditNavigationOption;
};

export class EditNavigationView extends React.Component<Props> {
    sectionRef: React.RefObject<HTMLDivElement> = React.createRef();
    lastComponent: React.ComponentType | null = null;

    render() {
        const { currentOption } = this.props;

        if (this.lastComponent !== currentOption.component) {
            if (this.sectionRef.current) {
                // make sure IE works!
                if (this.sectionRef.current.scrollTo) {
                    this.sectionRef.current.scrollTo(0, 0);
                } else {
                    if (this.sectionRef.current.scrollTop) {
                        this.sectionRef.current.scrollTop = 0;
                    }
                }
            }
            this.lastComponent = currentOption.component;
        }

        const alerts = currentOption.alerts ? currentOption.alerts : null;
        const component = currentOption.component !== null ? <currentOption.component /> : <div />;
        const isFinish: boolean = currentOption.label === "Finish and Submit";

        return (
            <StyledEditNavigationView ref={this.sectionRef}>
                {alerts && <div className={`alert-outer ${currentOption.layout}`}>{alerts}</div>}

                {!isFinish && <h2>{currentOption.label}</h2>}
                <div className="inner-view">
                    <div className={`edit-section ${currentOption.layout}`}>{component}</div>
                </div>
            </StyledEditNavigationView>
        );
    }
}

const StyledEditNavigationView = styled.div`
    display: block;
    width: 100%;
    height: inherit;
    padding: 0.5rem 2rem;

    h2 {
        display: block;
        font-size: 1.5rem;
        font-family: ${fontFamily.nunitoSans};
        font-weight: 600;
        margin-bottom: 2rem;
    }

    .alert-outer {
        width: 100%;
        margin-bottom: 4rem;
        padding: 1rem 0.5rem;
    }

    @media only screen and (min-width: 30rem) {
        max-width: 30rem;
        margin: 0 auto;
    }

    @media only screen and (min-width: 60rem) {
        max-width: none;
        margin: 0;
        overflow-y: auto;
        padding-left: 7.5rem;
        padding-top: 2.5rem;

        .inner-view {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            width: 100%;
            margin: 0 auto;

            .edit-section {
                display: flex;
                width: 100%;

                &.small {
                    max-width: 30rem;
                }

                &.medium {
                    max-width: 45rem;
                }

                &.large {
                    max-width: 60rem;
                }
            }
        }

        .alert-outer {
            &.small {
                width: 55%;
                margin-bottom: 2rem;
                padding: 1rem 0.5rem 1rem 0;
                margin-top: -2.5rem;

                .alert {
                    padding: 1.5rem 0 1.5rem 1.5rem;
                }
                .alert-text {
                    margin-right: 0;
                    margin-left: 3rem;
                }
            }

            &.medium {
                width: 70%;
            }

            &.large {
                width: 100%;
            }
        }
    }
`;
