import { SectionProgress } from "@yonder/db";

export type ViewLayout = "small" | "medium" | "large";

export type IEditNavigationOption = {
    label: string;
    component: React.ComponentType | null; // Used outside of this component ...maybe rework this
    info?: React.ReactNode; // Used outside of this component ...maybe rework this
    active?: boolean;
    progress?: SectionProgress;
    layout: ViewLayout;
    onClick?: () => void;
    alerts?: React.ReactNode;
};

export type EditNavigationMap = {
    [id: string]: IEditNavigationOption;
};
