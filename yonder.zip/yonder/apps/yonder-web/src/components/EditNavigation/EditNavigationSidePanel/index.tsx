import React from "react";
import styled from "styled-components";
import { ListingSectionProgresses, getSectionProgressKey } from "@yonder/db";

import { EditNavigationMap } from "./IEditNavigationOption";
import EditNavigationOption from "./EditNavigationOption";
import { color } from "../../../variables";
import { SelectInput, StyledForm } from "../..";

type Props = {
    options: EditNavigationMap;
    sectionProgress: ListingSectionProgresses;
    activeTab: string;
    label?: string;
    onOptionClick: (slug: string) => void;
};

export class EditNavigationSidePanel extends React.Component<Props> {
    options = Object.entries(this.props.options);

    render() {
        const { activeTab, onOptionClick, label, sectionProgress } = this.props;

        const mobileOptions = this.options.map(([key, value], i) => {
            return {
                value: key,
                label: value.label
            };
        });

        const desktopOptions = this.options.map(([key, value], i) => {
            const progressKey: string = getSectionProgressKey(value.label);
            return (
                <EditNavigationOption
                    {...value}
                    active={activeTab === key}
                    key={i}
                    onClick={() => onOptionClick(key)}
                    progress={sectionProgress[progressKey]}
                />
            );
        });

        return (
            <StyledEditNavigationSidePanel>
                {label && <label>{label}</label>}
                <StyledForm className="mobile-nav">
                    <SelectInput
                        name="itineraryItemTime"
                        onChange={(ev) => {
                            ev.preventDefault();
                            onOptionClick(ev.target.value);
                        }}
                        value={activeTab}
                        options={mobileOptions}
                    />
                </StyledForm>
                <div className="desktop-nav">
                    {desktopOptions}
                    <div className="vr" />
                </div>
            </StyledEditNavigationSidePanel>
        );
    }
}

const StyledEditNavigationSidePanel = styled.div`
    display: block;
    width: 100%;
    height: inherit;
    padding: 0.5rem 2rem;

    label {
        display: block;
        color: ${color.metal};
        font-size: 0.875rem;
        font-weight: 300;
        margin-bottom: 1rem;
    }

    .mobile-nav {
        display: inherit !important;
    }
    .desktop-nav {
        display: none !important;
    }

    @media only screen and (min-width: 30rem) {
        max-width: 30rem;
        margin: 0 auto;
    }

    @media only screen and (min-width: 60rem) {
        display: block;
        background-color: transparent;
        flex-basis: 20rem;
        height: inherit;
        overflow-x: hidden;
        overflow-y: auto;
        padding-left: 2.25rem;
        padding-right: 1.5rem;
        padding-top: 2.75rem;
        padding-bottom: 0;
        max-width: none;

        .message {
            padding: 2rem 1.5rem;
        }

        .mobile-nav {
            display: none !important;
        }
        .desktop-nav {
            display: inherit !important;

            div.vr {
                display: block;
                position: fixed;
                width: 1px;
                height: 100%;
                z-index: 9001;
                top: 0;
                left: 16.75rem;
                background-color: #ccc;
            }
        }
    }
`;
