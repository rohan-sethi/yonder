import React from "react";
import styled from "styled-components";
import { SectionProgress } from "@yonder/db";

import { color } from "../../../variables";
import { IEditNavigationOption } from "./IEditNavigationOption";
import Icon, { Props as IconProps } from "../../Icon";

type Props = IEditNavigationOption;

export default class EditNavigationOption extends React.Component<Props> {
    render() {
        const { label, onClick, active, progress } = this.props;

        const progressIcon = () => {
            const iconProps: IconProps = {
                type: "check-circle",
                size: "1.6875rem"
            };
            switch (progress) {
                case SectionProgress.Started:
                    return <Icon {...iconProps} color={color.wintersGray} />;

                case SectionProgress.Complete:
                    return <Icon {...iconProps} color={color.primary} />;
            }
            return "";
        };

        return (
            <StyledEditNavigationOption onClick={onClick} className={active ? "active" : ""}>
                <div className="display-name">{label}</div>
                {progressIcon()}
            </StyledEditNavigationOption>
        );
    }
}

const StyledEditNavigationOption = styled.div`
    display: block;
    position: relative;
    width: 100%;
    padding: 0.75rem 0;
    background-color: ${color.pureWhite};
    cursor: pointer;

    .display-name {
        display: block;
        color: ${color.blackInk};
        line-height: 1.5rem;
        font-weight: 400;
        transition: font-weight 0.125s linear;
    }

    .icon-container {
        display: block;
        position: absolute;
        right: 0;
        top: 50%;
        transform: translateY(-50%);
    }

    &.active {
        .display-name {
            font-weight: 700;
        }
    }

    :hover {
        .display-name {
            font-weight: 700;
        }
    }
`;
