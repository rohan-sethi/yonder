import React from "react";
import styled from "styled-components";
import { ListingSectionProgresses } from "@yonder/db";

import { EditNavigationSidePanel } from "./EditNavigationSidePanel";
import { EditNavigationView } from "./EditNavigationView";
import { IEditNavigationOption, EditNavigationMap } from "./index";

type Props = {
    currentOption: IEditNavigationOption;
    options: EditNavigationMap;
    sectionProgress: ListingSectionProgresses;
    activeTab: string;
    label?: string;
    onOptionClick: (slug: string) => void;
};

export class EditNavigationFrame extends React.Component<Props> {
    render() {
        const { currentOption, options, label, onOptionClick, activeTab, sectionProgress } = this.props;

        return (
            <StyledEditNavigationFrame>
                <EditNavigationSidePanel
                    label={label}
                    options={options}
                    activeTab={activeTab}
                    onOptionClick={onOptionClick}
                    sectionProgress={sectionProgress}
                />
                <EditNavigationView currentOption={currentOption} />
            </StyledEditNavigationFrame>
        );
    }
}

const StyledEditNavigationFrame = styled.div`
    @media only screen and (min-width: 60rem) {
        display: flex;
        flex-direction: row;
        width: 100%;
        height: inherit;
    }
`;
