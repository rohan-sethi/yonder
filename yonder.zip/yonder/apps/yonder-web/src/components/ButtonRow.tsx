import React from "react";
import styled from "styled-components";

export type ButtonAlignment = "center" | "space-between" | "block";

type Props = {
    children: React.ReactNode;
    alignment?: ButtonAlignment;
    padded?: boolean;
    topMargin?: boolean;
    bottomMargin?: boolean;
    className?: string;
};

export default (props: Props) => {
    const alignment = props.alignment || "space-between";
    const padded = props.padded ? "padded" : "";
    const topMargin = props.topMargin ? "top-margin" : "";
    const bottomMargin = props.bottomMargin ? "bottom-margin" : "";
    return (
        <StyledButtonRow
            className={`button-row ${alignment} ${padded} ${topMargin} ${bottomMargin} ${props.className || ""}`}
        >
            {props.children}
        </StyledButtonRow>
    );
};

const StyledButtonRow = styled.div`
    display: flex;
    margin: 2rem 0;

    &.padded {
        padding: 0 2rem;
    }

    &.top-margin {
        margin: 6rem 0;
    }

    &.bottom-margin {
        margin-bottom: 6rem;
    }

    &.space-between {
        justify-content: space-between;
        align-items: stretch;

        > div,
        > button {
            width: 100%;
        }

        > div {
            display: flex;
        }
    }

    &.center {
        justify-content: center;
        align-items: center;
    }

    p {
        display: flex;
    }

    > div,
    > button {
        display: inline-block;
        margin: 0 0.5rem;
        text-align: center;
        vertical-align: middle;

        &:first-child {
            margin-left: 0;
        }
        &:last-child {
            margin-right: 0;
        }
    }

    &.block {
        display: block;
        > div {
            display: flex;
            margin: 0.5rem 0;

            &:first-child {
                margin: 0;
            }
        }
    }
`;
