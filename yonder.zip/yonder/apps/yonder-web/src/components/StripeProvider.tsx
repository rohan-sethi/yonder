import React from "react";
import { StripeProvider } from "react-stripe-elements";

const stripeApiKey = process.env.REACT_APP_STRIPE_API_KEY || "null";

type Props = {
    children?: React.ReactNode;
};

export default (props: Props) => {
    return <StripeProvider apiKey={stripeApiKey}>{props.children}</StripeProvider>;
};
