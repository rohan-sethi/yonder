import React from "react";
import styled from "styled-components";
import { rgba, math } from "polished";

import { color } from "../variables";

type AvatarSize = number;
type AvatarPresense = "online" | "busy" | "away";

function avatarSize(size?: number) {
    let outSize = size ? `${size}rem` : undefined;
    return {
        fontSize: outSize ? math(`${outSize} / 2`) : "2rem",
        height: outSize || "100%",
        width: outSize || "100%"
    };
}

type ImageOrientation = "portrait" | "landscape";

function imageOrientation(orientation: ImageOrientation) {
    return {
        width: orientation === "portrait" ? "100%" : "auto",
        height: orientation === "landscape" ? "100%" : "auto"
    };
}

type Props = {
    size?: AvatarSize;
    file?: string;
    text?: string;
    title?: string;
    background?: string;
    presense?: AvatarPresense;
};

type State = {
    photoLoaded: boolean;
    orientation: ImageOrientation;
};

export class Avatar extends React.Component<Props, State> {
    photo: HTMLImageElement | null = null;
    state: State = {
        photoLoaded: false,
        orientation: "portrait"
    };

    componentDidMount() {
        const { file } = this.props;

        if (file) {
            this.photo = new Image();
            this.photo.src = file;
            this.photo.onload = () => {
                let orientation: ImageOrientation = "portrait";
                if (this.photo!.naturalWidth > this.photo!.naturalHeight) {
                    orientation = "landscape";
                }
                this.setState({ photoLoaded: true, orientation });
            };
        }
    }

    componentWillUnmount() {
        if (this.photo) {
            this.photo.onload = () => {};
        }
    }

    render() {
        const { text, title, background, size, presense } = this.props;
        const { photoLoaded, orientation } = this.state;
        return (
            <FigureAvatar
                data-initial={text ? text.substr(0, 2) : ""}
                title={title || ""}
                style={{
                    background,
                    ...avatarSize(size)
                }}
            >
                {photoLoaded && this.photo !== null && (
                    <img src={this.photo.src} alt="" style={imageOrientation(orientation)} />
                )}
                {presense && <PresenseIcon className={presense} />}
            </FigureAvatar>
        );
    }
}

const FigureAvatar = styled.figure`
    background: ${color.yonderGreen};
    border-radius: 50%;
    color: ${rgba(color.pureWhite, 0.85)};
    display: inline-block;
    vertical-align: middle;
    position: relative;
    font-weight: 300;
    line-height: 1.25;
    margin: 0;
    text-transform: uppercase;

    img {
        position: relative;
        z-index: 100;
    }

    &[data-initial]::before {
        color: currentColor;
        content: attr(data-initial);
        left: 50%;
        position: absolute;
        top: 50%;
        transform: translate(-50%, -50%);
        z-index: 10;
    }
`;

const PresenseIcon = styled.i`
    bottom: 14.64%;
    height: 50%;
    padding: 0.0675em;
    position: absolute;
    right: 14.64%;
    transform: translate(50%, 50%);
    width: 50%;
    z-index: 101;

    background: ${color.blackInk};
    box-shadow: 0 0 0 0.0675em ${color.pureWhite};
    border-radius: 50%;
    height: 0.5em;
    width: 0.5em;

    &.online {
        background: ${color.yonderGreen};
    }
    &.busy {
        background: ${color.fireBrick};
    }
    &.away {
        background: ${color.primaryDark};
    }
`;
