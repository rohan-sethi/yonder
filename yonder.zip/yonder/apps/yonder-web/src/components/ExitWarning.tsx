import React from "react";

export class ExitWarning extends React.Component {
    render() {
        return (
            <div>
                <h2>Are you sure you want to leave?</h2>
                <p>You have a few more steps before your submission is complete.</p>
            </div>
        );
    }
}
