import React from "react";
import { inject, observer } from "mobx-react";

import { IContentModalStore, IFirebaseStore } from "../store";
import { FirebaseProvider } from "../components";
import styled from "styled-components";
import { color, veryThin } from "../variables";

const INITIAL_STATE = {
    error: null as { message?: string } | null
};

type Props = IContentModalStore & IFirebaseStore;

@inject("contentModalState", "firebaseState")
@observer
export class ProviderIconSignIn extends React.Component<Props> {
    state = INITIAL_STATE;

    onProviderSignIn = async (provider: FirebaseProvider) => {
        const { firebase } = this.props.firebaseState!;
        const { closeCallback } = this.props.contentModalState!;

        try {
            let res = await firebase.doProviderSignIn(provider);
            const user = res.user;
            console.log("user: ", user);

            closeCallback();
        } catch (error) {
            console.log(error);
            this.setState({ error });
        }
    };

    render() {
        return (
            <ProviderIcons className="provider-icons">
                <img
                    src="/img/google.svg"
                    alt="google icon"
                    onClick={() => this.onProviderSignIn(FirebaseProvider.Google)}
                />
                <img
                    src="/img/facebook.svg"
                    alt="facebook icon"
                    onClick={() => this.onProviderSignIn(FirebaseProvider.Facebook)}
                />
            </ProviderIcons>
        );
    }
}

const ProviderIcons = styled.div`
    display: flex;
    flex-direction: row;
    justify-content: center;

    > img {
        width: 3.5rem;
        height: 3.5rem;
        cursor: pointer;
        border-radius: 50%;
        overflow: hidden;
        margin: 0 0.75rem;

        border: ${veryThin} solid ${color.metal};
        box-shadow: 0 0 0 0 transparent;
        transition: border-color 0.25s linear, box-shadow 0.25s linear;

        &:hover {
            border-color: ${color.primaryDark};
            box-shadow: 0 0 0.25rem 0 ${color.primaryDark};
        }
    }
`;
