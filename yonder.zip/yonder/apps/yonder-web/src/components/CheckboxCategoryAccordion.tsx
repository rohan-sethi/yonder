import React from "react";
import { StyledAccordion } from "./Form";

type Props = {
    header: string;
    hideHeader?: boolean;
    showAccordionLabel?: boolean;
    accordionExpandLabel?: string;
    accordionCollapseLabel?: string;
    labelAndButtonSplit?: boolean;
    children: React.ReactNode;
};

type State = {
    displayDetails: boolean;
};

export class CheckboxCategoryAccordion extends React.Component<Props, State> {
    state: State = {
        displayDetails: false
    };

    onChangeDisplay = (ev: React.MouseEvent) => {
        ev.preventDefault();

        const { displayDetails } = this.state;
        this.setState({
            displayDetails: !displayDetails
        });
    };

    render() {
        const {
            header,
            hideHeader,
            showAccordionLabel,
            accordionExpandLabel,
            accordionCollapseLabel,
            labelAndButtonSplit,
            children
        } = this.props;
        const { displayDetails } = this.state;
        const expandLabel = accordionExpandLabel || "Expand to enter response";
        const collapseLabel = accordionCollapseLabel || "Collapse";

        const accordionLabel = !!displayDetails ? collapseLabel : expandLabel;
        const accordionClass = !!displayDetails ? "minus" : "plus";

        const htmlForAndId = header
            .toLowerCase()
            .split(" ")
            .join("-");

        return (
            <StyledAccordion>
                <div
                    className={`header ${labelAndButtonSplit ? "split-label-button" : ""}`}
                    onClick={(ev: React.MouseEvent) => this.onChangeDisplay(ev)}
                >
                    {!hideHeader && <p>{header}</p>}

                    <div className="button-toggle">
                        <label className="accordion-label" htmlFor={htmlForAndId}>
                            {!!showAccordionLabel && accordionLabel}
                        </label>
                        <button id={htmlForAndId}>
                            <div className={accordionClass} />
                        </button>
                    </div>
                </div>

                {!!displayDetails && children}
                <hr className="thin-hr" />
            </StyledAccordion>
        );
    }
}
