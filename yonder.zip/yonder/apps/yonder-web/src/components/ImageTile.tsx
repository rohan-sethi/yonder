import React from "react";
import styled from "styled-components";
import { rgba } from "polished";

import { ImageBackground, RouterLink } from "./index";
import { Props as IImageBackground } from "./ImageBackground";
import { color } from "../variables";

export type Props = {
    image?: IImageBackground;
    activityCost?: number;
    color?: string;
    label?: string;
    subtitle?: string;
};

export default (props: Props) => {
    return (
        <StyledImageTile>
            <RouterLink>
                <ImageBackground {...props.image || { alt: "" }} />
                <div className="tile-container">
                    {props.label && (
                        <p>
                            <span>{props.label}</span>
                        </p>
                    )}
                    {props.subtitle && <p>{props.subtitle}</p>}
                    {props.activityCost && (
                        <p>
                            <span>${props.activityCost}</span> per person
                        </p>
                    )}
                </div>
            </RouterLink>
        </StyledImageTile>
    );
};

const fadeColor = "#233762";

const StyledImageTile = styled.div`
    display: inline-block;
    position: relative;
    vertical-align: bottom;
    height: 17rem;
    width: 12rem;
    margin: 0 1rem;
    box-shadow: none;
    transition: box-shadow 0.125s linear;

    &:first-child {
        margin-left: 0;
    }
    &:last-child {
        margin-right: 0;
    }

    :hover {
        box-shadow: 0.25rem 0.25rem 0 rgba(0, 0, 0, 0.125);
    }

    .router-link {
        .tile-container {
            position: absolute;
            display: block;
            color: ${color.pureWhite};
            width: 100%;
            bottom: 0;
            left: 0;
            padding: 1rem;
            padding-top: 1.5rem;
            text-align: right;
            background: linear-gradient(
                0deg,
                ${rgba(fadeColor, 0.25)} 0%,
                ${rgba(fadeColor, 0.25)} 80%,
                ${rgba(fadeColor, 0)} 100%
            );

            p {
                font-size: 1rem;
                line-height: 1.5;

                span {
                    font-size: 1rem;
                }
            }
        }

        .image-background {
            width: 100%;
            height: 100%;
        }
    }
`;
