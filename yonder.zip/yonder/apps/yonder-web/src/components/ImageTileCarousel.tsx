import React from "react";
import styled from "styled-components";

import { Section, ImageTile, ArrowButton } from "./index";
import { Props as IImageTile } from "./ImageTile";
import { color } from "../variables";

type Props = {
    title?: string;
    tiles: IImageTile[];
};

type State = {
    carouselOffset: number;
};

export default class ImageTileCarousel extends React.Component<Props, State> {
    range: number = 5;
    max: number = this.props.tiles.length - this.range;

    state: State = {
        carouselOffset: 0
    };

    onLeftArrow = () => {
        if (this.state.carouselOffset > 0) {
            let carouselOffset = this.state.carouselOffset - 1;
            this.setState({
                carouselOffset
            });
        }
    };

    onRightArrow = () => {
        if (this.state.carouselOffset < this.max) {
            let carouselOffset = this.state.carouselOffset + 1;
            this.setState({
                carouselOffset
            });
        }
    };

    render() {
        let rangeEnd = this.state.carouselOffset + this.range;
        let tiles = this.props.tiles.map((tile, i) => {
            let inRange = i >= this.state.carouselOffset && i < rangeEnd;
            return inRange ? <ImageTile {...tile} key={i} /> : undefined;
        });

        let buttonSettings = {
            color: "#616161",
            outlineColor: "#a4a4a4",
            hoverColor: "rgba(0, 0, 0, 0.1)"
        };

        return (
            <Section backgroundColor={color.pureWhite}>
                {this.props.title && <h3>{this.props.title}</h3>}
                <StyledImageTileCarousel>
                    <div className="arrow-container">
                        {this.state.carouselOffset > 0 && (
                            <div className="left-arrow">
                                <ArrowButton {...buttonSettings} type="back" onClick={this.onLeftArrow} />
                            </div>
                        )}
                        {this.state.carouselOffset < this.max && (
                            <div className="right-arrow">
                                <ArrowButton {...buttonSettings} onClick={this.onRightArrow} />
                            </div>
                        )}
                    </div>
                    <div className="carousel-container">{tiles}</div>
                </StyledImageTileCarousel>
            </Section>
        );
    }
}

const StyledImageTileCarousel = styled.div`
    display: block;
    position: relative;
    width: 100%;
    height: 100%;

    .carousel-container {
        display: table;
        width: calc(100% - 8rem);
        height: 100%;
        margin-top: 2rem;
        padding-bottom: 1rem;
        padding-right: 1rem;
        margin-bottom: -1rem;
        margin-right: -1rem;
        white-space: nowrap;
        overflow: hidden;
    }

    .arrow-container {
        display: block;
        position: relative;
        width: 100%;
        height: 4rem;
        margin-top: -4.25rem;

        .left-arrow {
            display: block;
            position: absolute;
            top: 25%;
            right: 3rem;
        }
        .right-arrow {
            display: block;
            position: absolute;
            top: 25%;
            right: 0;
        }
    }
`;
