import React from "react";
import styled, { css } from "styled-components";

import { Container } from "./index";
import { ScreenSize } from "./Grid";

type FontSize = "md" | "lg";

type Props = {
    children?: React.ReactNode;
    backgroundColor?: string;
    noPadding?: boolean;
    fontSize?: FontSize;
    containerSize?: ScreenSize;

    content?: {
        title?: string;
        subtitle?: string;
    };
};

export default (props: Props) => {
    return (
        <StyledSection
            className={`section ${props.noPadding ? "padding-none" : ""}`}
            style={props.backgroundColor ? { backgroundColor: props.backgroundColor } : {}}
            hasContent={!!props.content}
        >
            <Container size={props.containerSize || "md"}>
                {props.content ? (
                    <>
                        {props.content.title && (
                            <h2 className={`title ${props.fontSize || "md"}`}>{props.content.title}</h2>
                        )}
                        {props.content.subtitle && <p>{props.content.subtitle}</p>}
                    </>
                ) : (
                    props.children
                )}
            </Container>
        </StyledSection>
    );
};

type StyledSectionProps = {
    hasContent: boolean;
};

const StyledSection = styled.section<StyledSectionProps>`
    padding: 1rem 0;
    text-align: left;
    z-index: 5;

    @media only screen and (min-width: 40rem) {
        padding: 2rem 0;
    }
    @media only screen and (min-width: 60rem) {
        padding: 3rem 0;
    }

    &.padding-none {
        padding: 0;
    }

    ${(props: StyledSectionProps) =>
        props.hasContent &&
        css`
            .title {
                font-size: 1.25rem;
                max-width: 20rem;
                margin: 0 auto;
            }

            .title.lg {
                font-size: 2rem;
            }

            p {
                margin-top: 1rem;
                font-size: 1rem;
                line-height: 2;
                margin: 0 auto;
                white-space: pre-wrap;

                strong {
                    font-size: 1.5rem;
                    line-height: 1.5;
                    font-weight: 500;
                }
            }

            .title + p {
                margin-top: 2rem;
            }

            h3 {
                text-transform: uppercase;
                margin-bottom: 1rem;
            }

            @media only screen and (min-width: 40rem) {
                .title {
                    font-size: 1.5rem;
                    max-width: 25rem;
                }
                .title.lg {
                    font-size: 2.15rem;
                }
                p {
                    font-size: 1.125rem;

                    span {
                        font-size: 1.625rem;
                    }
                }
            }
            @media only screen and (min-width: 60rem) {
                .title {
                    font-size: 1.75rem;
                    max-width: none;
                }
                .title.lg {
                    font-size: 2.85rem;
                }
                p {
                    font-size: 1.25rem;

                    span {
                        font-size: 1.75rem;
                    }
                }
            }
        `}
`;
