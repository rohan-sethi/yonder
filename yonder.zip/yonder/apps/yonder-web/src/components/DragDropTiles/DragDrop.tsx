import React from "react";
import { DragDropContext, DropResult } from "react-beautiful-dnd";
import { reorderTiles } from "./Reorder";
import { DragDropTileMap, DragDropOptionsMap } from "./DragDropTypes";
import { DragDropList } from "./DragDropList";

type Props = {
    tiles: DragDropTileMap;
    options: DragDropOptionsMap;
    onReorder: (tiles: DragDropTileMap) => void;
};
type State = {
    tiles: DragDropTileMap;
};

export class DragDrop extends React.Component<Props, State> {
    state: State = {
        tiles: this.props.tiles
    };

    componentDidUpdate(prevProps: Props) {
        if (this.props.tiles !== prevProps.tiles) {
            this.setState({
                tiles: this.props.tiles
            });
        }
    }

    onDragEnd = (result: DropResult) => {
        if (!result.destination) return;

        let tiles = reorderTiles(this.state.tiles, result.source, result.destination);

        this.props.onReorder(tiles);
        this.setState({
            tiles
        });
    };

    render() {
        const lists = Object.entries(this.state.tiles).map(([key, value]) => {
            const { options } = this.props;
            const descriptor = options[key].descriptor;
            const category = options[key].category;

            const list = (
                <DragDropList
                    key={key}
                    id={key}
                    type="CARD"
                    tiles={value}
                    limit={this.props.options[key].limit}
                    internalScroll
                />
            );
            return (
                <div
                    className={`drop-list-category ${category && category.toLocaleLowerCase().replace(" ", "-")}`}
                    key={key}
                >
                    {options && descriptor && <>{descriptor}</>}
                    {list}
                </div>
            );
        });
        return <DragDropContext onDragEnd={this.onDragEnd}>{lists}</DragDropContext>;
    }
}
