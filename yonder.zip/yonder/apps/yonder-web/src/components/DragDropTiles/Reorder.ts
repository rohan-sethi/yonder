import { DraggableLocation } from "react-beautiful-dnd";
import { DragDropTileMap } from "./DragDropTypes";

export function reorder<T>(list: T[], startIndex: number, endIndex: number): T[] {
    const result = Array.from(list);
    const [removed] = result.splice(startIndex, 1);
    result.splice(endIndex, 0, removed);

    return result;
}

export const reorderTiles = (tiles: DragDropTileMap, source: DraggableLocation, destination: DraggableLocation) => {
    const current = tiles[source.droppableId];
    const next = tiles[destination.droppableId];
    const target = current[source.index];

    if (source.droppableId === destination.droppableId) {
        const reordered = reorder(current, source.index, destination.index);
        return {
            ...tiles,
            [source.droppableId]: reordered
        };
    }

    current.splice(source.index, 1);

    next.splice(destination.index, 0, target);

    return {
        ...tiles,
        [source.droppableId]: current,
        [destination.droppableId]: next
    };
};
