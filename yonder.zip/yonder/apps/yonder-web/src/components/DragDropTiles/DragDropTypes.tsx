import React from "react";

export type DragDropTile = {
    id: string;
    component: React.ReactNode;
};

export type DragDropTileMap = { [key: string]: DragDropTile[] };

export type DragDropOptionsMap = {
    [key: string]: {
        descriptor?: React.ReactNode;
        category?: string;
        limit: number;
    };
};
