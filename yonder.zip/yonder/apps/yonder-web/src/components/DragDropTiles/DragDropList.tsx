import React from "react";

import {
    Droppable,
    Draggable,
    DroppableProvided,
    DroppableStateSnapshot,
    DraggableProvided
} from "react-beautiful-dnd";
import { DragDropTile } from "./DragDropTypes";

interface Props {
    tiles: DragDropTile[];
    id: string;
    type: string;
    internalScroll?: boolean;
    isCombineEnabled?: boolean;
    limit: number;
}

export const DragDropList = (props: Props) => {
    const items = props.tiles.map((tile: DragDropTile, index: number) => (
        <Draggable key={tile.id} draggableId={tile.id} index={index} disableInteractiveElementBlocking={false}>
            {(provided: DraggableProvided) => (
                <div {...provided.dragHandleProps} {...provided.draggableProps} ref={provided.innerRef}>
                    {tile.component}
                </div>
            )}
        </Draggable>
    ));
    return (
        <Droppable
            droppableId={props.id}
            type={props.type}
            direction="horizontal"
            isDropDisabled={props.limit > 0 && props.tiles.length >= props.limit}
            isCombineEnabled={false}
        >
            {(provided: DroppableProvided, snapshot: DroppableStateSnapshot) => (
                <div {...provided.droppableProps}>
                    <div
                        className={`drop-list ${snapshot.isDraggingOver ? "is-dragging" : ""}`}
                        ref={provided.innerRef}
                    >
                        {items}
                        <div style={{ display: "none !important" }}>{provided.placeholder}</div>
                    </div>
                </div>
            )}
        </Droppable>
    );
};
