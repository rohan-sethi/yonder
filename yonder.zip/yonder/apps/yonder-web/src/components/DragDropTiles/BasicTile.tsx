import React from "react";
import styled from "styled-components";

type Props = {
    children?: React.ReactNode;
    color?: string;
};

export const BasicTile = (props: Props) => {
    return <StyledBasicTile style={props.color ? { backgroundColor: props.color } : {}} />;
};

const StyledBasicTile = styled.div`
    display: block;
    background-color: #ccc;
    margin: 0.5rem;
    padding: 2rem;
    width: 2rem;
    height: 2rem;
`;
