import React from "react";

import { BasicTile } from "./BasicTile";
import { DragDrop } from "./DragDrop";
import { DragDropTileMap } from "./DragDropTypes";
import styled from "styled-components";

export const DragDropTest = () => {
    const tiles = {
        a: [
            {
                id: "blue",
                component: <BasicTile color="#1188ff" />
            },
            {
                id: "red",
                component: <BasicTile color="#ff3333" />
            }
        ],
        b: [
            {
                id: "pink",
                component: <BasicTile color="#ffaabb" />
            },
            {
                id: "yellow",
                component: <BasicTile color="#ffee11" />
            }
        ],
        c: [
            {
                id: "green",
                component: <BasicTile color="#55ee55" />
            }
        ]
    };
    const options = {
        a: {
            category: "",
            limit: 0
        },
        b: {
            category: "",
            limit: 0
        },
        c: {
            category: "",
            limit: 0
        }
    };
    return (
        <StyledSandbox>
            <DragDrop
                tiles={tiles}
                options={options}
                onReorder={(tiles: DragDropTileMap) => {
                    console.log("Reordered!");
                }}
            />
        </StyledSandbox>
    );
};

const StyledSandbox = styled.div`
    background-color: #eee;
    padding: 2rem;

    .drop-list {
        display: flex;
        min-height: 5.25rem;
        border: 0.125rem solid transparent;
        &.is-dragging {
            border-color: #cc33ee;
        }
    }
`;
