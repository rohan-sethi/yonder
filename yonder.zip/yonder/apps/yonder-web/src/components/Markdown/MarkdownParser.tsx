import React from "react";
import Showdown from "showdown";

const MarkdownParser: Showdown.Converter = new Showdown.Converter({
    tables: true,
    simplifiedAutoLink: true,
    strikethrough: true,
    tasklists: true
});

// This is mainly for the MarkdownEditor. Must be promise-based
export const markdowntoHtml = async (markdown: string) => await MarkdownParser.makeHtml(markdown);

export const markdowntoJsx = (markdown: string) => {
    // Hate having to use dangerouslySetInnerHTML here, but this use should be fine since it's parsed from harmless markdown.
    return <div dangerouslySetInnerHTML={{ __html: MarkdownParser.makeHtml(markdown) }} />;
};
