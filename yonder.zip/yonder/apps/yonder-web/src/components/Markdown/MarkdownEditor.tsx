import React from "react";
import styled from "styled-components";
import ReactMde, { commands } from "react-mde";
import "react-mde/lib/styles/css/react-mde-all.css";

import { markdowntoHtml } from "./MarkdownParser";
import { color } from "../../variables";

type MarkdownEditorTab = "write" | "preview";

type Props = {
    value: string;
    onChange: (value: string) => void;
};
type State = {
    tab: MarkdownEditorTab;
};

export default class MarkdownEditor extends React.Component<Props, State> {
    state: State = {
        tab: "write"
    };

    handleTabChange = (tab: MarkdownEditorTab) => {
        this.setState({ tab });
    };

    render() {
        return (
            <StyledMarkdownEditor>
                <ReactMde
                    onChange={this.props.onChange}
                    onTabChange={this.handleTabChange}
                    value={this.props.value}
                    generateMarkdownPreview={markdowntoHtml}
                    selectedTab={this.state.tab}
                    commands={listCommands}
                />
            </StyledMarkdownEditor>
        );
    }
}

const StyledMarkdownEditor = styled.div`
    button {
        font-size: 1rem;
        line-height: 1;
    }

    textarea {
        margin: 0;
    }

    .mde-preview {
        background: ${color.pureWhite};
    }
`;

const listCommands = [
    {
        commands: [
            commands.boldCommand,
            commands.italicCommand
            //commands.strikeThroughCommand
        ]
    },
    {
        commands: [
            commands.headerCommand,
            //commands.linkCommand,
            commands.quoteCommand
            //commands.codeCommand,
            //commands.imageCommand
        ]
    },
    {
        commands: [
            commands.unorderedListCommand,
            commands.orderedListCommand
            //commands.checkedListCommand
        ]
    }
];
