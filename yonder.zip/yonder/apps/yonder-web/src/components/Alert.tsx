import React from "react";
import styled from "styled-components";
import { color } from "../variables";
import { Icon, MouseClickEvent } from ".";

export type Props = {
    title?: string;
    body: string;
};
type State = {
    isExpanded: boolean;
};

export class Alert extends React.Component<Props, State> {
    state: State = {
        isExpanded: false
    };

    toggleExpanded = (ev: MouseClickEvent) => {
        ev.preventDefault();

        this.setState({
            isExpanded: !this.state.isExpanded
        });
    };

    render() {
        const { title, body } = this.props;
        const { isExpanded } = this.state;
        return (
            <StyledAlert className="alert">
                <div className="alert-wrapper">
                    <Icon type="alert" color={color.charcoal} />
                    <div className="alert-text">
                        <p className="desktop-layout">
                            {title && (
                                <span>
                                    {title}
                                    {"  "}
                                </span>
                            )}
                            {body}
                        </p>
                        <p className="mobile-layout">
                            <span>{title}</span>
                            <button onClick={this.toggleExpanded}>{isExpanded ? "Hide" : "View"} details</button>
                        </p>
                    </div>
                </div>
                {isExpanded && (
                    <div className="mobile-body mobile-layout">
                        <p>{body}</p>
                    </div>
                )}
            </StyledAlert>
        );
    }
}

const StyledAlert = styled.div`
    display: block;
    position: relative;
    width: 100%;
    height: auto;
    padding: 1rem 1.5rem;
    background-color: ${color.pureWhite};
    box-shadow: 0px 0.0625rem 0.25rem 0px rgba(0, 0, 0, 0.15);

    .alert-wrapper {
        display: block;
        position: relative;
        height: auto;

        .icon-container {
            display: block;
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
        }

        .alert-text {
            display: inline-block;
            vertical-align: middle;
            width: auto;
            margin-left: 3rem;
        }
    }

    p {
        display: block;
        width: inherit;
        font-size: 0.875rem;
        line-height: 2;
        white-space: pre-wrap;

        span {
            font-weight: 700;
        }

        button {
            display: block;
            font-weight: 600;
            color: ${color.primary};
            margin: 0;
            padding: 0;
            line-height: 2;
            transition: color 0.125s linear;

            &:hover {
                color: ${color.primaryDark};
            }
        }
    }

    .mobile-body {
        margin-top: 1rem;
    }

    .mobile-layout {
        display: inherit !important;
    }
    .desktop-layout {
        display: none !important;
    }

    @media only screen and (min-width: 60rem) {
        padding: 1rem 2.5rem;

        .alert-wrapper {
            .alert-text {
                margin-left: 4rem;
            }
        }
        .mobile-layout {
            display: none !important;
        }
        .desktop-layout {
            display: inherit !important;
        }
    }
`;
