import React from "react";
import styled from "styled-components";

import { Icon } from "./index";
import { fontFamily } from "../variables";

export type Props = {
    name: string;
    rating: number;
    added: string;
    comment: string;
};

export default (props: Props) => {
    let rating = props.rating.toFixed(1);
    return (
        <StyledGuestbookEntry>
            <div className="tile-container">
                {props.rating && (
                    <div className="rating-container">
                        <span className="rating">
                            {rating} <Icon type="star" size="1.625rem" color="#ee7d23" />
                        </span>
                        <h3>{props.added}</h3>
                    </div>
                )}
                {props.comment && <p className="comment">{props.comment}</p>}
                {props.name && <p className="signature">{props.name}</p>}
            </div>
        </StyledGuestbookEntry>
    );
};

const StyledGuestbookEntry = styled.div`
    display: block;
    position: relative;
    width: 100%;
    height: 100%;
    padding: 0 1rem;

    .tile-container {
        position: relative;
        display: block;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        padding: 0;
        text-align: left;

        p {
            font-size: 1rem;
            line-height: 1.5;

            span {
                font-size: 1rem;
            }
        }

        .rating-container {
            user-select: none;

            .rating {
                font-size: 1.125rem;
                font-weight: 300;

                svg {
                    display: inline-block;
                    vertical-align: middle;
                    margin-top: -0.375rem;
                }
            }

            h3 {
                display: inline-block;
                font-size: 1.125rem;
                font-weight: 300;
                margin-left: 0.75rem;
                text-transform: none;
            }
        }

        .comment {
            font-size: 1rem;
            margin-bottom: 4.5rem;
        }

        .signature {
            margin-top: -3rem;
            float: right;
            font-family: ${fontFamily.script};
            font-size: 1.75rem;
        }

        :after {
            display: block;
            margin-left: -0.125rem;
            padding-right: 0.125rem;
            background-color: black;
        }
    }

    @media only screen and (min-width: 40rem) {
        width: 75%;
        max-width: calc(100% - 1rem);
        margin: 0 auto;
        padding: 0;
    }

    @media only screen and (min-width: 60rem) {
        width: 65%;
    }

    @media only screen and (min-width: 80rem) {
        display: table-cell;
        width: 33%;
        margin: 0;
        padding: 0 2rem;
        vertical-align: top;
        max-width: none;

        &:first-child {
            padding-left: 0;
            border-right: 1px solid #ebebeb;
        }

        &:last-child {
            padding-right: 0;
            border-left: 1px solid #ebebeb;
        }
    }
`;
