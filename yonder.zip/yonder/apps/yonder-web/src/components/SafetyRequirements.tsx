import React from "react";
import styled from "styled-components";
import { InformationLink, FormChangeEvent, InputCheckbox } from ".";
import { color } from "../variables";

type Props = {
    checked: boolean;
    onChange: FormChangeEvent;
};

export const SafetyRequirements = (props: Props) => {
    const { checked, onChange } = props;
    return (
        <StyledSafetyRequirements>
            <p>To keep your guests safe, all stays on Yonder are required to have safety equipment.</p>
            <InformationLink
                label="Learn more about safety requirements"
                to="https://help.yonder.com/hc/en-us/articles/360035700833-Safety-Equipment-Requirements"
                target="_blank"
                external
            />
            <InputCheckbox
                name="safetyRequirements"
                groupName="safetyRequirementCheckbox"
                label="I confirm that the following items are in place and in working condition."
                onChange={onChange}
                checked={checked}
            />
            <ul>
                <li>Smoke Alarm </li>
                <li>Carbon Monoxide Alarm</li>
                <li>Fire Extinguisher</li>
                <li>First Aid Kit</li>
            </ul>
        </StyledSafetyRequirements>
    );
};

const StyledSafetyRequirements = styled.div`
    p:first-child {
        margin-bottom: 0rem;
    }

    .input-checkbox {
        margin-left: 2rem;

        span.padded-label {
            color: ${color.blackInk};
            font-size: 1.125rem;
            font-weight: 300;
        }
    }

    ul {
        margin-left: 2rem;
    }
`;
