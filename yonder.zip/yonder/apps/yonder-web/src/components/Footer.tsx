import React from "react";
import styled from "styled-components";
import { Icon, ExternalLink } from ".";
import { color } from "../variables";

export class Footer extends React.Component {
    date: Date = new Date();
    render() {
        return (
            <StyledFooter>
                <img className="logo-minimal" src="/img/yonder-logo.svg" alt="yonder" />
                <p className="copyright">© {this.date.getFullYear()} Yonder. All rights reserved.</p>
                <ExternalLink
                    to="https://help.yonder.com/hc/en-us/articles/360034314273-Terms-of-Service"
                    target="_blank"
                    rel="noopener noreferrer"
                    label="Terms of Use"
                />
                <ExternalLink
                    to="https://help.yonder.com/hc/en-us/articles/360033818214-Privacy-Policy"
                    target="_blank"
                    rel="noopener noreferrer"
                    label="Privacy Policy"
                />

                <div className="social-icons">
                    <a href="https://www.instagram.com/findyouryonder">
                        <Icon type="instagram" size="1.125rem" color={color.blackInk} hoverColor={color.charcoal} />
                    </a>
                    <a href="https://www.facebook.com/findyouryonder">
                        <Icon type="facebook" size="1rem" color={color.blackInk} hoverColor={color.charcoal} />
                    </a>
                </div>
            </StyledFooter>
        );
    }
}

const StyledFooter = styled.footer`
    display: flex;
    flex-direction: column;
    padding: 3.5rem 3rem;
    border-top: 1px solid ${color.gray};
    background: ${color.coconut};

    p.copyright {
        align-self: center;
        font-size: 0.75rem;
        padding: 0;
        line-height: 2;
    }

    img {
        margin-bottom: 2rem;
        padding: 0;
        align-self: center;

        &.logo-minimal {
            display: block;
            width: auto;
            height: auto;
            max-width: 2.25rem;
            max-height: 2.25rem;
        }
    }

    .social-icons {
        display: flex;
        flex-direction: row;
        align-self: center;
        margin: 0 auto;
        padding: 2rem 0;

        a {
            width: 1.75rem;
            height: 1.75rem;
            margin: 0 0.5rem;
            display: flex;
            justify-content: center;

            .icon-container {
                align-self: center;
            }
        }
    }

    .external-link {
        align-self: center;
        color: ${color.metal} !important;
        border: none !important;
        padding: 0 0.25rem;
        margin: 0;
        font-size: 0.75rem;
        text-decoration-line: underline;
        vertical-align: baseline;
        transition: color 0.125s linear !important;

        &:hover {
            color: ${color.wintersGray} !important;
        }
    }

    @media only screen and (min-width: 40rem) {
        flex-direction: row;

        p.copyright,
        .external-link {
            padding: 1rem 0;
        }

        .social-icons {
            padding: 0;
            margin-right: 0;
        }

        .external-link {
            margin: 0 0.25rem;
        }

        img {
            margin-bottom: 0;
            margin-right: 2rem;
        }
    }
`;
