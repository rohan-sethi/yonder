import React from "react";
import styled from "styled-components";

import { IVideoElement } from "../interfaces";

export type Props = IVideoElement;

export default (props: Props) => {
    const videoTag: IVideoElement = {
        width: 640,
        height: 360,
        controls: false,
        loop: true,
        preLoad: "auto",
        autoPlay: true
    };
    return (
        <StyledVideoBackground className="image-container">
            <video {...videoTag}>
                <source src={props.src} type="video/mp4" />
                Your browser does not support the video tag.
            </video>
        </StyledVideoBackground>
    );
};

const StyledVideoBackground = styled.div`
    position: absolute;
    display: block;
    width: 100%;
    height: 100%;

    video {
        position: absolute;
        display: block;
        width: auto;
        height: 110%;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    @media only screen and (min-width: 40rem) {
        video {
            width: 110%;
            height: auto;
        }
    }

    @media only screen and (min-width: 60rem) {
        video {
            width: 100%;
            height: auto;
        }
    }
`;
