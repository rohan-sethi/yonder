import React from "react";
import styled from "styled-components";
import { InboxSidePanel } from "./InboxSidePanel";
import { InboxView } from "./InboxView";
import { Props as IInboxConversation } from "./InboxSidePanel/InboxConversation";

type Props = {
    conversations?: IInboxConversation[];
    currentConversation?: string;
    onConversationClick: (index: number) => void;
};

export class InboxFrame extends React.Component<Props> {
    render() {
        const { conversations, onConversationClick, currentConversation } = this.props;

        return (
            <StyledInboxFrame>
                <InboxSidePanel conversations={conversations} onConversationClick={onConversationClick} />
                <InboxView currentConversation={currentConversation} />
            </StyledInboxFrame>
        );
    }
}

const StyledInboxFrame = styled.div`
    display: block;
    width: 100%;
    height: inherit;
`;
