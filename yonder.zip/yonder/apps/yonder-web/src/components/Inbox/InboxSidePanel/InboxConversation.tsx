import React from "react";
import styled from "styled-components";

import { getDateString } from "../../../functions";
import { color } from "../../../variables";

export type Props = {
    displayName: string;
    lastMessage: string;
    lastReceived: Date;
    unread: boolean;
    onClick: () => void;
};

export default class InboxConversation extends React.Component<Props> {
    render() {
        const { displayName, lastMessage, lastReceived, unread, onClick } = this.props;
        const className = `conversation-container ${unread ? "unread" : ""}`;

        return (
            <StyledInboxConversation onClick={onClick}>
                <div className={className}>
                    <div className="display-name">{displayName}</div>
                    <div className="last-received">{getDateString(lastReceived)}</div>
                    <div className="last-message">{lastMessage}</div>
                </div>
                {unread ? <div className="marker unread" /> : <div className="marker read" />}
            </StyledInboxConversation>
        );
    }
}

const StyledInboxConversation = styled.div`
    display: block;
    position: relative;
    padding: 2rem 1.5rem;
    background-color: ${color.pureWhite};
    border-bottom: 0.0625rem solid #eee;
    cursor: pointer;

    .conversation-container {
        display: block;
        position: relative;

        .display-name,
        .last-received,
        .last-message {
            display: block;
            line-height: 1.5rem;
        }

        .display-name {
            font-weight: 400;
        }

        .last-received {
            position: absolute;
            right: 0;
            top: 0;
            font-size: 0.875rem;
            font-weight: 300;
            color: #444;
        }

        .last-message {
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            font-weight: 300;
            width: 75%;
            color: #444;
        }

        &.unread {
            .display-name {
                font-weight: 500;
            }
        }
    }

    .marker {
        display: block;
        position: absolute;
        left: 0;
        top: 0;
        height: 100%;
        width: 0;
        transition: width 0.125s linear;

        &.unread {
            width: 0.125rem;
            background-color: ${color.primaryDark};
        }
        &.read {
            background-color: ${color.gray};
        }
    }

    :hover {
        .marker {
            &.unread {
                width: 0.5rem;
            }
            &.read {
                width: 0.125rem;
            }
        }
    }
`;
