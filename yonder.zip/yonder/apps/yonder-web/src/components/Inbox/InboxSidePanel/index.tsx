import React from "react";
import styled from "styled-components";

import InboxConversation, { Props as IInboxConversation } from "./InboxConversation";

type Props = {
    conversations?: IInboxConversation[];
    onConversationClick: (index: number) => void;
};

export class InboxSidePanel extends React.Component<Props> {
    render() {
        const { conversations, onConversationClick } = this.props;
        let convos = conversations ? (
            conversations.map((convo, i) => {
                return <InboxConversation {...convo} key={i} onClick={() => onConversationClick(i)} />;
            })
        ) : (
            <div className="message">No conversations</div>
        );

        return <StyledInboxSidePanel>{convos}</StyledInboxSidePanel>;
    }
}

const StyledInboxSidePanel = styled.div`
    display: inline-block;
    vertical-align: top;
    background-color: transparent;
    width: 33%;
    height: inherit;
    border-left: 0.0625rem solid #eee;
    border-right: 0.0625rem solid #eee;
    overflow-x: hidden;
    overflow-y: auto;

    .message {
        padding: 2rem 1.5rem;
    }
`;
