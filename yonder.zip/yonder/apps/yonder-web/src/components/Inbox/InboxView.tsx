import React from "react";
import styled from "styled-components";
import { color } from "../../variables";

type Props = {
    currentConversation?: string;
};

export class InboxView extends React.Component<Props> {
    render() {
        const { currentConversation } = this.props;
        return (
            <StyledInboxView>
                <div className="current-message">{currentConversation || "Select a message on the left..."}</div>
            </StyledInboxView>
        );
    }
}

const StyledInboxView = styled.div`
    display: inline-block;
    vertical-align: top;
    background-color: #f5f5f5;
    width: 67%;
    height: inherit;
    border-left: 0.0625rem solid ${color.pureWhite};
    border-right: 0.0625rem solid #eee;
    padding: 2rem 1.5rem;
    overflow-y: auto;

    .current-message {
        display: block;
    }
`;
