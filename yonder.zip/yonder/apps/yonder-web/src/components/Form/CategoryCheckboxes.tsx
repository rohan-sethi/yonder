import React from "react";
import { FormChangeEventFunction, InputCheckbox } from ".";
import { LabeledEnum } from "../../interfaces";

type Props = {
    categoryName: string;
    categoryEnums: any;
    collection: any[];
    onChange: FormChangeEventFunction;
    columns?: "one" | "two";
    hideCategoryName?: boolean;
};
export const CategoryCheckboxes = (props: Props) => {
    const { categoryName, categoryEnums, collection, onChange, columns, hideCategoryName } = props;

    const checkboxes = categoryEnums.map((categoryEnum: LabeledEnum, i: number) => {
        const { name, label } = categoryEnum;
        let checked: boolean = false;
        if (collection) {
            checked = props.collection.includes(name as never);
        }
        return <InputCheckbox name={name} label={label} onChange={onChange} checked={checked} key={i} />;
    });
    return (
        <div className="category-checkboxes">
            {!hideCategoryName && <p className="category-name">{categoryName}</p>}
            <div className={`checkboxes ${columns || "one"}`}>{checkboxes}</div>
        </div>
    );
};
