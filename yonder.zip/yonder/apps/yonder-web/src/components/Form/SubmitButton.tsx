import React from "react";
import { FormMouseClickEventFunction } from ".";
import { Button } from "..";

type Props = {
    label?: string;
    disabled?: boolean;
    onClick?: FormMouseClickEventFunction;
};

export const SubmitButton = (props: Props) => {
    return <Button className="submit" type="submit" label={props.label || "Submit"} disabled={props.disabled} />;
};
