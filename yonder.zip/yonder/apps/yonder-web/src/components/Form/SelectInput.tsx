import React from "react";

import { FormChangeEventFunction } from "./FormFields";
import { InputLabel } from ".";

export type SelectOption = {
    value: string;
    label: string;
};

type Props = {
    name: string;
    value?: string;
    label?: string;
    descriptor?: string | React.ReactNode;
    onChange?: FormChangeEventFunction;
    options: SelectOption[];
    required?: boolean;
};

export const SelectInput = (props: Props) => {
    const { name, onChange, options } = props;
    const optionsJsx = options.map(({ value, label }, i) => {
        return (
            <option value={value} key={i}>
                {label}
            </option>
        );
    });

    return (
        <div className="input-select">
            {props.descriptor && <p>{props.descriptor}</p>}
            {props.label && <InputLabel label={props.label} for={props.name} required={props.required} />}
            <select name={name} onChange={onChange} value={props.value || ""}>
                {optionsJsx}
            </select>
            <div className="select-arrow" />
            <div className="input-flare" />
        </div>
    );
};
