export const reLatitude: RegExp = /^(\+|-)?(?:90(?:(?:\.0{1,6})?)|(?:[0-9]|[1-8][0-9])(?:(?:\.[0-9]{1,6})?))$/;

export const reLongitude: RegExp = /^(\+|-)?(?:180(?:(?:\.0{1,6})?)|(?:[0-9]|[1-9][0-9]|1[0-7][0-9])(?:(?:\.[0-9]{1,6})?))$/;

export const reEmail: RegExp = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

export const rePassword: RegExp = /^(?=.*[a-zA-Z])(?=.*[0-9!@#$%^&*])(?=.{8,})/;

export const rePhoneNumber: RegExp = /^\s*(?:\+?(\d{1,2}))?[-. (]*(\d{3})[-. )]*(\d{3})[-. ]*(\d{4})$/;

//TODO: only supports US and CA zip codes
export const reZipCode: RegExp = /^(\d{5}([ ?-]{1}\d{4})?|[A-Z]\d[A-Z][ ?-]?\d[A-Z]\d)$/;

export const reSpecialChars: RegExp = /[!@#$%^&*():;"',<>?/\\{}[\]]+/g;

export const reNumbers: RegExp = /\d+/g;
