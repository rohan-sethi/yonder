import React from "react";
import styled from "styled-components";
import { color } from "../../variables";

export const Required = () => {
    return <StyledIsRequired> *</StyledIsRequired>;
};

const StyledIsRequired = styled.span`
    color: ${color.fireBrick};
`;
