import React from "react";
import { InputLabel } from ".";
import { Icon } from "..";
import { color } from "../../variables";

// TODO: Refactor these awful types
export type FormSubmitEvent = React.FormEvent<HTMLFormElement>;
export type FormChangeEvent = React.FormEvent<HTMLInputElement> | React.FormEvent<HTMLSelectElement> | any;
export type InputChangeEvent = React.ChangeEvent<HTMLInputElement> | React.ChangeEvent<HTMLSelectElement> | any;
export type MouseClickEvent = React.MouseEvent<HTMLInputElement | HTMLButtonElement, MouseEvent>;
export type KeyPressEvent = React.KeyboardEvent<HTMLInputElement>;

export type FormChangeEventFunction = (ev: FormChangeEvent) => void;
export type InputChangeEventFunction = (ev: InputChangeEvent) => void;
export type FormMouseClickEventFunction = (ev: MouseClickEvent) => void;

export type PInput = {
    name: string;
    onChange: FormChangeEventFunction;
    label?: string;
    descriptor?: string | React.ReactNode; // Adds a <p> instead of a label
    rightLabel?: boolean;
    placeholder?: string;
    required?: boolean;
    onKeyDown?: FormChangeEvent;
    autoFocus?: boolean;
};

type PTextualInput = {
    value?: string | number | null;
    error?: string;
};

type Props = PInput & PTextualInput;

const NUMBER_MAX = 999999999999;

export const TextInput = (props: Props) => {
    let value: string | undefined;
    if (typeof props.value === "number") {
        const isInvalid = isNaN(props.value);
        const isZero = props.value === 0;
        const maxedValue = props.value < NUMBER_MAX ? props.value : NUMBER_MAX;
        value = isInvalid ? "" : `${isZero ? maxedValue : maxedValue || ""}`;
    } else {
        value = props.value || "";
    }
    return (
        <div className="input-field">
            {props.descriptor && <p>{props.descriptor}</p>}
            {props.label && !props.rightLabel && (
                <InputLabel label={props.label} for={props.name} required={props.required} />
            )}
            <input
                type="text"
                name={props.name}
                placeholder={props.placeholder || ""}
                value={value}
                onKeyDown={props.onKeyDown}
                required={props.required}
                autoFocus={props.autoFocus}
                onChange={props.onChange}
            />
            {props.rightLabel && <span>{props.label}</span>}
            <div className="input-flare" />
            {props.error && <p className="validation-error">{props.error}</p>}
        </div>
    );
};

export const EmailInput = (props: Props) => {
    return (
        <div className="input-field">
            {props.descriptor && <p>{props.descriptor}</p>}
            {props.label && <InputLabel label={props.label} for={props.name} required={props.required} />}
            <input
                type="email"
                name={props.name}
                value={props.value || ""}
                placeholder={props.placeholder || "name@company.com"}
                onKeyDown={props.onKeyDown}
                required={props.required}
                autoFocus={props.autoFocus}
                onChange={props.onChange}
            />
            <div className="input-flare" />
            {props.error && <p className="validation-error">{props.error}</p>}
            <Icon type="email" color={color.metal} />
        </div>
    );
};

export const PhoneInput = (props: Props) => {
    return (
        <div className="input-field">
            {props.descriptor && <p>{props.descriptor}</p>}
            {props.label && <InputLabel label={props.label} for={props.name} required={props.required} />}
            <input
                type="phone"
                name={props.name}
                value={props.value || ""}
                placeholder={props.placeholder || "(555) 555-5555"}
                onKeyDown={props.onKeyDown}
                required={props.required}
                autoFocus={props.autoFocus}
                onChange={props.onChange}
            />
            <div className="input-flare" />
            {props.error && <p className="validation-error">{props.error}</p>}
        </div>
    );
};

export const PasswordInput = (props: Props) => {
    return (
        <div className="input-field">
            {props.descriptor && <p>{props.descriptor}</p>}
            {props.label && <InputLabel label={props.label} for={props.name} required={props.required} />}
            <input
                type="password"
                name={props.name}
                placeholder={props.placeholder || ""}
                onKeyDown={props.onKeyDown}
                required={props.required}
                autoFocus={props.autoFocus}
                onChange={props.onChange}
            />
            <div className="input-flare" />
            <Icon type="lock" color={color.metal} />
        </div>
    );
};
