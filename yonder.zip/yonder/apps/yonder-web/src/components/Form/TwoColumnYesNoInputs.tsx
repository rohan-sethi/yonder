import styled from "styled-components";

export const TwoColumnYesNoInputs = styled.div`
    display: flex;
    flex-wrap: wrap;
    flex-direction: row;
    width: 100%;

    .input-yes-no-with-description {
        display: flex;
        flex-basis: 100%;
        justify-content: flex-end;
        flex-direction: column;
    }

    @media only screen and (min-width: 60rem) {
        .input-yes-no-with-description {
            flex-basis: 50%;

            .input-textarea,
            .button-row {
                width: calc(100% - 2rem);
            }
        }
    }
`;
