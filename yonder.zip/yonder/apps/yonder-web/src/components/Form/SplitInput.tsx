import React from "react";
import styled from "styled-components";

type Props = {
    children: React.ReactNode;
    hasLabel?: boolean;
    descriptor?: string | React.ReactNode;
    error?: string;
};

export const SplitInput = (props: Props) => {
    return (
        <>
            {props.descriptor && <p>{props.descriptor}</p>}
            <StyledSplitInput className={`split-input ${props.hasLabel ? "has-label" : ""}`}>
                {props.children}
            </StyledSplitInput>
            {props.error && <p className="validation-error">{props.error}</p>}
        </>
    );
};

const StyledSplitInput = styled.div`
    display: block;

    > div {
        display: block;
        width: 100%;
    }

    @media only screen and (min-width: 40rem) {
        display: flex;
        flex: 1;
        flex-direction: row;
        justify-content: space-between;
        margin: 1rem -1rem;
        margin-bottom: 4rem;

        &.has-label {
            margin-top: 0;
        }

        .input-select,
        .input-field,
        .input-checkbox,
        p.secondary-action {
            width: 100%;
            align-self: flex-end;
            margin: 0 1rem !important;
        }
    }
`;
