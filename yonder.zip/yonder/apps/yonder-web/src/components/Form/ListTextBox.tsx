import React from "react";
import styled from "styled-components";

import { FormChangeEvent, TextInput, KeyPressEvent, MouseClickEvent, InputTextArea } from ".";
import { focusOnNextInput, focusOnPreviousInput, focusOnInput } from "../../functions";
import { LabeledPlusMinusButton, ButtonRow } from "..";
import { ButtonAlignment } from "../ButtonRow";

type Props = {
    collection: string[];
    name: string;
    label: string;
    placeholder: string;
    onFieldAdd: (ev?: KeyPressEvent | MouseClickEvent) => void;
    addLabel?: string;
    onFieldRemove: (ev: KeyPressEvent | MouseClickEvent, i?: number) => void;
    removeLabel?: string;
    onChange: (ev: FormChangeEvent, i: number) => void;
    className?: string;
    buttonAlignment?: ButtonAlignment;
    inputType?: "input-field" | "text-area";
    maxLength?: number;
    rows?: number;
    maxRows?: number;
};
export class ListTextBox extends React.Component<Props> {
    componentDidMount() {
        const { collection, onFieldAdd } = this.props;
        if (collection.length === 0) {
            onFieldAdd();
        }
    }

    handleKeyDown = (ev: KeyPressEvent, i: number) => {
        const { collection, onFieldAdd, onFieldRemove } = this.props;
        if (ev.key === "Enter") {
            ev.preventDefault();
            if (i === collection.length - 1) {
                onFieldAdd(ev);
            } else {
                focusOnNextInput(ev);
            }
        }
        if (ev.key === "Backspace" && collection.length > 1 && collection[i] === "") {
            ev.preventDefault();
            onFieldRemove(ev, i);
            if (i > 0) {
                focusOnPreviousInput(ev);
            } else {
                focusOnInput(ev, 0);
            }
        }
    };

    renderTextInputs = (): JSX.Element[] => {
        const { name, collection, onChange, placeholder } = this.props;
        return collection.map((value: string, i: number) => (
            <TextInput
                name={name}
                value={value}
                onChange={(ev: FormChangeEvent) => onChange(ev, i)}
                key={i}
                onKeyDown={(ev: KeyPressEvent) => this.handleKeyDown(ev, i)}
                placeholder={i === 0 ? placeholder : ""}
            />
        ));
    };

    renderTextAreas = () => {
        const { name, collection, onChange, placeholder, maxLength, rows, maxRows } = this.props;
        return collection.map((value: string, i: number) => (
            <InputTextArea
                name={name}
                value={value}
                onChange={(ev: FormChangeEvent) => onChange(ev, i)}
                key={i}
                onKeyDown={(ev: KeyPressEvent) => this.handleKeyDown(ev, i)}
                placeholder={i === 0 ? placeholder : ""}
                maxLength={maxLength}
                rows={rows}
                maxRows={maxRows}
            />
        ));
    };

    render() {
        const {
            label,
            collection,
            onFieldAdd,
            addLabel,
            onFieldRemove,
            removeLabel,
            className,
            buttonAlignment,
            inputType
        } = this.props;

        return (
            <StyledListTextBox className={`list-textbox ${className}`}>
                <p>{label}</p>
                {inputType === "input-field" ? this.renderTextInputs() : this.renderTextAreas()}
                <ButtonRow alignment={buttonAlignment || "space-between"}>
                    <LabeledPlusMinusButton
                        label={addLabel || "Add another rule"}
                        size="small"
                        type="plus"
                        onClick={onFieldAdd}
                    />
                    {collection.length > 1 ? (
                        <>
                            <div className="space-middle" />
                            <LabeledPlusMinusButton
                                label={removeLabel || "Remove last rule"}
                                size="small"
                                type="minus"
                                onClick={onFieldRemove}
                            />
                        </>
                    ) : (
                        <div />
                    )}
                </ButtonRow>
            </StyledListTextBox>
        );
    }
}

const StyledListTextBox = styled.div`
    margin: 4rem 0;

    .input-field,
    .input-textarea {
        margin-bottom: 0 !important;
    }

    .field-buttons {
        display: inline-block;
        margin-top: 1rem;
    }

    &.top-margin {
        margin-top: 2rem;
    }

    .space-between {
        > div {
            width: auto;
        }
    }

    .list-textbox.label {
        margin-bottom: 2rem;
    }
`;
