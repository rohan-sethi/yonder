import React from "react";
import Button, { Props as ButtonProps } from "../Button/Button";

export const FormButton = (props: ButtonProps) => {
    const outProps = {
        ...props,
        className: `form-button ${props.className || ""}`
    };
    return <Button {...outProps} />;
};
