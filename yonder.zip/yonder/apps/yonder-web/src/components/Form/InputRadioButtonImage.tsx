import React from "react";

import { InputChangeEventFunction } from "./FormFields";

type Props = {
    name: string;
    groupName: string;
    label: string;
    checked: boolean;
    url?: string;
    onChange: InputChangeEventFunction;
    disabled?: boolean;
};

export const InputRadioButtonImage = (props: Props) => {
    const { name, groupName, checked, disabled, label, onChange } = props;

    let outGroupName = groupName ? groupName + "[]" : name;

    return (
        <div className="checkbox-image">
            <label htmlFor={name} className="input-checkbox">
                <img src={props.url || "http://via.placeholder.com/400"} alt="" />
                <input
                    id={name}
                    type="radio"
                    name={outGroupName}
                    value={name}
                    checked={checked}
                    disabled={disabled || false}
                    onChange={(ev) => {
                        onChange({
                            target: {
                                name: ev.target.value,
                                value: ev.target.checked,
                                groupName: ev.target.name
                            }
                        });
                    }}
                />
                <span className="checkmark" />
                <div className="image-border" />
            </label>
            <div className="image-label">{label}</div>
        </div>
    );
};
