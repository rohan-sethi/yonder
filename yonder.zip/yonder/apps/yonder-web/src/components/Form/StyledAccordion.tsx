import styled from "styled-components";
import { color } from "../../variables";

export const StyledAccordion = styled.div`
    display: block;
    width: 100%;

    .display-details {
        margin-left: 2rem;

        p:first-of-type {
            margin-top: 2.5rem;
            font-weight: 600;
            font-size: 1rem;
        }

        .input-field,
        .input-select {
            margin-bottom: 2rem;
        }

        .button-row.save-delete {
            margin-bottom: 4rem;

            .form-button {
                padding: 1rem 1.5rem;
            }
        }

        .button-row {
            margin-bottom: 0;
        }
    }

    .header {
        position: relative;
        cursor: pointer;
        user-select: none;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        p {
            width: 100%;
            display: block;
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 0;
            align-self: center;
        }
        .button-toggle {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            label {
                display: block;
                align-self: center;
                width: auto;
                white-space: nowrap;
            }
            button {
                display: block;
                align-self: center;
                height: 2rem;
                width: 2rem;

                box-shadow: 0 0 0 0 transparent;
                transition: border-color 0.25s linear, color 0.25s linear, box-shadow 0.25s linear;

                color: ${color.charcoal};
                border-color: ${color.charcoal};

                .plus,
                .minus,
                .plus:after {
                    display: block;
                    margin: auto;
                    background-color: ${color.charcoal};
                    transition: background-color 0.25s linear;
                    width: 1rem;
                    height: 2px;
                }

                .plus:after {
                    content: " ";
                    transform: rotate(90deg);
                }
            }
        }
        &.split-label-button {
            .button-toggle {
                width: 100%;
                justify-content: space-between;

                .accordion-label {
                    padding-left: 0;
                }
            }
        }
    }

    .accordion-label {
        display: inline-block;
        padding-left: 0.75rem;
        vertical-align: middle;
        color: ${color.charcoal};
        font-size: 0.8rem;
        cursor: pointer;
    }

    .input-select {
        margin-bottom: 0;
        margin-top: 0;
    }

    > .input-textarea {
        margin: 1rem 0.5rem !important;
        margin-left: 1rem !important;
    }
`;

export const StyledPropertyFactDetails = styled(StyledAccordion)`
    .display-details {
        margin-bottom: 2.5rem;

        p:first-of-type {
            font-weight: 300;
            font-size: 1.125rem;
        }
    }

    .display-details .input-field {
        margin-bottom: 0;
    }
    .input-field {
        margin-bottom: 0;
    }

    .right-label .input-field {
        display: inline-block;
        margin-top: 0;
        width: 100%;
        input {
            width: 10rem;
        }
        span {
            padding-left: 1rem;
        }
    }

    label.input-checkbox.margin-top {
        margin-top: 2rem;
    }
`;
