import React from "react";
import styled from "styled-components";
import pluralize from "pluralize";

import { MouseClickEvent } from "./FormFields";
import { color } from "../../variables";
import { InputLabel } from ".";
import { PlusMinusButton } from "..";

type Props = {
    value?: number;
    onChange: (newCount: number) => void;
    unitString: string;
    label?: string;
    descriptor?: string | React.ReactNode;
    minValue?: number;
    maxValue?: number;
    required?: boolean;
};

export default class InputCounter extends React.Component<Props> {
    minValue = this.props.minValue || 0;
    maxValue = this.props.maxValue || 99999;

    onIncrement = (ev: MouseClickEvent) => {
        ev.preventDefault();
        const value = this.props.value !== undefined ? this.props.value : this.minValue;

        if (value < this.maxValue) {
            let incrementedCount: number = value + 1;
            this.props.onChange(incrementedCount);
        }
    };

    onDecrement = (ev: MouseClickEvent) => {
        ev.preventDefault();
        const value = this.props.value !== undefined ? this.props.value : this.minValue;

        if (value > this.minValue) {
            let decrementedCount: number = value - 1;
            this.props.onChange(decrementedCount);
        }
    };

    render() {
        const { value, descriptor, label, unitString, required } = this.props;

        const units = pluralize(unitString, value);

        return (
            <StyledInputCounter>
                {descriptor && <p>{descriptor}</p>}
                {label && <InputLabel label={label} required={required} />}
                <div className="counter-wrapper">
                    <PlusMinusButton type="minus" onClick={this.onDecrement} />
                    <div className="counter-label">
                        <span>{value || this.minValue}</span> {units}
                    </div>
                    <PlusMinusButton type="plus" onClick={this.onIncrement} />
                </div>
            </StyledInputCounter>
        );
    }
}

const StyledInputCounter = styled.div`
    display: block;
    position: relative;
    width: 100%;
    margin-bottom: 4rem;

    .counter-wrapper {
        display: inline-block;
        text-align: center;
        width: 100%;
        margin: 1rem auto;

        button,
        .counter-label {
            display: inline-block;
            text-align: center;
            vertical-align: middle;
        }
        .counter-label {
            color: ${color.dark};
            width: 7rem;
            overflow: hidden;

            span {
                font-weight: 800;
            }
        }
        button {
            margin: 0rem 0.5rem;
        }

        .counter-label {
            margin: 0 1rem;
        }
    }
`;
