import React from "react";
import DatePicker from "react-datepicker";

import { InputLabel } from ".";

import "../../styles/datepicker.css";

type Props = {
    name: string;
    label?: string;
    value?: string;
    descriptor?: string | React.ReactNode; // Adds a <p> instead of a label
    placeholder?: string;
    required?: boolean;
    maxDate?: Date;
    onChange: (date: Date) => void;
};

export const DateInput = (props: Props) => {
    return (
        <div className="input-field">
            {props.descriptor && <p>{props.descriptor}</p>}
            {props.label && <InputLabel label={props.label} for={props.name} required={props.required} />}
            <DatePicker
                name={props.name}
                selected={props.value ? new Date(props.value) : null}
                onChange={props.onChange}
                showMonthDropdown
                showYearDropdown
                maxDate={props.maxDate}
                dropdownMode="select"
                placeholderText={props.placeholder}
            />
            <div className="input-flare" />
        </div>
    );
};
