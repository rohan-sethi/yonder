import React from "react";
import { ButtonRow } from "..";
import { FormButton, MouseClickEvent, InputLabel } from ".";
import styled from "styled-components";

type Props = {
    name: string;
    label?: string;
    descriptor?: string | React.ReactNode;
    value?: boolean;
    padded?: boolean;
    onClick: (ev: MouseClickEvent, name: string, value: boolean) => void;
    required?: boolean;
    topMargin?: boolean;
};

export const InputYesNo = (props: Props) => {
    const { value, onClick, topMargin } = props;
    const padded = props.padded !== undefined ? props.padded : true;
    return (
        <StyledInputYesNo className={`input-yes-no ${topMargin}`}>
            {props.descriptor && <p>{props.descriptor}</p>}
            {props.label && <InputLabel label={props.label} required={props.required} />}
            <ButtonRow padded={padded}>
                <FormButton
                    label="Yes"
                    buttonStyle={value ? "outline-color" : "outline"}
                    onClick={(ev: MouseClickEvent) => {
                        ev.preventDefault();
                        onClick(ev, props.name, true);
                    }}
                />
                <FormButton
                    label="No"
                    buttonStyle={!value ? "outline-color" : "outline"}
                    onClick={(ev: MouseClickEvent) => {
                        ev.preventDefault();
                        onClick(ev, props.name, false);
                    }}
                />
            </ButtonRow>
        </StyledInputYesNo>
    );
};

const StyledInputYesNo = styled.div`
    &.top-margin {
        margin-top: 2rem;
    }
`;
