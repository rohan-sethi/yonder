import React from "react";
import AutoTextArea from "react-autosize-textarea";

import { FormChangeEventFunction, InputLabel, FormChangeEvent } from ".";

const MAX_TEXTAREA_LENGTH = 2400;

export function limitTextAreaInput(value?: string, inMaxLength?: number): string {
    const maxLength = inMaxLength || MAX_TEXTAREA_LENGTH;
    let outValue: string = value || "";
    return outValue.substr(0, maxLength);
}

type PAutoTextArea = {
    name: string;
    value?: string;
    onChange: FormChangeEventFunction;
    placeholder?: string;
    rows?: number;
    maxRows?: number;
    maxLength?: number;
    required?: boolean;
    onKeyDown?: FormChangeEvent;
    autoFocus?: boolean;
};

type PInputTextArea = {
    label?: string;
    descriptor?: string | React.ReactNode;
};

type Props = PAutoTextArea & PInputTextArea;

export const InputTextArea = (props: Props) => {
    const maxLength = props.maxLength || MAX_TEXTAREA_LENGTH;

    let outProps: Props;
    let value: string;
    if (props.value !== undefined && props.value.length > maxLength) {
        value = limitTextAreaInput(props.value, maxLength);
        outProps = {
            ...props,
            value
        };
    } else {
        outProps = props;
        value = props.value || "";
    }

    return (
        <div className="input-textarea">
            {props.descriptor && <p>{props.descriptor}</p>}
            {props.label && <InputLabel label={props.label} for={props.name} required={props.required} />}
            <AutoTextArea {...outProps} />
            {value.length >= 0 && (
                <div className="textarea-count">
                    {value.length}/{maxLength}
                </div>
            )}
        </div>
    );
};
