import styled from "styled-components";
import { fontFamily, color, thin } from "../../variables";

const _checkboxSize = 1.125;

export const StyledForm = styled.div`
    display: block;
    position: relative;
    width: 100%;
    margin: 1rem 0;

    *:focus {
        outline: none;
    }

    h2 {
        font-size: 1.45rem;
        font-family: ${fontFamily.nunitoSans};
        font-weight: 700;
        margin-bottom: 1rem;

        &.center {
            text-align: center;
            margin-bottom: 0.5rem;
        }
    }

    form {
        display: block;
        position: relative;
        padding: 0;
    }

    input,
    select,
    textarea {
        font-size: 1rem;
        padding: 0.75rem;
        border: none;
        border-radius: 0;
        background-color: transparent;
        color: ${color.blackInk};
    }

    input,
    select {
        border-bottom: ${thin} solid ${color.gray};
        transition: border-color 0.18625s linear;

        &:hover {
            border-bottom-color: #ccc;
        }
    }

    input,
    textarea {
        &::placeholder {
            color: ${color.grayDark};
        }
    }

    textarea {
        border-radius: 0.25rem;
        border: 1px solid ${color.metal};
        transition: border-color 0.18625s linear;

        &:hover {
            border-color: ${color.charcoal};
        }
        &:active,
        &:focus {
            border-color: ${color.primary};
        }
    }

    .input-field,
    .input-select {
        position: relative;
        margin: 1rem 0;
        margin-bottom: 3rem;

        label {
            margin: 0;
            margin-bottom: 0.5rem;
        }

        .input-flare {
            display: block;
            position: relative;
            width: 0;
            height: ${thin};
            margin-top: -${thin};
            background-color: ${color.gray};
            z-index: 10;
            transition: width 0.25s linear, background-color 0.25s linear;
        }

        input:active + .input-flare,
        input:focus + .input-flare,
        select:active ~ .input-flare,
        select:focus ~ .input-flare,
        select:hover ~ .input-flare,
        .react-datepicker-popper ~ .input-flare {
            width: 100%;
            background-color: ${color.primary};
        }

        .icon-container {
            position: absolute;
            right: 0.5rem;
            bottom: 0.75rem;

            img {
                height: 1.125rem;
                width: 1.125rem;
            }
        }
        .validation-error + .icon-container {
            bottom: 4.6rem;
        }
    }

    .input-field {
        .react-datepicker-wrapper {
            width: 100%;

            .react-datepicker__input-container {
                width: 100%;

                input {
                    width: 100%;
                }
            }
        }
    }

    .input-select {
        .select-arrow {
            display: block;
            position: absolute;
            width: 0.75rem;
            height: 0.75rem;
            border-left: 0.125rem solid ${color.gray};
            border-bottom: 0.125rem solid ${color.gray};
            bottom: 1.25rem;
            right: 1rem;
            transform: rotate(-45deg);
            transition: border-color 0.25s linear;
            cursor: pointer;
        }

        select {
            cursor: pointer;
        }

        &:hover .select-arrow,
        select:active ~ .select-arrow,
        select:focus ~ .select-arrow {
            transition: border-color 0.25s 0.125s linear;
            border-left-color: ${color.primary};
            border-bottom-color: ${color.primary};
        }
    }

    .input-textarea {
        position: relative;
        margin: 1rem 0;
        margin-bottom: 3rem;

        p {
            margin-bottom: 2rem;
        }

        label {
            margin: 0;
            margin-bottom: 0.5rem;
        }

        textarea {
            padding-bottom: 2.75rem;
        }

        .textarea-count {
            position: absolute;
            display: block;
            font-size: 0.75rem;
            font-weight: 600;
            right: 0.75rem;
            bottom: 0.75rem;
            color: ${color.dark};
        }
    }

    p {
        vertical-align: middle;
        font-size: 1.125rem;
        line-height: 1.5;
        font-weight: 300;
        margin: 0;
        margin-bottom: 1rem;
        color: ${color.blackInk};

        &.error-message,
        &.validation-error {
            margin: 2rem 0;
            color: ${color.fireBrick};
        }

        &.success-message {
            margin: 2rem 0;
            color: ${color.primary};
        }

        &.status-message {
            display: block;
            position: fixed;
            z-index: 10;
            margin: 2rem 0;
            color: ${color.yonderGreen};
            font-weight: 500;
            background-color: ${color.pureWhite};
        }

        &.input-no-edit {
            font-size: 1rem;
            font-weight: 400;
            padding: 0.75rem;
            color: ${color.blackInk};
        }

        .note {
            display: block;
            font-size: 0.875rem;
            font-style: italic;
            line-height: 1.75;

            &:before {
                content: "* ";
            }
        }

        button {
            margin: 1rem 0;
        }
    }

    button + p {
        margin-top: 1rem;
    }

    button,
    p {
        .icon-container,
        .icon-container + span {
            display: inline-block;
            vertical-align: middle;
            margin-right: 0.75rem;
        }

        .icon-container + span {
            margin-top: 0.125rem;
        }

        &.secondary-action {
            font-size: 0.875rem;
            text-align: center;

            &.forgot-password {
                text-align: right;
                line-height: 1.25;
            }

            button,
            .router-link,
            .external-link {
                color: ${color.primary};
                background-color: transparent;
                border: none;
                font-size: inherit;
                font-weight: 700;
                margin: 0;
                transition: color 0.125s linear;

                :hover {
                    color: ${color.primaryDark};
                    background-color: transparent;
                }
            }

            &:last-child {
                margin-bottom: 0;
            }

            &.underline {
                button,
                .router-link,
                .external-link {
                    color: ${color.metal};
                    text-decoration: underline;
                    font-weight: normal;

                    &:hover {
                        color: ${color.wintersGray};
                    }
                }
            }
        }
    }

    h2.center + p.secondary-action {
        margin-bottom: 3.5rem;
    }

    fieldset {
        margin: 0;
        padding: 1rem 0;
        border: 0;
    }

    label {
        display: block;
        margin: 0.25rem 0;
        font-size: 0.875rem;
        color: ${color.grayDark};
    }

    hr {
        margin: 3rem 0;
    }

    .thin-hr {
        margin: 1.5rem 0;
    }

    .form-container {
        margin-top: 1rem;
        margin-bottom: 3rem;
    }

    .input-checkbox,
    .input-radio {
        display: inline-block;
        width: 100%;
        position: relative;
        user-select: none;
        margin: 0.75rem 0;

        .checkmark {
            display: block;
            position: absolute;
            background-color: ${color.pureWhite};
            border: 1px solid ${color.metal};
            border-radius: 0.125rem;
            width: ${_checkboxSize}rem;
            height: ${_checkboxSize}rem;
            box-shadow: 0 0 0 0 ${color.pureWhite};
            transition: background-color 0.125s linear, border-color 0.125s linear, box-shadow 0.125s linear;

            &:after {
                display: block;
                position: absolute;
                opacity: 0;
                content: " ";
                width: ${(_checkboxSize * 3) / 5}rem;
                height: ${_checkboxSize / 3}rem;
                border: 0;
                border-left: ${thin} solid ${color.pureWhite};
                border-bottom: ${thin} solid ${color.pureWhite};
                margin-top: 33%;
                margin-left: 50%;
                transform: translate(-50%, -33%) rotate(-45deg);
            }
        }

        input[type="checkbox"],
        input[type="radio"] {
            position: absolute;
            opacity: 0;
            cursor: pointer;
            z-index: 10;
            height: ${_checkboxSize}rem;
            margin: 0;

            &:checked + .checkmark {
                background-color: ${color.primary};
                border-color: ${color.primary};
                box-shadow: 0 0 ${thin} 0 ${color.primaryDark};

                &:after {
                    opacity: 1;
                }
            }
        }

        .padded-label {
            display: block;
            font-size: 1rem;
            margin-left: 2rem;
            line-height: 1.25;
            color: ${color.dark};
        }

        &:hover {
            .checkmark {
                background-color: ${color.gray};
            }

            input[type="checkbox"],
            input[type="radio"] {
                &:checked + .checkmark {
                    background-color: ${color.primaryDark};
                    border-color: ${color.primaryDark};
                }
            }
        }
    }

    .checkbox-image {
        display: inline-block;
        vertical-align: top;
        position: relative;
        margin: 1rem;
        width: calc(50% - 2rem);
        height: auto;

        label {
            margin-top: 0;
        }

        .input-checkbox {
            border-radius: 0.25rem;
            margin-bottom: 0.5rem;

            img {
                display: block;
                width: 100%;
                height: auto;
                border-radius: 0.25rem;
            }

            input[type="checkbox"],
            input[type="radio"],
            .image-border {
                position: absolute;
                height: 100%;
                width: 100%;
                left: 0;
                top: 0;
                cursor: pointer;
            }
            .checkmark {
                position: absolute;
                right: 1rem;
                bottom: 1rem;
            }

            input[type="checkbox"],
            input[type="radio"] {
                z-index: 10;
            }

            input[type="checkbox"] ~ .image-border,
            input[type="radio"] ~ .image-border {
                border: 0.125rem solid transparent;
                border-radius: 0.25rem;
                z-index: 5;
                transition: border-color 0.25s linear;
            }

            input[type="checkbox"]:hover ~ .image-border,
            input[type="radio"]:hover ~ .image-border {
                border-color: ${color.gray};
            }

            input[type="checkbox"]:checked ~ .image-border,
            input[type="radio"]:checked ~ .image-border {
                border-color: ${color.primary};
                box-shadow: 0 0 ${thin} 0 ${color.primaryDark};
            }

            input[type="checkbox"]:checked:hover ~ .image-border,
            input[type="radio"]:checked:hover ~ .image-border {
                border-color: ${color.primaryDark};
            }
        }

        .image-label {
            text-align: center;
            font-size: 1.125rem;
        }
    }

    .content-block {
        margin-bottom: 3rem;

        h2,
        img,
        p {
            margin: 2rem 0;
        }

        h2,
        p {
            padding: 0 2rem;
        }
    }

    .category-checkboxes {
        p {
            &.category-name {
                font-weight: bold;
                margin-bottom: 0;
                margin-top: 1rem;
            }
        }

        .checkboxes {
            display: flex;
            flex-wrap: wrap;
            flex-direction: row;
            padding: 0.5rem 1rem;

            .input-checkbox {
                display: flex;
                flex-basis: 100%;
                justify-content: center;
                flex-direction: column;
            }

            + hr {
                margin-top: 2rem;
            }
        }
    }

    div.static-list {
        display: block;
        margin: 3rem 0;
        margin-top: 0;
        padding-left: 0.75rem;

        > p {
            font-size: 1rem;
            line-height: 1.25;
            color: ${color.primaryDark};
        }
    }

    hr.with-text {
        line-height: 1rem;
        position: relative;
        outline: 0;
        border: 0;
        text-align: center;
        height: 1.5rem;
        opacity: 1;
        margin: 2rem 0;
        background: ${color.pureWhite};

        &:before {
            content: "";
            background: ${color.metal};
            position: absolute;
            left: 0;
            top: 50%;
            width: 100%;
            height: 1px;
        }

        &:after {
            content: attr(data-content);
            position: relative;
            display: inline-block;
            padding: 0 0.5rem;
            line-height: 1.5rem;
            font-size: 0.875rem;
            background-color: ${color.pureWhite};
        }
    }

    .list-textbox.three-quarter,
    .input-textbox.three-quarter {
        width: 100%;
    }
    @media only screen and (min-width: 35rem) {
        .category-checkboxes .checkboxes {
            &.two .input-checkbox {
                flex-basis: 50%;
            }
            &.three .input-checkbox {
                flex-basis: 33.33333%;
            }
            &.four .input-checkbox {
                flex-basis: 25%;
            }
        }
    }

    @media only screen and (min-width: 40rem) {
        .input-field,
        .input-select,
        .input-textarea,
        .content-block,
        .form-container {
            margin-bottom: 3rem;
        }
    }
    @media only screen and (min-width: 60rem) {
        h2 {
            font-size: 1.625rem;
        }
        fieldset {
            padding: 3rem 0;
        }

        .input-field,
        .input-select,
        .input-textarea,
        .content-block,
        .form-container {
            margin-bottom: 4rem;
        }

        .list-textbox.three-quarter,
        .input-textbox.three-quarter {
            width: 75%;
        }
    }
    @media only screen and (min-width: 80rem) {
        /**/
    }
`;
