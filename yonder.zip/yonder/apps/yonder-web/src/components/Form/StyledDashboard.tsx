import styled from "styled-components";
import { StyledForm } from "./index";
import { color } from "../../variables";

export const StyledDashboard = styled(StyledForm)`
    p {
        color: ${color.blackInk};
    }
    .input-radio,
    .input-checkbox {
        .padded-label {
            color: ${color.blackInk};
        }
    }
    .invite-button {
        margin-top: -2rem;
        margin-bottom: 4rem;
    }

    .checkboxes-with-descriptor {
        .descriptor {
            margin-bottom: 2rem;
        }
    }

    .right-label .input-field {
        display: inline-block;
        margin-top: 0;
        width: 100%;
        input {
            width: 10rem;
        }
        span {
            padding-left: 1rem;
        }
    }
`;
