import React from "react";
import styled from "styled-components";

type Props = {
    children: React.ReactNode;
};

export const FormGroup = (props: Props) => {
    return <StyledFormGroup>{props.children}</StyledFormGroup>;
};

const StyledFormGroup = styled.div`
    padding: 2rem 0;
`;
