import React from "react";
import { PInput } from "./FormFields";
import { InputLabel } from ".";

type PNumberInput = {
    value?: number;
    min?: number;
    max?: number;
    step?: number;
};

type Props = PInput & PNumberInput;

export const NumberInput = (props: Props) => {
    return (
        <div className="input-field">
            {props.descriptor && <p>{props.descriptor}</p>}
            {props.label && <InputLabel label={props.label} for={props.name} required={props.required} />}
            <input type="number" name={props.name || "number"} placeholder={props.placeholder || "Number"} {...props} />
            <div className="input-flare" />
        </div>
    );
};
