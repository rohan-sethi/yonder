import React from "react";

import { InputChangeEventFunction } from "./FormFields";

type Props = {
    name: string;
    groupName?: string;
    label: string;
    checked?: boolean;
    onChange: InputChangeEventFunction;
    disabled?: boolean;
    className?: string;
};

export const InputCheckbox = (props: Props) => {
    const { name, groupName, checked, disabled, label, onChange, className } = props;

    let outGroupName = groupName ? groupName + "[]" : name;

    return (
        <label htmlFor={name} className={`input-checkbox ${className || ""}`}>
            <input
                id={name}
                type="checkbox"
                name={outGroupName}
                value={name}
                checked={checked || false}
                disabled={disabled || false}
                onChange={(ev) => {
                    onChange({
                        target: {
                            name: ev.target.value,
                            value: ev.target.checked,
                            groupName: ev.target.name
                        }
                    });
                }}
            />
            <span className="checkmark" />
            <span className="padded-label">{label}</span>
        </label>
    );
};
