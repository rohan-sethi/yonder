import React from "react";

import { InputChangeEventFunction } from "./FormFields";

type Props = {
    name: string;
    groupName: string;
    label: string;
    checked: boolean;
    onChange: InputChangeEventFunction;
    disabled?: boolean;
};

export const InputRadioButton = (props: Props) => {
    const { name, groupName, checked, disabled, label, onChange } = props;

    let outGroupName = groupName ? groupName + "[]" : name;

    return (
        <label htmlFor={name} className="input-checkbox">
            <input
                id={name}
                type="radio"
                name={outGroupName}
                value={name}
                checked={checked}
                disabled={disabled || false}
                onChange={(ev: any) => {
                    onChange({
                        target: {
                            name: ev.target.value,
                            value: ev.target.checked,
                            groupName: ev.target.name
                        }
                    });
                }}
            />
            <span className="checkmark" />
            <span className="padded-label">{label}</span>
        </label>
    );
};
