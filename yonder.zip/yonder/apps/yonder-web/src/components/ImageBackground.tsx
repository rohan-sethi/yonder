import React from "react";
import styled from "styled-components";

import { IImageElement } from "../interfaces";

type PPosition = {
    position?: string;
    maxHeight?: boolean;
};

export type Props = IImageElement & PPosition;

export default (props: Props) => {
    let outProps = {
        alt: props.alt || "",
        ...props
    };
    return <StyledImage className="image-background" {...outProps} />;
};

const StyledImage = styled.div`
    position: relative;
    display: block;
    width: 100%;
    height: ${(props: Props) => (props.maxHeight ? "100%" : "30rem")};
    background: url(${(props: Props) => props.src || "http://via.placeholder.com/600"}) no-repeat;
    background-position: ${(props: Props) => props.position || "center"};
    background-size: cover;

    @media only screen and (min-width: 80rem) {
        height: 100%;
    }
`;
