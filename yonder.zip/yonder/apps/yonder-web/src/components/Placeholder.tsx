import React from "react";

type Props = {
    size?: string | number;
};

export default (props: Props) => {
    return <img className="placeholder" src={`http://via.placeholder.com/${props.size || 150}`} alt="placeholder" />;
};
