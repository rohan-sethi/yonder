import React from "react";
import styled from "styled-components";

import { Icon } from "./index";
import { ExternalLink, Props as ILink, RouterLink } from "./Link";
import { color } from "../variables";

type Props = ILink & {
    external?: boolean;
};

export const InformationLink = (props: Props) => {
    const external: boolean = !!props.external;
    const Link = external ? ExternalLink : RouterLink;
    const outProps = {
        ...props,
        label: undefined,
        external: undefined
    };
    return (
        <StyledInformationLink>
            <Link {...outProps}>
                <Icon type="tooltip-info" size="1rem" /> <span>{props.label}</span>
            </Link>
        </StyledInformationLink>
    );
};

const StyledInformationLink = styled.div`
    display: block;
    margin-bottom: 0.5rem;

    .router-link,
    .external-link {
        span {
            display: inline-block;
            vertical-align: middle;
            line-height: 1.5;
            font-size: 0.875rem;
        }
        .icon-container {
            display: inline-block;
            vertical-align: middle;
            line-height: 1;

            svg,
            svg path,
            svg polygon {
                color: ${color.primary};
                fill: ${color.primary};
            }
        }
    }

    &:active,
    &:hover {
        .router-link .icon-container,
        .external-link .icon-container {
            svg,
            svg path,
            svg polygon {
                color: ${color.primaryDark};
                fill: ${color.primaryDark};
            }
        }
    }
`;
