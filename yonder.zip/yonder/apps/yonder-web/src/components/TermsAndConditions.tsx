import React from "react";

class TermsAndConditions extends React.Component {
    render() {
        return (
            <div>
                <h2>Terms and Conditions</h2>
                <p>Terms and Conditions placeholder.</p>
            </div>
        );
    }
}

export const TermsAndConditionsModal = {
    body: <TermsAndConditions />
};
