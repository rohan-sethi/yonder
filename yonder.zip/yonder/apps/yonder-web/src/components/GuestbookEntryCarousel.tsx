import React from "react";
import styled from "styled-components";

import { GuestbookEntry, Section, ArrowButton } from "./index";
import { Props as IGuestbookEntry } from "./GuestbookEntry";
import { color } from "../variables";

type Props = {
    title?: string;
    entries: IGuestbookEntry[];
};

type State = {
    carouselOffset: number;
};

export default class GuestbookEntryCarousel extends React.Component<Props, State> {
    range: number = 3;
    max: number = this.props.entries.length - this.range;

    state: State = {
        carouselOffset: 0
    };

    onLeftArrow = () => {
        if (this.state.carouselOffset > 0) {
            let carouselOffset = this.state.carouselOffset - 1;
            this.setState({
                carouselOffset
            });
        }
    };

    onRightArrow = () => {
        if (this.state.carouselOffset < this.max) {
            let carouselOffset = this.state.carouselOffset + 1;
            this.setState({
                carouselOffset
            });
        }
    };

    render() {
        let rangeEnd = this.state.carouselOffset + this.range;
        let entries = this.props.entries.map((entry, i) => {
            let inRange = i >= this.state.carouselOffset && i < rangeEnd;
            return inRange ? <GuestbookEntry {...entry} key={i} /> : undefined;
        });

        let buttonSettings = {
            color: "#616161",
            outlineColor: "#a4a4a4",
            hoverColor: "rgba(0, 0, 0, 0.1)"
        };

        return (
            <Section backgroundColor={color.pureWhite}>
                <h3>{this.props.entries.length} Guest Book Entries</h3>
                <StyledGuestbookEntryCarousel>
                    <div className="arrow-container">
                        {this.state.carouselOffset > 0 && (
                            <div className="left-arrow">
                                <ArrowButton {...buttonSettings} type="back" onClick={this.onLeftArrow} />
                            </div>
                        )}
                        {this.state.carouselOffset < this.max && (
                            <div className="right-arrow">
                                <ArrowButton {...buttonSettings} onClick={this.onRightArrow} />
                            </div>
                        )}
                    </div>
                    <div className="carousel-container">{entries}</div>
                </StyledGuestbookEntryCarousel>
            </Section>
        );
    }
}

const StyledGuestbookEntryCarousel = styled.div`
    display: block;
    position: relative;
    width: 100%;
    height: 100%;

    .carousel-container {
        display: table;
        width: 100%;
        margin-top: 2rem;
        white-space: nowrap;
    }

    .arrow-container {
        display: block;
        position: relative;
        width: 100%;
        height: 4rem;
        margin-top: -4.25rem;

        .left-arrow {
            display: block;
            position: absolute;
            top: 25%;
            right: 3rem;
        }
        .right-arrow {
            display: block;
            position: absolute;
            top: 25%;
            right: 0;
        }
    }
`;
