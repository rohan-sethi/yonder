import React from "react";
import styled from "styled-components";
import { observer, inject } from "mobx-react";

import { color, thin, html } from "../variables";
import { Props as IRouterLink, ExternalLink } from "./Link";
import { RouterLink, Avatar, StyledForm, FormButton } from "./index";
import signInModal from "../modals/SignInConductor";
import { IFirebaseStore, INavigationStore, IContentModalStore } from "../store";
import { UserPermissions, HostTypes } from "@yonder/db";
import { isStringInvalid } from "../functions";

type NavigationProps = {
    navStyle: "normal" | "clear";
    swapNavStyleAt?: number;
};

type NavigationLink = IRouterLink & {
    external?: boolean;
};

type Props = NavigationProps & IFirebaseStore & INavigationStore & IContentModalStore;
type State = {
    hasScrolled?: boolean;
};

const navHeightNum = 5;

@inject("firebaseState", "navigationState", "contentModalState")
@observer
export class Navigation extends React.Component<Props, State> {
    state: State = {
        hasScrolled: false
    };

    supportLink: NavigationLink = {
        to: "//help.yonder.com",
        label: "Support",
        target: "_blank",
        rel: "noopener noreferrer",
        external: true
    };

    listingsLink: NavigationLink = {
        to: "/dash/listings",
        label: "Listings"
    };

    linksSignedIn: NavigationLink[] = [];

    linksSignedOut: NavigationLink[] = [
        this.supportLink,
        {
            to: "/",
            label: "Sign up"
        }
    ];

    logIn: NavigationLink = {
        label: "Log in",
        onClick: () => {
            const { open } = this.props.contentModalState!;
            open("", signInModal.body);
        }
    };

    profileLink: NavigationLink = {
        to: "/profile",
        label: "Host Profile"
    };

    myBusinessLink: NavigationLink = {
        to: "/my-business",
        label: "My Business"
    };

    accountLink: NavigationLink = {
        to: "/account",
        label: "Log In & Security"
    };

    settingsPane: any | null = null;
    settingsWrapper: any | null = null;

    handleKeyPress = (ev: KeyboardEvent) => {
        if (ev.key === "Escape") this.props.navigationState!.setMenuShown(false);
    };

    handleMouseClick = (ev: MouseEvent) => {
        const insideSettingsWrapper = this.settingsWrapper && this.settingsWrapper.contains(ev.target);
        const insideSettingsPane = this.settingsPane && this.settingsPane.contains(ev.target);
        if (insideSettingsWrapper || insideSettingsPane) return;

        this.props.navigationState!.setMenuShown(false);
    };

    componentDidMount() {
        window.addEventListener("scroll", this.handleScroll);
        document.addEventListener("keyup", this.handleKeyPress);
        document.addEventListener("mousedown", this.handleMouseClick);
    }

    componentWillUnmount() {
        window.removeEventListener("scroll", this.handleScroll);
        document.removeEventListener("keyup", this.handleKeyPress);
        document.removeEventListener("mousedown", this.handleMouseClick);
    }

    handleScroll = (_ev: Event) => {
        const navOffset = html.fontSize * navHeightNum;
        const offset = this.props.swapNavStyleAt ? this.props.swapNavStyleAt - navOffset : 0;
        if (window.pageYOffset > offset) {
            if (!this.state.hasScrolled) {
                this.setState({
                    hasScrolled: true
                });
            }
        } else {
            if (this.state.hasScrolled) {
                this.setState({
                    hasScrolled: false
                });
            }
        }
    };

    renderNavRouterLink = (link: NavigationLink, i?: number) => {
        const { setMenuShown } = this.props.navigationState!;
        if (!!link.external) {
            return (
                <ExternalLink
                    {...link}
                    key={i}
                    onClick={() => {
                        setMenuShown(false);
                        link.onClick && link.onClick();
                    }}
                />
            );
        }
        return (
            <RouterLink
                {...link}
                key={i}
                onClick={() => {
                    setMenuShown(false);
                    link.onClick && link.onClick();
                }}
            />
        );
    };

    renderNavMenuLink = (link: NavigationLink, i: number) => (
        <React.Fragment key={i}>
            <hr />
            {this.renderNavRouterLink(link)}
        </React.Fragment>
    );

    renderLogo = (isClear?: boolean) => {
        const { isSignedIn, dbUser } = this.props.firebaseState!;
        const logoUrl = isClear ? "/img/yonder-logo-light.svg" : "/img/yonder-minimal.svg";

        const isMgmt: boolean = dbUser.hostType === HostTypes.PropertyManagement;

        let toLink = isSignedIn ? (isMgmt ? "/new-mgmt" : "/new-host") : "/";
        if (dbUser.permissions === UserPermissions.Host) {
            toLink = "/dash/listings";
        } else if (dbUser.permissions === UserPermissions.Admin) {
            toLink = "/admin";
        }
        return (
            <RouterLink className="logo" to={toLink}>
                <img className="logo-minimal" src={logoUrl} alt="yonder" />
            </RouterLink>
        );
    };

    render() {
        const { isSignedIn, dbUser, authUser, firebase } = this.props.firebaseState!;
        const { menuShown, toggleMenu, setMenuShown } = this.props.navigationState!;

        if (dbUser.permissions === UserPermissions.Host || dbUser.permissions === UserPermissions.Admin) {
            this.linksSignedIn = [this.listingsLink];
        }

        const mainLinks = isSignedIn
            ? this.linksSignedIn.map(this.renderNavRouterLink)
            : this.linksSignedOut.concat(this.logIn).map(this.renderNavRouterLink);

        const settingsLink = () => {
            const mainLinksPane = isSignedIn
                ? this.linksSignedIn.map(this.renderNavMenuLink)
                : this.linksSignedOut.concat(this.logIn).map(this.renderNavMenuLink);
            const isGuest = dbUser.hostType === HostTypes.Guest;
            let profileLink = this.profileLink;
            if (isGuest) {
                profileLink.label = "Profile";
            }
            const settingsLinksArray = isGuest
                ? [this.profileLink, this.accountLink, this.supportLink]
                : [this.profileLink, this.myBusinessLink, this.accountLink, this.supportLink];
            const settingsLinks = settingsLinksArray.map(this.renderNavMenuLink);

            const firstName = !isStringInvalid(dbUser.firstName) ? dbUser.firstName : "Settings";

            // TODO: Scrap the idea of "FormButton" and make them the "Button" component.
            return (
                <div
                    className={`settings-wrapper ${isSignedIn ? "" : "signed-out"} ${menuShown ? "is-open" : ""}`}
                    ref={(node) => (this.settingsWrapper = node)}
                >
                    <div className="button mobile-only" onClick={toggleMenu}>
                        <div className="hamburger">
                            <span />
                            <span />
                            <span />
                        </div>
                    </div>
                    <div className="button desktop-only" onClick={toggleMenu}>
                        {firstName}
                        <div className="link-caret" />
                    </div>
                    <div className="settings-pane" ref={(node) => (this.settingsPane = node)}>
                        <div className="contents">
                            <div className="logo-wrapper mobile-only">{this.renderLogo(false)}</div>
                            <div className="desktop-only">
                                <div className="user-info-wrapper">
                                    <div className="user-avatar">
                                        <Avatar
                                            file={dbUser.photoURL || ""}
                                            text={
                                                dbUser.photoURL ? undefined : authUser ? authUser.displayInitials : ""
                                            }
                                            title="Profile"
                                        />
                                    </div>
                                    <div className="user-info">
                                        {!isStringInvalid(dbUser.firstName, true, true) &&
                                            !isStringInvalid(dbUser.lastName, true, true) && (
                                                <span>
                                                    {dbUser.firstName} {dbUser.lastName}
                                                </span>
                                            )}
                                        <span>{dbUser.email}</span>
                                    </div>
                                </div>
                            </div>
                            <div className="mobile-only">{mainLinksPane}</div>
                            {isSignedIn ? (
                                <>
                                    {settingsLinks}
                                    <hr />
                                    <StyledForm>
                                        <FormButton
                                            buttonStyle="outline-color"
                                            label="Log Out"
                                            onClick={() => {
                                                firebase.doSignOut();
                                                setMenuShown(false);
                                            }}
                                        />
                                    </StyledForm>
                                </>
                            ) : (
                                <>
                                    <hr />
                                    <StyledForm>
                                        <FormButton buttonStyle="outline-color" {...this.logIn} />
                                    </StyledForm>
                                </>
                            )}
                        </div>
                    </div>
                </div>
            );
        };

        const isClear: boolean = this.props.navStyle === "clear" && !this.state.hasScrolled;
        const navClassName = `container ${isClear ? "clear" : "normal"}`;

        return (
            <StyledNavigation className={this.state.hasScrolled ? "scroll" : ""}>
                <nav className={navClassName}>
                    {this.renderLogo(isClear)}
                    <div className="actions">
                        <div className="desktop-only">{mainLinks}</div>
                        {settingsLink()}
                    </div>
                </nav>
                {this.props.navStyle !== "clear" && <div className="spacer" />}
            </StyledNavigation>
        );
    }
}

export const navHeight = `${navHeightNum}rem`;
//export const subNavHeight = "3.5rem";
export const subNavHeight = 0;
const avatarSize = 6;

const StyledNavigation = styled.header`
    display: block;
    position: relative;
    background-color: transparent;

    nav {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        position: fixed;
        z-index: 9000;
        width: 100%;
        padding: 0 1.5rem;

        .router-link.logo {
            display: block;
            position: relative;
            align-self: center;
            margin: 0 0.25rem;

            img {
                display: block;
                width: auto;
                height: auto;
                max-width: 6.75rem;
                max-height: 1.25rem;
                align-self: center;
            }
        }

        .actions {
            display: flex;
            flex-direction: row;
            align-self: center;
            line-height: 1.5;

            .button,
            .router-link,
            .external-link {
                font-size: 1rem;
                font-weight: 500;
                display: block;
                align-self: center;
                padding: 0.75rem 0.5rem;
                margin: 0 0.75rem;
                color: ${color.blackInk};
                transition: color 0.125s linear, border-color 0.125s linear;
                user-select: none;
                border-top: 0.2rem solid transparent;
                border-bottom: 0.2rem solid transparent;

                :hover {
                    color: #666;
                    background-color: transparent;
                }
            }

            .router-link.avatar {
                padding-left: 0.75rem;
            }

            .settings-wrapper {
                display: block;
                align-self: center;
                margin: 0;

                .button {
                    margin: 0;
                    cursor: pointer;

                    &.mobile-only {
                        padding: 0.75rem 0;
                    }
                }

                .hamburger {
                    display: block;
                    position: relative;
                    width: 1.5rem;
                    height: 1.125rem;
                    z-index: 100;

                    span {
                        display: block;
                        position: absolute;
                        width: 100%;
                        height: 1px;
                        left: 0;
                        background-color: ${color.charcoal};
                        transform: rotate(0deg);
                        transition: width 0.25s ease-in-out, background-color 0.25s ease-in-out,
                            transform 0.25s ease-in-out, top 0.25s ease-in-out, bottom 0.25s ease-in-out;

                        &:first-child {
                            top: 0;
                        }

                        &:nth-child(2) {
                            top: calc(50% - 0.5px);
                            right: 0;
                        }

                        &:last-child {
                            bottom: 0;
                        }
                    }
                }

                .link-caret {
                    display: inline-block;
                    vertical-align: middle;
                    position: relative;
                    margin-left: 0.75rem;
                    margin-top: -0.125rem;
                    width: 1.25rem;
                    transition: margin-top 0.125s linear;

                    &:before,
                    &:after {
                        content: " ";
                        display: block;
                        position: absolute;
                        width: 0.75rem;
                        height: ${thin};
                        top: 0;
                        background-color: ${color.charcoal};
                        transition: transform 0.125s linear;
                    }

                    &:before {
                        left: 0;
                        transform: rotate(45deg);
                    }

                    &:after {
                        right: 0;
                        transform: rotate(-45deg);
                    }
                }

                .settings-pane {
                    display: block;
                    position: absolute;
                    width: 100%;
                    height: auto;
                    max-height: 0;
                    right: 0;
                    top: 0;
                    opacity: 0;
                    overflow: hidden;
                    transition: max-height 0.125s linear, opacity 0.25s linear;

                    .contents {
                        padding: 1.2rem 1.75rem;
                        background-color: ${color.coconut};

                        .router-link,
                        .external-link {
                            color: ${color.blackInk};
                            padding: 0.5rem 0rem;
                            margin: 0;
                        }

                        .logo-wrapper.mobile-only {
                            .router-link.logo {
                                display: inline-block;
                            }
                        }

                        button {
                            width: 50%;
                            margin-top: 1rem;
                        }

                        hr {
                            background-color: ${color.gray};
                        }

                        .user-info-wrapper {
                            display: flex;
                            flex-direction: row;
                            margin-left: 0.25rem;
                            margin-bottom: 1.5rem;
                            overflow: hidden;
                            width: 100%;

                            .user-avatar {
                                display: block;
                                align-self: center;
                                min-width: ${avatarSize}rem;
                                height: ${avatarSize}rem;
                                width: ${avatarSize}rem;
                                border-radius: 50%;
                                overflow: hidden;
                            }

                            .user-info {
                                display: block;
                                align-self: center;
                                padding-left: 1rem;
                                width: calc(100% - ${avatarSize + 1}rem);

                                span {
                                    font-size: 1.125rem;
                                    display: block;
                                    white-space: nowrap;
                                    overflow: hidden;
                                    text-overflow: ellipsis;

                                    &:first-child {
                                        font-weight: 800;
                                    }
                                }
                            }
                        }
                    }
                }

                &.is-open {
                    .settings-pane {
                        max-height: 100vh;
                        opacity: 1;
                    }

                    .hamburger {
                        span {
                            background-color: ${color.charcoal} !important;
                            &:first-child {
                                top: calc(0.5625rem - (${thin} / 2));
                                transform: rotate(45deg);
                            }

                            &:nth-child(2) {
                                width: 0;
                            }

                            &:last-child {
                                bottom: calc(0.5625rem - (${thin} / 2));
                                transform: rotate(-45deg);
                            }
                        }
                    }
                }
            }
        }

        /*&.normal {
            background-color: ${color.pureWhite};
        }*/

        &.clear {
            background-color: transparent;

            .actions {
                .button,
                .router-link,
                .external-link {
                    color: ${color.pureWhite};
                    background-color: transparent;

                    :hover {
                        color: ${color.coconut};
                    }
                }
                .settings-wrapper {
                    .hamburger {
                        span {
                            background-color: ${color.pureWhite};
                        }
                    }
                    .link-caret {
                        &:before,
                        &:after {
                            background-color: ${color.pureWhite};
                        }
                    }
                }
            }
        }
    }

    .spacer {
        position: relative;
        display: block;
    }

    nav,
    .spacer {
        height: ${navHeight};
        /*transition: height 0.125s linear;*/
    }

    &.scroll {
        nav {
            &.normal {
                background-color: ${color.pureWhite};
            }
        }

        /*nav,
        .spacer {
            height: 5rem;
        }*/
    }

    @media only screen and (min-width: 40rem) {
        nav {
            .router-link.logo {
                display: block;
                position: relative;
                align-self: center;

                img {
                    max-width: 6.75rem;
                    max-height: 2.25rem;
                }
            }
            .actions {
                .router-link,
                .external-link {
                    &.active,
                    &:hover {
                        border-bottom-color: ${color.primaryDark};
                    }
                }
                .settings-wrapper {
                    position: relative;

                    .button.desktop-only {
                        margin-left: 0.75rem;
                    }

                    &.signed-out {
                        display: none !important;
                    }

                    .settings-pane {
                        width: 26rem;
                        margin-top: 3.5rem;
                    }

                    &.is-open {
                        .link-caret {
                            margin-top: -0.25rem;

                            &:before {
                                transform: none;
                            }
                            &:after {
                                transform: none;
                            }
                        }

                        .settings-pane {
                            max-height: 40rem;
                        }
                    }

                    .settings-pane {
                        .contents {
                            .router-link,
                            .external-link {
                                border-bottom-color: transparent;

                                &.active {
                                    border-bottom-color: transparent !important;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    @media only screen and (min-width: 60rem) {
        nav {
            .router-link.logo {
                margin: 0 1rem;
            }

            .actions {
                .settings-wrapper {
                    .button.desktop-only {
                        margin-right: 1rem;
                    }
                }
            }
        }
    }
`;
