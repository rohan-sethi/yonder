import React from "react";
import styled from "styled-components";

export default (props: any) => {
    let playerVars =
        "Version=3&mute=1&autoplay=1&controls=0&showinfo=0&modestbranding=1&loop=1&fs=0&cc_load_policy=0&iv_load_policy=3&autohide=0";

    return (
        <StyledYouTube className="youtube-container">
            <iframe
                title="yt-embed"
                src={`http://www.youtube.com/embed/${props.url}?playlist=${props.url}&${playerVars}`}
                width="100%"
                height="100%"
                frameBorder="0"
                allowFullScreen
            />
        </StyledYouTube>
    );
};

const StyledYouTube = styled.div`
    position: absolute;
    width: 100%;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    overflow: hidden;
    width: 200%;
    height: 100%;
    padding-bottom: 56.25%;

    iframe {
        position: absolute;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;

        pointer-events: none;
    }
`;
