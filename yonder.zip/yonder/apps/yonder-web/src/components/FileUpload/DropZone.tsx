import React from "react";
import styled from "styled-components";

import { Icon, FormChangeEvent } from "..";
import { color } from "../../variables";

type Props = {
    onFilesAdded?: (files: File[]) => void;
    onFileAdded?: (files: File[]) => void;
};

type DragEvent = React.DragEvent<HTMLDivElement>;

export class DropZone extends React.Component<Props> {
    fileInputRef = React.createRef<HTMLInputElement>();

    openFileDialog = () => {
        this.fileInputRef.current!.click();
    };

    onChange = (ev: FormChangeEvent) => {
        this.addFiles(ev.target.files);

        // this ensures onChange gets triggered again if the same file(s) are chosen
        ev.target.value = null;
    };

    onDragOver = (ev: DragEvent) => {
        ev.preventDefault();

        this.setState({ highlight: true });
    };

    onDragLeave = (ev: DragEvent) => {
        ev.preventDefault();

        this.setState({ highlight: false });
    };

    onDrop = (ev: DragEvent) => {
        ev.preventDefault();

        this.addFiles(ev.dataTransfer.files);
        this.setState({ highlight: false });
    };

    addFiles = (files: FileList) => {
        let outArray: File[] = [];
        for (let i = 0; i < files.length; i++) {
            let file = files.item(i);
            outArray.push(file!);
        }

        if (this.props.onFileAdded) {
            this.props.onFileAdded(outArray);
        } else if (this.props.onFilesAdded) {
            this.props.onFilesAdded(outArray);
        }
    };

    render() {
        return (
            <StyledDropZone
                className="drop-zone"
                onDragOver={this.onDragOver}
                onDragLeave={this.onDragLeave}
                onDrop={this.onDrop}
                onClick={this.openFileDialog}
            >
                <input
                    ref={this.fileInputRef}
                    className="file-input"
                    type="file"
                    accept="image/*"
                    multiple={!!this.props.onFilesAdded}
                    onChange={this.onChange}
                />
                <div className="fancy-glow" />
                <Icon type="photo-upload" size="3rem" color={color.charcoal} />
                <span>Select or drag & drop</span>
            </StyledDropZone>
        );
    }
}

const StyledDropZone = styled.div`
    position: relative;
    height: 100%;
    width: 100%;
    font-size: 1rem;
    cursor: pointer;
    padding: 1rem;

    .file-input {
        display: none;
    }

    .icon-container {
        display: block;
        position: relative;
        z-index: 2;
        width: 100%;
        text-align: center;
        margin-bottom: 0.5rem;
    }

    .fancy-glow {
        display: block;
        position: absolute;
        width: 100%;
        height: 100%;
        background: rgb(255, 255, 255);
        background: -moz-radial-gradient(circle, rgba(255, 255, 255, 1) 25%, rgba(255, 255, 255, 0) 75%);
        background: -webkit-radial-gradient(circle, rgba(255, 255, 255, 1) 25%, rgba(255, 255, 255, 0) 75%);
        background: radial-gradient(circle, rgba(255, 255, 255, 1) 25%, rgba(255, 255, 255, 0) 75%);
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#ffffff",endColorstr="#ffffff",GradientType=1);
        opacity: 0;
        transition: opacity 0.25s linear;
    }

    span {
        display: block;
        position: relative;
        z-index: 2;
        width: 100%;
        font-size: 0.875rem;
        text-align: center;
        user-select: none;
        color: ${color.wintersGray};
        transition: color 0.125s linear;
    }

    &:hover {
        border-color: ${color.primaryDark};

        .icon-container {
            svg {
                color: ${color.primaryDark};
                fill: ${color.primaryDark};
                stroke: ${color.primaryDark};
            }
        }

        .fancy-glow {
            opacity: 1;
        }

        span {
            color: ${color.primaryDark};
        }
    }
`;
