import React from "react";
import styled from "styled-components";
import { ImageAsset } from "@yonder/db";

import { Icon, LoadingSpinner, TextInput, FormChangeEventFunction, DropZone } from "..";
import { color } from "../../variables";
import { imgSourcesFromAsset } from "../../functions";

type PPhotoThumbnail = {
    onDelete?: () => void;
    onCaptionChange?: FormChangeEventFunction;
    percentage?: number; // future use?
    showDropZone?: boolean;
    showPending?: boolean;
    onFileAdded?: (file: File[]) => void;
    onFilesAdded?: (file: File[]) => void;
};

type Props = PPhotoThumbnail & ImageAsset;
type State = {
    photoLoaded: boolean;
    isPending: boolean;
};

export class PhotoThumbnail extends React.Component<Props, State> {
    photo: HTMLImageElement | null = null;
    state: State = {
        photoLoaded: false,
        isPending: false
    };

    componentDidMount() {
        const { file, renders } = this.props;
        this.photo = new Image();
        this.photo.src = file;
        const sources = imgSourcesFromAsset(renders);
        if (sources !== null) {
            this.photo.srcset = sources.srcSet;
            this.photo.sizes = sources.sizes;
        }
        this.photo.alt = "";
        this.photo.onload = () => {
            this.setState({ photoLoaded: true });
        };
    }

    componentWillUnmount() {
        if (this.photo) {
            this.photo.onload = () => {};
        }
    }

    render() {
        const { photoLoaded, isPending } = this.state;
        const { onDelete, onCaptionChange, file, caption, showPending } = this.props;

        const onFileAdded = this.props.onFileAdded
            ? (files: File[]) => {
                  this.props.onFileAdded!(files);
                  if (showPending) {
                      this.setState({ isPending: true });
                  }
              }
            : undefined;

        const onFilesAdded = this.props.onFilesAdded
            ? (files: File[]) => {
                  this.props.onFilesAdded!(files);
                  if (showPending) {
                      this.setState({ isPending: true });
                  }
              }
            : undefined;

        const showPhoto: boolean = this.photo !== null && photoLoaded;
        const showCaption: boolean = showPhoto && !!onCaptionChange;
        const showDropZone: boolean = (!isPending && this.props.showDropZone) || false;

        return (
            <StyledPhotoThumbnail className="photo-thumbnail">
                <div className={`thumb-container ${!showDropZone && !showPhoto ? "loading" : ""}`}>
                    {showDropZone ? (
                        <DropZone onFileAdded={onFileAdded} onFilesAdded={onFilesAdded} />
                    ) : showPhoto ? (
                        <>
                            <img
                                src={this.photo!.src}
                                srcSet={this.photo!.srcset !== "" ? this.photo!.srcset : undefined}
                                sizes={this.photo!.sizes !== "" ? this.photo!.sizes : undefined}
                                alt={this.photo!.alt}
                            />
                            {onDelete && (
                                <div className="remove-button" onClick={onDelete}>
                                    <Icon type="trash" size="2rem" color={color.pureWhite} />
                                </div>
                            )}
                        </>
                    ) : (
                        <LoadingSpinner size={2} />
                    )}
                </div>
                {showCaption && (
                    <div className="thumb-caption">
                        <TextInput
                            name={file}
                            placeholder="Add a caption."
                            value={caption}
                            onChange={onCaptionChange!}
                        />
                    </div>
                )}
            </StyledPhotoThumbnail>
        );
    }
}

const StyledPhotoThumbnail = styled.div`
    display: block;
    width: 100%;
    padding: 1.5rem;
    padding-top: 3rem;

    .thumb-container {
        display: inline-block;
        vertical-align: top;
        position: relative;
        width: inherit;
        height: auto;
        background-color: ${color.fog};
        background-position: center;
        background-size: cover;
        overflow: hidden;
        cursor: pointer;

        &:before {
            content: " ";
            display: block;
            padding-top: 100%;
        }

        img {
            display: block;
            position: absolute;
            width: auto;
            height: auto;
            max-width: 100%;
            max-height: 32rem;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .drop-zone,
        .loading-spinner {
            display: flex;
            position: absolute;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            width: 100%;
            height: 100%;
            top: 0;
        }

        .remove-button {
            display: block;
            position: absolute;
            z-index: 10;
            top: 0.5rem;
            right: 0.5rem;
            cursor: pointer;
            transition: opacity 0.25s linear;
        }
    }

    .thumb-caption {
        display: block;
        position: relative;
        overflow: hidden;
        margin-bottom: 1rem;

        .input-field {
            margin: 0;
            margin-top: 1rem;
        }
    }

    @media only screen and (min-width: 60rem) {
        .thumb-container {
            .remove-button {
                opacity: 0;
                right: -8rem;
            }

            &:hover {
                .remove-button {
                    opacity: 1;
                    right: 0.5rem;
                }
            }
        }
    }
`;
