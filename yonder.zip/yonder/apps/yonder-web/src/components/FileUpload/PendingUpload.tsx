import React from "react";
import styled from "styled-components";

import { UploadProgressBar } from "./UploadProgressBar";
import { Icon } from "..";
import { color } from "../../variables";

type Props = {
    isUploading: boolean;
    percentage: number;
    label: string;
};

export const PendingUpload = (props: Props) => {
    return (
        <StyledPendingUpload>
            {props.isUploading ? (
                props.percentage < 100 ? (
                    <UploadProgressBar progress={props.percentage} />
                ) : (
                    <Icon type="check-circle" size="1rem" />
                )
            ) : (
                <UploadProgressBar progress={0} />
            )}
            <span className="filename">{props.label}</span>
        </StyledPendingUpload>
    );
};

const StyledPendingUpload = styled.div`
    height: 100%;
    width: 100%;
    background-color: ${color.pureWhite};
    border: 0.125rem solid rgb(187, 186, 186);
    border-radius: 0.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    font-size: 1rem;
    cursor: pointer;

    .filename {
        display: block;
        margin-right: 0.5rem;
        font-size: 0.5rem;
        color: #555;
    }
`;
