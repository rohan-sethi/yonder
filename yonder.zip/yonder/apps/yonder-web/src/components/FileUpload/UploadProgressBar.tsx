import React from "react";
import styled from "styled-components";

type Props = {
    progress: number;
};

export const UploadProgressBar = (props: Props) => {
    return (
        <StyledUploadProgressBar {...props}>
            <div className="progress" style={{ width: `${props.progress}%` }} />
        </StyledUploadProgressBar>
    );
};

const StyledUploadProgressBar = styled.div`
    display: block;
    width: 50%;
    height: 0.5rem;
    background-color: red;

    .progress {
        background-color: blue;
        height: 100%;
        margin: 0;
        transition: width 0.125s linear;
    }
`;
