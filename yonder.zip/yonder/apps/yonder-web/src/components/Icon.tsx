import React from "react";
import styled, { css } from "styled-components";
import SVG from "react-inlinesvg";
import * as md from "react-icons/md";
import * as fa from "react-icons/fa";

// prettier-ignore
type NavigationTypes = "arrow-up" | "arrow-right" | "arrow-down" | "arrow-left" | "upward" | "forward" | "downward" | "back" | "caret" | "menu" | "apps" | "more-horiz" | "more-vert";
// prettier-ignore
type ActionTypes = "resize-horiz" | "resize-vert" | "add" | "remove" | "close" | "check" | "stop" | "shutdown" | "refresh" | "search" | "flag" | "bookmark" | "edit" | "delete" | "share" | "download" | "upload" | "cut" | "copy" | "paste" | "play" | "cloud-upload" | "photo-upload" | "cancel" | "attention" | "tooltip-info" | "alert";
// prettier-ignore
type ObjectTypes = "mail" | "person" | "message" | "photo" | "time" | "location" | "link" | "emoji" | "star" | "star-border" | "star-half" | "check-circle" | "email" | "lock" | "copyright" | "trash" | "bed-king" | "bed-queen" | "bed-full" | "bed-twin" | "bed-futon" | "bed-bunk" | "bed-crib" | "bed-sofa-bed";
// prettier-ignore
type ServiceTypes = "google" | "instagram" | "facebook" | "twitter"

export type IconType = NavigationTypes | ActionTypes | ObjectTypes | ServiceTypes;

export type Props = {
    type: IconType;
    color?: string;
    size?: string;
    hoverColor?: string;
};

export default (props: Props) => {
    const icon = (props: Props) => {
        switch (props.type) {
            // Navigation
            case "arrow-up":
                return <md.MdExpandLess />;
            case "arrow-right":
                return <md.MdChevronRight />;
            case "arrow-down":
                return <md.MdExpandMore />;
            case "arrow-left":
                return <md.MdChevronLeft />;
            case "upward":
                return <md.MdArrowUpward />;
            case "forward":
                return <md.MdArrowForward />;
            case "downward":
                return <md.MdArrowDownward />;
            case "back":
                return <md.MdArrowBack />;
            case "caret":
                return <md.MdArrowDropDown />;
            case "menu":
                return <md.MdMenu />;
            case "apps":
                return <md.MdApps />;
            case "more-horiz":
                return <md.MdMoreHoriz />;
            case "more-vert":
                return <md.MdMoreVert />;
            // Action
            case "resize-horiz":
                return <md.MdCode />;
            case "resize-vert":
                return <md.MdUnfoldMore />;
            case "add":
                return <md.MdAdd />;
            case "remove":
                return <md.MdRemove />;
            case "close":
                return <md.MdClose />;
            case "check":
                return <md.MdCheck />;
            case "stop":
                return <md.MdDoNotDisturb />;
            case "shutdown":
                return <md.MdPowerSettingsNew />;
            case "refresh":
                return <md.MdRefresh />;
            case "search":
                return <md.MdSearch />;
            case "flag":
                return <md.MdFlag />;
            case "bookmark":
                return <md.MdBookmark />;
            case "edit":
                return <md.MdEdit />;
            case "delete":
                return <md.MdDelete />;
            case "share":
                return <md.MdShare />;
            case "download":
                return <md.MdFileDownload />;
            case "upload":
                return <md.MdFileUpload />;
            case "cut":
                return <md.MdContentCut />;
            case "copy":
                return <md.MdContentCopy />;
            case "paste":
                return <md.MdContentPaste />;
            case "play":
                return <md.MdPlayCircleFilled />;
            case "cloud-upload":
                return <md.MdCloudUpload />;
            case "photo-upload":
                return <SVG src="/img/icon-photos.svg" />;
            case "cancel":
                return <md.MdCancel />;
            //
            case "mail":
                return <md.MdMail />;
            case "person":
                return <md.MdPerson />;
            case "message":
                return <md.MdMessage />;
            case "photo":
                return <md.MdPhoto />;
            case "time":
                return <md.MdAccessTime />;
            case "location":
                return <md.MdLocationOn />;
            case "link":
                return <md.MdLink />;
            case "emoji":
                return <md.MdSentimentSatisfied />;
            case "star":
                return <md.MdStar />;
            case "star-border":
                return <md.MdStarBorder />;
            case "star-half":
                return <md.MdStarHalf />;
            case "check-circle":
                return <SVG src="/img/icon-check-circle.svg" />;
            case "copyright":
                return <md.MdCopyright />;
            // TODO: inline these svgs
            case "email":
                return <SVG src="/img/icon-email.svg" />;
            case "lock":
                return <SVG src="/img/icon-lock.svg" />;
            case "tooltip-info":
                return <SVG src="/img/icon-question.svg" />;
            case "trash":
                return <SVG src="/img/icon-trash.svg" />;
            case "alert":
                return <SVG src="/img/icon-alert.svg" />;
            case "bed-king":
                return <SVG src="/img/bed-king.svg" />;
            case "bed-queen":
                return <SVG src="/img/bed-queen.svg" />;
            case "bed-full":
                return <SVG src="/img/bed-full.svg" />;
            case "bed-twin":
                return <SVG src="/img/bed-twin.svg" />;
            case "bed-futon":
                return <SVG src="/img/bed-futon.svg" />;
            case "bed-sofa-bed":
                return <SVG src="/img/bed-sofa-bed.svg" />;
            case "bed-bunk":
                return <SVG src="/img/bed-bunk.svg" />;
            case "bed-crib":
                return <SVG src="/img/bed-crib.svg" />;
            // Social
            case "instagram":
                return <fa.FaInstagram />;
            case "facebook":
                return <fa.FaFacebookF />;
            case "twitter":
                return <fa.FaTwitter />;
            case "google":
                return <fa.FaGoogle />;
            //
            default:
                return <md.MdSentimentVeryDissatisfied />;
        }
    };

    return (
        <StyledIcon className="icon-container" {...props}>
            {icon(props)}
        </StyledIcon>
    );
};

const StyledIcon = styled.i<Props>`
    display: inline-block;
    vertical-align: middle;
    line-height: 0;
    ${(props) =>
        props.size &&
        css`
            width: ${props.size};
            height: ${props.size};
        `}

    svg {
        color: ${(props) => props.color || "#000"};
        fill: ${(props) => props.color || "#000"};
        stroke: ${(props) => props.color || "#000"};
        transition: color 0.125s linear, fill 0.125s linear, stroke 0.125s linear;
    }

    /* Fixes icons not showing in Firefox */
    svg {
        ${(props) =>
            props.size &&
            css`
                width: ${props.size};
                height: ${props.size};
            `}
    }

    &:hover {
        svg {
            color: ${(props) => props.hoverColor || props.color || "#000"};
            fill: ${(props) => props.hoverColor || props.color || "#000"};
            stroke: ${(props) => props.hoverColor || props.color || "#000"};
        }
    }
`;
