import React from "react";
import { NavLink } from "react-router-dom";

export type Props = {
    children?: React.ReactNode;
    className?: string;
    to?: string;
    label?: string;
    onClick?: () => void;
    target?: "_blank" | "_self" | "_parent" | "_top";
    rel?: "noopener" | "noreferrer" | "noopener noreferrer";
};

export const RouterLink = (props: Props) => {
    return (
        <NavLink
            to={{ pathname: props.to || window.location.pathname, search: window.location.search }}
            className={`router-link ${props.className || ""}`}
            onClick={props.onClick}
            activeClassName={window.location.pathname !== "/" ? "active" : ""}
            exact
        >
            {props.label || props.children}
            {props.label && props.children ? props.children : null}
        </NavLink>
    );
};

export const ExternalLink = (props: Props) => {
    return (
        <a
            href={props.to || "#"}
            target={props.target}
            className={"external-link " + (props.className || "")}
            onClick={props.onClick}
        >
            {props.label || props.children}
        </a>
    );
};
