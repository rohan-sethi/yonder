import React from "react";
import styled from "styled-components";
import { math } from "polished";

import { layoutSpacing, fontSize, size } from "../variables";

// ============================================================================
// Container
// ============================================================================
export type ScreenSize = "xs" | "sm" | "md" | "lg";
type PropsContainer = {
    children: React.ReactNode;
    size?: ScreenSize;
};
export const Container = (props: PropsContainer) => {
    return <StyledContainer className={`container ${props.size || ""}`}>{props.children}</StyledContainer>;
};

const gridSpacing = math(`(${layoutSpacing} / (${layoutSpacing} * 0 + 1)) * ${fontSize}`);
const StyledContainer = styled.div`
    margin: 0 auto;
    padding: 0 1.5rem;
    width: 100%;

    &.lg {
        max-width: ${math(`${gridSpacing} * 2 + ${size.lg}`)};
    }

    &.md {
        max-width: ${math(`${gridSpacing} * 2 + ${size.md}`)};
    }

    &.sm {
        max-width: ${math(`${gridSpacing} * 2 + ${size.sm}`)};
    }

    &.xs {
        max-width: ${math(`${gridSpacing} * 2 + ${size.xs}`)};
    }
`;

// ============================================================================
// Column
// ============================================================================
type ColumnSize = "auto" | "12" | "11" | "10" | "9" | "8" | "7" | "6" | "5" | "4" | "3" | "2" | "1";
type PropsColumn = {
    children: React.ReactNode;
    className?: string;
    size?: ColumnSize;
};
export const Column = (props: PropsColumn) => {
    return (
        <StyledColumn className={`column col-${props.size || "auto"} ${props.className || ""}`}>
            {props.children}
        </StyledColumn>
    );
};

const StyledColumn = styled.div`
    flex: 1;
    max-width: 100%;
    margin: 0 auto;
    /*
    padding-left: ${layoutSpacing};
    padding-right: ${layoutSpacing};
    */

    &.col-12,
    &.col-11,
    &.col-10,
    &.col-9,
    &.col-8,
    &.col-7,
    &.col-6,
    &.col-5,
    &.col-4,
    &.col-3,
    &.col-2,
    &.col-1,
    &.col-auto {
        flex: none;
    }

`;

// ============================================================================
// Columns
// ============================================================================
type RowAttributes = "gapless" | "oneline";
type PropsRow = {
    children: React.ReactNode;
    type?: RowAttributes;
};
export const Row = (props: PropsRow) => {
    return <StyledRow className={`row ${props.type || ""}`}>{props.children}</StyledRow>;
};

const StyledRow = styled.div`
    display: flex;
    flex-wrap: wrap;
    flex-direction: column;
    /*margin-left: -${layoutSpacing};
    margin-right: -${layoutSpacing};*/

    &.gapless {
        margin-left: 0;
        margin-right: 0;

        & > ${StyledColumn} {
            padding-left: 0;
            padding-right: 0;
        }
    }

    &.oneline {
        flex-wrap: nowrap;
        overflow-x: auto;
    }

    @media only screen and (min-width: 60rem) {
        flex-direction: row;

        .column {
            padding: 0 1.5rem;

            &:first-child {
                padding-left: 0;
            }

            &:last-child {
                padding-right: 0;
            }
        }
    }
`;
