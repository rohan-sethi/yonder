import React from "react";
import styled from "styled-components";
import { Marker, InfoWindow } from "react-google-maps";

type Props = {
    center: { lat: string; lng: string };
};

type State = {
    visible: boolean;
};

export default class MapMarker extends React.Component<Props, State> {
    state: State = {
        visible: true
    };

    toggleVisible = () => {
        this.setState({ visible: !this.state.visible });
    };

    render() {
        let infoWindowOptions = {
            closeBoxMargin: "1rem"
        };
        return (
            <Marker position={this.props.center} onClick={this.toggleVisible}>
                {this.state.visible && (
                    <InfoWindow onCloseClick={this.toggleVisible} {...infoWindowOptions}>
                        <StyledInfoContainer>{this.props.children}</StyledInfoContainer>
                    </InfoWindow>
                )}
            </Marker>
        );
    }
}

const StyledInfoContainer = styled.div`
    padding: 0.75rem 1rem;
    padding-top: 0.5rem;
`;
