import React from "react";
//import { GoogleMap, withScriptjs, withGoogleMap } from "react-google-maps";
import styled from "styled-components";
import { PropertyLocation, StatesUS, getStateName, PropertyPricing } from "@yonder/db";

import { Container } from "../Grid";
//import MapMarker from "./MapMarker";

//import devMap from "./devmap.png";

const GMAPS_API_KEY = process.env.REACT_APP_GMAPS_API_KEY || "";

if (GMAPS_API_KEY === "") {
    throw new Error(
        "Google Maps API Key was not found.\n Please add the following environment variable:\nREACT_APP_GMAPS_API_KEY"
    );
}

export const googleMapURL = `//maps.googleapis.com/maps/api/js?key=${GMAPS_API_KEY}`;

type Props = {
    title: string;
    pricing: PropertyPricing;
    location: PropertyLocation;
    showMarker?: boolean;
};

type State = {
    center: {
        lat: string;
        lng: string;
    };
    zoom: number;
    showMarker: boolean;
    hasClicked: boolean;
};

export default class MapEmbed extends React.Component<Props, State> {
    state: State = {
        center: {
            lat: this.props.location.lat || "",
            lng: this.props.location.long || ""
        },

        zoom: 12,
        showMarker: this.props.showMarker || true,
        hasClicked: false
    };

    activateMap = () => {
        this.setState({
            hasClicked: true
        });
    };

    render() {
        /*const mapOptions = {
            defaultCenter: this.state.center,
            defaultZoom: this.state.zoom,
            options: {
                disableDefaultUI: false,
                draggable: false,
                fullscreenControl: false,
                mapTypeControl: false,
                streetViewControl: false,
                zoomControl: false
            }
        };

        const MyGoogleMap = withScriptjs(
            withGoogleMap(() => (
                <GoogleMap {...mapOptions}>
                    {this.state.showMarker && (
                        <MapMarker center={this.state.center}>
                            <>
                                <p>{this.props.title}</p>
                                {this.props.pricing.defaultWeekday && (
                                    <span>
                                        ${this.props.pricing.defaultWeekday} / {this.props.pricing.rate}
                                    </span>
                                )}
                            </>
                        </MapMarker>
                    )}
                </GoogleMap>
            ))
        );

        const loadingElement = <div />;
        const containerEl = <div style={{ height: "48rem" }} />;*/

        const state = getStateName(this.props.location.state as StatesUS);

        return (
            <StyledMapEmbed>
                <Container size="md">
                    <h3>
                        {this.props.location.city}, {state}
                    </h3>
                    <p>{this.props.location.description}</p>
                </Container>
                <div className="map-container">
                    {/*this.state.hasClicked ? (
                        <MyGoogleMap
                            loadingElement={loadingElement}
                            containerElement={containerEl}
                            googleMapURL={googleMapURL}
                            mapElement={containerEl}
                        />
                    ) : (
                        <img className="map-placeholder" src={devMap} alt="" onClick={this.activateMap} />
                    )*/}
                </div>
            </StyledMapEmbed>
        );
    }
}

const StyledMapEmbed = styled.div`
    display: block;
    padding: 2.5rem 0;

    p {
        margin-top: 1rem;
        font-size: 1rem;
        line-height: 2;
        margin: 0 auto;
        white-space: pre-wrap;

        span {
            font-size: 1.5rem;
            font-weight: 500;
        }
    }

    .map-container {
        margin: 2.5rem 0;

        img.map-placeholder {
            display: block;
            width: 100vw;
            min-width: 80rem;
            height: auto;
            cursor: pointer;
            margin-left: 50%;
            transform: translateX(-50%);
        }
    }

    h3 {
        text-transform: uppercase;
        margin-bottom: 1rem;
    }

    @media only screen and (min-width: 40rem) {
        p {
            font-size: 1.125rem;

            span {
                font-size: 1.625rem;
            }
        }
    }

    @media only screen and (min-width: 60rem) {
        p {
            font-size: 1.25rem;

            span {
                font-size: 1.75rem;
            }
        }
    }
`;
