import { css } from "styled-components";
import { size } from "../../variables";

export const BaseLayout = css`
    .show-xs,
    .show-sm,
    .show-md,
    .show-lg {
        display: none !important;
    }

    .col-12,
    .col-11,
    .col-10,
    .col-9,
    .col-8,
    .col-7,
    .col-6,
    .col-5,
    .col-4,
    .col-3,
    .col-2,
    .col-1,
    .col-auto {
        width: 100%;
    }

    @media only screen and (min-width: 40rem) {
        .col-12,
        .col-11,
        .col-10,
        .col-9,
        .col-8,
        .col-7,
        .col-6,
        .col-5,
        .col-4,
        .col-3,
        .col-2,
        .col-1,
        .col-auto {
            width: 50%;
        }
    }
    @media only screen and (min-width: 60rem) {
        .col-12 {
            width: 100%;
        }
        .col-11 {
            width: 91.66666667%;
        }
        .col-10 {
            width: 83.33333333%;
        }
        .col-9 {
            width: 75%;
        }
        .col-8 {
            width: 66.66666667%;
        }
        .col-7 {
            width: 58.33333333%;
        }
        .col-6 {
            width: 50%;
        }
        .col-5 {
            width: 41.66666667%;
        }
        .col-4 {
            width: 33.33333333%;
        }
        .col-3 {
            width: 25%;
        }
        .col-2 {
            width: 16.66666667%;
        }
        .col-1 {
            width: 8.33333333%;
        }
        .col-auto {
            flex: 0 0 auto;
            max-width: none;
            width: auto;
        }
    }
    @media only screen and (min-width: 80rem) {
        /**/
    }

    /* Change this later */

    @media (min-width: ${size.xs}) {
        .hide-xs {
            display: none !important;
        }
        .show-xs {
            display: block !important;
        }
    }

    @media (max-width: ${size.sm}) {
        .hide-sm {
            display: none !important;
        }
        .show-sm {
            display: block !important;
        }
    }

    @media (max-width: ${size.md}) {
        .hide-md {
            display: none !important;
        }
        .show-md {
            display: block !important;
        }
    }

    @media (max-width: ${size.lg}) {
        .hide-lg {
            display: none !important;
        }
        .show-lg {
            display: block !important;
        }
    }
`;
