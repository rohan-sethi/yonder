import { createGlobalStyle } from "styled-components";

import { BaseLayout } from "./BaseLayout";
import { html, fontFamily, fontSize, color, size, veryThin } from "../../variables";

export default createGlobalStyle`
    *,
    *::before,
    *::after {
        box-sizing: inherit;
    }

    html, body {
        width: 100%;
        height: 100%;
    }

    html {
        box-sizing: border-box;
        font-size: ${html.fontSize}px;
        line-height: ${html.lineHeight};
        -webkit-tap-highlight-color: transparent;
        scrollbar-width: thin;

    }

    body {
        color: ${color.blackInk};
        font-family: ${fontFamily.nunitoSans};
        font-size: ${fontSize};
        overflow-x: hidden;
        overflow-y: auto;
        text-rendering: optimizeLegibility;
    }

    h1 {
        font-family: ${fontFamily.cabin};
        font-size: 1.75rem;
        margin: 0;
        font-weight: 600;
        letter-spacing: ${veryThin};
    }

    h2,
    h3,
    h4 {
        font-family: ${fontFamily.nunitoSans};
        margin: 0;
    }

    hr {
        border: 0;
        background-color: ${color.gray};
        height: 0.0625rem;
        outline: 0;
    }

    p {
        font-weight: 300;
        line-height: 1.25;
        margin: 0;
    }

    a {
        color: ${color.primary};
        outline: none;
        text-decoration: none;
        transition: color 0.125s linear;
        user-select: none;

        &:focus,
        &:hover,
        &:active,
        &.active {
            box-shadow: none;
            color: ${color.primaryDark};
        }
    }

    ul,
    ol {
        margin: 0.25rem 0;

        li {
            color: ${color.blackInk};
            font-family: ${fontFamily.nunitoSans};
            font-weight: 300;
            font-size: 1rem;
            line-height: 2;
        }
    }

    ul {
        list-style: none;

        li {
            padding-left: 1.25rem;
            position: relative;

            &:before {
                display: block;
                content: ' ';
                width: 0.35rem;
                height: 0.35rem;
                background-color: ${color.primary};
                vertical-align: middle;
                border-radius: 50%;
                margin-left: -1.25rem;
                position: absolute;
                top: 50%;
                transform: translateY(-50%);
            }
        }
    }

    button {
        background: none;
        border: none;
        outline: 0;
        cursor: pointer;
        user-select: none;


        &[disabled],
        &:disabled,
        &.disabled {
            cursor: auto;
        }
    }

    input,
    textarea,
    select {
        width: 100%;
        padding: 0;
        background-color: transparent;
    }

    select {
        appearance: none;
    }

    textarea {
        display: block;
        box-sizing: border-box;
        resize: none;
        line-height: 1.5;
        height: auto;
    }

    .container {
        margin: 0 auto;
        padding: 0;
        width: 100%;

        &.lg {
            max-width: ${size.lg};
        }

        &.md {
            max-width: ${size.md};
        }

        &.sm {
            max-width: ${size.sm};
        }

        &.xs {
            max-width: ${size.xs};
        }
    }

    @media only screen and (min-width: 112rem) {
        html {
            font-size: ${html.fontSizeHD};
        }
    }

    ${BaseLayout}


    .mobile-only {
        display: inherit !important;
    }
    .desktop-only {
        display: none !important;
    }

    @media only screen and (min-width: 40rem) {
        .mobile-only {
            display: none !important;
        }
        .desktop-only {
            display: inherit !important;
        }
    }
`;
