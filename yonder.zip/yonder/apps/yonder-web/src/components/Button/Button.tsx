import React from "react";
import styled from "styled-components";

import { color, veryThin } from "../../variables";
import { FormMouseClickEventFunction } from "../Form";

export type ButtonStyle = "solid" | "outline" | "outline-color" | "no-outline" | "none";

export type ButtonClickFunction = () => void;
export type Props = {
    className?: string;
    label?: string;
    disabled?: boolean;
    buttonStyle?: ButtonStyle;
    onClick?: FormMouseClickEventFunction | ButtonClickFunction;
    type?: "button" | "submit";
};

export default (props: Props) => {
    const label = props.label || "Button";
    const outProps = {
        className: `${props.buttonStyle || "solid"} ${props.className || ""}`,
        type: props.type || "button",
        disabled: props.disabled || false,
        onClick: props.onClick
    };
    if (props.buttonStyle === "none") {
        return <button {...outProps}>{label}</button>;
    }
    return <StyledButton {...outProps}>{label}</StyledButton>;
};

const StyledButton = styled.button`
    display: inline-block;
    padding: 0;
    font-size: 1rem;
    font-weight: 600;
    padding: 1rem 2rem;
    transition: background-color 0.25s linear, color 0.25s linear;
    border-radius: 0.25rem;

    &.solid {
        color: ${color.pureWhite};
        background-color: ${color.primary};
        transition: background-color 0.25s linear;

        &:hover,
        &:active {
            background-color: ${color.primaryDark};
        }
    }

    &.outline,
    &.outline-color,
    &.no-outline {
        border: ${veryThin} solid transparent;
        box-shadow: 0 0 0 0 transparent;
        transition: border-color 0.25s linear, color 0.25s linear, box-shadow 0.25s linear;
    }

    &.outline {
        color: ${color.metal};
        border-color: ${color.metal};

        &:hover,
        &:active {
            color: ${color.primaryDark};
            border-color: ${color.primaryDark};
            box-shadow: 0 0 0.25rem 0 ${color.primaryDark};
        }
    }

    &.outline-color {
        color: ${color.primary};
        border-color: ${color.primary};

        &:hover,
        &:active {
            color: ${color.primaryDark};
            border-color: ${color.primaryDark};
            box-shadow: 0 0 0.25rem 0 ${color.primaryDark};
        }
    }

    &.no-outline {
        color: ${color.primary};
        border-color: transparent;

        &:hover,
        &:active {
            color: ${color.primaryDark};
            border-color: ${color.primaryDark};
            box-shadow: 0 0 0.25rem 0 ${color.primaryDark};
        }
    }

    &[disabled],
    &:disabled,
    &.disabled {
        &.solid {
            background-color: ${color.fog};
        }
        &.outline {
            border-color: ${color.fog};
        }
        &.outline-color {
            border-color: ${color.fog};
        }
        &.no-outline {
            background-color: transparent;
        }
    }

    &.form-button,
    &.submit {
        width: 100%;
    }

    &.submit {
        margin-top: 2rem;
        margin-bottom: 0.5rem;
    }

    &.clear {
        color: ${color.primary};

        &:hover,
        &:active {
            color: ${color.primaryDark};
        }
    }
`;
