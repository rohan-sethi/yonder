import React from "react";
import styled from "styled-components";

import { Icon } from "..";
import { IconType } from "../Icon";

type Props = {
    color?: string;
    outlineColor?: string;
    hoverColor?: string;
    type?: IconType;
    onClick?: () => void;
};

export default (props: Props) => {
    const buttonProps = {
        color: props.color,
        outlineColor: props.outlineColor,
        hoverColor: props.hoverColor,
        onClick: props.onClick
    };
    return (
        <StyledButtonArrow className="button-arrow" {...buttonProps}>
            <Icon type={props.type || "forward"} size="1.5rem" color={props.color} />
        </StyledButtonArrow>
    );
};

const StyledButtonArrow = styled.button`
    .icon-container {
        position: relative;
        padding: 1.125rem;
        border-radius: 50%;
        border: 0.125rem solid ${(props: Props) => props.outlineColor || props.color || "#000"};
        transition: background-color 0.125s linear;

        svg {
            transform: translate(-50%, -50%);
        }

        :hover {
            background-color: ${(props: Props) => props.hoverColor || "rgba(255, 255, 255, 0.2)"};
        }
    }
`;
