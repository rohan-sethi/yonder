import React from "react";
import { observer, inject } from "mobx-react";

import { IconButton, Button } from "./index";
import { Icon } from "../index";
import { Props as IButton } from "./Button";
import { IContentModalStore } from "../../store";
import { color } from "../../variables";

type PModalButton = {
    modal: any;
    playButton?: boolean;
};

type Props = IButton & IContentModalStore & PModalButton;

export default inject("contentModalState")(
    observer((props: Props) => {
        const {
            openVideoIFrame,
            openVideo,
            openIFrame,
            openDialog,
            open,
            cancelButton,
            confirmButton
        } = props.contentModalState!;
        const { url, video, iframe, dialog, header, body, onConfirm } = props.modal;

        let outProps = {
            ...props,
            onClick: () => {
                if (video && iframe) {
                    return openVideoIFrame(url);
                } else if (video) {
                    return openVideo(url);
                } else if (iframe) {
                    return openIFrame(url);
                } else if (dialog) {
                    return openDialog(body, cancelButton, confirmButton, onConfirm);
                } else {
                    return open(header, body);
                }
            }
        };

        if (!!props.playButton) {
            return (
                <IconButton {...outProps}>
                    <Icon type="play" color={color.pureWhite} hoverColor="#ccc" size="4rem" />
                </IconButton>
            );
        } else {
            return <Button {...outProps} />;
        }
    })
);
