import React from "react";
import styled from "styled-components";

import { ButtonClickFunction } from "./Button";

export type Props = {
    onClick?: ButtonClickFunction;
};

export default (props: Props) => {
    return <StyledIconButton className="icon-button" {...props} />;
};

const StyledIconButton = styled.a`
    display: block;
    background: transparent;
    border: none;
    padding: 0;

    .icon-container {
        cursor: pointer;
    }
`;
