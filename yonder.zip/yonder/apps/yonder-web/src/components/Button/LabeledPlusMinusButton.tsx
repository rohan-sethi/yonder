import React from "react";
import styled from "styled-components";

import { color } from "../../variables";
import { PlusMinusButton, Props as IPlusMinusButton } from "./PlusMinusButton";

export type Props = IPlusMinusButton & {
    children?: React.ReactNode;
    label?: string;
    color?: string;
    disabled?: boolean;
    className?: string;
};

export const LabeledPlusMinusButton = (props: Props) => {
    const { type, size, children, label } = props;
    return (
        <StyledPlusMinusButton {...props} onClick={undefined}>
            <PlusMinusButton size={size} type={type} onClick={props.onClick} />
            <div className="button-label" onClick={props.onClick}>
                {!children ? label || "" : children}
            </div>
        </StyledPlusMinusButton>
    );
};

const StyledPlusMinusButton = styled.div`
    display: inline-block;
    width: 100%;
    text-align: left !important;

    .button-label {
        display: inline-block;
        padding-left: 0.75rem;
        vertical-align: middle;
        align-self: center;
        color: ${color.charcoal};
        transition: color 0.25s linear;
        cursor: pointer;
        user-select: none;
        line-height: 2.5rem;
    }

    button.small + .button-label {
        line-height: 1.5rem;
    }

    :hover {
        button {
            color: ${color.primaryDark};
            border-color: ${color.primaryDark};
            box-shadow: 0 0 0.25rem 0 ${color.primaryDark};

            .minus,
            .plus,
            .plus:after {
                background-color: ${color.primaryDark};
            }
        }

        .button-label {
            color: ${color.primaryDark};
        }
    }

    button.small {
        align-self: center;
        min-height: 1.5rem;
        min-width: 1.5rem;
        max-height: 1.5rem;
        max-width: 1.5rem;
    }
`;
