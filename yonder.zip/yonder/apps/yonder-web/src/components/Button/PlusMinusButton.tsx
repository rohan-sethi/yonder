import React from "react";
import styled from "styled-components";

import { color } from "../../variables";

export type Props = {
    type: "plus" | "minus";
    size?: "small" | "large";
    onClick?: any;
};

export const PlusMinusButton = (props: Props) => {
    const { type, size } = props;
    return (
        <StyledPlusMinusButton className={size || "large"} onClick={props.onClick}>
            <div className={type} />
        </StyledPlusMinusButton>
    );
};

const StyledPlusMinusButton = styled.button`
    display: inline-block;
    vertical-align: middle;
    height: 2.5rem;
    width: 2.5rem;
    padding: 0;
    border-radius: 50%;
    cursor: pointer;
    user-select: none;

    border: 1px solid transparent;
    box-shadow: 0 0 0 0 transparent;
    transition: border-color 0.25s linear, color 0.25s linear, box-shadow 0.25s linear;

    color: ${color.charcoal};
    border-color: ${color.charcoal};

    .plus,
    .minus,
    .plus:after {
        display: block;
        margin: auto;
        background-color: ${color.charcoal};
        transition: background-color 0.25s linear;
        width: 1.125rem;
        height: 1px;
    }

    .plus:after {
        content: " ";
        transform: rotate(90deg);
    }

    &.small {
        height: 1.5rem;
        width: 1.5rem;

        .plus,
        .minus,
        .plus:after {
            width: 0.75rem;
        }
    }

    &:hover {
        color: ${color.primaryDark};
        border-color: ${color.primaryDark};
        box-shadow: 0 0 0.25rem 0 ${color.primaryDark};

        .minus,
        .plus,
        .plus:after {
            background-color: ${color.primaryDark};
        }
    }
`;
