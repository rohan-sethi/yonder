import React from "react";
import styled, { Keyframes } from "styled-components";
import { fadeIn } from "../animations";

type Props = {
    children?: React.ReactNode;
    animation?: Keyframes;
};

export const PageTransition = (props: Props) => {
    return <Transition animation={props.animation || fadeIn}>{props.children}</Transition>;
};

const Transition = styled.div<Props>`
    animation: ${(props) => props.animation} 0.5s;
`;
