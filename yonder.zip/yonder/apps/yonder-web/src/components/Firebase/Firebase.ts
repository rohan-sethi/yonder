import firebase from "firebase/app";
import "firebase/app";
import "firebase/auth";
import "firebase/storage";
//import "firebase/firestore";

import uuidv1 from "uuid/v1";

import config from "./FirebaseConfig";

const LISTING_PHOTOS = "listing-photos";
const USER_PHOTOS = "user-photos";

// Unused currently. "Stay Logged In" always defaults to true
export const localStorageStayLoggedIn: boolean = window.localStorage.getItem("__stayLoggedIn") === "true";

export enum FirebaseProvider {
    Google,
    Facebook,
    Twitter,
    Microsoft
}

type AllowedProviders = firebase.auth.FacebookAuthProvider | firebase.auth.GoogleAuthProvider;

export interface IFirebase {
    app: firebase.app.App;
    auth: firebase.auth.Auth;
    storage: firebase.storage.Storage;
    //db: firebase.firestore.Firestore;

    googleProvider: firebase.auth.GoogleAuthProvider;
    facebookProvider: firebase.auth.FacebookAuthProvider;

    getProvider(inProvider: FirebaseProvider): AllowedProviders;
    setStayLoggedIn(inValue: boolean): void;
    doSignInWithCredentials(credentials: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential>;
    doCreateUserWithEmailAndPassword(email: string, password: string): Promise<firebase.auth.UserCredential>;
    doSignInWithEmailAndPassword(email: string, password: string): Promise<firebase.auth.UserCredential>;
    doProviderSignIn(inProvider: FirebaseProvider): Promise<firebase.auth.UserCredential>;
    doSignOut(): Promise<void>;
    doPasswordReset(email: string): Promise<void>;
    doUserReauthenticate(currentPassword: string): Promise<firebase.auth.UserCredential>;
    doPasswordUpdate(password: string): Promise<void>;
    doEmailUpdate(email: string): Promise<void>;
    doUserPhotoImageUpload(
        file: File,
        onProgress: (percentage: number) => void,
        onSuccess: (url: string, uuid: string) => void,
        onError: (err: Error) => void
    ): void;
    doListingImageUpload(
        file: File,
        onProgress: (percentage: number) => void,
        onSuccess: (url: string, uuid: string) => void,
        onError: (err: Error) => void
    ): void;
    getUploadProgress(snapshot: firebase.storage.UploadTaskSnapshot): number;
    handleSameEmail(error: any, password: string): Promise<void>;
}

class Firebase implements IFirebase {
    app: firebase.app.App = firebase.initializeApp(config);
    auth: firebase.auth.Auth = this.app.auth();
    storage: firebase.storage.Storage = this.app.storage();
    //db: firebase.firestore.Firestore =  = firebase.firestore();

    googleProvider: firebase.auth.GoogleAuthProvider = new firebase.auth.GoogleAuthProvider();
    facebookProvider: firebase.auth.FacebookAuthProvider = new firebase.auth.FacebookAuthProvider();
    _stayLoggedIn: boolean = true;

    constructor() {
        this.googleProvider.addScope("email");
        this.googleProvider.addScope("profile");
        this.googleProvider.addScope("openid");
        this.googleProvider.setCustomParameters({
            login_hint: "user@example.com"
        });

        this.facebookProvider.addScope("email");
    }

    getProvider = (inProvider: FirebaseProvider) => {
        switch (inProvider) {
            case FirebaseProvider.Facebook:
                return this.facebookProvider;

            default:
                return this.googleProvider;
        }
    };

    setStayLoggedIn = (inValue: boolean) => {
        this._stayLoggedIn = inValue;
        window.localStorage.setItem("__stayLoggedIn", `${inValue}`);
    };

    /*getCredential = (provider: FirebaseProvider, token: string) => {
        switch (provider) {
            case FirebaseProvider.Facebook:
                return firebase.auth.FacebookAuthProvider.credential(token);
            default:
                return firebase.auth.GoogleAuthProvider.credential(token);
        }
    };*/

    _withControlledAuthPersistence = async (returnFunction: any) => {
        let persistence: firebase.auth.Auth.Persistence;
        if (this._stayLoggedIn) {
            persistence = firebase.auth.Auth.Persistence.LOCAL;
        } else {
            persistence = firebase.auth.Auth.Persistence.NONE;
        }
        try {
            await this.auth.setPersistence(persistence);
            return returnFunction;
        } catch (err) {
            throw err;
        }
    };

    doSignInWithCredentials = (credentials: firebase.auth.AuthCredential) =>
        this._withControlledAuthPersistence(this.auth.signInWithCredential(credentials));

    doCreateUserWithEmailAndPassword = (email: string, password: string) =>
        this._withControlledAuthPersistence(this.auth.createUserWithEmailAndPassword(email, password));

    doSignInWithEmailAndPassword = (email: string, password: string) =>
        this._withControlledAuthPersistence(this.auth.signInWithEmailAndPassword(email, password));

    doProviderSignIn = (inProvider: FirebaseProvider) =>
        this._withControlledAuthPersistence(this.auth.signInWithPopup(this.getProvider(inProvider)));

    doSignOut = () => this.auth.signOut();

    doPasswordReset = (email: string) => this.auth.sendPasswordResetEmail(email);

    doUserReauthenticate = (currentPassword: string) => {
        let cred = firebase.auth.EmailAuthProvider.credential(this.auth.currentUser!.email!, currentPassword);
        return this.auth.currentUser!.reauthenticateWithCredential(cred);
    };

    doPasswordUpdate = (password: string) => this.auth.currentUser!.updatePassword(password);
    doEmailUpdate = (email: string) => this.auth.currentUser!.updateEmail(email);

    doUserPhotoImageUpload = (
        file: File,
        onProgress: (percentage: number) => void,
        onSuccess: (url: string, uuid: string) => void,
        onError: (err: Error) => void
    ) => this._doImageUpload(USER_PHOTOS, file, onProgress, onSuccess, onError);

    doListingImageUpload = (
        file: File,
        onProgress: (percentage: number) => void,
        onSuccess: (url: string, uuid: string) => void,
        onError: (err: Error) => void
    ) => this._doImageUpload(LISTING_PHOTOS, file, onProgress, onSuccess, onError);

    getUploadProgress = (snapshot: firebase.storage.UploadTaskSnapshot) => {
        return (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
    };

    handleSameEmail = async (error: any, password: string) => {
        // An error happened.
        if (error.code === "auth/account-exists-with-different-credential") {
            // TODO
            // https://firebase.google.com/docs/auth/web/google-signin#handling-account-exists-with-different-credential-errors
            console.log(error);
        }
    };

    //

    _doImageUpload = (
        firebaseFolder: string,
        file: File,
        onProgress: (percentage: number) => void,
        onSuccess: (url: string, uuid: string) => void,
        onError: (err: Error) => void
    ) => {
        const uuid = uuidv1();
        const name = `${firebaseFolder}/${uuid}`;
        const metaData = {
            contentType: file.type
        };

        let uploadTask = this.storage
            .ref()
            .child(name)
            .put(file, metaData);

        uploadTask.on(
            "state_changed",
            (snapshot: any) => {
                const percentage = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                switch (snapshot.state) {
                    case firebase.storage.TaskState.RUNNING: {
                        onProgress(percentage);
                        break;
                    }
                }
            },
            onError,
            async () => {
                try {
                    const snapshot = await uploadTask;
                    const meta = await snapshot.ref.getMetadata();
                    // public url
                    const url = `https://storage.googleapis.com/${meta.bucket}/${meta.fullPath}`;

                    onSuccess(url, uuid);
                } catch (err) {
                    onError(err);
                }
            }
        );
    };
}

const firebaseInstance = new Firebase();

export { firebaseInstance };
