import React from "react";
import { Redirect } from "react-router-dom";
import { inject, observer } from "mobx-react";

import { IFirebaseStore } from "../../store";
import { FullPageSpinner } from "..";

export const withAuthorization = (Component: React.ComponentType<any>, inProps?: any) => {
    return inject("firebaseState")(
        observer((props: IFirebaseStore) => {
            const { firebaseInitialized, isSignedIn } = props.firebaseState!;

            if (!firebaseInitialized) {
                return <FullPageSpinner />;
            }

            if (!isSignedIn) {
                return <Redirect to="/" />;
            }
            return <Component {...props} {...inProps} />;
        })
    );
};
