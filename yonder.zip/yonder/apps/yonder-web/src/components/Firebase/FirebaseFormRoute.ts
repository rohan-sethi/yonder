export enum FirebaseFormRoute {
    SignIn,
    SignUp,
    SignUpEmail,
    PasswordReset
}
