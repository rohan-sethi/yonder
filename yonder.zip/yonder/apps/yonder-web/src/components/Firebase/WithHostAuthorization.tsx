import React from "react";
import { Redirect } from "react-router-dom";
import { inject, observer } from "mobx-react";
import { UserPermissions } from "@yonder/db";

import { IFirebaseStore } from "../../store";
import { FullPageSpinner } from "..";

type Props = IFirebaseStore;

export const withHostAuthorization = (Component: React.ComponentType<any>, inProps?: any) => {
    return inject("firebaseState")(
        observer((props: Props) => {
            const { firebaseInitialized, isSignedIn, dbUser } = props.firebaseState!;

            if (!firebaseInitialized) {
                return <FullPageSpinner />;
            }

            if (
                (!isSignedIn && !dbUser.permissions) ||
                (dbUser.permissions !== UserPermissions.Host && dbUser.permissions !== UserPermissions.Admin)
            ) {
                return <Redirect to="/" />;
            }

            return <Component {...props} {...inProps} />;
        })
    );
};
