export interface FirebaseUser {
    displayName?: string;
    displayInitials: string;
    emailVerified: boolean;
    photoURL?: string;
    isAnonymous: boolean;
    uid: string;
    providerData: any;
}
