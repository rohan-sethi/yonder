const API_KEY = process.env.REACT_APP_FIREBASE_API_KEY || "";
const PROJECT_ID = process.env.REACT_APP_FIREBASE_PROJECT_ID || "";
const APP_ID = process.env.REACT_APP_FIREBASE_APP_ID || ":::";

const SENDER_ID = APP_ID.split(":")[1] || "";

if (API_KEY === "" || PROJECT_ID === "" || APP_ID === ":::" || SENDER_ID === "") {
    throw new Error(
        "Firebase could not be configured correctly.\n Please add the following environment variables:\nREACT_APP_FIREBASE_API_KEY\nREACT_APP_FIREBASE_PROJECT_ID\nREACT_APP_FIREBASE_APP_ID"
    );
}

const devConfig = {
    apiKey: API_KEY,
    authDomain: `${PROJECT_ID}.firebaseapp.com`,
    databaseURL: `https://${PROJECT_ID}.firebaseio.com`,
    projectId: PROJECT_ID,
    storageBucket: `${PROJECT_ID}.appspot.com`,
    messagingSenderId: SENDER_ID,
    appId: APP_ID
};

const prodConfig = devConfig; // TODO

export default (process.env.NODE_ENV === "production" ? prodConfig : devConfig);
