import React from "react";
import styled from "styled-components";
import { LoadingSpinner, Base } from "./index";

export const FullPageSpinner = () => {
    return (
        <StyledPageSpinner>
            <Base />
            <LoadingSpinner />
        </StyledPageSpinner>
    );
};

const StyledPageSpinner = styled.div`
    display: block;
    position: fixed;
    width: 100vw;
    height: 100vh;
`;
