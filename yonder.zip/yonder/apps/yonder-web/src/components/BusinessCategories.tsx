import React from "react";
import styled from "styled-components";

export class BusinessCategories extends React.Component {
    render() {
        return (
            <StyledCategories>
                <h4>What is Yonder Experience Category?</h4>
                <p>
                    Yonder offers four unique experience categories: Farm, Ranch, Vineyard, and Escape. Each one invites
                    guests to step into an authentic nature immersive experience, learn something new and see the world
                    through fresh eyes.
                </p>

                <h4>FARM</h4>
                <p>
                    Farm operations that offer overnight accommodations and/or activities, and connect guests to natural
                    food systems and animals.
                </p>

                <h4>RANCH</h4>
                <p>
                    Ranch operations that offer overnight accommodations and/or activities, and connect guests with
                    horsemanship and cattle handling.
                </p>

                <h4>VINEYARD</h4>
                <p>
                    Vineyards that offer overnight accommodations and/or activities, and connect guests to the
                    experience of growing, harvesting or producing wines.
                </p>

                <h4>ESCAPE</h4>
                <p>
                    Properties that offer overnight accommodations/and or activities, and provide guests with direct
                    access to nature and local wildlife.
                </p>
            </StyledCategories>
        );
    }
}

const StyledCategories = styled.div`
    h4:first-child {
        margin-bottom: 1rem;
    }
    p {
        margin-bottom: 1rem;

        :first-of-type {
            margin-bottom: 2rem;
        }
    }
`;
