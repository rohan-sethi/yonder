import React from "react";
import styled from "styled-components";
import { loadSix, rotateRight } from "../animations";
import { color } from "../variables";

type SpinnerSize = 1 | 2 | 3;
type Props = {
    size?: SpinnerSize;
    style?: React.CSSProperties;
};

export default (props: Props) => {
    let size = props.size || 3;
    return (
        <StyledLoadingSpinner className="loading-spinner" {...props}>
            <div
                style={{
                    fontSize: `${size}rem`,
                    width: `${size}rem`,
                    height: `${size}rem`
                }}
            >
                <span>Loading...</span>
            </div>
        </StyledLoadingSpinner>
    );
};

const speed = 2;

const StyledLoadingSpinner = styled.div`
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    width: 100%;
    height: 100%;

    > div {
        display: block;
        color: ${color.primaryDark};
        overflow: hidden;
        border-radius: 50%;
        animation: ${loadSix} ${speed}s infinite ease, ${rotateRight} ${speed}s infinite ease;

        span {
            font-size: 0.125rem;
            visibility: hidden;
        }
    }
`;
