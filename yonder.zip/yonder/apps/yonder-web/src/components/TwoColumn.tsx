import React from "react";
import styled from "styled-components";

import { color } from "../variables";
import { Section, ModalButton, ImageBackground } from "./index";
import { IImageElement } from "../interfaces";

type Props = {
    title?: string[];
    body?: string;
    image: IImageElement;
    reverse?: boolean;
    third?: boolean;
    styleB?: boolean;
    modal?: any;
};

export default (props: Props) => {
    let title = props.title!.map((line, i) => <h2 key={i}>{line}</h2>) || undefined;
    let reverse = props.reverse ? "reverse" : "";
    let third = props.third ? " third" : "";
    let styleB = props.styleB ? " style-b" : "";

    return (
        <Section>
            <StyledTwoColumnLayout className={reverse + third + styleB}>
                <div className="image-side">
                    {props.modal && <ModalButton modal={props.modal} playButton />}
                    <ImageBackground {...props.image} />
                </div>
                {!props.styleB && <div className="spacer" />}
                <div className="content-side">
                    <StyledContent className={styleB}>
                        {title}
                        <p>{props.body || "undefined"}</p>
                        <hr />
                    </StyledContent>
                </div>
            </StyledTwoColumnLayout>
        </Section>
    );
};

const StyledContent = styled.div`
    padding: 2rem;

    h2 {
        font-size: 1.5rem;
    }

    p {
        font-size: 1rem;
    }

    h2 + p {
        margin-top: 1rem;
    }

    hr {
        max-width: 12rem;
        background-color: ${color.blackInk};
        height: 0.1rem;
        margin-top: 1.5rem;
        margin-left: 0;
    }

    &.style-b {
        hr {
            background-color: ${color.pureWhite};
        }
    }

    @media only screen and (min-width: 40rem) {
        padding: 2.5rem;

        h2 {
            font-size: 2rem;
        }

        p {
            font-size: 1.25rem;
        }

        hr {
            margin-top: 2rem;
        }
    }
    @media only screen and (min-width: 60rem) {
        position: absolute;
        padding: 0 3rem;
        top: 50%;
        transform: translateY(-50%);

        h2 {
            font-size: 2rem;
        }

        p {
            font-size: 1.25rem;
        }

        hr {
            margin-top: 2.5rem;
        }
    }
`;

const StyledTwoColumnLayout = styled.div`
    display: block;
    width: 100%;
    height: auto;

    .spacer {
        display: none;
    }

    .image-side,
    .content-side {
        color: ${color.pureWhite};
        vertical-align: top;
    }

    .image-side {
        width: 100%;
        height: 26rem;
        margin: 0;
        padding: 0;
        display: block;
        position: relative;
        overflow: hidden;

        .icon-button {
            display: block;
            position: absolute;
            width: 100%;
            height: 100%;
            z-index: 10;

            .icon-container {
                display: block;
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
            }
        }

        .image-background {
            padding: 2rem;
        }
    }

    .content-side {
        width: 100%;
        display: block;
        position: relative;
        text-align: left;
        background-color: ${color.pureWhite};
        color: ${color.blackInk};
    }

    &.reverse {
        flex-direction: row-reverse;

        .content-side {
            background-color: ${color.pureWhite};
        }
    }

    &.style-b {
        box-shadow: 0 0 1rem rgba(0, 0, 0, 0.1);

        .content-side {
            color: ${color.pureWhite};
        }
    }

    @media only screen and (min-width: 60rem) {
        display: flex;
        flex-direction: row;
        justify-content: space-between;

        .spacer {
            display: block;
            width: 2rem;
            background-color: ${color.pureWhite};
        }
        .content-side {
            width: 100%;
            display: block;
            position: relative;
            background-color: ${color.pureWhite};
            color: ${color.blackInk};

            .content-container {
                position: absolute;
                padding: 0 3rem;
                top: 50%;
                transform: translateY(-50%);
            }
        }

        &.third {
            .image-side {
                width: ${(100 * 5) / 7}%;
            }
        }
    }
`;
