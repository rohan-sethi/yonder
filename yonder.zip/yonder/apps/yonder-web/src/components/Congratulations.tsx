import React from "react";
import styled from "styled-components";
import confetti from "canvas-confetti";

type Props = {
    name?: string;
};

export const Congratulations = (props: Props) => {
    confetti({ zIndex: 99999 });
    return (
        <StyledCongratulations>
            <h2>Thanks {props.name}!</h2>
            <p>
                Congratulations you’ve completed your first listing! Now keep the party going, and Yonder over to your
                next listing.
            </p>
        </StyledCongratulations>
    );
};

const StyledCongratulations = styled.div`
    text-align: center;
    font-size: 1.125rem;

    h2 {
        margin: 2rem 0;
    }

    p {
        margin-bottom: 4rem;
    }

    @media only screen and (min-width: 40rem) {
        max-width: 34rem;
        margin: 3rem auto;
        padding: 0 2rem;
    }
`;
