import React from "react";
import styled from "styled-components";
import { inject, observer } from "mobx-react";

//import { color } from "../variables";
import { Base, Navigation, Footer, PageTransition, FullPageSpinner } from "./index";
import { color } from "../variables";
import { INavigationStore, IFirebaseStore } from "../store";

type PageProps = {
    backgroundColor?: string;
    clearNavigation?: boolean;
    showFooter?: boolean;
    swapNavStyleAt?: number;
    noTransition?: boolean;
};

type Props = PageProps & INavigationStore & IFirebaseStore;

@inject("firebaseState")
@observer
export default class Page extends React.Component<Props> {
    componentDidMount() {
        // make sure IE works!
        if (window.scrollTo) {
            window.scrollTo(0, 0);
        }
    }
    render() {
        const { firebaseInitialized } = this.props.firebaseState!;
        if (!firebaseInitialized) {
            return <FullPageSpinner />;
        }
        const { backgroundColor } = this.props;
        document.body.style.backgroundColor = backgroundColor || color.pureWhite;

        const innerPage = (
            <>
                {this.props.children}
                {this.props.showFooter && <Footer />}
            </>
        );

        return (
            <StyledPage>
                <Base />
                <Navigation
                    navStyle={this.props.clearNavigation ? "clear" : "normal"}
                    swapNavStyleAt={this.props.swapNavStyleAt}
                />
                {!!this.props.noTransition ? innerPage : <PageTransition>{innerPage}</PageTransition>}
            </StyledPage>
        );
    }
}

const StyledPage = styled.div`
    display: block;
    position: relative;
    width: 100%;
    height: 100%;
`;
