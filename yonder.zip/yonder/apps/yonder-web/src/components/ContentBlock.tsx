import React from "react";
import styled from "styled-components";

type Props = {
    header?: string | React.ReactNode;
    url?: string;
    alt?: string;
    body?: string | React.ReactNode;
};

export default class ContentBlock extends React.Component<Props> {
    render() {
        const { header, url, alt, body } = this.props;
        return (
            <StyledContentBlock className="content-block">
                {header && <h2>{header}</h2>}
                {url && <img src={url} alt={alt || ""} />}
                <p>{body}</p>
            </StyledContentBlock>
        );
    }
}

const StyledContentBlock = styled.div`
    display: block;
    text-align: center;
`;
