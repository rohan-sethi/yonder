import React from "react";
import styled from "styled-components";

type Props = {
    header?: string;
    body: string;
};

export const TooltipModal = (props: Props) => {
    const { header, body } = props;
    return (
        <StyledTooltipModal>
            {header && <h4>{header}</h4>}
            <p>{body}</p>
        </StyledTooltipModal>
    );
};

const StyledTooltipModal = styled.div`
    h4:first-child {
        margin-bottom: 1rem;
    }
`;
