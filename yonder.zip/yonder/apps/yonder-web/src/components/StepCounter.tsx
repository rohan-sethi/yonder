import React from "react";
import styled from "styled-components";

import { color } from "../variables";
import { expandWidth } from "../animations/expand-width";
import { gradient } from "../styles";

type StyledProps = {
    startWidth: number;
    currentWidth: number;
};

type Props = {
    label: string;
    from: number;
    to: number;
    max: number;
};

export const StepCounter = (props: Props) => {
    if (props.from > props.max || props.to > props.max) {
        throw new Error("progress cannot exceed max progress");
    }
    if (props.max < 0 || props.from < 0 || props.to < 0) {
        throw new Error("progress value cannot be less than 0");
    }

    const startWidth: number = (props.from / props.max) * 100;
    const currentWidth: number = (props.to / props.max) * 100;

    return (
        <StyledStepCounter className="step-counter">
            <Meter startWidth={startWidth} currentWidth={currentWidth}>
                <div className="progress" />
            </Meter>
            <div className="meter-label">{props.label}</div>
        </StyledStepCounter>
    );
};

const StyledStepCounter = styled.div`
    margin-bottom: 1.5rem;

    .meter-label {
        display: block;
        color: ${color.dark};
        font-size: 0.875rem;
        font-weight: 600;
        margin: 1rem 0;
    }
`;

const Meter = styled.div<StyledProps>`
    height: 0.5rem;
    width: 100%;
    background: ${color.gray};
    border-radius: 0.25rem;
    margin-bottom: 1rem;

    .progress {
        height: 100%;
        width: ${(props) => props.currentWidth}%;
        border-radius: 0.25rem;
        animation: ${(props) => expandWidth(props.startWidth, props.currentWidth)} 1s;

        ${gradient(color.yonderGreen, color.primary, 90)}
    }
`;
