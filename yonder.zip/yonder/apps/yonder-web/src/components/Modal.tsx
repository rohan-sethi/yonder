import React from "react";
import styled from "styled-components";
import { rgba } from "polished";
import { observer, inject } from "mobx-react";
import { fadeIn, fadeOut, modalOpen, modalClose } from "../animations";
import { IVideoElement } from "../interfaces";

import { IContentModalState } from "../store/ContentModalState";
import { IFirebaseState } from "../store/FirebaseState";
import { Button } from ".";
import { color, thin, veryThin } from "../variables";

type ModalType = "content" | "iframe" | "video" | "youtube" | "dialog";

type Props = {
    type: ModalType;
    contentModalState?: IContentModalState;
    firebaseState?: IFirebaseState;
    isYoutube?: boolean;
};

type State = {
    isClosing: boolean;
    dialogConfirmed: boolean;
};

@inject("contentModalState", "firebaseState")
@observer
export default class Modal extends React.Component<Props, State> {
    state: State = {
        isClosing: false,
        dialogConfirmed: false
    };

    componentDidMount() {
        document.addEventListener("keyup", this.handleKeyPress);
        this.props.contentModalState!.setCloseCallback(this.startClose);
    }

    componentWillUnmount() {
        document.removeEventListener("keyup", this.handleKeyPress);
        this.props.contentModalState!.setCloseCallback(() => {});
    }

    handleKeyPress = (ev: KeyboardEvent) => {
        if (ev.keyCode === 27) this.startClose();
    };

    startClose = () => {
        this.setState({ isClosing: true });
    };

    close = () => {
        if (this.state.isClosing) {
            this.setState({ isClosing: false });
            this.props.contentModalState!.close();
        }
    };

    onCancel = () => {
        this.startClose();
        this.props.contentModalState!.dialogCancelCallback();
    };

    onConfirm = () => {
        this.startClose();
        this.props.contentModalState!.dialogConfirmCallback();
    };

    renderVideoIframe = () => {
        const { url } = this.props.contentModalState!;
        const iframeProps = {
            allowFullScreen: true,
            gesture: "media",
            allow: "encrypted-media",
            title: "Video player",
            //src: "https://www.youtube.com/embed/" + url + "?autoplay=1&showinfo=0&enablejsapi=1&widgetid=1",
            src: url,
            id: "modal-video-player",
            width: 640,
            height: 360,
            frameBorder: 0
        };
        return <iframe className={this.state.isClosing ? "hidden" : ""} title="modal-iframe" {...iframeProps} />;
    };

    renderVideo = () => {
        const { url } = this.props.contentModalState!;
        const videoTag: IVideoElement = {
            width: 640,
            height: 360,
            controls: true,
            preLoad: "auto",
            autoPlay: true
        };

        return (
            <video {...videoTag}>
                <source src={url} type="video/mp4" />
                Your browser does not support the video tag.
            </video>
        );
    };

    renderIframe = () => {
        const { url } = this.props.contentModalState!;
        return <ModalIframe src={url} title="modal-iframe-video" />;
    };

    renderDialogButtons = () => {
        const { cancelButton, confirmButton } = this.props.contentModalState!;
        return (
            <DialogButtons>
                <Button label={cancelButton} buttonStyle="outline" onClick={this.onCancel} />
                <Button label={confirmButton} onClick={this.onConfirm} />
            </DialogButtons>
        );
    };

    renderHeaderBodyContent = () => {
        const { header, body, dialog } = this.props.contentModalState!;
        return (
            <div className="modal-inner">
                <button className="close-button" onClick={this.startClose}>
                    <span />
                    <span />
                </button>
                {header && <h2>{header}</h2>}
                {body && <div className="main-content">{body}</div>}
                {dialog && this.renderDialogButtons()}
            </div>
        );
    };

    renderInnerModal = () => {
        const { iframe, video } = this.props.contentModalState!;
        if (video) {
            if (iframe) return this.renderVideoIframe();

            return this.renderVideo();
        }

        if (iframe) return this.renderIframe();

        return this.renderHeaderBodyContent();
    };

    render() {
        const { iframe, video, dialog } = this.props.contentModalState!;
        const isClosing = this.state.isClosing ? " is-closing" : "";
        const hasIframe = iframe || video ? " has-iframe" : "";
        const hasVideo = video ? " has-video" : "";
        const isDialog = dialog ? " is-dialog" : "";

        return (
            <ModalWrap>
                <ModalBackground className={isClosing} onClick={this.startClose} />
                <ModalDialog className={isClosing}>
                    <ModalContent className={hasIframe + hasVideo + isDialog} onAnimationEnd={this.close}>
                        {this.renderInnerModal()}
                    </ModalContent>
                </ModalDialog>
            </ModalWrap>
        );
    }
}

const ModalContent = styled.div`
    display: block;
    position: relative;
    margin: auto;
    padding: 0;
    background-color: ${color.pureWhite};
    max-width: 45rem;
    height: auto;
    max-height: 100vh;
    outline: 0;
    border: ${thin} solid ${color.fog};
    opacity: 0;
    box-shadow: 0 0.25rem 0.5rem 0 rgba(0, 0, 0, 0.2), 0 0.375rem 1.25rem 0 rgba(0, 0, 0, 0.19);
    animation: ${modalOpen} 0.25s forwards;
    overflow-y: auto;

    &.has-iframe {
        border: none;
        width: auto;
        min-width: 0;
        max-width: 880px; /* Pixels are used instead of rems because the iframe content is separate from the html font-size */
        height: 720px;
        overflow: hidden;
        border-radius: 0;

        &.has-video {
            min-width: 95vw;
            min-height: 53.4375vw;
            width: 95vw;
            height: 53.4375vw;
            background-color: #000;

            video,
            iframe {
                display: block;
                top: 0;
                left: 0;
                width: 100.02%;
                height: 100%;

                &.hidden {
                    display: none;
                }
            }
        }
    }

    .modal-inner {
        padding: 2rem;

        h2 {
            text-align: center;
        }
        .main-content {
            white-space: pre-wrap;
        }
    }

    &.is-dialog {
        max-width: 32rem;

        .modal-inner {
            padding-top: 4rem;
        }
    }

    hr {
        margin-top: 2rem;
        margin-bottom: 2rem;
        height: 0.125rem;
        background-color: #333; /* theme.primary */
    }

    @media only screen and (min-width: 40rem) {
        &.has-iframe {
            &.has-video {
                min-width: 90vw;
                min-height: 50.625vw;
                width: 90vw;
                height: 50.625vw;
            }
        }
    }
`;

const ModalBackground = styled.div`
    animation: ${fadeIn} 0.33s;
    background: ${rgba(color.blackInk, 0.5)};
    opacity: 1;
    display: block;
    position: absolute;
    top: 0;
    left: 0;
    width: 200vw;
    height: 200vh;
    cursor: pointer;

    &.is-closing {
        animation-name: ${fadeOut};
        opacity: 0;
    }
`;

const ModalDialog = styled.div`
    z-index: 99999;
    display: table-cell;
    vertical-align: middle;

    &.is-closing {
        ${ModalContent} {
            animation-name: ${modalClose};
        }
    }
`;

const ModalWrap = styled.div`
    z-index: 99995;
    /*display: none;*/
    display: table;
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;

    .close-button {
        display: block;
        position: absolute;
        width: 1.5rem;
        height: 1rem;
        z-index: 100;
        right: 1rem;
        top: 1.25rem;

        span {
            display: block;
            position: absolute;
            width: 100%;
            height: ${veryThin};
            left: 0;
            background-color: ${color.charcoal};
            transform: rotate(0deg);
            transition: width 0.25s ease-in-out, background-color 0.25s ease-in-out, transform 0.25s ease-in-out,
                top 0.25s ease-in-out, bottom 0.25s ease-in-out;

            &:first-child {
                top: calc(0.5rem - (${veryThin} / 2));
                transform: rotate(45deg);
            }

            &:last-child {
                bottom: calc(0.5rem - (${veryThin} / 2));
                transform: rotate(-45deg);
            }
        }

        &:hover,
        &:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }
    }

    .closed {
        display: none;
    }

    .container {
        padding: 0.125rem 1rem;
    }
`;

const ModalIframe = styled.iframe`
    display: block;
    top: 0;
    left: 0;
    width: 100.02%;
    height: 100%;
    border: 0;
    background-color: ${color.pureWhite};
`;

const DialogButtons = styled.div`
    display: flex;
    justify-content: flex-end;
    margin-top: 2rem;

    button {
        font-size: 1rem;
        margin: 0.25rem;
        padding: 0.5rem 1rem;
        border-radius: 0.25rem;
    }
`;
