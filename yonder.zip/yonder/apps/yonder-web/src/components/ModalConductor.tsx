import React from "react";
import { observer, inject } from "mobx-react";

import { Modal } from "./index";
import { IContentModalStore } from "../store";

export default inject("contentModalState")(
    observer((props: IContentModalStore) => {
        const { isOpen } = props.contentModalState!;
        if (isOpen) {
            return <Modal type="content" />;
        }
        return null;
    })
);
