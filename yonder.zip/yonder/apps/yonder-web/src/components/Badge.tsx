import React from "react";
import styled from "styled-components";

import { color } from "../variables";

type Props = {
    count: number;
};

export default (props: Props) => {
    return props.count > 0 ? <StyledBadge>{props.count}</StyledBadge> : <span />;
};

export const StyledBadge = styled.span`
    display: inline-block;
    vertical-align: middle;
    font-size: 0.75rem;
    padding: 0.25rem 0.425rem;
    padding-top: 0.325rem;
    background-color: ${color.primaryDark};
    color: ${color.pureWhite};
    line-height: 1;
    margin-left: 0.5rem;
    border-radius: 1rem;
    transition: background-color 0.125s linear;

    :hover {
        background-color: ${color.primary};
    }
`;
