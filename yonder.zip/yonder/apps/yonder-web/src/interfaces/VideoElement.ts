export interface IVideoElement {
    src?: string;
    width?: number;
    height?: number;
    autoPlay?: boolean;
    controls?: boolean;
    loop?: boolean;
    muted?: boolean;
    poster?: string;
    preLoad?: "auto" | "metadata" | "none";
}
