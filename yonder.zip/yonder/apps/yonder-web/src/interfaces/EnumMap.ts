import { ID } from "@yonder/db";

export type LabeledEnum = {
    name: string;
    label: string;
};

export interface EnumMap {
    [id: number]: string;
}

export type EnumLabelFunction = (enumObj: any) => string;

export type LabeledActivity = LabeledEnum & { id: ID };
