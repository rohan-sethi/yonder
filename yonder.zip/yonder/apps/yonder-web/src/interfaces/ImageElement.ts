export interface IImageElement {
    alt: string;
    src?: string;
    srcSet?: string;
    width?: number;
    height?: number;
}
