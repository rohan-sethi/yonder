// TODO: Refactor, make more typescript-y
// TODO: Evaluate need for isEdgeChromium

/**
 * A magical class file that evaluates the browser being used and stores some information about it (mostly for MS IE/Edge)
 * TODO: Firefox version (although probably not necessary), Opera versions, Safari
 */
class CrossBrowser {
    isEdge: boolean;
    ieVersion: number;
    isIE: boolean;
    isEdgeIE: boolean;
    isFirefox: boolean;
    isOpera: boolean;
    isElectron: boolean;
    isChromium: boolean;

    /**
     * Everything is stored when the class is constructed
     */
    constructor() {
        const userAgent: string = navigator.userAgent;

        // Detects if MS Edge
        this.isEdge = /Edge/.test(userAgent);
        //this.docMode = document.documentMode;

        // Get the IE version & set the isIE var (true/false)
        this.ieVersion = this._getIeVersion(userAgent);
        this.isIE = this.ieVersion !== -1;

        // Set the isEdgeIE var
        this.isEdgeIE = this.isEdge || this.isIE;

        // Detects if using Firefox (no version checking yet)
        this.isFirefox = /firefox/i.test(userAgent);

        // Opera uses Chromium now, but they use document.body, so they need to be excluded when Chromium is detected
        this.isOpera = /OPR/.test(userAgent);

        // Test for Electron (which uses Chromium as well, but checking for it may be useful
        this.isElectron = /electron/i.test(userAgent);

        // Chromium uses document.documentElement for the clientHeight and document.body for everything else like with Edge,
        // so we want to detect them at the same time
        this.isChromium = this._isChromium();

        // logging
        /*if (this.isIE) {
            console.log('MS IE Version: ' + this.ieVersion);
        } else if (this.isEdge) {
            console.log('MS Edge');
        } else if (this.isFirefox) {
            console.log('Firefox');
        } else if (this.isOpera) {
            console.log('Opera');
        } else if (this.isChromium) {
            console.log('Chromium');
        }*/
    }

    /**
     * Gets the document body element
     * @return {HTMLElement} the correct element based on the browser
     */
    getDocumentElement = (): HTMLElement => {
        if (this.isEdge || this.isChromium) return document.body;
        else return document.documentElement;
    };

    /**
     * Utility function that returns the correct clientHeight variable
     * Always use this function if the clientHeight is needed
     * @return {number} The client's height
     */
    getClientHeight = (): number => {
        if (this.isEdgeIE || this.isChromium) return document.documentElement.clientHeight;
        else return this.getDocumentElement().clientHeight;
    };

    /**
     * Returns the IE version, and gets it from various places
     * @return {number} the IE version number (6-11), or -1 if not IE
     */
    _getIeVersion = (userAgent: string): number => {
        let ieVersion = -1;

        // Start by detecting IE versions 6-9 (React only supports 9+ natively anyway)
        if (/MSIE (\d+\.\d+);/.test(userAgent)) {
            let re = new RegExp("MSIE ([0-9]{1,}[.0-9]{0,})");
            if (re.exec(userAgent) != null) ieVersion = parseFloat(RegExp.$1);
        }

        // IE 10 is dected from navigator.appVersion instead of navigator.userAgent...
        // Must've been a wild & crazy time at MS
        if (ieVersion === -1) {
            if (navigator.appVersion.indexOf("MSIE 10") !== -1) ieVersion = 10;
        }

        // IE 11 is detected from navigator.userAgent again
        // Different once again since the MS devs were each going for their own Balmer peaks...
        if (ieVersion === -1) {
            let trident = !!userAgent.match(/Trident\/7.0/);
            let rv = userAgent.indexOf("rv:11.0");
            if (trident && rv !== -1) ieVersion = 11;
        }

        return ieVersion;
    };

    /**
     * Hack to detect Chromium, since it uses document.documentElement for the clientHeight like IE & Edge
     * @return {boolean} true if Chromium was detected
     */
    _isChromium = (): boolean => {
        // Check for "Chromium" in the plugin names
        if (navigator.plugins) {
            for (let i = 0; i < navigator.plugins.length; i++) {
                // Although Opera uses Chromium now in 2018, they use the document.body element instead of document.documentElement
                if (navigator.plugins[i].name.substr(0, 8) === "Chromium" && !this.isOpera) return true;
            }
        }
        return false;
    };
}

const crossBrowser = new CrossBrowser();

export default crossBrowser;
