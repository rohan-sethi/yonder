export function shortenListString(str: string, len: number, delimeter?: string): string {
    let lastIndex: number = 0;
    let del: string = delimeter || " ";
    let shortened: boolean = false;

    while (str.length > len && lastIndex !== -1) {
        lastIndex = str.lastIndexOf(del);
        str = str.substr(0, lastIndex - 1);
        shortened = true;
    }

    if (shortened) {
        str += "...";
    }

    return str;
}
