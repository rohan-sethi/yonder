export function listToMatrix<T>(list: T[], itemsPerSubArray: number): T[][] {
    let matrix: T[][] = [];

    for (let i = 0, k = -1; i < list.length; i++) {
        if (i % itemsPerSubArray === 0) {
            k++;
            matrix[k] = [];
        }

        matrix[k].push(list[i]);
    }

    return matrix;
}

type OrderedObject = {
    order: number;
};

export function sortList<T extends OrderedObject>(list: T[]): T[] {
    return list.slice().sort((first, second) => first.order - second.order);
}

/**
 * Returns true if item was added, otherwise false if not found
 * Note: This does not allow for duplicates
 * @param array the array to add to
 * @param item the item to add
 */
export function addToArray<T>(array: T[], item: T, callback: () => void, forceAdd: boolean = false): boolean {
    const index = array.indexOf(item);
    if (forceAdd || index === -1) {
        array.push(item);
        callback();
        return true;
    }
    return false;
}

/**
 * Returns true if item was removed, otherwise false if not found
 * @param array the array to add to
 * @param item the item to add
 */
export function removeIndexFromArray<T>(array: T[], index: number, callback: () => void): boolean {
    if (index !== -1) {
        array.splice(index, 1);
        callback();
        return true;
    }
    return false;
}
/**
 * Returns true if item was removed, otherwise false if not found
 * @param array the array to add to
 * @param item the item to add
 */
export function removeFromArray<T>(array: T[], item: T, callback: () => void): boolean {
    const index: number = array.indexOf(item);
    return removeIndexFromArray(array, index, callback);
}

/**
 * Returns true if item was removed, otherwise false if not found
 * @param array the array to add to
 * @param item the item to add
 */
export function removeLastFromArray<T>(array: T[]): boolean {
    return array.pop() !== undefined;
}

export function spaceSeparateStringArray(stringArray: string[]) {
    const stringList = stringArray.map((string, i) => {
        if (i !== stringArray.length - 1) {
            return ` ${string}`;
        } else {
            return ` and ${string}`;
        }
    });

    return stringList;
}
