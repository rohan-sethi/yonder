import { SelectOption, KeyPressEvent, reSpecialChars, reNumbers } from "../components/Form";
import { EnumMap, EnumLabelFunction, LabeledEnum } from "../interfaces";

export function stringToNumber(value?: string): number | null {
    return value !== "" && value !== undefined ? parseInt(value) : null;
}

/**
 * Takes in a string and returns a monetary value
 * Any extra period and decimal places past position 2 are stripped out
 */
export function stringToMonetary(value?: string): number | string | null {
    if (value === "" || value === undefined) return null;

    const valueSplit: string[] = value.split(".");
    const hasDecimal: boolean = valueSplit[1] !== undefined;
    if (!hasDecimal) return parseInt(value);

    // Reformat the string so it only has 1 period and 2 decimal places
    const decimalValue: string = hasDecimal ? valueSplit[1].substr(0, 2) : "";
    const toParse: string = `${valueSplit[0]}${hasDecimal ? "." + decimalValue : ""}`;

    // Just return the string value if the last character is "."
    const lastChar: string = toParse.substr(-1);
    if (lastChar === ".") return toParse;

    // toFixed ensures a leading zero like ".20" doesn't get stripped out
    return parseFloat(toParse).toFixed(decimalValue.length);
}

export function enumToInputOptions<T extends EnumMap>(enumObj: T, labelFunc: EnumLabelFunction): LabeledEnum[] {
    return Object.values(enumObj).map((value: string) => {
        return {
            name: value,
            label: labelFunc(value)
        } as LabeledEnum;
    });
}

export function enumToSelectOptions<T extends EnumMap>(
    enumObj: T,
    labelFunc: EnumLabelFunction,
    placeholder: boolean = true,
    placeholderValue?: string,
    placeholderLabel?: string
): SelectOption[] {
    let result: SelectOption[] = Object.entries(enumObj).map(([key, value]) => {
        return {
            value,
            label: labelFunc(enumObj[key])
        } as SelectOption;
    });
    if (placeholder) {
        result.unshift({
            value: placeholderValue || "none",
            label: placeholderLabel || "—"
        });
    }
    return result;
}

export function stringsToSelectOptions(options: string[]): SelectOption[] {
    return options.map((option: string) => {
        return {
            value: option
                .toLowerCase()
                .replace(/ /g, "-")
                .replace(/&/g, "and"),
            label: option
        } as SelectOption;
    });
}

export function isStringInvalid(
    string?: string | null,
    disallowSpecialChars: boolean = false,
    disallowNumbers: boolean = false
): boolean {
    if (string === null || string === undefined || string === "") return true;

    let ret: boolean = string.startsWith(" ");
    if (disallowSpecialChars) {
        ret = reSpecialChars.test(string) || ret;
    }
    if (disallowNumbers) {
        ret = reNumbers.test(string) || ret;
    }
    return ret;
}

export function focusOnInput(ev: KeyPressEvent, indexOffset: number) {
    const { form } = ev.target as any;
    const index = Array.prototype.indexOf.call(form, ev.target);
    form.elements[index + indexOffset].focus();
}

export const focusOnNextInput = (ev: KeyPressEvent) => focusOnInput(ev, 1);

export const focusOnPreviousInput = (ev: KeyPressEvent) => focusOnInput(ev, -1);
