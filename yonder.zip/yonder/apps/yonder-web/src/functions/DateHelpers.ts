export function toShortMonthUS(date: Date): string {
    let options: Intl.DateTimeFormatOptions = {
        month: "short"
    };
    return new Intl.DateTimeFormat("en-US", options).format(date);
}

export function toLongMonthUS(date: Date): string {
    let options: Intl.DateTimeFormatOptions = {
        month: "long"
    };
    return new Intl.DateTimeFormat("en-US", options).format(date);
}

type DateFormat = "mmm dd, yyyy";

export function getDateString(date: Date, format: DateFormat = "mmm dd, yyyy"): string {
    switch (format) {
        case "mmm dd, yyyy": {
            let month = toShortMonthUS(date);
            let day = date.getDate();
            let year = date.getFullYear();

            return `${month} ${day} ${year}`;
        }
    }
}

export function dateOnly(date: Date): string {
    return date.toLocaleDateString();
}
