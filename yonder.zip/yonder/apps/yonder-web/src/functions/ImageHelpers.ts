import { ImageAsset, AssetRendersMap } from "@yonder/db";

export function randomImage(width: number = 600, height?: number): string {
    const IMAGE_RANGE = 600;
    let id = Math.round(Math.random() * IMAGE_RANGE);
    //return `https://picsum.photos/id/${id}/${width}/${height || width}`;
    return `https://picsum.photos/${width}/${height || width}?random=${id}`;
}

type ImgSources = {
    srcSet: string;
    sizes: string;
};

export function imgSourcesFromAsset(renders?: AssetRendersMap): ImgSources | null {
    if (renders === undefined) return null;

    const rendersArray = Object.values(renders);
    if (rendersArray.length === 0) return null;

    // convert the renders into an array & sort from small to large (by width)
    const values = rendersArray.sort((a: ImageAsset, b: ImageAsset) => {
        if (a.width === undefined || b.width === undefined) return 0;
        if (a.width > b.width) return 1;
        if (b.width > a.width) return -1;
        return 0;
    });

    const filtered = values.filter((render: ImageAsset) => !!render.file && !!render.width);

    // parse the srcSet string
    const srcSet = filtered
        .map((render: ImageAsset) => {
            return `${render.file} ${render.width}w`;
        })
        .join(", ");

    // parse the sizes string
    const sizes = filtered
        .map((render: ImageAsset, i: number) => {
            const width: number = render.width ? render.width : 0;
            return `${i < filtered.length - 1 ? `(max-width: ${width}px) ` : ""}${width >= 40 ? width - 40 : 0}px`;
        })
        .join(", ");

    return {
        srcSet,
        sizes
    };
}
