export default {
    iframe: true,
    url: "/forms/host.html"
};
