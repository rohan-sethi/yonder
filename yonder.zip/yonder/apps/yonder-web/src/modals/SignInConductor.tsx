import React from "react";
import { observer, inject } from "mobx-react";

import { FirebaseFormRoute } from "../components";
import { IContentModalStore, IFirebaseStore } from "../store";

import { SignInForm, SignUpForm, PasswordResetForm, SignUpEmailForm } from "../layouts/Forms";

type Props = IContentModalStore & IFirebaseStore;

@inject("contentModalState", "firebaseState")
@observer
class VisibleForm extends React.Component<Props> {
    componentDidMount() {
        this.props.firebaseState!.setRoute(FirebaseFormRoute.SignIn);
    }

    render() {
        const { formRoute } = this.props.firebaseState!;
        switch (formRoute) {
            case FirebaseFormRoute.SignUp:
                return <SignUpForm />;
            case FirebaseFormRoute.SignUpEmail:
                return <SignUpEmailForm />;
            case FirebaseFormRoute.PasswordReset:
                return <PasswordResetForm />;
            default:
                return <SignInForm />;
        }
    }
}

export default {
    body: <VisibleForm />
};
