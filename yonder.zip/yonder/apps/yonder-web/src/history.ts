import { createBrowserHistory } from "history";

const _history = createBrowserHistory();

export const history = _history;
