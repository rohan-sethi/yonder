import { css, FlattenSimpleInterpolation } from "styled-components";

export function gradient(fromColor: string, toColor: string, degrees: number = 0): FlattenSimpleInterpolation {
    if (degrees < 0 || degrees > 360) {
        throw new Error("set degrees between 0 and 360");
    }
    return css`
        background: rgb(255, 255, 255);
        background: -moz-linear-gradient(${degrees}deg, ${fromColor} 0%, ${toColor} 100%);
        background: -webkit-linear-gradient(${degrees}deg, ${fromColor} 0%, ${toColor} 100%);
        background: linear-gradient(${degrees}deg, ${fromColor} 0%, ${toColor} 100%);
    `;
}
