import React from "react";
import styled from "styled-components";

import { Page, Section } from "../components";

export class LayoutSupport extends React.Component {
    render() {
        return (
            <Page>
                <StyledHome>
                    <Section>Support</Section>
                </StyledHome>
            </Page>
        );
    }
}

const StyledHome = styled.div`
    display: block;
`;
