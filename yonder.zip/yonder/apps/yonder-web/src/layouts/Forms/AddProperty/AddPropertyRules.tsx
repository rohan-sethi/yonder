import React from "react";
import { observer, inject } from "mobx-react";

import { IAddPropertyStore } from "../../../store";
import {
    StyledDashboard,
    FormChangeEvent,
    InputTextArea,
    limitTextAreaInput,
    KeyPressEvent,
    MouseClickEvent,
    InputYesNo,
    ListTextBox,
    TwoColumnYesNoInputs,
    SafetyRequirements
} from "../../../components";
import { AddPropertyActions } from "./AddPropertyActions";

type Props = IAddPropertyStore;

type State = {
    placeholder?: string;
};

@inject("addPropertyState")
@observer
export class AddPropertyRules extends React.Component<Props, State> {
    state: State = {
        placeholder: ""
    };

    update = this.props.addPropertyState!.updateProperty;

    onYesNoChange = (ev: MouseClickEvent, name: string, value: boolean) => {
        ev.preventDefault();

        switch (name) {
            case "hasRequiredSafetyFeatures":
                this.update({
                    hasRequiredSafetyFeatures: value
                });
                break;
            case "suitableForChildren":
                this.update({
                    suitableForChildren: value
                });
                break;
            case "suitableForInfants":
                this.update({
                    suitableForInfants: value
                });
                break;
            case "handicapAccessible":
                this.update({
                    handicapAccessible: value
                });
                break;
            case "surveillanceOrRecordingDeviceOnProperty":
                this.update({
                    surveillanceOrRecordingDeviceOnProperty: value
                });
                break;
            case "petsAllowed":
                this.update({
                    petsAllowed: value
                });
                break;
            case "potentialForNoise":
                this.update({
                    potentialForNoise: value
                });
                break;
            case "smokingAllowed":
                this.update({
                    smokingAllowed: value
                });
                break;
        }
    };

    onChange = (ev: FormChangeEvent | MouseClickEvent) => {
        if (ev.preventDefault) {
            ev.preventDefault();
        }

        const { name, value } = ev.target;

        switch (name) {
            case "suitableForInfantsDescription":
                this.update({
                    petsAndAnimalsPolicyDescription: limitTextAreaInput(value)
                });
                break;
            case "suitableForChildrenDescription":
                this.update({
                    suitableForChildrenDescription: limitTextAreaInput(value)
                });
                break;
            case "surveillanceOrRecordingDeviceDescription":
                this.update({
                    surveillanceOrRecordingDeviceDescription: limitTextAreaInput(value)
                });
                break;
            case "petsAndAnimalsPolicyDescription":
                this.update({
                    petsAndAnimalsPolicyDescription: limitTextAreaInput(value)
                });
                break;
            case "potentialNoiseDescription":
                this.update({
                    potentialNoiseDescription: limitTextAreaInput(value)
                });
                break;
            case "smokingPolicyDescription":
                this.update({
                    smokingPolicyDescription: limitTextAreaInput(value)
                });
                break;
            case "safetyRequirements":
                this.update({
                    hasRequiredSafetyFeatures: value
                });
        }
    };

    onFieldAdd = async (ev?: KeyPressEvent | MouseClickEvent) => {
        if (ev) {
            ev.preventDefault();
        }

        const { addPropertyRule } = this.props.addPropertyState!;
        const { propertyRules } = this.props.addPropertyState!.property;

        addPropertyRule("");

        this.props.addPropertyState!.updateProperty({
            propertyRules: propertyRules
        });
    };

    onFieldRemove = (ev: KeyPressEvent | MouseClickEvent, i?: number) => {
        ev.preventDefault();

        const { removePropertyRuleIndex, updateProperty, removeLastPropertyRule } = this.props.addPropertyState!;
        const { propertyRules } = this.props.addPropertyState!.property;

        if (propertyRules.length > 1) {
            if (i === undefined) {
                removeLastPropertyRule();
            } else {
                removePropertyRuleIndex(i);
            }
            updateProperty({
                propertyRules: propertyRules
            });
        }
    };

    onRulesChange = (ev: FormChangeEvent, i: number) => {
        const { value } = ev.target;
        const { updateProperty } = this.props.addPropertyState!;

        let propertyRules = this.props.addPropertyState!.property.propertyRules;

        propertyRules[i] = value;

        updateProperty({
            propertyRules: propertyRules
        });
    };

    render() {
        const { property } = this.props.addPropertyState!;

        return (
            <StyledDashboard>
                <form>
                    <SafetyRequirements checked={property.hasRequiredSafetyFeatures} onChange={this.onChange} />
                    <hr />
                    <TwoColumnYesNoInputs>
                        <div className="input-yes-no-with-description">
                            <InputYesNo
                                name="suitableForInfants"
                                descriptor="Suitable for babies/toddlers age 4 and under?"
                                value={property.suitableForInfants}
                                onClick={this.onYesNoChange}
                                padded={false}
                            />
                            <InputTextArea
                                name="suitableForInfantsDescription"
                                value={property.suitableForInfantsDescription}
                                onChange={this.onChange}
                                rows={4}
                                maxRows={6}
                                placeholder="Any notes for guests?"
                                maxLength={240}
                            />
                        </div>
                        <div className="input-yes-no-with-description">
                            <InputYesNo
                                name="suitableForChildren"
                                descriptor="Suitable for children 5 and older?"
                                value={property.suitableForChildren}
                                onClick={this.onYesNoChange}
                                padded={false}
                            />
                            <InputTextArea
                                name="suitableForChildrenDescription"
                                value={property.suitableForChildrenDescription}
                                onChange={this.onChange}
                                rows={4}
                                maxRows={6}
                                placeholder="Any notes for guests?"
                                maxLength={240}
                            />
                        </div>
                        <div className="input-yes-no-with-description">
                            <InputYesNo
                                name="petsAllowed"
                                descriptor="Pets Allowed?"
                                value={property.petsAllowed}
                                onClick={this.onYesNoChange}
                                padded={false}
                            />
                            <InputTextArea
                                name="petsAndAnimalsPolicyDescription"
                                value={property.petsAndAnimalsPolicyDescription}
                                onChange={this.onChange}
                                rows={4}
                                maxRows={6}
                                placeholder="Any notes for guests?"
                                maxLength={2400}
                            />
                        </div>
                        <div className="input-yes-no-with-description">
                            <InputYesNo
                                name="surveillanceOrRecordingDeviceOnProperty"
                                descriptor="Surveillance or Recording Device on the Property?"
                                value={property.surveillanceOrRecordingDeviceOnProperty}
                                onClick={this.onYesNoChange}
                                padded={false}
                            />
                            <InputTextArea
                                name="surveillanceOrRecordingDeviceDescription"
                                value={property.surveillanceOrRecordingDeviceDescription}
                                onChange={this.onChange}
                                rows={4}
                                maxRows={6}
                                placeholder="Any notes for guests?"
                                maxLength={240}
                            />
                        </div>

                        <div className="input-yes-no-with-description">
                            <InputYesNo
                                name="smokingAllowed"
                                descriptor="Smoking Allowed?"
                                value={property.smokingAllowed}
                                onClick={this.onYesNoChange}
                                padded={false}
                            />
                            <InputTextArea
                                name="smokingPolicyDescription"
                                value={property.smokingPolicyDescription}
                                onChange={this.onChange}
                                rows={4}
                                maxRows={6}
                                placeholder="Any notes for guests?"
                                maxLength={240}
                            />
                        </div>
                        <div className="input-yes-no-with-description">
                            <InputYesNo
                                name="potentialForNoise"
                                descriptor="Any potential noise?"
                                value={property.potentialForNoise}
                                onClick={this.onYesNoChange}
                                padded={false}
                            />
                            <InputTextArea
                                name="potentialNoiseDescription"
                                value={property.potentialNoiseDescription}
                                onChange={this.onChange}
                                rows={4}
                                maxRows={6}
                                placeholder="Any notes for guests?"
                                maxLength={240}
                            />
                        </div>
                    </TwoColumnYesNoInputs>

                    <ListTextBox
                        name="propertyRules"
                        label="Are there any other property rules that you would like to include?"
                        collection={property.propertyRules}
                        onFieldAdd={this.onFieldAdd}
                        onFieldRemove={this.onFieldRemove}
                        onChange={this.onRulesChange}
                        placeholder="Example: Please lock the garage door."
                        inputType="input-field"
                        className="three-quarter"
                    />

                    <AddPropertyActions />
                </form>
            </StyledDashboard>
        );
    }
}
