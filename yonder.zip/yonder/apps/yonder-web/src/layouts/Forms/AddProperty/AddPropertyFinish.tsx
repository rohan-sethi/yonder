import React from "react";
import { observer, inject } from "mobx-react";
import { ListingProgress } from "@yonder/db";

import { IAddPropertyStore, IContentModalStore, IFirebaseStore } from "../../../store";
import { StyledDashboard, MouseClickEvent, Button, Congratulations, LoadingSpinner } from "../../../components";
import { history } from "../../../history";
import { StyledAddPropertyActivityActions } from "./AddPropertyActions";

type Props = IFirebaseStore & IAddPropertyStore & IContentModalStore;

type State = {
    showSpinner: boolean;
};

@inject("firebaseState", "addPropertyState", "contentModalState")
@observer
export class AddPropertyFinish extends React.Component<Props> {
    state: State = {
        showSpinner: false
    };

    save = this.props.addPropertyState!.saveProperty;

    onSave = async (ev: MouseClickEvent) => {
        ev.preventDefault();

        const { property, setSectionComplete, setListingInReview } = this.props.addPropertyState!;
        const { refreshStaysActivities } = this.props.firebaseState!;

        const prevListingProgress = property.listingProgress;

        setSectionComplete();
        setListingInReview();
        this.setState({
            showSpinner: true
        });
        try {
            await this.save();
            if (prevListingProgress === ListingProgress.Draft) {
                await refreshStaysActivities(true);
            }

            const { dbUser, organizationStays, organizationActivities } = this.props.firebaseState!;

            const inReviewStays = organizationStays.filter((stay) => stay.listingProgress === ListingProgress.InReview);
            const inReviewActivities = organizationActivities.filter(
                (activity) => activity.listingProgress === ListingProgress.InReview
            );
            let count: number = inReviewStays.length + inReviewActivities.length;

            const { open } = this.props.contentModalState!;
            if (prevListingProgress === ListingProgress.Draft && count === 1) {
                open("", <Congratulations name={dbUser.firstName} />);
            }
            history.push("/dash/listings");
        } catch (err) {
            console.log(err);
        }
    };

    render() {
        //const { getListingComplete } = this.props.addPropertyState!;
        //const submitDisabled: boolean = !getListingComplete();
        return (
            <StyledDashboard>
                <hr />
                {this.state.showSpinner ? (
                    <LoadingSpinner />
                ) : (
                    <StyledAddPropertyActivityActions>
                        <Button
                            label="Finish and submit"
                            //disabled={submitDisabled}
                            onClick={this.onSave}
                            buttonStyle="solid"
                        />
                    </StyledAddPropertyActivityActions>
                )}
            </StyledDashboard>
        );
    }
}
