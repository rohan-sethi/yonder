import React from "react";
import { observer, inject } from "mobx-react";
import { Keywords, getKeywordLabel } from "@yonder/db";

import { IAddPropertyStore } from "../../../store";
import { StyledDashboard, FormChangeEvent, InputCheckbox } from "../../../components";
import { enumToInputOptions } from "../../../functions";
import { LabeledEnum } from "../../../interfaces";
import { AddPropertyActions } from "./AddPropertyActions";

type Props = IAddPropertyStore;

@inject("addPropertyState")
@observer
export class AddPropertyKeywords extends React.Component<Props> {
    keywords: LabeledEnum[] = enumToInputOptions(Keywords, getKeywordLabel);

    update = this.props.addPropertyState!.updateProperty;
    save = this.props.addPropertyState!.saveProperty;

    onChange = (ev: FormChangeEvent) => {
        const { value } = ev.target;
        const { addKeyword, removeKeyword } = this.props.addPropertyState!;
        const keyword: Keywords = ev.target.name;

        if (value) {
            addKeyword(keyword);
        } else {
            removeKeyword(keyword);
        }
    };

    render() {
        const { property } = this.props.addPropertyState!;

        const checkboxes = this.keywords.map((keyword: LabeledEnum, i: number) => {
            const { name, label } = keyword;
            let checked: boolean = false;
            if (property.keywords) {
                checked = property.keywords.includes(name as Keywords);
            }
            return (
                <InputCheckbox
                    groupName="keywords"
                    name={name}
                    label={label}
                    onChange={this.onChange}
                    checked={checked}
                    key={i}
                />
            );
        });

        return (
            <StyledDashboard>
                <form>
                    {checkboxes}

                    <AddPropertyActions />
                </form>
            </StyledDashboard>
        );
    }
}
