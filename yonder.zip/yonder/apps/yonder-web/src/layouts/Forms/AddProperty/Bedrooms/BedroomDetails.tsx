import React from "react";
import styled from "styled-components";

import { PropertyBedroom, getBedTypeLabel, BedTypes } from "@yonder/db";
import {
    ButtonRow,
    Icon,
    FormChangeEventFunction,
    MouseClickEvent,
    FormButton,
    SelectInput,
    SelectOption,
    TextInput,
    InputTextArea,
    LabeledPlusMinusButton,
    StyledAccordion
} from "../../../../components";
import { enumToSelectOptions } from "../../../../functions";
import { color } from "../../../../variables";
import { IconType } from "../../../../components/Icon";

type Props = {
    roomNumber: number;
    bedroom: PropertyBedroom;
    onAddBed: (roomIndex: number, ev?: MouseClickEvent) => void;
    onRemoveBed: (ev: MouseClickEvent, roomIndex: number) => void;
    onBedChange: (ev: FormChangeEventFunction, bedTypeIndex: number, roomIndex: number) => void;
    onChange: (ev: FormChangeEventFunction, roomIndex: number) => void;
    onSave: () => void;
    onDelete: (ev: MouseClickEvent, roomIndex: number) => void;
    commonSpace?: boolean;
};

type State = {
    displayDetails: boolean;
};

export class BedroomDetails extends React.Component<Props, State> {
    bedTypeOptions: SelectOption[] = enumToSelectOptions(BedTypes, getBedTypeLabel);

    state: State = {
        displayDetails: false
    };

    onChangeBedroomDisplay = (ev: React.MouseEvent) => {
        ev.preventDefault();

        const { displayDetails } = this.state;
        this.setState({
            displayDetails: !displayDetails
        });
    };

    render() {
        const {
            roomNumber,
            bedroom,
            onAddBed,
            onRemoveBed,
            onBedChange,
            onChange,
            onSave,
            onDelete,
            commonSpace
        } = this.props;
        const { displayDetails } = this.state;
        const roomIndex = roomNumber - 1;

        const bedTypeIcons = bedroom.bedTypes.map((bedType: BedTypes, i: number) => {
            if (!bedType || bedType === undefined) return "";

            const type = bedType.split("_").join("-") as IconType;
            return <Icon key={i} type={type} color={color.charcoal} />;
        });

        const bedTypeSelectInputs = bedroom.bedTypes.map((bedType: BedTypes, bedTypeIndex: number) => {
            return (
                <SelectInput
                    key={bedTypeIndex}
                    name="bedType"
                    value={bedType || "none"}
                    options={this.bedTypeOptions}
                    onChange={(ev) => onBedChange(ev, bedTypeIndex, roomIndex)}
                />
            );
        });

        const accordionLabel = !!displayDetails ? "Collapse" : "Expand to enter response";
        const accordionClass = !!displayDetails ? "minus" : "plus";
        const roomLabel = !commonSpace ? `Bedroom ${roomNumber}` : `Room ${roomNumber}`;
        return (
            <StyledBedroomDetails key={roomNumber}>
                <div className="header" onClick={(ev: React.MouseEvent) => this.onChangeBedroomDisplay(ev)}>
                    <p>{bedroom.name || roomLabel}</p>

                    <div className="button-toggle">
                        <label className="accordion-label" htmlFor={`room-${roomNumber}`}>
                            {accordionLabel}
                        </label>
                        <button id={`room-${roomNumber}`}>
                            <div className={accordionClass} />
                        </button>
                    </div>
                </div>

                {!!displayDetails && (
                    <div className="display-details">
                        <p>Bed Type</p>
                        {(bedroom.bedTypes.length > 0 || bedroom.bedTypes[0] !== undefined) && (
                            <div className="bed-icons">{bedTypeIcons}</div>
                        )}
                        {bedTypeSelectInputs}
                        <ButtonRow>
                            <LabeledPlusMinusButton
                                label="Add another bed"
                                type="plus"
                                size="small"
                                onClick={(ev: MouseClickEvent) => onAddBed(roomIndex, ev)}
                            />

                            {bedTypeSelectInputs.length > 1 ? (
                                <LabeledPlusMinusButton
                                    label="Remove last bed"
                                    type="minus"
                                    size="small"
                                    onClick={(ev: MouseClickEvent) => onRemoveBed(ev, roomIndex)}
                                />
                            ) : (
                                <div />
                            )}
                        </ButtonRow>

                        <TextInput
                            name={!commonSpace ? `bedroomName` : `roomName`}
                            descriptor={!commonSpace ? `Bedroom Name` : `Room Name`}
                            value={bedroom.name}
                            placeholder={!commonSpace ? `E.g. The Master Suite` : `E.g. Livingroom`}
                            onChange={(ev) => onChange(ev, roomIndex)}
                        />
                        <InputTextArea
                            name={!commonSpace ? `bedroomDescription` : `roomDescription`}
                            descriptor={!commonSpace ? `Bedroom Description` : `Room Description`}
                            value={bedroom.description}
                            placeholder={
                                !commonSpace
                                    ? `E.g. The Master Suite includes a comfortable king size bed with Egyptian cotton sheets and down feather pillows, in addition to a wood burning fireplace and a panoramic view of Lake Michigan.`
                                    : `E.g. Livingroom has a pull-out sofa that can be converted into a comfortable queen size bed. Extra sheets, blankets and pillows are available in the closet.`
                            }
                            onChange={(ev) => onChange(ev, roomIndex)}
                            rows={8}
                            maxRows={8}
                        />

                        <ButtonRow className="save-delete">
                            <FormButton
                                label={!commonSpace ? `Save this bedroom` : `Save this room`}
                                onClick={(ev) => {
                                    ev.preventDefault();
                                    onSave();
                                    this.onChangeBedroomDisplay(ev);
                                }}
                                buttonStyle="outline-color"
                            />

                            <FormButton
                                label="Delete"
                                onClick={(ev) => onDelete(ev, roomIndex)}
                                buttonStyle="no-outline"
                            />
                        </ButtonRow>
                    </div>
                )}
                <hr className="thin-hr" />
            </StyledBedroomDetails>
        );
    }
}

const StyledBedroomDetails = styled(StyledAccordion)`
    .bed-icons {
        display: inline-block;
        i {
            margin-right: 0.5rem;
        }
    }
`;
