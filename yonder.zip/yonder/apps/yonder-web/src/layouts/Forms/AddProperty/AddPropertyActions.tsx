import React from "react";
import { observer, inject } from "mobx-react";
import styled from "styled-components";

import { IAddPropertyStore } from "../../../store";
import { Button, MouseClickEvent } from "../../../components";

type Props = IAddPropertyStore & {
    submitDisabled?: boolean;
    onSave?: (ev: MouseClickEvent) => void;
};

@inject("addPropertyState")
@observer
export class AddPropertyActions extends React.Component<Props> {
    onSave = (ev: MouseClickEvent) => {
        ev.preventDefault();

        const { setSectionComplete, nextSection, saveProperty } = this.props.addPropertyState!;
        setSectionComplete();
        saveProperty();
        nextSection();
    };

    render() {
        const { submitDisabled, onSave } = this.props;
        return (
            <StyledAddPropertyActivityActions>
                <Button
                    label="Save and Continue"
                    disabled={submitDisabled || false}
                    onClick={onSave || this.onSave}
                    buttonStyle="solid"
                />
            </StyledAddPropertyActivityActions>
        );
    }
}

export const StyledAddPropertyActivityActions = styled.div`
    display: block;
    margin-top: 5rem;
`;
