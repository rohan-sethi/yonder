import React from "react";
import styled from "styled-components";
import { observer, inject } from "mobx-react";
import { PropertyBedroom } from "@yonder/db";

import { IAddPropertyStore } from "../../../store";
import {
    StyledDashboard,
    FormChangeEvent,
    InputCounter,
    SelectInput,
    SelectOption,
    ButtonRow,
    MouseClickEvent,
    LabeledPlusMinusButton
} from "../../../components";
import { BedroomDetails } from "./Bedrooms/BedroomDetails";
import { AddPropertyActions } from "./AddPropertyActions";

function getBedrooomCountOptions(): SelectOption[] {
    let options: SelectOption[] = [];

    for (let i = 0; i <= 20; ++i) {
        if (i === 0) options.push({ label: "Studio", value: `${i}` } as SelectOption);
        else {
            let bedroomFormatted = i === 1 ? "Bedroom" : "Bedrooms";
            options.push({ label: `${i} ${bedroomFormatted}`, value: `${i}` });
        }
    }

    return options;
}

type Props = IAddPropertyStore;

@inject("addPropertyState")
@observer
export class AddPropertyBedrooms extends React.Component<Props> {
    bedroomCountOptions: SelectOption[] = getBedrooomCountOptions();

    componentDidMount() {
        const { bedrooms } = this.props.addPropertyState!.property;

        if (bedrooms.length === 0) {
            this.onAddBedroom();
        }
    }

    update = this.props.addPropertyState!.updateProperty;
    save = this.props.addPropertyState!.saveProperty;

    onChangeGuestCapacity = async (count: number) => {
        this.update({
            guestCapacity: count
        });
    };

    onChangeBedroomCount = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { value } = ev.target;

        this.update({
            bedroomCount: parseInt(value)
        });
    };

    onAddBedroom = (ev?: MouseClickEvent) => {
        const { addPropertyBedroom } = this.props.addPropertyState!;
        const { bedrooms } = this.props.addPropertyState!.property;
        if (ev) {
            ev.preventDefault();
        }

        addPropertyBedroom();

        this.update({
            bedrooms: bedrooms
        });
    };

    onAddRoom = (ev?: MouseClickEvent) => {
        const { addCommonSpaceRoom } = this.props.addPropertyState!;
        const { commonSpaceRooms } = this.props.addPropertyState!.property;
        if (ev) {
            ev.preventDefault();
        }

        addCommonSpaceRoom();

        this.update({
            commonSpaceRooms: commonSpaceRooms
        });
    };

    onAddBedroomBed = (roomIndex: number, ev?: MouseClickEvent) => {
        const { addBedroomBed } = this.props.addPropertyState!;
        const { bedrooms } = this.props.addPropertyState!.property;
        if (ev) {
            ev.preventDefault();
        }

        addBedroomBed(bedrooms[roomIndex]);
    };

    onAddCommonSpaceBed = (roomIndex: number, ev?: MouseClickEvent) => {
        const { addCommonSpaceBed } = this.props.addPropertyState!;
        const { commonSpaceRooms } = this.props.addPropertyState!.property;
        if (ev) {
            ev.preventDefault();
        }
        addCommonSpaceBed(commonSpaceRooms[roomIndex]);
    };

    onRemoveBedroomBed = (ev: MouseClickEvent, roomIndex: number) => {
        const { removeBedroomBed } = this.props.addPropertyState!;
        const { commonSpaceRooms } = this.props.addPropertyState!.property;
        ev.preventDefault();

        removeBedroomBed(roomIndex);

        this.update({
            commonSpaceRooms: commonSpaceRooms
        });
    };

    onRemoveCommonSpaceBed = (ev: MouseClickEvent, roomIndex: number) => {
        const { removeCommonSpaceBed } = this.props.addPropertyState!;
        const { bedrooms } = this.props.addPropertyState!.property;
        ev.preventDefault();

        removeCommonSpaceBed(roomIndex);

        this.update({
            bedrooms: bedrooms
        });
    };

    onBedroomBedChange = (ev: FormChangeEvent, bedTypeIndex: number, roomIndex: number) => {
        const { bedrooms } = this.props.addPropertyState!.property;
        const { value } = ev.target;

        bedrooms[roomIndex].bedTypes[bedTypeIndex] = value !== "none" ? value : undefined;

        this.update({
            bedrooms: bedrooms
        });
    };

    onCommonSpaceBedChange = (ev: FormChangeEvent, bedTypeIndex: number, roomIndex: number) => {
        const { commonSpaceRooms } = this.props.addPropertyState!.property;
        const { value } = ev.target;

        commonSpaceRooms[roomIndex].bedTypes[bedTypeIndex] = value !== "none" ? value : undefined;

        this.update({
            commonSpaceRooms: commonSpaceRooms
        });
    };

    onChange = (ev: FormChangeEvent, roomIndex: number) => {
        const { name, value } = ev.target;
        const { bedrooms, commonSpaceRooms } = this.props.addPropertyState!.property;

        switch (name) {
            case "bedroomName":
                bedrooms[roomIndex].name = value;
                break;
            case "bedroomDescription":
                bedrooms[roomIndex].description = value;
                break;
            case "roomName":
                commonSpaceRooms[roomIndex].name = value;
                break;
            case "roomDescription":
                commonSpaceRooms[roomIndex].description = value;
                break;
        }

        this.update({
            bedrooms: bedrooms,
            commonSpaceRooms: commonSpaceRooms
        });
    };

    onBedroomDelete = (ev: MouseClickEvent, roomIndex: number) => {
        const { removePropertyBedroom } = this.props.addPropertyState!;
        ev.preventDefault();

        removePropertyBedroom(roomIndex);
    };

    onCommonSpaceDelete = (ev: MouseClickEvent, roomIndex: number) => {
        const { removeCommonSpaceRoom } = this.props.addPropertyState!;
        ev.preventDefault();

        removeCommonSpaceRoom(roomIndex);
    };

    render() {
        const { property } = this.props.addPropertyState!;

        const bedroomList = property.bedrooms.map((bedroom: PropertyBedroom, i: number) => {
            return (
                <BedroomDetails
                    key={i}
                    roomNumber={i + 1}
                    bedroom={bedroom}
                    onAddBed={this.onAddBedroomBed}
                    onRemoveBed={this.onRemoveBedroomBed}
                    onBedChange={this.onBedroomBedChange}
                    onChange={this.onChange}
                    onSave={this.save}
                    onDelete={this.onBedroomDelete}
                />
            );
        });

        const commonSpaceList = property.commonSpaceRooms.map((room: PropertyBedroom, i: number) => {
            return (
                <BedroomDetails
                    key={i}
                    roomNumber={i + 1}
                    bedroom={room}
                    onAddBed={this.onAddCommonSpaceBed}
                    onRemoveBed={this.onRemoveCommonSpaceBed}
                    onBedChange={this.onCommonSpaceBedChange}
                    onChange={this.onChange}
                    onSave={this.save}
                    onDelete={this.onCommonSpaceDelete}
                    commonSpace
                />
            );
        });

        return (
            <StyledDashboard>
                <StyledPropertyBedrooms>
                    <InputCounter
                        descriptor="How many guests can stay at this place comfortably?"
                        unitString="Guest"
                        value={property.guestCapacity}
                        minValue={2}
                        onChange={this.onChangeGuestCapacity}
                    />
                    <SelectInput
                        name="bedroomCount"
                        descriptor="How many bedrooms are there?"
                        onChange={this.onChangeBedroomCount}
                        value={`${property.bedroomCount}`}
                        options={this.bedroomCountOptions}
                    />

                    <p className="descriptor">Provide descriptive detail about bedroom and special qualities.</p>
                    <hr className="thin-hr" />

                    {bedroomList}

                    <ButtonRow className="first-button-row">
                        <LabeledPlusMinusButton
                            label="Add a bedroom"
                            type="plus"
                            size="small"
                            onClick={this.onAddBedroom}
                        />
                        <div />
                    </ButtonRow>

                    <p className="descriptor">Please add any common space beds. (E.g. futon in the livingroom)</p>
                    <hr className="thin-hr" />

                    {commonSpaceList}

                    <ButtonRow className="first-button-row">
                        <LabeledPlusMinusButton label="Add a room" type="plus" size="small" onClick={this.onAddRoom} />
                        <div />
                    </ButtonRow>

                    <AddPropertyActions />
                </StyledPropertyBedrooms>
            </StyledDashboard>
        );
    }
}

const StyledPropertyBedrooms = styled.form`
    .first-button-row {
        margin-top: 0;
    }
    .input-select {
        margin-bottom: 0;
    }
    .descriptor {
        margin-top: 4rem;
    }
`;
