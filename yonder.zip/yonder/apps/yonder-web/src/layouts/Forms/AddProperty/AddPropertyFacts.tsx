import React from "react";
import { inject, observer } from "mobx-react";

import { IAddPropertyStore } from "../../../store";
import {
    AirportAndTransportation,
    NearbyGroceryAndGas,
    OtherHelpfulInfo,
    RestaurantOptions,
    ThingsToDo
} from "./Facts";
import { StyledDashboard, FormChangeEvent, MouseClickEvent, KeyPressEvent, TextInput } from "../../../components";
import { AddPropertyActions } from "./AddPropertyActions";
import { stringToNumber } from "../../../functions";

type Props = IAddPropertyStore;

@inject("addPropertyState")
@observer
export class AddPropertyFacts extends React.Component<Props> {
    update = this.props.addPropertyState!.updateProperty;

    onChange = (ev: FormChangeEvent) => {
        const { name, value } = ev.target;
        switch (name) {
            case "squareFootage":
                this.update({
                    squareFootage: stringToNumber(value)
                });
                break;
            case "nearestAirport":
                this.update({
                    nearestAirport: value
                });
                break;
            case "milesToNearestAirport":
                this.update({
                    milesToNearestAirport: stringToNumber(value)
                });
                break;
            case "groceryStoreRecommendation":
                this.update({
                    groceryStoreRecommendation: value
                });
                break;
            case "milesToSuggestedGroceryStore":
                this.update({
                    milesToNearestGroceryStore: stringToNumber(value)
                });
                break;
            case "lessThanMileToGrocery":
                this.update({
                    lessThanMileToNearestGroceryStore: value
                });
                break;
            case "milesToSuggestedGasStation":
                this.update({
                    milesToNearestGasStation: stringToNumber(value)
                });
                break;
            case "lessThanMileToGasStation":
                this.update({
                    lessThanMileToNearestGasStation: value
                });
                break;
            case "milesToNearestOffSiteRestaurant":
                this.update({
                    milesToNearestOffSiteRestaurant: stringToNumber(value)
                });
                break;
            case "lessThanMileToOffSiteRestaurant":
                this.update({
                    lessThanMileToNearestOffSiteRestaurant: value
                });
                break;
            case "privateRoadType":
                this.update({
                    privateRoadType: value
                });
                break;
            case "winterAverageTemperatureFahrenheit":
                this.update({ winterAverageTemperatureFahrenheit: value });
                break;
            case "summerAverageTemperatureFahrenheit":
                this.update({
                    summerAverageTemperatureFahrenheit: value
                });
                break;
            case "animalsOnPropertyPolicy":
                this.update({
                    animalsOnPropertyPolicy: value
                });
                break;
        }
    };

    onYesNoChange = (ev: MouseClickEvent, name: string, value: boolean) => {
        ev.preventDefault();

        switch (name) {
            case "ridesharingApps":
                this.update({
                    ridesharingApps: value
                });
                break;
            case "restaurantOnSite":
                this.update({
                    restaurantOnSite: value
                });
                break;
            case "gateEntry":
                this.update({
                    gateEntry: value
                });
                break;
            case "fourWheelDriveSuggestedToGetToProperty":
                this.update({
                    fourWheelDriveSuggestedToGetToProperty: value
                });
                break;
            case "walkingHikingTrailsAdjacentToProperty":
                this.update({
                    walkingHikingTrailsAdjacentToProperty: value
                });
                break;
        }
    };

    onAddTransportationOption = (ev?: KeyPressEvent | MouseClickEvent) => {
        if (ev) {
            ev.preventDefault();
        }

        const { addTransportationOption } = this.props.addPropertyState!;

        addTransportationOption("");
    };

    onRemoveTransportationOption = (ev: KeyPressEvent | MouseClickEvent, i?: number) => {
        ev.preventDefault();

        const { removeTransportationOptionIndex, removeLastTransportationOption } = this.props.addPropertyState!;
        const { transportationOptions } = this.props.addPropertyState!.property;

        i === undefined ? removeLastTransportationOption() : removeTransportationOptionIndex(i);

        this.update({
            transportationOptions
        });
    };

    onChangeTransportationOption = (ev: FormChangeEvent, i: number) => {
        const { value } = ev.target;

        let transportationOptions = this.props.addPropertyState!.property.transportationOptions;

        transportationOptions[i] = value;

        this.update({
            transportationOptions: transportationOptions
        });
    };

    onAddRestaurant = (ev?: KeyPressEvent | MouseClickEvent) => {
        if (ev) {
            ev.preventDefault();
        }

        const { suggestedRestaurantsNearby } = this.props.addPropertyState!.property;
        const { addRestaurantOption } = this.props.addPropertyState!;

        if (suggestedRestaurantsNearby.length < 5) {
            addRestaurantOption("");
        }
    };

    onRemoveRestaurant = (ev: KeyPressEvent | MouseClickEvent, i?: number) => {
        ev.preventDefault();

        const { removeRestaurantOptionIndex, removeLastRestaurantOption } = this.props.addPropertyState!;
        const { suggestedRestaurantsNearby } = this.props.addPropertyState!.property;

        i === undefined ? removeLastRestaurantOption() : removeRestaurantOptionIndex(i);

        this.update({
            suggestedRestaurantsNearby
        });
    };

    onChangeRestaurant = (ev: FormChangeEvent, i: number) => {
        const { value } = ev.target;

        let restaurantOptions = this.props.addPropertyState!.property.suggestedRestaurantsNearby;

        restaurantOptions[i] = value;

        this.update({
            suggestedRestaurantsNearby: restaurantOptions
        });
    };

    onAddOnSiteActivity = (ev?: KeyPressEvent | MouseClickEvent) => {
        if (ev) {
            ev.preventDefault();
        }

        const { addOnSiteActivityOption } = this.props.addPropertyState!;

        addOnSiteActivityOption("");
    };

    onRemoveOnSiteActivity = (ev: KeyPressEvent | MouseClickEvent, i?: number) => {
        ev.preventDefault();

        const { removeOnSiteActivityOptionIndex, removeLastOnSiteActivityOption } = this.props.addPropertyState!;
        const { recommendedThingsToDoOnProperty } = this.props.addPropertyState!.property;

        i === undefined ? removeLastOnSiteActivityOption() : removeOnSiteActivityOptionIndex(i);

        this.update({
            recommendedThingsToDoOnProperty
        });
    };

    onChangeOnSiteActivity = (ev: FormChangeEvent, i: number) => {
        const { value } = ev.target;

        let recommendedThingsToDoOnProperty = this.props.addPropertyState!.property.recommendedThingsToDoOnProperty;

        recommendedThingsToDoOnProperty[i] = value;

        this.update({
            recommendedThingsToDoOnProperty
        });
    };

    onAddOffSiteActivity = (ev?: KeyPressEvent | MouseClickEvent) => {
        if (ev) {
            ev.preventDefault();
        }

        const { addOffSiteActivityOption } = this.props.addPropertyState!;

        addOffSiteActivityOption("");
    };

    onRemoveOffSiteActivity = (ev: KeyPressEvent | MouseClickEvent, i?: number) => {
        ev.preventDefault();

        const { removeOffSiteActivityOptionIndex, removeLastOffSiteActivityOption } = this.props.addPropertyState!;
        const { recommendedThingsToDoOffProperty } = this.props.addPropertyState!.property;

        i === undefined ? removeLastOffSiteActivityOption() : removeOffSiteActivityOptionIndex(i);

        this.update({
            recommendedThingsToDoOffProperty
        });
    };

    onChangeOffSiteActivity = (ev: FormChangeEvent, i: number) => {
        const { value } = ev.target;

        let recommendedThingsToDoOffProperty = this.props.addPropertyState!.property.recommendedThingsToDoOffProperty;

        recommendedThingsToDoOffProperty[i] = value;

        this.update({
            recommendedThingsToDoOffProperty
        });
    };

    onAddFootwearRecommendation = (ev?: KeyPressEvent | MouseClickEvent) => {
        if (ev) {
            ev.preventDefault();
        }
        const { footwearRecommendations } = this.props.addPropertyState!.property;
        const { addFootwearRecommendationOption } = this.props.addPropertyState!;

        if (footwearRecommendations.length < 5) {
            addFootwearRecommendationOption("");
        }
    };

    onRemoveFootwearRecommendation = (ev: KeyPressEvent | MouseClickEvent, i?: number) => {
        ev.preventDefault();

        const {
            removeFootwearRecommendationOptionIndex,
            removeLastFootwearRecommendationOption
        } = this.props.addPropertyState!;
        const { footwearRecommendations } = this.props.addPropertyState!.property;

        i === undefined ? removeLastFootwearRecommendationOption() : removeFootwearRecommendationOptionIndex(i);

        this.update({
            footwearRecommendations
        });
    };

    onChangeFootwearRecommendation = (ev: FormChangeEvent, i: number) => {
        const { value } = ev.target;

        let footwearRecommendations = this.props.addPropertyState!.property.footwearRecommendations;

        footwearRecommendations[i] = value;

        this.update({
            footwearRecommendations
        });
    };

    render() {
        const { property } = this.props.addPropertyState!;
        return (
            <StyledDashboard>
                <form>
                    <div className="right-label">
                        <TextInput
                            name="squareFootage"
                            label="feet"
                            descriptor="Square footage?"
                            placeholder="Numeric value only"
                            value={property.squareFootage}
                            onChange={this.onChange}
                            rightLabel
                        />
                    </div>

                    <p>These are commonly asked questions by guests. Please fill out as much as possible. (Optional)</p>
                    <hr className="thin-hr" />

                    <AirportAndTransportation
                        property={property}
                        onChange={this.onChange}
                        onAddTransportationOption={this.onAddTransportationOption}
                        onRemoveTransportationOption={this.onRemoveTransportationOption}
                        onChangeTransportationOption={this.onChangeTransportationOption}
                        onYesNoChange={this.onYesNoChange}
                    />
                    <NearbyGroceryAndGas property={property} onChange={this.onChange} />
                    <RestaurantOptions
                        property={property}
                        onChange={this.onChange}
                        onYesNoChange={this.onYesNoChange}
                        onAddRestaurant={this.onAddRestaurant}
                        onRemoveRestaurant={this.onRemoveRestaurant}
                        onChangeRestaurant={this.onChangeRestaurant}
                    />
                    <ThingsToDo
                        property={property}
                        onAddOnSiteActivity={this.onAddOnSiteActivity}
                        onRemoveOnSiteActivity={this.onRemoveOnSiteActivity}
                        onChangeOnSiteActivity={this.onChangeOnSiteActivity}
                        onAddOffSiteActivity={this.onAddOffSiteActivity}
                        onRemoveOffSiteActivity={this.onRemoveOffSiteActivity}
                        onChangeOffSiteActivity={this.onChangeOffSiteActivity}
                    />
                    <OtherHelpfulInfo
                        property={property}
                        onChange={this.onChange}
                        onYesNoChange={this.onYesNoChange}
                        onAddFootwearRecommendation={this.onAddFootwearRecommendation}
                        onRemoveFootwearRecommendation={this.onRemoveFootwearRecommendation}
                        onChangeFootwearRecommendation={this.onChangeFootwearRecommendation}
                    />

                    <AddPropertyActions />
                </form>
            </StyledDashboard>
        );
    }
}
