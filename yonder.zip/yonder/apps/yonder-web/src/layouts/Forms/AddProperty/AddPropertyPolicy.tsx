import React from "react";
import styled from "styled-components";
import { observer, inject } from "mobx-react";
import {
    CancellationPolicies,
    getCancellationPolicyLabel,
    getCancellationPolicyDescription,
    getCancellationPolicyUrl,
    AvailabilityTimesByHour,
    getAvailabilityTimeByHourLabel
} from "@yonder/db";

import { IAddPropertyStore } from "../../../store";
import {
    StyledDashboard,
    FormChangeEvent,
    InputCounter,
    InputCheckbox,
    InformationLink,
    SelectInput,
    SplitInput
} from "../../../components";
import { enumToInputOptions, enumToSelectOptions } from "../../../functions";
import { LabeledEnum } from "../../../interfaces";
import { color } from "../../../variables";
import { AddPropertyActions } from "./AddPropertyActions";

type Props = IAddPropertyStore;

@inject("addPropertyState")
@observer
export class AddPropertyPolicy extends React.Component<Props> {
    availabilityTimes = enumToSelectOptions(AvailabilityTimesByHour, getAvailabilityTimeByHourLabel);
    cancellationPolicies: LabeledEnum[] = enumToInputOptions(CancellationPolicies, getCancellationPolicyLabel);

    update = this.props.addPropertyState!.updateProperty;

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;

        switch (name) {
            case "checkInTime":
                this.update({
                    checkInTime: value
                });
                break;
            case "checkOutTime":
                this.update({
                    checkOutTime: value
                });
                break;
        }
    };

    onChangeCancellationPolicy = (ev: FormChangeEvent) => {
        this.update({
            cancellationPolicy: ev.target.name
        });
    };

    onChangePrepDays = (count: number) => {
        this.update({
            preparationDays: count
        });
    };

    onChangeMaximumStay = (count: number) => {
        this.update({
            maximumStay: count
        });
    };

    onChangeMinimumStay = (count: number) => {
        this.update({
            minimumStay: count
        });
    };

    onChangeWeekendMinimumStay = (count: number) => {
        this.update({
            weekendMinimumStay: count
        });
    };

    render() {
        const { property } = this.props.addPropertyState!;

        const cancellationPolicies = this.cancellationPolicies.map((policy: LabeledEnum, i: number) => {
            const { name, label } = policy;
            const policyEnum: CancellationPolicies = name as CancellationPolicies;
            const policyUrl = getCancellationPolicyUrl(policyEnum);
            const policyDescription = getCancellationPolicyDescription(policyEnum);

            return (
                <React.Fragment key={i}>
                    <InputCheckbox
                        groupName="cancellationPolicy"
                        name={name}
                        label={`${label} ${policyDescription}`}
                        onChange={this.onChangeCancellationPolicy}
                        checked={property.cancellationPolicy === name}
                        key={i}
                    />
                    <div className="policy-description">
                        <InformationLink
                            to={policyUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            label={`Read full ${label} policy here`}
                            external
                        />
                    </div>
                </React.Fragment>
            );
        });

        return (
            <StyledDashboard>
                <form>
                    <StyledCancellationPolicy>
                        <p>Please select your cancellation policy.</p>
                        <div className="cancellation-policies">{cancellationPolicies}</div>
                    </StyledCancellationPolicy>
                    <InputCounter
                        descriptor={
                            <>
                                How many preparation days between bookings? (Turn over)
                                <span className="note">Choose "0" for same-day turn over</span>
                            </>
                        }
                        unitString="day"
                        value={property.preparationDays}
                        maxValue={7}
                        onChange={this.onChangePrepDays}
                    />
                    <InputCounter
                        descriptor={
                            <>
                                What's the maximum night stay per booking?
                                <span className="note">Choose "0" for no maximum night required</span>
                            </>
                        }
                        unitString="day"
                        value={property.maximumStay}
                        maxValue={31}
                        onChange={this.onChangeMaximumStay}
                    />
                    <InputCounter
                        descriptor="What's the weekday minimum stay per booking?"
                        unitString="day"
                        value={property.minimumStay}
                        maxValue={31}
                        onChange={this.onChangeMinimumStay}
                    />
                    <InputCounter
                        descriptor="What's the weekend minimum stay per booking?"
                        unitString="day"
                        value={property.weekendMinimumStay}
                        maxValue={31}
                        onChange={this.onChangeWeekendMinimumStay}
                    />
                    <SplitInput>
                        <SelectInput
                            name="checkInTime"
                            descriptor="Check-In"
                            onChange={this.onChange}
                            value={property.checkInTime}
                            options={this.availabilityTimes}
                        />
                        <SelectInput
                            name="checkOutTime"
                            descriptor="Check-Out"
                            onChange={this.onChange}
                            value={property.checkOutTime}
                            options={this.availabilityTimes}
                        />
                    </SplitInput>

                    <AddPropertyActions />
                </form>
            </StyledDashboard>
        );
    }
}

const StyledCancellationPolicy = styled.div`
    margin-top: 1rem;
    padding-bottom: 4rem;

    .cancellation-policies {
        margin-top: 2rem;
        padding-left: 0.5rem;
    }

    .policy-description {
        display: block;
        color: ${color.charcoal};
        font-size: 0.875rem;
        margin-left: 2rem;

        a {
            display: block;
            margin-top: 0.5rem;
        }
    }
`;
