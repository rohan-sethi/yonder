import React from "react";
import { observer, inject } from "mobx-react";
import {
    OrganizationCertificates,
    getOrganizationCertificateLabel,
    getSustainabilityEffortLabel,
    getSustainabilityEffortCategories,
    getSustainabilityEffortsByCategory,
    SustainabilityEfforts
} from "@yonder/db";

import {
    MouseClickEvent,
    KeyPressEvent,
    InputCheckbox,
    FormChangeEvent,
    ListTextBox,
    StyledDashboard,
    CategoryCheckboxes,
    CheckboxCategoryAccordion
} from "../../../components";
import { IFirebaseStore, IAddPropertyStore, IAddActivityStore } from "../../../store";
import { enumToInputOptions } from "../../../functions";
import { LabeledEnum } from "../../../interfaces";
import { AddPropertyActions } from "./AddPropertyActions";

type SustainabilityEffortCategory = {
    name: string;
    sustainabilityEfforts: LabeledEnum[];
};

type Props = IFirebaseStore & IAddPropertyStore & IAddActivityStore;

@inject("firebaseState", "addPropertyState", "addActivityState")
@observer
export class AddPropertyCertifications extends React.Component<Props> {
    certificates: LabeledEnum[] = enumToInputOptions(OrganizationCertificates, getOrganizationCertificateLabel);

    categorizedSustainabilityEfforts: SustainabilityEffortCategory[] = getSustainabilityEffortCategories().map(
        (category: string) => {
            const sustainabilityEfforts: SustainabilityEfforts[] = getSustainabilityEffortsByCategory(category);
            return {
                name: category,
                sustainabilityEfforts: enumToInputOptions(SustainabilityEfforts, getSustainabilityEffortLabel).filter(
                    (sustainabilityEffort: LabeledEnum) =>
                        sustainabilityEfforts.includes(sustainabilityEffort.name as SustainabilityEfforts)
                )
            } as SustainabilityEffortCategory;
        }
    );

    update = this.props.addPropertyState!.updateProperty;

    onCertificationChange = (ev: FormChangeEvent) => {
        const { name, value } = ev.target;
        const { addCertificate, removeCertificate } = this.props.addPropertyState!;

        const certificate: OrganizationCertificates = name;
        value ? addCertificate(certificate) : removeCertificate(certificate);
    };

    onSustainabilityEffortChange = (ev: FormChangeEvent) => {
        const { name, value } = ev.target;
        const { addSustainabilityEffort, removeSustainabilityEffort } = this.props.addPropertyState!;

        const sustainabilityEffort: SustainabilityEfforts = name;
        value ? addSustainabilityEffort(sustainabilityEffort) : removeSustainabilityEffort(sustainabilityEffort);
    };

    onFieldAdd = async (ev?: KeyPressEvent | MouseClickEvent) => {
        if (ev) {
            ev.preventDefault();
        }

        const { addOtherCertificate } = this.props.addPropertyState!;
        const { otherCertificates } = this.props.addPropertyState!.property;

        addOtherCertificate("");

        this.update({
            otherCertificates: otherCertificates
        });
    };

    onFieldRemove = (ev: KeyPressEvent | MouseClickEvent, i?: number) => {
        ev.preventDefault();

        const { removeOtherCertificateIndex, removeLastOtherCertificate } = this.props.addPropertyState!;
        const { otherCertificates } = this.props.addPropertyState!.property;

        if (otherCertificates.length > 1) {
            i === undefined ? removeLastOtherCertificate() : removeOtherCertificateIndex(i);

            this.update({
                otherCertificates: otherCertificates
            });
        }
    };

    onFieldChange = (ev: FormChangeEvent, i: number) => {
        const { value } = ev.target;

        let otherCertificates = this.props.addPropertyState!.property.otherCertificates;

        otherCertificates[i] = value;

        this.update({
            otherCertificates: otherCertificates
        });
    };

    onEffortAdd = async (ev?: KeyPressEvent | MouseClickEvent) => {
        if (ev) {
            ev.preventDefault();
        }

        const { addOtherSustainabilityEffort } = this.props.addPropertyState!;
        const { otherSustainabilityEfforts } = this.props.addPropertyState!.property;

        addOtherSustainabilityEffort("");

        this.update({
            otherSustainabilityEfforts
        });
    };

    onEffortRemove = (ev: KeyPressEvent | MouseClickEvent, i?: number) => {
        ev.preventDefault();

        const {
            removeOtherSustainabilityEffortIndex,
            removeLastOtherSustainabilityEffort
        } = this.props.addPropertyState!;
        const { otherSustainabilityEfforts } = this.props.addPropertyState!.property;

        if (otherSustainabilityEfforts.length > 1) {
            i === undefined ? removeLastOtherSustainabilityEffort() : removeOtherSustainabilityEffortIndex(i);

            this.update({
                otherSustainabilityEfforts
            });
        }
    };

    onEffortChange = (ev: FormChangeEvent, i: number) => {
        const { value } = ev.target;

        let otherSustainabilityEfforts = this.props.addPropertyState!.property.otherSustainabilityEfforts;

        otherSustainabilityEfforts[i] = value;

        this.update({
            otherSustainabilityEfforts
        });
    };

    render() {
        const { property } = this.props.addPropertyState!;
        const checkboxes = this.certificates.map((certificate: LabeledEnum, i: number) => {
            const { name, label } = certificate;

            let checked: boolean = false;
            if (property.certificates) {
                checked = property.certificates.includes(name as OrganizationCertificates);
            }
            return (
                <InputCheckbox
                    groupName="certificates"
                    name={name}
                    label={label}
                    onChange={this.onCertificationChange}
                    checked={checked}
                    key={i}
                />
            );
        });

        return (
            <StyledDashboard>
                <form>
                    <div className="category-checkboxes">
                        <p>Is your business certified by any of these organizations? Please select all that apply.</p>

                        <hr className="thin-hr" />
                        <CheckboxCategoryAccordion
                            header="certifications"
                            hideHeader
                            showAccordionLabel
                            accordionExpandLabel="Expand to select organizations"
                            accordionCollapseLabel="Collapse to hide organizations"
                            labelAndButtonSplit
                        >
                            <div className="checkboxes">{checkboxes}</div>
                        </CheckboxCategoryAccordion>
                    </div>

                    <ListTextBox
                        name="otherCertificates"
                        label="Please list other certifications you have."
                        collection={property.otherCertificates}
                        onFieldAdd={this.onFieldAdd}
                        addLabel="Add a certificate"
                        onFieldRemove={this.onFieldRemove}
                        removeLabel="Remove last certificate"
                        onChange={this.onFieldChange}
                        placeholder="E.g. Bee Friendly Farms Certification"
                        className="top-margin"
                        inputType="input-field"
                    />

                    <p>Please indicate which of the following practices guests can enjoy at your property / stay.</p>

                    <hr className="thin-hr" />
                    <CheckboxCategoryAccordion header={this.categorizedSustainabilityEfforts[0].name}>
                        <CategoryCheckboxes
                            categoryName={this.categorizedSustainabilityEfforts[0].name}
                            categoryEnums={this.categorizedSustainabilityEfforts[0].sustainabilityEfforts}
                            collection={property.sustainabilityEfforts}
                            onChange={this.onSustainabilityEffortChange}
                            hideCategoryName
                        />
                    </CheckboxCategoryAccordion>
                    <CheckboxCategoryAccordion header={this.categorizedSustainabilityEfforts[1].name}>
                        <CategoryCheckboxes
                            categoryName={this.categorizedSustainabilityEfforts[1].name}
                            categoryEnums={this.categorizedSustainabilityEfforts[1].sustainabilityEfforts}
                            collection={property.sustainabilityEfforts}
                            onChange={this.onSustainabilityEffortChange}
                        />
                    </CheckboxCategoryAccordion>
                    <CheckboxCategoryAccordion header={this.categorizedSustainabilityEfforts[2].name}>
                        <CategoryCheckboxes
                            categoryName={this.categorizedSustainabilityEfforts[2].name}
                            categoryEnums={this.categorizedSustainabilityEfforts[2].sustainabilityEfforts}
                            collection={property.sustainabilityEfforts}
                            onChange={this.onSustainabilityEffortChange}
                        />
                    </CheckboxCategoryAccordion>
                    <CheckboxCategoryAccordion header={this.categorizedSustainabilityEfforts[3].name}>
                        <CategoryCheckboxes
                            categoryName={this.categorizedSustainabilityEfforts[3].name}
                            categoryEnums={this.categorizedSustainabilityEfforts[3].sustainabilityEfforts}
                            collection={property.sustainabilityEfforts}
                            onChange={this.onSustainabilityEffortChange}
                        />
                    </CheckboxCategoryAccordion>
                    <CheckboxCategoryAccordion header={this.categorizedSustainabilityEfforts[4].name}>
                        <CategoryCheckboxes
                            categoryName={this.categorizedSustainabilityEfforts[4].name}
                            categoryEnums={this.categorizedSustainabilityEfforts[4].sustainabilityEfforts}
                            collection={property.sustainabilityEfforts}
                            onChange={this.onSustainabilityEffortChange}
                        />
                    </CheckboxCategoryAccordion>
                    <CheckboxCategoryAccordion header={this.categorizedSustainabilityEfforts[5].name}>
                        <CategoryCheckboxes
                            categoryName={this.categorizedSustainabilityEfforts[5].name}
                            categoryEnums={this.categorizedSustainabilityEfforts[5].sustainabilityEfforts}
                            collection={property.sustainabilityEfforts}
                            onChange={this.onSustainabilityEffortChange}
                        />
                    </CheckboxCategoryAccordion>
                    <CheckboxCategoryAccordion header={this.categorizedSustainabilityEfforts[6].name}>
                        <CategoryCheckboxes
                            categoryName={this.categorizedSustainabilityEfforts[6].name}
                            categoryEnums={this.categorizedSustainabilityEfforts[6].sustainabilityEfforts}
                            collection={property.sustainabilityEfforts}
                            onChange={this.onSustainabilityEffortChange}
                        />
                    </CheckboxCategoryAccordion>
                    <CheckboxCategoryAccordion header={this.categorizedSustainabilityEfforts[7].name}>
                        <CategoryCheckboxes
                            categoryName={this.categorizedSustainabilityEfforts[7].name}
                            categoryEnums={this.categorizedSustainabilityEfforts[7].sustainabilityEfforts}
                            collection={property.sustainabilityEfforts}
                            onChange={this.onSustainabilityEffortChange}
                        />
                    </CheckboxCategoryAccordion>

                    <ListTextBox
                        name="otherSustainabilityEfforts"
                        label="If your business has implemented any other sustainable practices, please list them here."
                        collection={property.otherSustainabilityEfforts}
                        onFieldAdd={this.onEffortAdd}
                        addLabel="Add another"
                        onFieldRemove={this.onEffortRemove}
                        removeLabel="Remove last"
                        onChange={this.onEffortChange}
                        placeholder="E.g. Local in-town food waste pickup"
                        inputType="input-field"
                    />

                    <AddPropertyActions />
                </form>
            </StyledDashboard>
        );
    }
}
