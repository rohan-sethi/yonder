import React from "react";
import styled from "styled-components";
import { observer, inject } from "mobx-react";

import { IAddPropertyStore, IAddActivityStore } from "../../../store";
import { StyledDashboard, ButtonRow, FormButton, InputCheckbox, FormChangeEvent } from "../../../components";
import { LabeledActivity } from "../../../interfaces";
import { ID } from "@yonder/db";
import { AddPropertyActions } from "./AddPropertyActions";

type Props = IAddPropertyStore & IAddActivityStore;

type State = {
    activityOptions: LabeledActivity[];
};

@inject("addPropertyState", "addActivityState")
@observer
export class AddPropertyActivities extends React.Component<Props, State> {
    state: State = {
        activityOptions: []
    };

    update = this.props.addPropertyState!.updateProperty;

    componentDidMount() {
        this.loadActivities();
    }

    loadActivities = async () => {
        try {
            const { activities } = this.props.addPropertyState!;
            this.setState({
                activityOptions: activities.map((activity) => {
                    return {
                        name: activity.name,
                        label: activity.name,
                        id: activity.id
                    } as LabeledActivity;
                })
            });
        } catch (err) {
            console.log(err);
        }
    };

    addNewActivity = async () => {
        const { createNewActivity } = this.props.addPropertyState!;
        const { createOrLoadActivity } = this.props.addActivityState!;

        let id = await createNewActivity();
        if (id !== null) {
            await createOrLoadActivity(id);
            const newWindow = window.open(`${window.location.origin}/dash/listings/activities/${id}`, "_blank");
            newWindow!.opener = null;
        }
    };

    onActivityChange = (ev: FormChangeEvent, id: ID) => {
        const { value } = ev.target;
        const { addActivityAvailable, removeActivityAvailable } = this.props.addPropertyState!;

        if (value) {
            addActivityAvailable(id);
        } else {
            removeActivityAvailable(id);
        }
    };

    render() {
        const { property, activities } = this.props.addPropertyState!;
        const activityCheckboxes = this.state.activityOptions.map((activity: LabeledActivity, i: number) => {
            const { label, id } = activity;
            let checked: boolean = false;
            if (property.activitiesAvailable) {
                checked = property.activitiesAvailable.includes(id);
            }

            return (
                <InputCheckbox
                    groupName="organizationActivities"
                    name={id}
                    label={label || "New Activity"}
                    onChange={(ev) => this.onActivityChange(ev, id)}
                    checked={checked}
                    key={i}
                />
            );
        });

        const activitiesConfirmation =
            activities.length > 0 ? (
                <>
                    <ActivitiesDescription>
                        Below is the list of activities you've already submitted to Yonder. Please confirm all that are
                        available for guests at this property.
                    </ActivitiesDescription>
                    {activityCheckboxes}
                </>
            ) : (
                <>
                    <p>You don't have any activities listed with Yonder.</p>
                    <p>If you offer activities for your guests at this stay, please create a new activity listing.</p>
                </>
            );

        return (
            <StyledDashboard>
                <form>
                    {activitiesConfirmation}

                    <ButtonRow bottomMargin>
                        <FormButton
                            label="Create New Activity"
                            onClick={this.addNewActivity}
                            buttonStyle="outline-color"
                        />
                        <div />
                    </ButtonRow>

                    <hr />
                    <AddPropertyActions />
                </form>
            </StyledDashboard>
        );
    }
}

const ActivitiesDescription = styled.p`
    margin-bottom: 2rem;
`;
