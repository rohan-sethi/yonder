import React from "react";
import { Link } from "react-router-dom";
import { observer, inject } from "mobx-react";
import { PropertyTypes, getPropertyTypeLabel, ExperienceCategories } from "@yonder/db";

import { IAddPropertyStore, IFirebaseStore } from "../../../store";
import {
    StyledDashboard,
    SelectInput,
    TextInput,
    FormChangeEvent,
    SelectOption,
    ButtonRow,
    FormButton
} from "../../../components";
import { enumToSelectOptions } from "../../../functions";
//import { AddPropertyActions } from "./AddPropertyActions";
import { AddPropertyLocation } from ".";

type Props = IAddPropertyStore & IFirebaseStore;

type State = {
    selected?: ExperienceCategories[];
};

@inject("addPropertyState")
@observer
export class AddPropertyOverview extends React.Component<Props, State> {
    propertyTypes = enumToSelectOptions(PropertyTypes, getPropertyTypeLabel);
    hostOptions: SelectOption[] = this.props.addPropertyState!.hosts.map((user) => {
        return {
            value: user.id,
            label: `${user.firstName} ${user.lastName}`
        } as SelectOption;
    });

    update = this.props.addPropertyState!.updateProperty;
    save = this.props.addPropertyState!.saveProperty;

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;

        switch (name) {
            case "propertyType":
                this.update({
                    propertyType: value !== "none" ? value : null
                });
                break;

            case "propertyName":
                this.update({
                    name: value
                });
                break;

            case "selectHost":
                this.update({
                    hostId: value
                });
                break;

            case "hostOnProperty":
                this.update({
                    hostOnProperty: value === "true"
                });
                break;
        }
    };

    render() {
        const { property } = this.props.addPropertyState!;

        return (
            <StyledDashboard>
                <form>
                    <SelectInput
                        name="propertyType"
                        descriptor="What kind of stay are you hosting?"
                        onChange={this.onChange}
                        value={property.propertyType || "none"}
                        options={this.propertyTypes}
                    />
                    <TextInput
                        name="propertyName"
                        descriptor="Give your stay a unique name that reflects its surroundings. Avoid using bedroom count or location in the name."
                        value={property.name}
                        onChange={this.onChange}
                        placeholder="E.g. The Enchanted Lakeside Cabin"
                    />
                    <SelectInput
                        name="selectHost"
                        descriptor="Who is the host for this property?"
                        value={property.hostId || (this.hostOptions[0] && this.hostOptions[0].value)} // TODO
                        onChange={this.onChange}
                        options={this.hostOptions}
                    />
                    <ButtonRow className="invite-button">
                        <Link to="/my-business" target="_blank">
                            <FormButton label="Invite a Co-host" onClick={this.save} buttonStyle="outline-color" />
                        </Link>
                    </ButtonRow>
                    <SelectInput
                        name="hostOnProperty"
                        descriptor="Is there a host representative available for guests on site?"
                        onChange={this.onChange}
                        value={!!property.hostOnProperty ? "true" : "false"}
                        options={[
                            { label: "Off site and available remotely", value: "false" },
                            { label: "Available on site", value: "true" }
                        ]}
                    />

                    <AddPropertyLocation />

                    {/*<AddPropertyActions />*/}
                </form>
            </StyledDashboard>
        );
    }
}
