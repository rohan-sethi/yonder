import React from "react";

import { Property, RoadTypes, getRoadTypeLabel, TemperatureRanges, getTemperatureRangeLabel } from "@yonder/db";
import {
    FormChangeEventFunction,
    MouseClickEvent,
    KeyPressEvent,
    StyledPropertyFactDetails,
    InputYesNo,
    SelectInput,
    ListTextBox,
    InputTextArea
} from "../../../../components";
import { enumToSelectOptions } from "../../../../functions";

type Props = {
    property: Property;
    onChange: (ev: FormChangeEventFunction) => void;
    onYesNoChange: (ev: MouseClickEvent, name: string, value: boolean) => void;
    onAddFootwearRecommendation: (ev?: MouseClickEvent | KeyPressEvent) => void;
    onRemoveFootwearRecommendation: (ev: MouseClickEvent | KeyPressEvent, i?: number) => void;
    onChangeFootwearRecommendation: (ev: FormChangeEventFunction, i: number) => void;
};

type State = {
    displayDetails: boolean;
};

export class OtherHelpfulInfo extends React.Component<Props, State> {
    roadTypeOptions = enumToSelectOptions(RoadTypes, getRoadTypeLabel);
    temperatureRangeOptions = enumToSelectOptions(TemperatureRanges, getTemperatureRangeLabel);

    state: State = {
        displayDetails: false
    };

    onChangeDisplay = (ev: React.MouseEvent) => {
        ev.preventDefault();

        const { displayDetails } = this.state;
        this.setState({
            displayDetails: !displayDetails
        });
    };

    render() {
        const {
            property,
            onChange,
            onYesNoChange,
            onAddFootwearRecommendation,
            onRemoveFootwearRecommendation,
            onChangeFootwearRecommendation
        } = this.props;
        const { displayDetails } = this.state;

        const accordionLabel = !!displayDetails ? "Collapse" : "Expand to enter response";
        const accordionClass = !!displayDetails ? "minus" : "plus";

        return (
            <StyledPropertyFactDetails>
                <div className="header" onClick={(ev: React.MouseEvent) => this.onChangeDisplay(ev)}>
                    <p>Other Helpful Info</p>

                    <div className="button-toggle">
                        <label className="accordion-label" htmlFor={`otherHelpfulInfo`}>
                            {accordionLabel}
                        </label>
                        <button id={`otherHelpfulInfo`}>
                            <div className={accordionClass} />
                        </button>
                    </div>
                </div>

                {!!displayDetails && (
                    <div className="display-details">
                        <InputYesNo
                            name="gateEntry"
                            descriptor="Is there a gate entry?"
                            value={property.gateEntry}
                            onClick={onYesNoChange}
                            padded={false}
                        />
                        <SelectInput
                            name="privateRoadType"
                            descriptor="Specify private road type?"
                            value={property.privateRoadType}
                            options={this.roadTypeOptions}
                            onChange={onChange}
                        />
                        <InputYesNo
                            name="fourWheelDriveSuggestedToGetToProperty"
                            descriptor="Is four wheel drive suggested to get around your property?"
                            value={property.fourWheelDriveSuggestedToGetToProperty}
                            onClick={onYesNoChange}
                            padded={false}
                        />
                        <InputYesNo
                            name="walkingHikingTrailsAdjacentToProperty"
                            descriptor="Is there walking/hiking trails adjacent to your property?"
                            value={property.walkingHikingTrailsAdjacentToProperty}
                            onClick={onYesNoChange}
                            padded={false}
                            topMargin
                        />
                        <ListTextBox
                            name="footwearRecommendations"
                            label="Please recommend up to 5 footwear types for your guests to bring."
                            collection={property.footwearRecommendations}
                            onFieldAdd={onAddFootwearRecommendation}
                            addLabel="Add a footwear recommendation"
                            onFieldRemove={(ev, i) => onRemoveFootwearRecommendation(ev, i)}
                            removeLabel="Remove last recommendation"
                            onChange={(ev, i) => onChangeFootwearRecommendation(ev, i)}
                            placeholder="E.g. High top shoes"
                            buttonAlignment="block"
                        />
                        <InputTextArea
                            name="animalsOnPropertyPolicy"
                            descriptor="If you have any animals living on your property, please provide rules or instructions for your guests."
                            value={property.animalsOnPropertyPolicy}
                            onChange={onChange}
                            rows={7}
                            maxRows={10}
                            placeholder="E.g. Please do not feed or touch our alpacas. Visit our office to schedule the tour."
                        />
                    </div>
                )}
                <hr className="thin-hr" />
            </StyledPropertyFactDetails>
        );
    }
}
