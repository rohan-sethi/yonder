import React from "react";
import { Property } from "@yonder/db";
import {
    FormChangeEventFunction,
    MouseClickEvent,
    StyledPropertyFactDetails,
    ListTextBox,
    KeyPressEvent
} from "../../../../components";

type Props = {
    property: Property;
    onAddOnSiteActivity: (ev?: MouseClickEvent | KeyPressEvent) => void;
    onRemoveOnSiteActivity: (ev: MouseClickEvent | KeyPressEvent, i?: number) => void;
    onChangeOnSiteActivity: (ev: FormChangeEventFunction, i: number) => void;
    onAddOffSiteActivity: (ev?: MouseClickEvent | KeyPressEvent) => void;
    onRemoveOffSiteActivity: (ev: MouseClickEvent | KeyPressEvent, i?: number) => void;
    onChangeOffSiteActivity: (ev: FormChangeEventFunction, i: number) => void;
};

type State = {
    displayDetails: boolean;
};

export class ThingsToDo extends React.Component<Props> {
    state: State = {
        displayDetails: false
    };

    onChangeDisplay = (ev: React.MouseEvent) => {
        ev.preventDefault();

        const { displayDetails } = this.state;
        this.setState({
            displayDetails: !displayDetails
        });
    };

    render() {
        const {
            property,
            onAddOnSiteActivity,
            onRemoveOnSiteActivity,
            onChangeOnSiteActivity,
            onAddOffSiteActivity,
            onRemoveOffSiteActivity,
            onChangeOffSiteActivity
        } = this.props;
        const { displayDetails } = this.state;

        const accordionLabel = !!displayDetails ? "Collapse" : "Expand to enter response";
        const accordionClass = !!displayDetails ? "minus" : "plus";

        return (
            <StyledPropertyFactDetails>
                <div className="header" onClick={(ev: React.MouseEvent) => this.onChangeDisplay(ev)}>
                    <p>Things To Do</p>

                    <div className="button-toggle">
                        <label className="accordion-label" htmlFor={`thingsToDo`}>
                            {accordionLabel}
                        </label>
                        <button id={`thingsToDo`}>
                            <div className={accordionClass} />
                        </button>
                    </div>
                </div>

                {!!displayDetails && (
                    <div className="display-details">
                        <ListTextBox
                            name="recommendedThingsToDoOnProperty"
                            label="What are some activities your guests can enjoy on-site at your property?"
                            collection={property.recommendedThingsToDoOnProperty}
                            onFieldAdd={onAddOnSiteActivity}
                            addLabel="Add an on-site activity"
                            onFieldRemove={(ev, i) => onRemoveOnSiteActivity(ev, i)}
                            removeLabel="Remove last activity"
                            onChange={(ev, i) => onChangeOnSiteActivity(ev, i)}
                            placeholder="E.g. Winery tour and tasting"
                            buttonAlignment="block"
                        />
                        <ListTextBox
                            name="recommendedThingsToDoOffProperty"
                            label="What are some activities your guests can enjoy nearby your property (off-site)?"
                            collection={property.recommendedThingsToDoOffProperty}
                            onFieldAdd={onAddOffSiteActivity}
                            addLabel="Add a nearby (off-site) activity"
                            onFieldRemove={(ev, i) => onRemoveOffSiteActivity(ev, i)}
                            removeLabel="Remove last activity"
                            onChange={(ev, i) => onChangeOffSiteActivity(ev, i)}
                            placeholder="E.g. Green Valley National Park"
                            buttonAlignment="block"
                        />
                    </div>
                )}
                <hr className="thin-hr" />
            </StyledPropertyFactDetails>
        );
    }
}
