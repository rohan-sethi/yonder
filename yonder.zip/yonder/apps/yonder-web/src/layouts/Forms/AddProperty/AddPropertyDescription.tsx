import React from "react";
import { observer, inject } from "mobx-react";

import { IAddPropertyStore } from "../../../store";
import {
    StyledDashboard,
    InputTextArea,
    FormChangeEvent,
    limitTextAreaInput,
    MouseClickEvent,
    ListTextBox,
    KeyPressEvent
} from "../../../components";
import { AddPropertyActions } from "./AddPropertyActions";

type Props = IAddPropertyStore;

@inject("addPropertyState")
@observer
export class AddPropertyDescription extends React.Component<Props> {
    update = this.props.addPropertyState!.updateProperty;

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;

        switch (name) {
            case "propertySummary":
                this.update({
                    summary: value
                });
                break;
            case "whatWeLove":
                this.update({
                    whatWeLove: limitTextAreaInput(value)
                });
                break;
        }
    };

    onKeyThingToKnowChange = (ev: FormChangeEvent, i: number) => {
        const { value } = ev.target;

        let keyThingsToKnow = this.props.addPropertyState!.property.keyThingsToKnow;

        keyThingsToKnow[i] = value;

        this.update({
            keyThingsToKnow: keyThingsToKnow
        });
    };

    onKeyThingToKnowAdd = async (ev?: KeyPressEvent | MouseClickEvent) => {
        if (ev) {
            ev.preventDefault();
        }

        const { addKeyThingToKnow } = this.props.addPropertyState!;
        const { keyThingsToKnow } = this.props.addPropertyState!.property;

        addKeyThingToKnow("");

        this.update({
            keyThingsToKnow: keyThingsToKnow
        });
    };

    onKeyThingToKnowRemove = (ev: KeyPressEvent | MouseClickEvent, i?: number) => {
        ev.preventDefault();

        const { removeKeyThingToKnowIndex, removeLastKeyThingToKnow } = this.props.addPropertyState!;
        const { keyThingsToKnow } = this.props.addPropertyState!.property;

        if (keyThingsToKnow.length > 1) {
            if (i === undefined) {
                removeLastKeyThingToKnow();
            } else {
                removeKeyThingToKnowIndex(i);
            }
            this.update({
                keyThingsToKnow: keyThingsToKnow
            });
        }
    };

    render() {
        const { property } = this.props.addPropertyState!;

        return (
            <StyledDashboard>
                <form>
                    <InputTextArea
                        name="propertySummary"
                        value={property.summary}
                        onChange={this.onChange}
                        rows={5}
                        maxRows={5}
                        descriptor="Write a brief description of your stay."
                        placeholder="E.g. Here at Birch Hill Cabin, guests can take a dip in the lake, feed chickens at the Ranch, or relax on our open porch and listen to the hum of cicadas."
                        maxLength={240}
                    />
                    <InputTextArea
                        name="whatWeLove"
                        value={property.whatWeLove}
                        onChange={this.onChange}
                        rows={12}
                        maxRows={12}
                        descriptor="Showcase what sets your stay apart! What will guests remember most about their visit? Create a narrative that touches on all the highlights of your location."
                        placeholder={`E.g. The Birch Hill Cabin is in a location like no other. Steps away from the serene, Birch Hill Lake, and less than a mile from Birch Hill Ranch, you are sure to get a unique experience customized just for you.

The interior of the Cabin is decorated with antiques from the 1950s and cedar-wood furnishings. The space is equally charming and cozy. From the rocking chairs out on the front porch, to the vintage-style bathtub, the Cabin is decorated with breath-taking details for you to admire!

The Cabin is pet-friendly, so feel free to bring your furry friend along for the experience! We offer a home-cooked breakfast every morning of your stay, and are always available for you if you have any questions. We will be staying at the main Ranch House located less than a mile away from the Cabin.

If you’re searching for an adventure, hike one of the gorgeous trails behind the Cabin. If you want to spend some time with animals, come and meet some of the happiest cows over at the Ranch. If you’re looking for an immersive experience, the Birch Hill Cabin is the perfect spot for you.`}
                    />
                    <ListTextBox
                        name="keyThingsToKnow"
                        label="Share some fun facts you would like guests to know about your property and its surroundings."
                        collection={property.keyThingsToKnow}
                        onFieldAdd={this.onKeyThingToKnowAdd}
                        onFieldRemove={this.onKeyThingToKnowRemove}
                        onChange={this.onKeyThingToKnowChange}
                        placeholder="E.g. This Cabin was hand-crafted in the early 1800’s, using materials from the surrounding forest."
                        inputType="text-area"
                        addLabel="Add another fact"
                        removeLabel="Remove last fact"
                        rows={5}
                        maxRows={5}
                        maxLength={240}
                    />

                    <AddPropertyActions />
                </form>
            </StyledDashboard>
        );
    }
}
