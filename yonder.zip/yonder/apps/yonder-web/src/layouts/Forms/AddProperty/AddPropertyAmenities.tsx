import React from "react";
import { observer, inject } from "mobx-react";
import { Amenities, getAmenityLabel, getAmenityCategories, getAmenitiesByCategory } from "@yonder/db";

import { IAddPropertyStore } from "../../../store";
import {
    StyledDashboard,
    FormChangeEvent,
    CategoryCheckboxes,
    CheckboxCategoryAccordion,
    InputTextArea
} from "../../../components";
import { enumToInputOptions } from "../../../functions";
import { LabeledEnum } from "../../../interfaces";
import { AddPropertyActions } from "./AddPropertyActions";

type AmenityCategory = {
    name: string;
    amenities: LabeledEnum[];
};

type Props = IAddPropertyStore;

@inject("addPropertyState")
@observer
export class AddPropertyAmenities extends React.Component<Props> {
    categorizedAmenities: (AmenityCategory | undefined)[] = getAmenityCategories().map((category: string) => {
        if (category !== "Bathroom") {
            const amenities: Amenities[] = getAmenitiesByCategory(category);
            return {
                name: category,
                amenities: enumToInputOptions(Amenities, getAmenityLabel).filter((amenity: LabeledEnum) =>
                    amenities.includes(amenity.name as Amenities)
                )
            } as AmenityCategory;
        }
        return undefined;
    });

    update = this.props.addPropertyState!.updateProperty;

    onAmenityChange = (ev: FormChangeEvent) => {
        const { value } = ev.target;
        const { addAmenity, removeAmenity } = this.props.addPropertyState!;

        const amenity: Amenities = ev.target.name;
        if (value) {
            addAmenity(amenity);
        } else {
            removeAmenity(amenity);
        }
    };

    onChange = (ev: FormChangeEvent) => {
        const { name, value } = ev.target;

        switch (name) {
            case "accessibilityDescription":
                this.update({
                    accessibilityDescription: value
                });
                break;
        }
    };

    render() {
        const { property } = this.props.addPropertyState!;

        const categoryCheckboxes = this.categorizedAmenities.map((category?: AmenityCategory, i?: number) => {
            if (category) {
                return (
                    <CheckboxCategoryAccordion header={category.name} key={i}>
                        <CategoryCheckboxes
                            categoryName={category.name}
                            categoryEnums={category.amenities}
                            collection={property.amenities}
                            onChange={this.onAmenityChange}
                            columns="one"
                            hideCategoryName
                        />
                        {category.name === "Accessibility" && (
                            <InputTextArea
                                name="accessibilityDescription"
                                placeholder="Any other information to share about accessibility amenities?"
                                value={property.accessibilityDescription}
                                onChange={this.onChange}
                                rows={5}
                                maxRows={5}
                            />
                        )}
                    </CheckboxCategoryAccordion>
                );
            }
            return undefined;
        });

        return (
            <StyledDashboard>
                <form>
                    <p className="bottom-margin">Please select all that apply.</p>

                    <hr className="thin-hr" />
                    {categoryCheckboxes}

                    <AddPropertyActions />
                </form>
            </StyledDashboard>
        );
    }
}
