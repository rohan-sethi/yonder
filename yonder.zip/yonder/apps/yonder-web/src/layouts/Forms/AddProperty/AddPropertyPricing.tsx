import React from "react";
import { observer, inject } from "mobx-react";
import { CurrencyCodes, getCurrencyCodeLabel, PropertyPricing } from "@yonder/db";

import { IAddPropertyStore } from "../../../store";
import {
    StyledDashboard,
    SelectInput,
    FormChangeEvent,
    SelectOption,
    TextInput,
    SplitInput
} from "../../../components";
import { enumToSelectOptions, stringToMonetary } from "../../../functions";
import { AddPropertyActions } from "./AddPropertyActions";
import { Props as AlertProps, Alert } from "../../../components/Alert";

/**
 * Security deposit (Future)
 */

const alertsArray: AlertProps[] = [{ body: "Advanced pricing and availability options will be available soon." }];

export const PropertyPricingAlerts = alertsArray.map((alert: AlertProps, i: number) => {
    return <Alert {...alert} key={i} />;
});

type Props = IAddPropertyStore;

@inject("addPropertyState")
@observer
export class AddPropertyPricing extends React.Component<Props> {
    currencyCodes: SelectOption[] = enumToSelectOptions(CurrencyCodes, getCurrencyCodeLabel);

    update = this.props.addPropertyState!.updateProperty;

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;
        const { property } = this.props.addPropertyState!;

        let pricing: PropertyPricing = {};
        switch (name) {
            case "currencyCode":
                this.update({
                    currency: value !== "none" ? value : null
                });
                break;

            case "defaultWeekdayPricing":
                pricing.defaultWeekday = stringToMonetary(value);
                break;

            case "defaultWeekendPricing":
                pricing.defaultWeekend = stringToMonetary(value);
                break;

            case "cleaningFee":
                pricing.cleaningFee = stringToMonetary(value);
                break;
        }

        this.update({
            pricing: {
                ...property.pricing,
                ...pricing
            }
        });
    };

    render() {
        const { property } = this.props.addPropertyState!;

        return (
            <StyledDashboard>
                <form>
                    <TextInput
                        name="defaultWeekdayPricing"
                        descriptor={
                            <>
                                What is the weekday pricing per night? (Sunday to Thursday)
                                <span className="note">All overnight stays require a $100 guest deposit</span>
                            </>
                        }
                        value={property.pricing.defaultWeekday}
                        placeholder="Numeric value only. E.g. 150"
                        onChange={this.onChange}
                    />
                    <TextInput
                        name="defaultWeekendPricing"
                        descriptor={
                            <>
                                What is the weekend pricing per night? (Friday to Saturday)
                                <span className="note">All overnight stays require a $100 guest deposit</span>
                            </>
                        }
                        value={property.pricing.defaultWeekend}
                        placeholder="Numeric value only. E.g. 160"
                        onChange={this.onChange}
                    />
                    <TextInput
                        name="cleaningFee"
                        descriptor="What is the cleaning fee per booking?"
                        value={property.pricing.cleaningFee}
                        placeholder="Numeric value only. E.g. 35"
                        onChange={this.onChange}
                    />
                    <SplitInput descriptor="Please select the currency">
                        <SelectInput
                            name="currencyCode"
                            onChange={this.onChange}
                            value={property.currency || "none"}
                            options={this.currencyCodes}
                        />
                        <div />
                    </SplitInput>

                    <AddPropertyActions />
                </form>
            </StyledDashboard>
        );
    }
}
