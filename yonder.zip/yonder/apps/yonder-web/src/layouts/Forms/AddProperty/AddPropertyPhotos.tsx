import React from "react";
import styled from "styled-components";
import { observer, inject } from "mobx-react";
import { ImageAsset, ID } from "@yonder/db";

import { IAddPropertyStore, IFirebaseStore, IListingPhotoUploadStore, IContentModalStore } from "../../../store";
import { StyledDashboard, PhotoThumbnail, MouseClickEvent, FormChangeEvent } from "../../../components";
import { isStringInvalid, spaceSeparateStringArray } from "../../../functions";
import { AddPropertyActions } from "./AddPropertyActions";

export type ImageUploadCallback = (id: ID) => Promise<void>;
export type PhotoGroup = {
    descriptor?: React.ReactNode;
    category?: string;
};

type Props = IAddPropertyStore & IFirebaseStore & IListingPhotoUploadStore & IContentModalStore;

@inject("addPropertyState", "firebaseState", "listingPhotoUploadState", "contentModalState")
@observer
export class AddPropertyPhotos extends React.Component<Props> {
    update = this.props.addPropertyState!.updateProperty;
    save = this.props.addPropertyState!.saveProperty;

    notEnoughPhotos: boolean = true;
    editedCaption: boolean = false;

    galleryMin: number = 7;
    galleryMax: number = 30;
    uploadedOverGalleryMaxMessage: string = "";

    coverPhoto: ImageAsset[] = [];
    galleryPhotos: ImageAsset[] = [];

    thumbDefaults = {
        name: "new",
        size: 0,
        file: "",
        caption: "",
        showDropZone: true,
        onCaptionChange: (ev: FormChangeEvent) => ev.preventDefault()
    };

    photoGroups: PhotoGroup[] = [
        {
            category: "Cover Photo",
            descriptor: (
                <>
                    <h4>Cover Photo (Establishing Shot)</h4>
                    <p>
                        Please upload a landscape or panoramic photo that best embodies both your accommodation
                        (building) and the natural space surrounding it. The cover photo should capture a 'wide field of
                        view' of your Yonder stay experience location.
                    </p>
                    <ul>
                        <li>The image cannot contain people</li>
                        <li>It should evoke awe, convey "Can this be real? Where is this place?"</li>
                        <li>Must be larger than 1920 x 1280px, JPG or PNG file only</li>
                    </ul>
                </>
            )
        },
        {
            descriptor: (
                <>
                    <h4>Gallery Photos (Detail Shot)</h4>
                    <p>
                        Please upload at least 7 photos (add up to 30 photos) that most accurately showcase the interior
                        of your stay as well as the exterior surrounding natural spaces. These are photos that show the
                        particulars that make up the story of your Yonder stay experience.
                    </p>
                    <ul>
                        <li>Avoid having people in these images</li>
                        <li>It should show unique details that bring the environment to life</li>
                        <li>It should enrich the narrative and feel meaningful to your location's story</li>
                        <li>Must be larger than 1024 x 683px, JPG or PNG file only</li>
                    </ul>
                </>
            )
        }
    ];

    initializePhotos = () => {
        const { property, dbPhotos, getPhoto } = this.props.addPropertyState!;

        // Get the cover photo asset (as an array)
        this.coverPhoto = dbPhotos.filter((photo) => photo.id === property.coverPhoto);

        // Get the gallery photo assets from the property.galleryPhotos object
        this.galleryPhotos = property.galleryPhotos
            .filter((id: ID) => {
                let asset: ImageAsset | null = getPhoto(id);
                return asset !== null;
            })
            .map((id: ID) => getPhoto(id)!);

        // Get any leftover unsorted photos
        let unsorted: ImageAsset[] = dbPhotos.filter(
            (photo) => photo.id !== property.coverPhoto && !property.galleryPhotos.includes(photo.id!)
        );
        this.galleryPhotos = this.galleryPhotos.concat(unsorted);
        this.notEnoughPhotos = this.galleryPhotos.length < this.galleryMin || isStringInvalid(property.coverPhoto);
    };

    onFilesAdded = async (files: File[], max: number, callback?: ImageUploadCallback) => {
        if (files.length < 1) return;

        const { firebase } = this.props.firebaseState!;
        const { uploadFiles } = this.props.listingPhotoUploadState!;
        const { addPendingPhoto } = this.props.addPropertyState!;
        const remainingSlots = max - this.galleryPhotos.length;

        if (files.length <= remainingSlots) {
            try {
                if (callback !== this.updateCoverPhoto) {
                    for (let file of files) {
                        addPendingPhoto(file);
                    }
                }

                await uploadFiles(files, firebase, (uploadedFile: File, url: string, uuid: string) => {
                    this.onUpload(uploadedFile, url, uuid, callback);
                });

                this.uploadedOverGalleryMaxMessage = "";
            } catch (err) {
                throw err;
            }
        } else {
            const willUpload = files.slice(0, remainingSlots);
            const willNotUpload = files.slice(remainingSlots);
            const notUploadedPhotoNames = willNotUpload.map((file) => file.name);

            try {
                if (callback !== this.updateCoverPhoto) {
                    for (let file of willUpload) {
                        addPendingPhoto(file);
                    }
                }

                await uploadFiles(willUpload, firebase, (uploadedFile: File, url: string, uuid: string) => {
                    this.onUpload(uploadedFile, url, uuid, callback);
                });

                this.uploadedOverGalleryMaxMessage = `You uploaded over ${
                    this.galleryMax
                } photos. Files${spaceSeparateStringArray(notUploadedPhotoNames)} weren't uploaded.`;
            } catch (err) {
                throw err;
            }
        }
    };

    // This is called after a file has completed
    onUpload = async (uploadedFile: File, url: string, uuid: string, callback?: ImageUploadCallback) => {
        const { addPhoto } = this.props.addPropertyState!;

        let photoId = await addPhoto(uploadedFile, uuid, url);
        if (callback) {
            await callback(photoId);
        }
    };

    onPhotoDelete = (photo: ImageAsset) => {
        const { firebase } = this.props.firebaseState!;
        const { property, deletePhoto, removeGalleryPhoto } = this.props.addPropertyState!;
        const { openDialog } = this.props.contentModalState!;

        openDialog(`Are you sure you want to delete "${photo.name}?"`, "Cancel", "Okay", async () => {
            try {
                if (photo.id === property.coverPhoto) {
                    this.update({
                        coverPhoto: ""
                    });
                } else {
                    removeGalleryPhoto(photo.id!);
                }
                await deletePhoto(photo, firebase);
                await this.save();
            } catch (err) {
                throw err;
            }
        });
    };

    onCaptionChange = (ev: FormChangeEvent, photo: ImageAsset) => {
        ev.preventDefault();

        this.editedCaption = true;

        const { setPhotoCaption } = this.props.addPropertyState!;
        const { value } = ev.target;
        photo.caption = value;
        setPhotoCaption(photo);
    };

    photoThumbFromAsset = (photo: ImageAsset, index: number) => {
        const id = `${index}-${photo.file}`;
        return (
            <PhotoThumbnail
                {...photo}
                key={id}
                caption={photo.caption}
                onCaptionChange={(ev) => this.onCaptionChange(ev, photo)}
                onDelete={() => this.onPhotoDelete(photo)}
            />
        );
    };

    addEmptyPhotos = (array: JSX.Element[], max: number, callback?: ImageUploadCallback) => {
        if (array.length < max) {
            array.push(
                <PhotoThumbnail
                    {...this.thumbDefaults}
                    key={array.length}
                    onFilesAdded={(file) => {
                        this.onFilesAdded(file, max, callback);
                    }}
                    showPending
                />
            );
        }
    };

    updateCoverPhoto = async (id: ID) => {
        this.update({
            coverPhoto: id
        });
        await this.save();
    };

    addGalleryPhoto = async (id: ID) => {
        const { addGalleryPhoto } = this.props.addPropertyState!;
        addGalleryPhoto(id);
        await this.save();
    };

    onSave = (ev: MouseClickEvent) => {
        ev.preventDefault();

        const { setSectionComplete, nextSection } = this.props.addPropertyState!;
        if (!this.notEnoughPhotos) {
            setSectionComplete();
            this.save();
        }
        nextSection();
    };

    render() {
        // Don't re-populate the photos when the captions are edited
        if (!this.editedCaption) {
            this.initializePhotos();
        }
        this.editedCaption = false;

        // Render the cover photo
        let coverPhoto: JSX.Element[] = this.coverPhoto.map(this.photoThumbFromAsset);
        this.addEmptyPhotos(coverPhoto, 1, this.updateCoverPhoto);

        // Render the gallery photos
        let galleryPhotos: JSX.Element[] = this.galleryPhotos.map(this.photoThumbFromAsset);
        this.addEmptyPhotos(galleryPhotos, this.galleryMax, this.addGalleryPhoto);

        const galleries = [coverPhoto, galleryPhotos];

        const lists = this.photoGroups.map((group: PhotoGroup, i: number) => {
            const descriptor = group.descriptor;
            const category = group.category;
            const gallery = galleries[i];

            return (
                <ListCategory className={category ? category.toLocaleLowerCase().replace(" ", "-") : ""} key={i}>
                    {descriptor && <>{descriptor}</>}
                    <div className="list">{gallery}</div>
                </ListCategory>
            );
        });

        //const submitDisabled: boolean = isStringInvalid(property.coverPhoto);

        return (
            <StyledDashboard>
                {lists}

                {this.notEnoughPhotos && (
                    <p className="success-message">
                        To complete this section, please upload at least 7 gallery photos and a cover photo.
                    </p>
                )}
                {this.uploadedOverGalleryMaxMessage && (
                    <p className="success-message">{this.uploadedOverGalleryMaxMessage}</p>
                )}
                <AddPropertyActions onSave={this.onSave} />
            </StyledDashboard>
        );
    }
}

export const ListCategory = styled.div`
    width: 100%;
    margin-bottom: 1rem;

    h4 {
        margin-bottom: 1rem;
    }

    .list {
        display: flex;
        flex-wrap: wrap;
        flex-direction: row;
        margin: 0 -1.5rem;

        .photo-thumbnail {
            display: flex;
            flex-basis: 50%;
            flex-direction: column;
        }
    }

    &.cover-photo {
        margin-bottom: 3rem;

        .photo-thumbnail {
            flex-basis: 100%;

            .thumb-container {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;

                img,
                .drop-zone,
                .loading-spinner {
                    position: relative;
                }
                img {
                    align-self: center;
                    transform: none;
                    top: 0;
                    left: 0;
                }
                .drop-zone,
                .loading-spinner {
                    min-height: 16rem;
                }
                &:before {
                    display: none;
                }
            }
        }
    }

    @media only screen and (min-width: 75rem) {
        .list .photo-thumbnail {
            flex-basis: 33%;
        }

        &.cover-photo {
            .list {
                width: 70%;
                .photo-thumbnail {
                    flex-basis: 100%;
                }
            }
        }
    }
`;
