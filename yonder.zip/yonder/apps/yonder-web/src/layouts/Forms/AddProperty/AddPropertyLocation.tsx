import React from "react";
import { observer, inject } from "mobx-react";
import {
    StatesUS,
    getStateName,
    Countries,
    getCountryName,
    PropertyLocation,
    ProvincesCanada,
    getProvinceName
} from "@yonder/db";

import { IAddPropertyStore } from "../../../store";
import { SelectInput, TextInput, FormChangeEvent, SplitInput, reZipCode, SelectOption } from "../../../components";
import { enumToSelectOptions, isStringInvalid } from "../../../functions";
import { AddPropertyActions } from "./AddPropertyActions";

type ValidationErrors = {
    zipCode?: string;
};
type Props = IAddPropertyStore;
type State = {
    validationErrors: ValidationErrors;
    zipCode?: string;
};

@inject("addPropertyState")
@observer
export class AddPropertyLocation extends React.Component<Props, State> {
    provincesCanada: SelectOption[] = enumToSelectOptions(ProvincesCanada, getProvinceName);
    statesUS: SelectOption[] = enumToSelectOptions(StatesUS, getStateName);
    countryOptions: SelectOption[] = enumToSelectOptions(Countries, getCountryName, false);

    state: State = {
        validationErrors: {},
        zipCode: undefined
    };

    update = this.props.addPropertyState!.updateProperty;

    initLocation = () => {
        const { property } = this.props.addPropertyState!;
        if (!property.location.country) {
            this.update({
                location: {
                    country: Countries.USA
                }
            });
        }
    };

    componentDidMount() {
        this.initLocation();
    }

    onChange = (ev: FormChangeEvent) => {
        const { name, value } = ev.target;

        let validationErrors: ValidationErrors = this.state.validationErrors;

        let location: PropertyLocation = {};

        switch (name) {
            case "propertyLocationAddress1":
                location.address1 = value;
                break;

            case "propertyLocationAddress2":
                location.address2 = value;
                break;

            case "propertyLocationCity":
                location.city = value;
                break;

            case "propertyLocationState":
                location.state = value !== "none" ? value : null;
                break;

            case "propertyLocationZipcode":
                let zipCode: string | undefined = value;
                if (location.country === Countries.Other) {
                    location.zipCode = value;
                } else {
                    if (reZipCode.test(value) && value !== "") {
                        validationErrors.zipCode = undefined;
                        zipCode = undefined;
                        location.zipCode = value;
                    } else {
                        validationErrors.zipCode = "Must be a valid zip code.";
                        this.setState({ zipCode, validationErrors });
                        return;
                    }
                    this.setState({ validationErrors });
                }
                break;

            case "propertyLocationCountry":
                location.state = "";
                location.country = value !== "none" ? value : undefined;
                break;

            case "propertyLocationCountryName":
                location.countryName = value;
                break;
        }

        const { property } = this.props.addPropertyState!;
        this.update({
            location: {
                ...property.location,
                ...location
            }
        });
    };

    render() {
        const { validationErrors, zipCode } = this.state;
        const { property } = this.props.addPropertyState!;
        const { location } = property;

        const invalidZipCode = !!validationErrors.zipCode || isStringInvalid(location.zipCode);
        const invalidAddress = isStringInvalid(location.address1);
        const invalidCity = isStringInvalid(location.city);
        const invalidState = isStringInvalid(location.state);
        const invalidCountry = location.country === Countries.Other && isStringInvalid(location.countryName);

        const submitDisabled = invalidZipCode || invalidAddress || invalidCity || invalidState || invalidCountry;

        const countryInput = (
            <SelectInput
                name="propertyLocationCountry"
                label="Country"
                value={location.country}
                options={this.countryOptions}
                onChange={this.onChange}
            />
        );

        return (
            <>
                <TextInput
                    name="propertyLocationAddress1"
                    value={location.address1}
                    onChange={this.onChange}
                    label="Street address"
                />
                <TextInput
                    name="propertyLocationAddress2"
                    value={location.address2}
                    onChange={this.onChange}
                    label="Suite, unit number (optional)"
                />
                <TextInput name="propertyLocationCity" value={location.city} onChange={this.onChange} label="City" />
                <SplitInput error={validationErrors.zipCode}>
                    {location.country !== Countries.Other ? (
                        <SelectInput
                            name="propertyLocationState"
                            label={location.country === Countries.Canada ? "Province" : "State"}
                            value={location.state || "none"}
                            options={location.country === Countries.Canada ? this.provincesCanada : this.statesUS}
                            onChange={this.onChange}
                        />
                    ) : (
                        <TextInput
                            name="propertyLocationState"
                            label="State/Province"
                            value={location.state}
                            onChange={this.onChange}
                        />
                    )}
                    <TextInput
                        name="propertyLocationZipcode"
                        label="Zip code"
                        value={invalidZipCode ? zipCode : location.zipCode}
                        onChange={this.onChange}
                    />
                </SplitInput>

                {location.country !== Countries.Other ? (
                    countryInput
                ) : (
                    <SplitInput>
                        {countryInput}
                        <TextInput
                            name="propertyLocationCountryName"
                            value={location.countryName}
                            onChange={this.onChange}
                        />
                    </SplitInput>
                )}

                <AddPropertyActions submitDisabled={submitDisabled} />
            </>
        );
    }
}
