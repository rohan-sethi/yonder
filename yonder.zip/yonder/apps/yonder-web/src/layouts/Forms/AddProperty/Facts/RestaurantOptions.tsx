import React from "react";

import { Property } from "@yonder/db";
import {
    FormChangeEventFunction,
    MouseClickEvent,
    StyledPropertyFactDetails,
    InputYesNo,
    ListTextBox,
    KeyPressEvent,
    TextInput,
    InputCheckbox
} from "../../../../components";

type Props = {
    property: Property;
    onChange: (ev: FormChangeEventFunction) => void;
    onYesNoChange: (ev: MouseClickEvent, name: string, value: boolean) => void;
    onAddRestaurant: (ev?: MouseClickEvent | KeyPressEvent) => void;
    onRemoveRestaurant: (ev: MouseClickEvent | KeyPressEvent, i?: number) => void;
    onChangeRestaurant: (ev: FormChangeEventFunction, i: number) => void;
};

type State = {
    displayDetails: boolean;
};

export class RestaurantOptions extends React.Component<Props, State> {
    state: State = {
        displayDetails: false
    };

    onChangeDisplay = (ev: React.MouseEvent) => {
        ev.preventDefault();

        const { displayDetails } = this.state;
        this.setState({
            displayDetails: !displayDetails
        });
    };

    render() {
        const {
            property,
            onChange,
            onYesNoChange,
            onAddRestaurant,
            onRemoveRestaurant,
            onChangeRestaurant
        } = this.props;
        const { displayDetails } = this.state;

        const accordionLabel = !!displayDetails ? "Collapse" : "Expand to enter response";
        const accordionClass = !!displayDetails ? "minus" : "plus";

        return (
            <StyledPropertyFactDetails>
                <div className="header" onClick={(ev: React.MouseEvent) => this.onChangeDisplay(ev)}>
                    <p>Restaurant Options</p>

                    <div className="button-toggle">
                        <label className="accordion-label" htmlFor={`restaurantOptions`}>
                            {accordionLabel}
                        </label>
                        <button id={`restaurantOptions`}>
                            <div className={accordionClass} />
                        </button>
                    </div>
                </div>

                {!!displayDetails && (
                    <div className="display-details">
                        <InputYesNo
                            name="restaurantOnSite"
                            descriptor="Is there any restaurants on site?"
                            value={property.restaurantOnSite}
                            onClick={onYesNoChange}
                            padded={false}
                        />
                        <ListTextBox
                            name="suggestedRestaurantsNearby"
                            label="Please recommend up to 5 additional restaurants nearby."
                            collection={property.suggestedRestaurantsNearby}
                            onFieldAdd={onAddRestaurant}
                            addLabel="Add a restaurant"
                            onFieldRemove={(ev, i) => onRemoveRestaurant(ev, i)}
                            removeLabel="Remove last restaurant"
                            onChange={(ev, i) => onChangeRestaurant(ev, i)}
                            placeholder="E.g. Nick's Diner"
                            buttonAlignment="block"
                        />
                        <div className="right-label">
                            <TextInput
                                name="milesToNearestOffSiteRestaurant"
                                label="Miles"
                                descriptor="How far is the nearest off-site restaurant?"
                                value={property.milesToNearestOffSiteRestaurant}
                                placeholder="Numeric value only"
                                onChange={onChange}
                                rightLabel
                            />
                        </div>
                        <InputCheckbox
                            name="lessThanMileToOffSiteRestaurant"
                            label="This restaurant is less than a mile away."
                            onChange={onChange}
                            checked={property.lessThanMileToNearestOffSiteRestaurant}
                            className="margin-top"
                        />
                    </div>
                )}
                <hr className="thin-hr" />
            </StyledPropertyFactDetails>
        );
    }
}
