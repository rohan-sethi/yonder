import React from "react";
import { Property } from "@yonder/db";
import { FormChangeEventFunction, TextInput, InputCheckbox, StyledPropertyFactDetails } from "../../../../components";

type Props = {
    property: Property;
    onChange: (ev: FormChangeEventFunction) => void;
};

type State = {
    displayDetails: boolean;
};

export class NearbyGroceryAndGas extends React.Component<Props, State> {
    state: State = {
        displayDetails: false
    };

    onChangeDisplay = (ev: React.MouseEvent) => {
        ev.preventDefault();

        const { displayDetails } = this.state;
        this.setState({
            displayDetails: !displayDetails
        });
    };

    render() {
        const { property, onChange } = this.props;
        const { displayDetails } = this.state;

        const accordionLabel = !!displayDetails ? "Collapse" : "Expand to enter response";
        const accordionClass = !!displayDetails ? "minus" : "plus";

        return (
            <StyledPropertyFactDetails>
                <div className="header" onClick={(ev: React.MouseEvent) => this.onChangeDisplay(ev)}>
                    <p>Nearby Grocery and Gas</p>

                    <div className="button-toggle">
                        <label className="accordion-label" htmlFor="nearby-grocery-and-gas">
                            {accordionLabel}
                        </label>
                        <button id="nearby-grocery-and-gas">
                            <div className={accordionClass} />
                        </button>
                    </div>
                </div>

                {!!displayDetails && (
                    <div className="display-details">
                        <TextInput
                            name="groceryStoreRecommendation"
                            descriptor="Please suggest a nearby grocery store for your guests."
                            value={property.groceryStoreRecommendation}
                            placeholder="E.g. ABC Grocery Store"
                            onChange={onChange}
                        />
                        <div className="right-label">
                            <TextInput
                                name="milesToSuggestedGroceryStore"
                                label="Miles"
                                descriptor="How far is the nearby grocery store from your property?"
                                value={property.milesToNearestGroceryStore}
                                placeholder="Numeric value only"
                                onChange={onChange}
                                rightLabel
                            />
                        </div>
                        <InputCheckbox
                            name="lessThanMileToGrocery"
                            label="This grocery store is less than a mile away."
                            onChange={onChange}
                            checked={property.lessThanMileToNearestGroceryStore}
                            className="margin-top"
                        />
                        <div className="right-label">
                            <TextInput
                                name="milesToSuggestedGasStation"
                                label="Miles"
                                descriptor="How far is the nearest gas station from your property?"
                                value={property.milesToNearestGasStation}
                                placeholder="Numeric value only"
                                onChange={onChange}
                                rightLabel
                            />
                        </div>
                        <InputCheckbox
                            name="lessThanMileToGasStation"
                            label="This gas station is less than a mile away."
                            onChange={onChange}
                            checked={property.lessThanMileToNearestGasStation}
                            className="margin-top"
                        />
                    </div>
                )}
                <hr className="thin-hr" />
            </StyledPropertyFactDetails>
        );
    }
}
