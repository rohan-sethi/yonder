import React from "react";
import { observer, inject } from "mobx-react";
import { Amenities, getAmenityLabel, getAmenitiesByCategory } from "@yonder/db";

import { IAddPropertyStore } from "../../../store";
import { StyledDashboard, FormChangeEvent, InputCheckbox, InputCounter } from "../../../components";
import { enumToInputOptions } from "../../../functions";
import { LabeledEnum } from "../../../interfaces";
import { AddPropertyActions } from "./AddPropertyActions";

type AmenityCategory = {
    name: string;
    amenities: LabeledEnum[];
};

type Props = IAddPropertyStore;

@inject("addPropertyState")
@observer
export class AddPropertyBathrooms extends React.Component<Props> {
    amenitiesByCategory: Amenities[] = getAmenitiesByCategory("Bathroom");

    bathroomAmenities: AmenityCategory = {
        name: "Bathroom",
        amenities: enumToInputOptions(Amenities, getAmenityLabel).filter((amenity: LabeledEnum) =>
            this.amenitiesByCategory.includes(amenity.name as Amenities)
        )
    };

    update = this.props.addPropertyState!.updateProperty;

    onChangeAmenity = (ev: FormChangeEvent) => {
        const { value } = ev.target;
        const { addAmenity, removeAmenity } = this.props.addPropertyState!;

        const amenity: Amenities = ev.target.name;
        if (value) {
            addAmenity(amenity);
        } else {
            removeAmenity(amenity);
        }
    };

    onChangeFullBathrooms = async (count: number) => {
        this.update({
            fullBathroomCount: count
        });
    };

    onChangeHalfBathrooms = async (count: number) => {
        this.update({
            halfBathroomCount: count
        });
    };

    render() {
        const { property } = this.props.addPropertyState!;

        const checkboxes = this.bathroomAmenities.amenities.map((amenity: LabeledEnum, i: number) => {
            const { name, label } = amenity;
            let checked: boolean = false;
            if (property.amenities) {
                checked = property.amenities.includes(name as Amenities);
            }

            return (
                <InputCheckbox
                    groupName="bathroomAmenities"
                    name={name}
                    label={label}
                    onChange={this.onChangeAmenity}
                    checked={checked}
                    key={i}
                />
            );
        });

        return (
            <StyledDashboard>
                <form>
                    <InputCounter
                        descriptor="Number of full baths that include shower, toilet and sink."
                        unitString="full bath"
                        value={property.fullBathroomCount}
                        minValue={0}
                        onChange={this.onChangeFullBathrooms}
                    />
                    <InputCounter
                        descriptor="Number of half baths that include a toilet and sink."
                        unitString="half bath"
                        value={property.halfBathroomCount}
                        minValue={0}
                        onChange={this.onChangeHalfBathrooms}
                    />
                    <p>Select all available bathroom amenities.</p>
                    {checkboxes}

                    <AddPropertyActions />
                </form>
            </StyledDashboard>
        );
    }
}
