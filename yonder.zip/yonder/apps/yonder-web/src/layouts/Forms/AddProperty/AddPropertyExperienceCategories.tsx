import React from "react";
import { observer, inject } from "mobx-react";
import { ExperienceCategories, getExperienceCategoryLabel, getExperienceCategoryImageUrl } from "@yonder/db";

import { IAddPropertyStore, IContentModalStore } from "../../../store";
import {
    StyledDashboard,
    FormChangeEvent,
    InputCheckboxImage,
    BusinessCategories,
    InformationLink
} from "../../../components";
import { LabeledEnum } from "../../../interfaces";
import { enumToInputOptions } from "../../../functions";
import { StyledExperienceCategories } from "../SubmissionApproval";
import { AddPropertyActions } from "./AddPropertyActions";

type Props = IAddPropertyStore & IContentModalStore;

@inject("addPropertyState", "contentModalState")
@observer
export class AddPropertyExperienceCategories extends React.Component<Props> {
    experienceCategories: LabeledEnum[] = enumToInputOptions(ExperienceCategories, getExperienceCategoryLabel);

    update = this.props.addPropertyState!.updateProperty;

    onChange = (ev: FormChangeEvent) => {
        const { value } = ev.target;
        const { addExperienceCategory, removeExperienceCategory } = this.props.addPropertyState!;
        const { experienceCategories } = this.props.addPropertyState!.property;
        const experienceCategory: ExperienceCategories = ev.target.name;

        if (value) {
            if (experienceCategories.length <= 1) {
                addExperienceCategory(experienceCategory);
            }
        } else {
            removeExperienceCategory(experienceCategory);
        }
    };

    render() {
        const { property } = this.props.addPropertyState!;
        const { open } = this.props.contentModalState!;

        const experienceCategoryCheckboxes = this.experienceCategories.map((category: LabeledEnum, i: number) => {
            const { name, label } = category;
            const checked: boolean = property.experienceCategories.includes(name as ExperienceCategories);

            return (
                <InputCheckboxImage
                    groupName="experienceCategory"
                    name={name}
                    label={label}
                    url={getExperienceCategoryImageUrl(name as any)}
                    onChange={this.onChange}
                    checked={checked}
                    key={i}
                />
            );
        });

        const submitDisabled = experienceCategoryCheckboxes.every((checkbox) => checkbox.props.checked === false);

        return (
            <StyledDashboard>
                <form>
                    <p>What Experience Category best describes your stay? You can choose two.</p>
                    <InformationLink
                        onClick={() => open("", <BusinessCategories />)}
                        label="Explain business categories"
                    />
                    <StyledExperienceCategories>{experienceCategoryCheckboxes}</StyledExperienceCategories>

                    <AddPropertyActions submitDisabled={submitDisabled} />
                </form>
            </StyledDashboard>
        );
    }
}
