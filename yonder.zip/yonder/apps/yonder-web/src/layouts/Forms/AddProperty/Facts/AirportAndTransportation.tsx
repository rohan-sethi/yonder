import React from "react";

import { Property } from "@yonder/db";
import {
    FormChangeEventFunction,
    MouseClickEvent,
    TextInput,
    InputYesNo,
    ListTextBox,
    StyledPropertyFactDetails,
    KeyPressEvent
} from "../../../../components";

type Props = {
    property: Property;
    onChange: (ev: FormChangeEventFunction) => void;
    onYesNoChange: (ev: MouseClickEvent, name: string, value: boolean) => void;
    onAddTransportationOption: (ev?: MouseClickEvent | KeyPressEvent) => void;
    onRemoveTransportationOption: (ev: MouseClickEvent | KeyPressEvent, i?: number) => void;
    onChangeTransportationOption: (ev: FormChangeEventFunction, i: number) => void;
};

type State = {
    displayDetails: boolean;
};

export class AirportAndTransportation extends React.Component<Props, State> {
    state: State = {
        displayDetails: false
    };

    onChangeDisplay = (ev: React.MouseEvent) => {
        ev.preventDefault();

        const { displayDetails } = this.state;
        this.setState({
            displayDetails: !displayDetails
        });
    };

    render() {
        const {
            property,
            onChange,
            onYesNoChange,
            onAddTransportationOption,
            onRemoveTransportationOption,
            onChangeTransportationOption
        } = this.props;
        const { displayDetails } = this.state;

        const accordionLabel = !!displayDetails ? "Collapse" : "Expand to enter response";
        const accordionClass = !!displayDetails ? "minus" : "plus";

        return (
            <StyledPropertyFactDetails>
                <div className="header" onClick={(ev: React.MouseEvent) => this.onChangeDisplay(ev)}>
                    <p>Airport and Transportation</p>

                    <div className="button-toggle">
                        <label className="accordion-label" htmlFor="airport-and-transportation">
                            {accordionLabel}
                        </label>
                        <button id="airport-and-transportation">
                            <div className={accordionClass} />
                        </button>
                    </div>
                </div>

                {!!displayDetails && (
                    <div className="display-details">
                        <TextInput
                            name="nearestAirport"
                            descriptor="What's the name of the nearest airport?"
                            value={property.nearestAirport}
                            placeholder="E.g. EWR- Newark Liberty International"
                            onChange={onChange}
                        />
                        <div className="right-label">
                            <TextInput
                                name="milesToNearestAirport"
                                label="Miles"
                                descriptor="How far is the nearest airport from your property?"
                                value={property.milesToNearestAirport}
                                placeholder="Numeric value only"
                                onChange={onChange}
                                rightLabel
                            />
                        </div>

                        <InputYesNo
                            name="ridesharingApps"
                            descriptor="Are ridesharing apps (E.g. Uber or Lyft) available in the area where your property is located?"
                            value={property.ridesharingApps}
                            onClick={onYesNoChange}
                            padded={false}
                        />
                        <ListTextBox
                            name="transportationOptions"
                            label="Please list any other transportation options that your guests can use during their visit."
                            collection={property.transportationOptions}
                            onFieldAdd={onAddTransportationOption}
                            addLabel="Add a transportation option"
                            onFieldRemove={(ev, i) => onRemoveTransportationOption(ev, i)}
                            removeLabel="Remove last option"
                            onChange={(ev, i) => onChangeTransportationOption(ev, i)}
                            placeholder="E.g. Bus"
                            buttonAlignment="block"
                        />
                    </div>
                )}
                <hr className="thin-hr" />
            </StyledPropertyFactDetails>
        );
    }
}
