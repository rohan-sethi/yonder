import React from "react";
import styled from "styled-components";
import { observer, inject } from "mobx-react";

import {
    FirebaseProvider,
    StyledForm,
    EmailInput,
    PasswordInput,
    FormChangeEvent,
    reEmail,
    SplitInput,
    FirebaseFormRoute,
    SubmitButton,
    ProviderIconSignIn,
    FormSubmitEvent
} from "../../components";
import { IContentModalStore, IFirebaseStore } from "../../store";

type Props = IContentModalStore & IFirebaseStore;

const INITIAL_STATE = {
    email: "",
    password: "",
    error: null as { message?: string } | null,
    providerError: null as { message?: string } | null,
    validationErrors: {
        email: undefined
    }
};

@inject("contentModalState", "firebaseState")
@observer
export class SignInForm extends React.Component<Props> {
    state = INITIAL_STATE;

    componentDidMount() {
        const { setHeader } = this.props.contentModalState!;
        setHeader("");
    }

    onSubmit = async (ev: FormSubmitEvent) => {
        ev.preventDefault();

        const { email, password } = this.state;
        const { firebase } = this.props.firebaseState!;
        const { closeCallback } = this.props.contentModalState!;

        try {
            await firebase.doSignInWithEmailAndPassword(email, password);
            closeCallback();
        } catch (error) {
            this.setState({ error });
        }
    };

    onProviderSignIn = async (provider: FirebaseProvider) => {
        const { firebase } = this.props.firebaseState!;
        const { closeCallback } = this.props.contentModalState!;

        try {
            await firebase.doProviderSignIn(provider);

            closeCallback();
        } catch (error) {
            console.log(error);
            this.setState({ error });
        }
    };

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;
        let validationErrors: any = this.state.validationErrors;
        if (name === "email" && value !== "") {
            if (reEmail.test(value)) {
                validationErrors.email = undefined;
            } else {
                validationErrors.email = "Must be a valid email address";
            }
        }
        this.setState({ [name]: value, validationErrors });
    };

    render() {
        const { email, password, error, validationErrors } = this.state;
        const { setRoute } = this.props.firebaseState!;

        const isInvalid = password === "" || email === "";

        return (
            <StyledSignIn>
                <StyledForm>
                    <form onSubmit={this.onSubmit}>
                        <h2 className="center">Log In</h2>
                        <p className="secondary-action">
                            Not a member yet?{" "}
                            <button type="button" onClick={() => setRoute(FirebaseFormRoute.SignUp)}>
                                Sign up
                            </button>
                        </p>
                        <EmailInput
                            name="email"
                            value={email}
                            placeholder="Email address"
                            onChange={this.onChange}
                            error={validationErrors.email}
                        />
                        <PasswordInput name="password" onChange={this.onChange} placeholder="Password" />
                        <SplitInput>
                            <p className="secondary-action forgot-password">
                                <button type="button" onClick={() => setRoute(FirebaseFormRoute.PasswordReset)}>
                                    Forgot your password?
                                </button>
                            </p>
                        </SplitInput>
                        <SubmitButton label="Log in" disabled={isInvalid} />
                        {error && <p className="error-message">{error.message}</p>}
                    </form>

                    <hr className="with-text" data-content="Or log in with" />

                    <ProviderIconSignIn />
                </StyledForm>
            </StyledSignIn>
        );
    }
}

const StyledSignIn = styled.div`
    max-width: 34rem;
    margin: 3rem auto;
    padding: 0 2rem;

    label.input-checkbox {
        margin: 0;

        .padded-label {
            font-size: 0.875rem;
        }
    }

    h2 {
        font-size: 1.75rem;
    }

    .input-field,
    .split-input {
        margin-bottom: 2.5rem;
    }

    button.submit {
        margin-top: 1rem;
    }
`;
