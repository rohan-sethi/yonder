import React from "react";
import styled from "styled-components";
import { observer, inject } from "mobx-react";

import {
    StyledForm,
    EmailInput,
    SubmitButton,
    FormChangeEvent,
    FormSubmitEvent,
    FirebaseFormRoute,
    reEmail,
    ExternalLink
} from "../../components";
import { IContentModalStore, IFirebaseStore } from "../../store";
import { color } from "../../variables";

type Props = IContentModalStore & IFirebaseStore;

const INITIAL_STATE = {
    email: "",
    success: null as { message?: string } | null,
    error: null as { message?: string } | null,
    validationErrors: {
        email: undefined
    }
};

@inject("contentModalState", "firebaseState")
@observer
export class PasswordResetForm extends React.Component<Props> {
    state = INITIAL_STATE;

    onSubmit = async (ev: FormSubmitEvent) => {
        ev.preventDefault();

        const { email } = this.state;
        const { firebase } = this.props.firebaseState!;

        try {
            await firebase.doPasswordReset(email);

            this.setState({
                success: {
                    message: "Password reset email successfully sent!"
                }
            });
        } catch (error) {
            this.setState({ error });
        }
    };

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;
        let validationErrors: any = this.state.validationErrors;
        if (name === "email" && value !== "") {
            if (reEmail.test(value)) {
                validationErrors.email = undefined;
            } else {
                validationErrors.email = "Must be a valid email address";
            }
        }
        this.setState({ [name]: value, validationErrors });
    };

    render() {
        const { email, success, error, validationErrors } = this.state;
        const { setRoute } = this.props.firebaseState!;

        const isInvalid = email === "" || !!success;

        return (
            <StyledPasswordReset>
                <StyledForm>
                    <h2 className="center">Reset Password</h2>
                    <p className="information">
                        Enter the email address that you used to sign up. We'll email you a link to create a new
                        password.
                    </p>
                    <form onSubmit={this.onSubmit}>
                        <EmailInput
                            name="email"
                            value={email}
                            placeholder="Email address"
                            onChange={this.onChange}
                            error={validationErrors.email}
                        />
                        <SubmitButton label="Send" disabled={isInvalid} />
                        {success && <p className="success-message">{success.message}</p>}
                        {error && <p className="error-message">{error.message}</p>}
                    </form>
                    <button className="clear" onClick={() => setRoute(FirebaseFormRoute.SignIn)}>
                        Back to log in
                    </button>

                    <p className="secondary-action trouble">
                        Still having trouble? <ExternalLink to="//help.yonder.com/hc/en-us" label="Contact us" />
                    </p>
                </StyledForm>
            </StyledPasswordReset>
        );
    }
}

const StyledPasswordReset = styled.div`
    max-width: 34rem;
    margin: 3rem auto;
    padding: 0 2rem;

    p {
        &.information {
            font-size: 1rem;
            text-align: left;
            margin: 2.5rem 0;
        }

        &.trouble {
            margin-top: 2rem;
        }
    }

    button.clear {
        margin: 1.5rem auto 0;
        display: block;
        color: ${color.primary};

        :hover {
            color: ${color.primaryDark};
        }
    }
`;
