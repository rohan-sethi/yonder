import React from "react";
import { observer, inject } from "mobx-react";
import { yonderGet, HostTypes } from "@yonder/db";

import {
    StyledForm,
    TextInput,
    EmailInput,
    PasswordInput,
    SubmitButton,
    FormChangeEvent,
    FormSubmitEvent,
    reEmail,
    SplitInput,
    rePassword,
    reSpecialChars,
    reNumbers
} from "../../components";
import { IContentModalStore, IFirebaseStore } from "../../store";
import { isStringInvalid } from "../../functions";

type Props = IContentModalStore & IFirebaseStore;

type ValidationErrors = {
    name?: string;
    email?: string;
    password?: string;
};
const INITIAL_STATE = {
    firstName: "",
    lastName: "",
    email: "",
    passwordOne: "",
    passwordTwo: "",
    invited: false,
    error: null as { message?: string } | null,
    validationErrors: {
        name: undefined,
        email: undefined,
        password: undefined
    } as ValidationErrors
};

type VoidFunction = () => void;

@inject("contentModalState", "firebaseState")
@observer
export class SignUpEmailForm extends React.Component<Props> {
    state = INITIAL_STATE;
    onSubmitAction: VoidFunction | null = null;
    onBeforeSubmitAction: VoidFunction | null = null;

    onSubmit = async (ev: FormSubmitEvent) => {
        ev.preventDefault();

        const { validationErrors } = this.state;
        if (validationErrors.password || validationErrors.email) return;

        const { firstName, lastName, email, passwordOne } = this.state;
        const { signUpUserViaEmail } = this.props.firebaseState!;
        const { closeCallback } = this.props.contentModalState!;

        try {
            if (this.onBeforeSubmitAction) {
                this.onBeforeSubmitAction();
            }
            await signUpUserViaEmail(firstName, lastName, email, passwordOne);
            if (this.onSubmitAction) {
                this.onSubmitAction();
            }
            closeCallback();
        } catch (error) {
            this.setState({ error });
        }
    };

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;
        const { passwordOne } = this.state;
        let validationErrors: ValidationErrors = this.state.validationErrors;

        switch (name) {
            case "firstName":
            case "lastName":
                if (!reSpecialChars.test(value) && !reNumbers.test(value) && value !== "") {
                    validationErrors.name = undefined;
                } else {
                    validationErrors.name = "First or last name must not contain special characters or numbers";
                }
                break;

            case "email":
                if (reEmail.test(value) && value !== "") {
                    validationErrors.email = undefined;
                } else {
                    validationErrors.email = "Must be a valid email address";
                }
                break;

            case "passwordOne":
                if (rePassword.test(value) && value !== "") {
                    validationErrors.password = undefined;
                } else {
                    validationErrors.password =
                        "Password should contain at least 8 characters and either one number or special character (!@#$%^&*)";
                }
                break;

            case "passwordTwo":
                if (passwordOne === value && value !== "") {
                    validationErrors.password = undefined;
                } else {
                    validationErrors.password = "Passwords must match";
                }
                break;
        }

        this.setState({ [name]: value, validationErrors });
    };

    componentDidMount() {
        const { setHeader } = this.props.contentModalState!;
        setHeader("Sign Up with Email");

        if (window.location.search !== "") {
            const { redeemInviteLink } = this.props.firebaseState!;
            let urlParams = new URLSearchParams(window.location.search);

            // ?invite=id
            const inviteId = urlParams.get("invite");
            if (inviteId !== null) {
                //console.log(inviteId);
                (async () => {
                    let result = await yonderGet(`/invite/${inviteId}`);
                    if (result.email) {
                        this.setState({ email: result.email, invited: true });
                    }
                })();
                this.onSubmitAction = () => {
                    redeemInviteLink(inviteId);
                };
            }

            const signUpType = urlParams.get("type");
            if (signUpType !== null) {
                if (signUpType === "mgmt") {
                    this.onBeforeSubmitAction = () => {
                        const { setSubmissionRoute } = this.props.firebaseState!;
                        setSubmissionRoute(HostTypes.PropertyManagement);
                    };
                }
            }

            const startedSignupEmail = urlParams.get("email");
            if (startedSignupEmail !== null) {
                this.setState({ email: startedSignupEmail });
            }
        }
    }

    render() {
        const { firstName, lastName, email, passwordOne, passwordTwo, error, validationErrors } = this.state;

        const invalidFirstName = isStringInvalid(firstName);
        const invalidLastName = isStringInvalid(lastName);
        const invalidEmail = isStringInvalid(email);
        const invalidPasswordOne = isStringInvalid(passwordOne) || !!validationErrors.password;
        const invalidPasswordTwo = isStringInvalid(passwordTwo);
        const isInvalid =
            invalidEmail || invalidPasswordOne || invalidPasswordTwo || invalidFirstName || invalidLastName;

        return (
            <StyledForm>
                <form onSubmit={this.onSubmit}>
                    <SplitInput error={validationErrors.name}>
                        <TextInput
                            name="firstName"
                            value={firstName}
                            onChange={this.onChange}
                            placeholder="First Name"
                            autoFocus
                        />
                        <TextInput name="lastName" value={lastName} onChange={this.onChange} placeholder="Last Name" />
                    </SplitInput>

                    {!this.state.invited ? (
                        <EmailInput
                            name="email"
                            value={email}
                            placeholder="Email Address"
                            onChange={this.onChange}
                            error={validationErrors.email}
                        />
                    ) : (
                            <div className="input-field">
                                <p className="input-no-edit">{email}</p>
                            </div>
                        )}

                    <PasswordInput name="passwordOne" onChange={this.onChange} placeholder="Password" />
                    <PasswordInput name="passwordTwo" onChange={this.onChange} placeholder="Confirm Password" />
                    {validationErrors.password && <p className="error-message">{validationErrors.password}</p>}
                    <SubmitButton label="Sign up" disabled={isInvalid} />
                    {error && <p className="error-message">{error.message}</p>}
                </form>
            </StyledForm>
        );
    }
}
