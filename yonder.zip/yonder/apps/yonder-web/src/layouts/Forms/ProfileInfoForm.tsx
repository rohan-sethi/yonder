import React from "react";
import { observer, inject } from "mobx-react";
import { Genders, getGenderLabel } from "@yonder/db";

import { IFirebaseStore } from "../../store";
import {
    StyledForm,
    TextInput,
    DateInput,
    SubmitButton,
    SelectInput,
    // PhoneInput,
    InputTextArea,
    FormChangeEvent,
    FormSubmitEvent,
    rePhoneNumber,
    SplitInput,
    SelectOption,
    InputLabel,
    limitTextAreaInput
} from "../../components";
import { enumToSelectOptions, isStringInvalid, dateOnly } from "../../functions";

type ValidationErrors = {
    phoneNumber?: string;
};
type Props = IFirebaseStore;
type State = {
    phoneNumber?: string;
    success: { message?: string } | null;
    error: { message?: string } | null;
    validationErrors: ValidationErrors;
};

@inject("firebaseState")
@observer
export class ProfileInfoForm extends React.Component<Props, State> {
    genders: SelectOption[] = enumToSelectOptions(Genders, getGenderLabel);
    state: State = {
        phoneNumber: undefined,
        success: null,
        error: null,
        validationErrors: {}
    };

    onSubmit = async (ev: FormSubmitEvent) => {
        ev.preventDefault();

        const { saveUserProfile } = this.props.firebaseState!;

        try {
            await saveUserProfile();

            this.setState({
                success: {
                    message: "Profile successfully saved!"
                }
            });
        } catch (error) {
            this.setState({ error });
        }
    };

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;
        const { updateUserProfile } = this.props.firebaseState!;

        let validationErrors: ValidationErrors = this.state.validationErrors;

        switch (name) {
            case "firstName":
                updateUserProfile({
                    firstName: value
                });
                break;

            case "lastName":
                updateUserProfile({
                    lastName: value
                });
                break;

            case "gender":
                updateUserProfile({
                    gender: value
                });
                break;

            case "userLocation":
                updateUserProfile({
                    userLocation: value
                });
                break;

            case "about":
                updateUserProfile({
                    about: limitTextAreaInput(value)
                });
                break;

            case "phoneNumber":
                let phoneNumber: string | undefined = value;
                if (rePhoneNumber.test(value) || value === "") {
                    validationErrors.phoneNumber = undefined;
                    phoneNumber = undefined;
                    updateUserProfile({
                        phoneNumber: value
                    });
                } else {
                    validationErrors.phoneNumber = "Must be a valid phone number.";
                    this.setState({ phoneNumber, validationErrors });
                    return;
                }
                this.setState({ validationErrors });
                break;
        }
    };

    onDateChange = (date: Date) => {
        const { updateUserProfile } = this.props.firebaseState!;
        updateUserProfile({
            dateOfBirth: dateOnly(date)
        });
    };

    render() {
        const {
            //phoneNumber,
            success,
            error,
            validationErrors
        } = this.state;
        const { dbUser } = this.props.firebaseState!;

        const invalidPhone = !!validationErrors.phoneNumber;
        const invalidFirstName = isStringInvalid(dbUser.firstName, true, true);
        const invalidLastName = isStringInvalid(dbUser.lastName, true, true);

        const isInvalid = invalidPhone || invalidFirstName || invalidLastName;

        return (
            <StyledForm>
                <form onSubmit={this.onSubmit}>
                    <InputLabel label="Full name" />
                    <SplitInput hasLabel>
                        <TextInput
                            name="firstName"
                            placeholder="First Name"
                            value={dbUser.firstName}
                            onChange={this.onChange}
                        />
                        <TextInput
                            name="lastName"
                            placeholder="Last Name"
                            value={dbUser.lastName}
                            onChange={this.onChange}
                        />
                    </SplitInput>
                    <SelectInput
                        name="gender"
                        label="Gender"
                        onChange={this.onChange}
                        value={dbUser.gender}
                        options={this.genders}
                    />
                    <DateInput
                        name="dateOfBirth"
                        label="Birthday"
                        value={dbUser.dateOfBirth}
                        onChange={this.onDateChange}
                        placeholder="MM/DD/YYYY"
                        maxDate={new Date()}
                    />
                    {/* <PhoneInput
                        name="phoneNumber"
                        value={invalidPhone ? phoneNumber : dbUser.phoneNumber}
                        label="Phone Number"
                        onChange={this.onChange}
                        error={validationErrors.phoneNumber}
                    /> */}
                    <TextInput
                        name="userLocation"
                        label="Where You Live"
                        value={dbUser.userLocation}
                        onChange={this.onChange}
                    />
                    <InputTextArea
                        name="about"
                        label="About Me"
                        value={dbUser.about}
                        onChange={this.onChange}
                        rows={2}
                        maxRows={6}
                    />
                    {success && <p className="success-message">{success.message}</p>}
                    {error && <p className="error-message">{error.message}</p>}
                    <SubmitButton label="Save" disabled={isInvalid} />
                </form>
            </StyledForm>
        );
    }
}
