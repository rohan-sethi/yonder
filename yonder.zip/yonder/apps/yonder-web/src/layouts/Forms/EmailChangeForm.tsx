import React from "react";
import { observer, inject } from "mobx-react";

import { StyledForm, EmailInput, SubmitButton, FormChangeEvent, FormSubmitEvent, reEmail } from "../../components";
import { IFirebaseStore } from "../../store";

type Props = IFirebaseStore;

const INITIAL_STATE = {
    email: "",
    emailTwo: "",
    success: null as { message?: string } | null,
    error: null as { message?: string } | null,
    validationErrors: {
        email: undefined,
        emailTwo: undefined
    }
};

@inject("firebaseState")
@observer
export class EmailChangeForm extends React.Component<Props> {
    state = INITIAL_STATE;

    onSubmit = async (ev: FormSubmitEvent) => {
        ev.preventDefault();

        const { email } = this.state;
        const { firebase } = this.props.firebaseState!;

        try {
            //await firebase.doUserReauthenticate(currentPassword);
            await firebase.doEmailUpdate(email);

            // refs aren't allowed in stateless components (PasswordInput) so this is done instead
            let fields = [
                document.querySelector('input[name="email"]'),
                document.querySelector('input[name="emailTwo"]')
            ];
            fields.forEach((field: Element | null) => {
                if (field) {
                    (field as HTMLInputElement).value = "";
                }
            });

            this.setState({
                ...INITIAL_STATE,
                success: {
                    message: "Successfully changed email!"
                }
            });
        } catch (error) {
            this.setState({ error });
        }
    };

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;
        let validationErrors: any = this.state.validationErrors;
        if (name === "email" && value !== "") {
            if (reEmail.test(value)) {
                validationErrors.email = undefined;
            } else {
                validationErrors.email = "Must be a valid email address";
            }
        } else if (name === "emailTwo" && value !== "") {
            if (reEmail.test(value)) {
                validationErrors.emailTwo = undefined;
            } else {
                validationErrors.emailTwo = "Must be a valid email address";
            }
        }
        this.setState({ [name]: value, validationErrors });
    };

    render() {
        const { email, emailTwo, success, error, validationErrors } = this.state;

        const isInvalid = email !== emailTwo || email === "";

        return (
            <StyledForm>
                {success && <p className="success-message">{success.message}</p>}
                <form onSubmit={this.onSubmit}>
                    <EmailInput
                        name="email"
                        label="New Email"
                        value={email}
                        onChange={this.onChange}
                        error={validationErrors.email}
                        required
                    />
                    <EmailInput
                        name="emailTwo"
                        label="Confirm New Email"
                        value={emailTwo}
                        onChange={this.onChange}
                        error={validationErrors.emailTwo}
                        required
                    />
                    <SubmitButton label="Change Email" disabled={isInvalid} />
                    {error && <p className="error-message">{error.message}</p>}
                </form>
            </StyledForm>
        );
    }
}
