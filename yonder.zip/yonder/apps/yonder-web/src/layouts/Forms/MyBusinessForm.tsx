import React from "react";
import { inject, observer } from "mobx-react";
import {
    StatesUS,
    getStateName,
    Countries,
    getCountryName,
    LocationAddress,
    ProvincesCanada,
    getProvinceName,
    User,
    UserPermissions
} from "@yonder/db";

import { IFirebaseStore, IHostApprovalSubmissionStore } from "../../store";
import {
    TextInput,
    PhoneInput,
    SubmitButton,
    StyledForm,
    SplitInput,
    SelectInput,
    FormSubmitEvent,
    FormChangeEvent,
    rePhoneNumber,
    SelectOption,
    reZipCode,
    MouseClickEvent,
    EmailInput,
    reEmail,
    FormButton
} from "../../components";
import { isStringInvalid, enumToSelectOptions } from "../../functions";

type ValidationErrors = {
    businessPhone?: string;
    zipCode?: string;
    coHostEmailInvite?: string;
};

type Props = IFirebaseStore & IHostApprovalSubmissionStore;
type State = {
    businessPhone?: string;
    zipCode?: string;
    coHostEmailInvite?: string;
    success: { message?: string } | null;
    inviteSuccess: { message?: string } | null;
    validationErrors: ValidationErrors;
};

@inject("firebaseState", "hostApprovalSubmissionState")
@observer
export class MyBusinessForm extends React.Component<Props, State> {
    statesUS: SelectOption[] = enumToSelectOptions(StatesUS, getStateName);
    provincesCanada: SelectOption[] = enumToSelectOptions(ProvincesCanada, getProvinceName);
    countryOptions: SelectOption[] = enumToSelectOptions(Countries, getCountryName, false);
    initializing: boolean = false;

    state: State = {
        businessPhone: undefined,
        zipCode: undefined,
        coHostEmailInvite: "",
        success: null,
        inviteSuccess: null,
        validationErrors: {}
    };

    init = async () => {
        const { dbOrganization, saveOrganization } = this.props.firebaseState!;
        const { createOrLoadApproval } = this.props.hostApprovalSubmissionState!;
        this.initializing = true;
        //console.log("initializing host approval submission store. Should only trigger once per session...");
        await createOrLoadApproval(saveOrganization, dbOrganization.approvalSubmissionId);
        this.initLocation();
    };

    checkForInit = () => {
        const { dbOrganization } = this.props.firebaseState!;
        const { dbHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        const orgDefined: boolean = dbOrganization.id !== undefined;
        const initNeeded: boolean = orgDefined && dbHostApprovalSubmission.id === undefined;
        if (initNeeded) {
            if (!this.initializing) this.init();
        }
    };

    componentDidMount() {
        this.checkForInit();
    }

    componentDidUpdate() {
        this.checkForInit();
    }

    initLocation = () => {
        const { dbHostApprovalSubmission, updateHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        if (!dbHostApprovalSubmission.location.country) {
            updateHostApprovalSubmission({
                location: {
                    country: Countries.USA
                }
            });
        }
    };

    onSubmit = async (ev: FormSubmitEvent) => {
        ev.preventDefault();

        const { saveHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        const { saveOrganization } = this.props.firebaseState!;

        await saveHostApprovalSubmission();
        await saveOrganization();

        this.setState({
            success: {
                message: "Profile successfully saved!"
            }
        });
    };

    onSendInvite = async (ev: MouseClickEvent) => {
        ev.preventDefault();

        if (!this.state.coHostEmailInvite) return;

        const { createInviteLink, refreshUsers } = this.props.firebaseState!;
        await createInviteLink(this.state.coHostEmailInvite);

        refreshUsers();

        this.setState({
            inviteSuccess: {
                message: `Invite sent to ${this.state.coHostEmailInvite}!`
            }
        });
    };

    onChange = async (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;
        const { updateOrganization } = this.props.firebaseState!;
        const { dbHostApprovalSubmission, updateHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        let validationErrors: ValidationErrors = this.state.validationErrors;

        let location: LocationAddress = {};

        switch (name) {
            case "businessName":
                updateOrganization({
                    name: value
                });
                break;

            case "businessWebsite":
                updateOrganization({
                    website: value
                });
                break;

            case "businessPhone":
                let businessPhone: string | undefined = value;
                if (rePhoneNumber.test(value) && value !== "") {
                    validationErrors.businessPhone = undefined;
                    businessPhone = undefined;
                    updateOrganization({
                        businessPhone: value
                    });
                } else {
                    validationErrors.businessPhone = "Must be a valid phone number.";
                    this.setState({ businessPhone, validationErrors });
                    return;
                }
                this.setState({ validationErrors });
                break;

            case "coHostEmailInvite": {
                const { dbUser } = this.props.firebaseState!;
                let coHostEmailInvite: string | undefined = value;
                if (reEmail.test(value) && value !== "") {
                    validationErrors.coHostEmailInvite = undefined;
                } else {
                    validationErrors.coHostEmailInvite = "Must be a valid email address";
                }
                if (value === dbUser.email) {
                    validationErrors.coHostEmailInvite = "You're already a host!";
                }
                this.setState({ coHostEmailInvite, validationErrors });
                return;
            }

            case "locationAddress1":
                location.address1 = value;
                break;

            case "locationAddress2":
                location.address2 = value;
                break;

            case "locationCity":
                location.city = value;
                break;

            case "locationState":
                location.state = value !== "none" ? value : undefined;
                break;

            case "locationZipCode":
                let zipCode: string | undefined = value;
                if (reZipCode.test(value) && value !== "") {
                    validationErrors.zipCode = undefined;
                    zipCode = undefined;
                    location.zipCode = value;
                } else {
                    validationErrors.zipCode = "Must be a valid zip code.";
                    this.setState({ zipCode, validationErrors });
                    return;
                }
                this.setState({ validationErrors });
                break;

            case "locationCountry":
                location.country = value !== "none" ? value : undefined;
                break;

            case "locationCountryName":
                location.state = "";
                location.countryName = value;
                break;

            default:
                return;
        }

        updateHostApprovalSubmission({
            location: {
                ...dbHostApprovalSubmission.location,
                ...location
            }
        });
    };

    render() {
        const { dbOrganization, dbUser, organizationUsers } = this.props.firebaseState!;
        const { dbHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        const { location } = dbHostApprovalSubmission;

        const { businessPhone, coHostEmailInvite, validationErrors, zipCode, success, inviteSuccess } = this.state;

        const invalidCoHostEmail =
            !!validationErrors.coHostEmailInvite || isStringInvalid(this.state.coHostEmailInvite);

        const invalidName = isStringInvalid(dbOrganization.name);
        const invalidWebsite = isStringInvalid(dbOrganization.website);
        const invalidPhone = !!validationErrors.businessPhone || isStringInvalid(dbOrganization.businessPhone);
        const invalidAddress = isStringInvalid(location.address1);
        const invalidCity = isStringInvalid(location.city);
        const invalidState = isStringInvalid(location.state);
        const invalidZipCode = !!validationErrors.zipCode || isStringInvalid(location.zipCode);
        const invalidCountry = location.country === Countries.Other && isStringInvalid(location.countryName);

        const showCoHosts = dbUser.permissions === UserPermissions.Host || dbUser.permissions === UserPermissions.Admin;

        const isInvalid =
            invalidName ||
            invalidWebsite ||
            invalidPhone ||
            invalidZipCode ||
            invalidAddress ||
            invalidCity ||
            invalidState ||
            invalidCountry;

        const countryInput = (
            <SelectInput
                name="locationCountry"
                label="Country"
                value={location.country}
                options={this.countryOptions}
                onChange={this.onChange}
            />
        );

        const users = organizationUsers.map((user: Partial<User>, i: number) => {
            if (user.id === dbUser.id) return "";

            let name = `${user.firstName} ${user.lastName}`;

            if (user.permissions === UserPermissions.Invited) name = `${user.email} (invited)`;

            return <p key={i}>{name}</p>;
        });

        return (
            <StyledForm>
                <form onSubmit={this.onSubmit}>
                    <h2 id="my-business">My Business</h2>
                    <TextInput
                        name="businessName"
                        value={dbOrganization.name}
                        label="Business name"
                        placeholder="E.g. Yonder Lakeside Cabins"
                        onChange={this.onChange}
                    />
                    <TextInput
                        name="businessWebsite"
                        value={dbOrganization.website}
                        label="Business website"
                        placeholder="www.yonderlakesidecabins.com"
                        onChange={this.onChange}
                    />
                    <PhoneInput
                        name="businessPhone"
                        value={invalidPhone ? businessPhone : dbOrganization.businessPhone}
                        label="Phone Number"
                        onChange={this.onChange}
                        error={validationErrors.businessPhone}
                    />
                    {showCoHosts && (
                        <fieldset name="businessCoHosts">
                            <h2 id="co-hosts">Co-hosts</h2>
                            <div className="static-list">{users}</div>
                            <EmailInput
                                name="coHostEmailInvite"
                                value={coHostEmailInvite}
                                descriptor="Invite a co-host"
                                placeholder="Email address"
                                onChange={this.onChange}
                                error={validationErrors.coHostEmailInvite}
                            />
                            {inviteSuccess && <p className="success-message">{inviteSuccess.message}</p>}
                            <FormButton label="Send Invite" onClick={this.onSendInvite} disabled={invalidCoHostEmail} />
                        </fieldset>
                    )}
                    <fieldset name="propertyLocation">
                        <h2 id="location">Location</h2>
                        <TextInput
                            name="locationAddress1"
                            value={location.address1}
                            onChange={this.onChange}
                            label="Street address"
                            placeholder="123 Yonder Road"
                        />
                        <TextInput
                            name="locationAddress2"
                            value={location.address2}
                            onChange={this.onChange}
                            label="Suite, unit number (optional)"
                        />
                        <TextInput
                            name="locationCity"
                            value={location.city}
                            onChange={this.onChange}
                            label="City"
                            placeholder="Yonderville"
                        />
                        <SplitInput error={validationErrors.zipCode}>
                            {location.country !== Countries.Other ? (
                                <SelectInput
                                    name="locationState"
                                    label="State"
                                    value={location.state || "none"}
                                    options={
                                        // location.country ?
                                        location.country === Countries.Canada ? this.provincesCanada : this.statesUS
                                        // : [{ value: "none", label: "—" }]
                                    }
                                    onChange={this.onChange}
                                />
                            ) : (
                                <TextInput
                                    name="locationState"
                                    label="State"
                                    value={location.state}
                                    onChange={this.onChange}
                                />
                            )}

                            <TextInput
                                name="locationZipCode"
                                label="Zip Code"
                                value={invalidZipCode ? zipCode : location.zipCode}
                                onChange={this.onChange}
                            />
                        </SplitInput>

                        {location.country !== Countries.Other ? (
                            countryInput
                        ) : (
                            <SplitInput>
                                {countryInput}
                                <TextInput
                                    name="locationCountryName"
                                    value={location.countryName}
                                    onChange={this.onChange}
                                />
                            </SplitInput>
                        )}
                        {success && <p className="success-message">{success.message}</p>}
                    </fieldset>

                    <SubmitButton label="Save" disabled={isInvalid} />
                </form>
            </StyledForm>
        );
    }
}
