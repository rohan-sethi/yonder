import React, { FormEvent } from "react";
import styled from "styled-components";
import { inject, observer } from "mobx-react";
import { CardElement, injectStripe, ReactStripeElements } from "react-stripe-elements";

import { StyledForm, SubmitButton, FormButton } from "../../components";
import { IFirebaseStore, IPaymentMethodStore } from "../../store";
import { fontFamily } from "../../variables";
import { MyCards } from "./MyCards";

type Props = IFirebaseStore & ReactStripeElements.InjectedStripeProps & IPaymentMethodStore;
type State = {
    cardInputForm: boolean;
    success: { message?: string } | null;
    error: { message?: string } | null;
};

@inject("firebaseState", "paymentMethodState")
@observer
class PaymentFormComponent extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props);

        this.state = {
            cardInputForm: false,
            success: null,
            error: null
        };
    }

    onFormChange = () => {
        this.setState({ cardInputForm: !this.state.cardInputForm, success: null });
    };

    handleSubmit = async (ev: FormEvent) => {
        ev.preventDefault();

        const { dbUser } = this.props.firebaseState!;
        const { cards, createPaymentMethod } = this.props.paymentMethodState!;

        try {
            const payload = await this.props.stripe!.createToken({ name: `${dbUser.firstName} ${dbUser.lastName}` });
            if (cards.some((card) => card.fingerprint === payload.token!.card!.fingerprint)) {
                return this.setState({
                    cardInputForm: !this.state.cardInputForm,
                    error: {
                        message: "This card already exists."
                    }
                });
            }
            createPaymentMethod(payload.token!.id, payload);

            this.setState({
                cardInputForm: !this.state.cardInputForm,
                success: {
                    message: "Card successfully saved!"
                }
            });
        } catch (error) {
            console.log(error);
        }
    };

    render() {
        const { cardInputForm } = this.state;

        return (
            <StyledForm>
                <MyCards />
                {cardInputForm && (
                    <>
                        <form onSubmit={this.handleSubmit}>
                            <CardInput>
                                <CardElement style={CardElementStyle} />
                            </CardInput>
                            <SubmitButton label="Done" />
                        </form>
                        <FormButton label="Cancel" onClick={this.onFormChange} />
                    </>
                )}
                {!cardInputForm && <FormButton label="Add Card" onClick={this.onFormChange} />}
            </StyledForm>
        );
    }
}

export const PaymentForm = injectStripe(PaymentFormComponent);

const CardInput = styled.div`
    padding: 1rem;
    margin: 0.5rem 0;
    background: white;
    border: solid 1px lightgray;
`;

const CardElementStyle = {
    base: {
        fontFamily: fontFamily.nunitoSans,
        fontSize: "16px"
    }
};
