import React from "react";
import { observer, inject } from "mobx-react";
import { UserPermissions, HostApprovalSubmissionProgress, HostTypes } from "@yonder/db";

import {
    StyledForm,
    SubmitButton,
    FormSubmitEvent,
    FormChangeEvent,
    TextInput,
    rePhoneNumber,
    PhoneInput,
    PageTransition,
    InformationLink,
    TooltipModal
} from "../../../components";
import { IFirebaseStore, IContentModalStore } from "../../../store";
import { isStringInvalid } from "../../../functions";

type ValidationErrors = {
    businessPhone?: string;
};

type Props = IFirebaseStore & IContentModalStore;
type State = {
    businessPhone?: string;
    validationErrors: ValidationErrors;
};

@inject("firebaseState", "contentModalState")
@observer
export class TellUsAboutYourBusiness extends React.Component<Props, State> {
    state: State = {
        validationErrors: {},
        businessPhone: undefined
    };

    noWebsite = {
        header: "What if I don’t have a website?",
        body: `You can also link to anywhere else you may have previously posted your stay or activity. Please write ‘none’ if you don’t have this information available.`
    };

    onSubmit = async (ev: FormSubmitEvent) => {
        ev.preventDefault();

        const { dbUser, saveOrganization, saveUserProfile } = this.props.firebaseState!;
        const mgmt: boolean = dbUser.hostType === HostTypes.PropertyManagement;
        const approvalSubmissionProgress = mgmt
            ? HostApprovalSubmissionProgress.OvernightStays
            : HostApprovalSubmissionProgress.ExperienceCategory;

        let organizationId = await saveOrganization({
            approvalSubmissionProgress
        });
        await saveUserProfile({
            permissions: UserPermissions.HostOrganizationCreated,
            organizationId
        });
    };

    onChange = async (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;
        const { updateOrganization } = this.props.firebaseState!;
        let validationErrors: ValidationErrors = this.state.validationErrors;

        switch (name) {
            case "businessName":
                updateOrganization({
                    name: value
                });
                break;

            case "businessWebsite":
                updateOrganization({
                    website: value
                });
                break;

            case "businessReferralWriteIn":
                updateOrganization({
                    referralWriteIn: value
                });
                break;

            case "businessPhone":
                let businessPhone: string | undefined = value;
                if (rePhoneNumber.test(value) && value !== "") {
                    validationErrors.businessPhone = undefined;
                    businessPhone = undefined;
                    updateOrganization({
                        businessPhone: value
                    });
                } else {
                    validationErrors.businessPhone = "Must be a valid phone number.";
                    this.setState({ businessPhone, validationErrors });
                    return;
                }
                this.setState({ validationErrors });
                break;
        }
    };

    render() {
        const { dbOrganization } = this.props.firebaseState!;
        const { open } = this.props.contentModalState!;

        const { businessPhone, validationErrors } = this.state;

        const invalidName = isStringInvalid(dbOrganization.name);
        const invalidWebsite = isStringInvalid(dbOrganization.website);
        const invalidPhone = !!validationErrors.businessPhone || isStringInvalid(dbOrganization.businessPhone);

        const isInvalid = invalidName || invalidWebsite || invalidPhone;

        return (
            <PageTransition>
                <StyledForm>
                    <h2>Let us get to know you!</h2>
                    <form onSubmit={this.onSubmit}>
                        <fieldset>
                            <TextInput
                                name="businessName"
                                value={dbOrganization.name}
                                descriptor="What is the name of your organization, business, listing, or activity?"
                                placeholder="E.g. Yonder Lakeside Cabin"
                                onChange={this.onChange}
                            />

                            <div className="form-container">
                                <p style={{ marginBottom: ".5rem" }}>What is your website?</p>
                                <InformationLink
                                    onClick={() => open("", <TooltipModal {...this.noWebsite} />)}
                                    label="What if I don’t have a website?"
                                />
                                <TextInput
                                    name="businessWebsite"
                                    value={dbOrganization.website}
                                    placeholder="E.g. www.yonderlakesidecabin.com"
                                    onChange={this.onChange}
                                />
                            </div>
                            <PhoneInput
                                name="businessPhone"
                                value={invalidPhone ? businessPhone : dbOrganization.businessPhone}
                                descriptor="What's the best number to reach you?"
                                onChange={this.onChange}
                                error={validationErrors.businessPhone}
                            />
                            <TextInput
                                name="businessReferralWriteIn"
                                value={dbOrganization.referralWriteIn}
                                label="Once you complete this submission, make sure you refer 6 of your own host-worthy friends to collect 100% of earnings on all bookings for an entire year!"
                                descriptor="Were you referred by another Yonder Host?
                                Include their name below so they can receive some Yonder Love:"
                                placeholder="E.g. Cindy Ruth at Yonder Vineyards"
                                onChange={this.onChange}
                            />
                        </fieldset>

                        <SubmitButton label="Continue" disabled={isInvalid} />
                    </form>
                </StyledForm>
            </PageTransition>
        );
    }
}
