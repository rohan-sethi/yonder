import React from "react";

import {
    StyledForm,
    ContentBlock,
    PageTransition,
    FormButton,
    MouseClickEvent,
    ReferralInfo
} from "../../../components";
import { IContentModalStore } from "../../../store";
import { inject, observer } from "mobx-react";

type Props = IContentModalStore;

@inject("contentModalState")
@observer
export class ApprovalFinish extends React.Component<Props> {
    /*onContact = (ev: MouseClickEvent) => {
        ev.preventDefault();
        console.log("Contact");
    };*/

    onOpenModal = (ev: MouseClickEvent) => {
        const { open } = this.props.contentModalState!;
        ev.preventDefault();
        open("", <ReferralInfo />);
    };

    render() {
        return (
            <PageTransition>
                <StyledForm>
                    <form>
                        <ContentBlock
                            header="We’ve received your info!"
                            body="Regarding the next step, one of our Yonder Scouts will be in touch within 5 business days to discuss your submission."
                            url="/img/icon-hand.svg"
                        />

                        <ContentBlock
                            body="Meanwhile, check out our Host Referral Program and learn more about how you can receive up
                            to an entire year of booking fees waived."
                        />

                        <FormButton buttonStyle="outline-color" label="Tell me more" onClick={this.onOpenModal} />

                        {/*<FormButton type="submit" label="Contact Us" buttonStyle="outline-color" onClick={this.onContact} />*/}
                    </form>
                </StyledForm>
            </PageTransition>
        );
    }
}
