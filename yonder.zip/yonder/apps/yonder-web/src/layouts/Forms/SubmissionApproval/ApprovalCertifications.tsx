import React from "react";
import { observer, inject } from "mobx-react";
import {
    OrganizationCertificates,
    getOrganizationCertificateLabel,
    HostApprovalSubmissionProgress,
    //UserPermissions,
    getSustainabilityEffortLabel,
    getSustainabilityEffortCategories,
    getSustainabilityEffortsByCategory,
    SustainabilityEfforts,
    UserPermissions
} from "@yonder/db";

import {
    StyledForm,
    MouseClickEvent,
    KeyPressEvent,
    FormButton,
    ButtonRow,
    InputCheckbox,
    FormChangeEvent,
    PageTransition,
    ListTextBox,
    CategoryCheckboxes,
    CheckboxCategoryAccordion
} from "../../../components";
import { IFirebaseStore, IHostApprovalSubmissionStore } from "../../../store";
import { enumToInputOptions } from "../../../functions";
import { LabeledEnum } from "../../../interfaces";

type SustainabilityEffortCategory = {
    name: string;
    sustainabilityEfforts: LabeledEnum[];
};

type Props = IFirebaseStore &
    IHostApprovalSubmissionStore & {
        managementHostCertificationsDescriptor?: string;
        sustainabilityEffortsDescriptor?: boolean;
    };

@inject("firebaseState", "hostApprovalSubmissionState")
@observer
export class ApprovalCertifications extends React.Component<Props> {
    certificates: LabeledEnum[] = enumToInputOptions(OrganizationCertificates, getOrganizationCertificateLabel);

    categorizedSustainabilityEfforts: SustainabilityEffortCategory[] = getSustainabilityEffortCategories().map(
        (category: string) => {
            const sustainabilityEfforts: SustainabilityEfforts[] = getSustainabilityEffortsByCategory(category);
            return {
                name: category,
                sustainabilityEfforts: enumToInputOptions(SustainabilityEfforts, getSustainabilityEffortLabel).filter(
                    (sustainabilityEffort: LabeledEnum) =>
                        sustainabilityEfforts.includes(sustainabilityEffort.name as SustainabilityEfforts)
                )
            } as SustainabilityEffortCategory;
        }
    );

    onCertificationChange = (ev: FormChangeEvent) => {
        const { name, value } = ev.target;
        const { addCertificate, removeCertificate } = this.props.hostApprovalSubmissionState!;

        const certificate: OrganizationCertificates = name;
        value ? addCertificate(certificate) : removeCertificate(certificate);
    };

    onSustainabilityEffortChange = (ev: FormChangeEvent) => {
        const { name, value } = ev.target;
        const { addSustainabilityEffort, removeSustainabilityEffort } = this.props.hostApprovalSubmissionState!;

        const sustainabilityEffort: SustainabilityEfforts = name;
        value ? addSustainabilityEffort(sustainabilityEffort) : removeSustainabilityEffort(sustainabilityEffort);
    };

    onSave = async (ev: MouseClickEvent) => {
        ev.preventDefault();
        const { saveOrganization, saveUserProfile } = this.props.firebaseState!;
        const { saveHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        saveHostApprovalSubmission();

        //const mgmt: boolean = dbUser.hostType === HostTypes.PropertyManagement;
        const progress = HostApprovalSubmissionProgress.Completed;

        await saveOrganization({
            approvalSubmissionProgress: progress
        });
        //if (mgmt) {
        await saveUserProfile({
            permissions: UserPermissions.HostApprovalSubmitted
        });
        //}
    };

    onBack = async (ev: MouseClickEvent) => {
        ev.preventDefault();
        const { saveOrganization } = this.props.firebaseState!;

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.Description
        });
    };

    onCertificateAdd = async (ev?: KeyPressEvent | MouseClickEvent) => {
        if (ev) {
            ev.preventDefault();
        }

        const { addOtherCertificate } = this.props.hostApprovalSubmissionState!;
        const { otherCertificates } = this.props.hostApprovalSubmissionState!.dbHostApprovalSubmission;

        addOtherCertificate("");

        this.props.hostApprovalSubmissionState!.updateHostApprovalSubmission({
            otherCertificates: otherCertificates
        });
    };

    onCertificateRemove = (ev: KeyPressEvent | MouseClickEvent, i?: number) => {
        ev.preventDefault();

        const {
            removeOtherCertificateIndex,
            updateHostApprovalSubmission,
            removeLastOtherCertificate
        } = this.props.hostApprovalSubmissionState!;
        const { otherCertificates } = this.props.hostApprovalSubmissionState!.dbHostApprovalSubmission;

        if (otherCertificates.length > 1) {
            i === undefined ? removeLastOtherCertificate() : removeOtherCertificateIndex(i);

            updateHostApprovalSubmission({
                otherCertificates: otherCertificates
            });
        }
    };

    onCertificateChange = (ev: FormChangeEvent, i: number) => {
        const { value } = ev.target;
        const { updateHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        let otherCertificates = this.props.hostApprovalSubmissionState!.dbHostApprovalSubmission.otherCertificates;

        otherCertificates[i] = value;

        updateHostApprovalSubmission({
            otherCertificates: otherCertificates
        });
    };

    onEffortAdd = async (ev?: KeyPressEvent | MouseClickEvent) => {
        if (ev) {
            ev.preventDefault();
        }

        const { addOtherSustainabilityEffort } = this.props.hostApprovalSubmissionState!;
        const { otherSustainabilityEfforts } = this.props.hostApprovalSubmissionState!.dbHostApprovalSubmission;

        addOtherSustainabilityEffort("");

        this.props.hostApprovalSubmissionState!.updateHostApprovalSubmission({
            otherSustainabilityEfforts
        });
    };

    onEffortRemove = (ev: KeyPressEvent | MouseClickEvent, i?: number) => {
        ev.preventDefault();

        const {
            removeOtherSustainabilityEffortIndex,
            updateHostApprovalSubmission,
            removeLastOtherSustainabilityEffort
        } = this.props.hostApprovalSubmissionState!;
        const { otherSustainabilityEfforts } = this.props.hostApprovalSubmissionState!.dbHostApprovalSubmission;

        if (otherSustainabilityEfforts.length > 1) {
            i === undefined ? removeLastOtherSustainabilityEffort() : removeOtherSustainabilityEffortIndex(i);

            updateHostApprovalSubmission({
                otherSustainabilityEfforts
            });
        }
    };

    onEffortChange = (ev: FormChangeEvent, i: number) => {
        const { value } = ev.target;
        const { updateHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        let otherSustainabilityEfforts = this.props.hostApprovalSubmissionState!.dbHostApprovalSubmission
            .otherSustainabilityEfforts;

        otherSustainabilityEfforts[i] = value;

        updateHostApprovalSubmission({
            otherSustainabilityEfforts
        });
    };

    render() {
        const { dbHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        const { managementHostCertificationsDescriptor } = this.props;
        let { sustainabilityEffortsDescriptor } = this.props;

        const checkboxes = this.certificates.map((certificate: LabeledEnum, i: number) => {
            const { name, label } = certificate;

            let checked: boolean = false;
            if (dbHostApprovalSubmission.certificates) {
                checked = dbHostApprovalSubmission.certificates.includes(name as OrganizationCertificates);
            }
            return (
                <InputCheckbox
                    groupName="certificates"
                    name={name}
                    label={label}
                    onChange={this.onCertificationChange}
                    checked={checked}
                    key={i}
                />
            );
        });

        return (
            <PageTransition>
                <StyledForm>
                    <h2>Sustainability Efforts</h2>
                    <div className="form-container">
                        <form>
                            <div className="category-checkboxes">
                                <p>
                                    {managementHostCertificationsDescriptor ||
                                        `Is your business certified by any of these organizations? Please select all that
                                    apply.`}
                                </p>

                                <hr className="thin-hr" />
                                <CheckboxCategoryAccordion
                                    header="certifications"
                                    hideHeader
                                    showAccordionLabel
                                    accordionExpandLabel="Expand to select organizations"
                                    accordionCollapseLabel="Collapse to hide organizations"
                                    labelAndButtonSplit
                                >
                                    <div className="checkboxes">{checkboxes}</div>
                                </CheckboxCategoryAccordion>
                            </div>

                            <ListTextBox
                                name="otherCertificates"
                                label="If your business has any other certifications, please list them here."
                                collection={dbHostApprovalSubmission.otherCertificates}
                                onFieldAdd={this.onCertificateAdd}
                                addLabel="Add a certificate"
                                onFieldRemove={this.onCertificateRemove}
                                removeLabel="Remove last certificate"
                                onChange={this.onCertificateChange}
                                placeholder="E.g. Bee Friendly Farms Certification"
                                inputType="input-field"
                            />

                            {(!!sustainabilityEffortsDescriptor || sustainabilityEffortsDescriptor === undefined) && (
                                <>
                                    <p>
                                        Which of the following sustainable practices can guests enjoy at your
                                        property/stay? Please select all that apply.
                                    </p>
                                </>
                            )}

                            <hr className="thin-hr" />
                            <CheckboxCategoryAccordion header={this.categorizedSustainabilityEfforts[0].name}>
                                <CategoryCheckboxes
                                    categoryName={this.categorizedSustainabilityEfforts[0].name}
                                    categoryEnums={this.categorizedSustainabilityEfforts[0].sustainabilityEfforts}
                                    collection={dbHostApprovalSubmission.sustainabilityEfforts}
                                    onChange={this.onSustainabilityEffortChange}
                                    hideCategoryName
                                />
                            </CheckboxCategoryAccordion>
                            <CheckboxCategoryAccordion header={this.categorizedSustainabilityEfforts[1].name}>
                                <CategoryCheckboxes
                                    categoryName={this.categorizedSustainabilityEfforts[1].name}
                                    categoryEnums={this.categorizedSustainabilityEfforts[1].sustainabilityEfforts}
                                    collection={dbHostApprovalSubmission.sustainabilityEfforts}
                                    onChange={this.onSustainabilityEffortChange}
                                    hideCategoryName
                                />
                            </CheckboxCategoryAccordion>
                            <CheckboxCategoryAccordion header={this.categorizedSustainabilityEfforts[2].name}>
                                <CategoryCheckboxes
                                    categoryName={this.categorizedSustainabilityEfforts[2].name}
                                    categoryEnums={this.categorizedSustainabilityEfforts[2].sustainabilityEfforts}
                                    collection={dbHostApprovalSubmission.sustainabilityEfforts}
                                    onChange={this.onSustainabilityEffortChange}
                                    hideCategoryName
                                />
                            </CheckboxCategoryAccordion>
                            <CheckboxCategoryAccordion header={this.categorizedSustainabilityEfforts[3].name}>
                                <CategoryCheckboxes
                                    categoryName={this.categorizedSustainabilityEfforts[3].name}
                                    categoryEnums={this.categorizedSustainabilityEfforts[3].sustainabilityEfforts}
                                    collection={dbHostApprovalSubmission.sustainabilityEfforts}
                                    onChange={this.onSustainabilityEffortChange}
                                    hideCategoryName
                                />
                            </CheckboxCategoryAccordion>
                            <CheckboxCategoryAccordion header={this.categorizedSustainabilityEfforts[4].name}>
                                <CategoryCheckboxes
                                    categoryName={this.categorizedSustainabilityEfforts[4].name}
                                    categoryEnums={this.categorizedSustainabilityEfforts[4].sustainabilityEfforts}
                                    collection={dbHostApprovalSubmission.sustainabilityEfforts}
                                    onChange={this.onSustainabilityEffortChange}
                                    hideCategoryName
                                />
                            </CheckboxCategoryAccordion>
                            <CheckboxCategoryAccordion header={this.categorizedSustainabilityEfforts[5].name}>
                                <CategoryCheckboxes
                                    categoryName={this.categorizedSustainabilityEfforts[5].name}
                                    categoryEnums={this.categorizedSustainabilityEfforts[5].sustainabilityEfforts}
                                    collection={dbHostApprovalSubmission.sustainabilityEfforts}
                                    onChange={this.onSustainabilityEffortChange}
                                    hideCategoryName
                                />
                            </CheckboxCategoryAccordion>
                            <CheckboxCategoryAccordion header={this.categorizedSustainabilityEfforts[6].name}>
                                <CategoryCheckboxes
                                    categoryName={this.categorizedSustainabilityEfforts[6].name}
                                    categoryEnums={this.categorizedSustainabilityEfforts[6].sustainabilityEfforts}
                                    collection={dbHostApprovalSubmission.sustainabilityEfforts}
                                    onChange={this.onSustainabilityEffortChange}
                                    hideCategoryName
                                />
                            </CheckboxCategoryAccordion>
                            <CheckboxCategoryAccordion header={this.categorizedSustainabilityEfforts[7].name}>
                                <CategoryCheckboxes
                                    categoryName={this.categorizedSustainabilityEfforts[7].name}
                                    categoryEnums={this.categorizedSustainabilityEfforts[7].sustainabilityEfforts}
                                    collection={dbHostApprovalSubmission.sustainabilityEfforts}
                                    onChange={this.onSustainabilityEffortChange}
                                    hideCategoryName
                                />
                            </CheckboxCategoryAccordion>

                            <ListTextBox
                                name="otherSustainabilityEfforts"
                                label="If your business has implemented any other sustainable practices, please list them here."
                                collection={dbHostApprovalSubmission.otherSustainabilityEfforts}
                                onFieldAdd={this.onEffortAdd}
                                addLabel="Add another"
                                onFieldRemove={this.onEffortRemove}
                                removeLabel="Remove last"
                                onChange={this.onEffortChange}
                                placeholder="E.g. Local in-town food waste pickup"
                                inputType="input-field"
                            />
                        </form>
                    </div>
                    <ButtonRow>
                        <FormButton label="Back" buttonStyle="no-outline" onClick={this.onBack} />
                        <div />
                        <FormButton label="Next" onClick={this.onSave} />
                    </ButtonRow>
                </StyledForm>
            </PageTransition>
        );
    }
}
