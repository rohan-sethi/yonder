import React from "react";
import { inject, observer } from "mobx-react";
import { HostApprovalSubmissionProgress } from "@yonder/db";

import {
    StyledForm,
    FormButton,
    ButtonRow,
    InputCounter,
    MouseClickEvent,
    InputYesNo,
    PageTransition,
    InformationLink,
    TooltipModal
} from "../../../components";
import { IFirebaseStore, IHostApprovalSubmissionStore, IContentModalStore } from "../../../store";

type Props = IFirebaseStore & IHostApprovalSubmissionStore & IContentModalStore;
type State = {
    displayNightStayCounter: boolean;
};

@inject("firebaseState", "hostApprovalSubmissionState", "contentModalState")
@observer
export class ApprovalStays extends React.Component<Props, State> {
    state: State = {
        displayNightStayCounter: true
    };

    overnightStaysModal = {
        header: "Overnight Stay",
        body:
            "An overnight stay is a fully-furnished structure guests can sleep in. Your property can offer more than one structure for guests to choose from. This is the total number of structures located on your property, and is not to be confused with the number of rooms in each structure."
    };

    resetStaysCount = () => {
        const { updateHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        updateHostApprovalSubmission({
            overnightStaysCount: 0
        });
    };

    componentDidMount() {
        const { dbHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        if (!dbHostApprovalSubmission.overnightStaysCount) {
            this.resetStaysCount();
        }
    }

    onYesNoChange = (ev: MouseClickEvent, name: string, value: boolean) => {
        ev.preventDefault();

        if (name === "displayCounter") {
            if (value) {
                if (!this.state.displayNightStayCounter)
                    this.setState({
                        displayNightStayCounter: true
                    });
            } else {
                if (this.state.displayNightStayCounter) {
                    this.setState({
                        displayNightStayCounter: false
                    });
                }
                const { dbHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
                if (dbHostApprovalSubmission.overnightStaysCount && dbHostApprovalSubmission.overnightStaysCount > 0) {
                    this.resetStaysCount();
                }
            }
        }
    };

    onChange = async (count: number) => {
        const { updateHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        updateHostApprovalSubmission({
            overnightStaysCount: count
        });
    };

    onSave = async (ev: MouseClickEvent) => {
        ev.preventDefault();
        const { saveOrganization } = this.props.firebaseState!;
        const { saveHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        saveHostApprovalSubmission();

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.Activities
        });
    };

    onBack = async (ev: MouseClickEvent) => {
        ev.preventDefault();
        const { saveOrganization } = this.props.firebaseState!;

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.ExperienceCategory
        });
    };

    render() {
        const { displayNightStayCounter } = this.state;
        const { dbHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        const { open } = this.props.contentModalState!;

        return (
            <PageTransition>
                <StyledForm>
                    <h2>Overnight Stays</h2>
                    <div className="form-container">
                        <div className="form-container">
                            <p style={{ marginBottom: ".5rem" }}>Do you have any overnight stays?</p>
                            <InformationLink
                                onClick={() => open("", <TooltipModal {...this.overnightStaysModal} />)}
                                label="Explain overnight stays"
                            />
                            <InputYesNo
                                name="displayCounter"
                                value={displayNightStayCounter}
                                onClick={this.onYesNoChange}
                            />
                        </div>

                        {displayNightStayCounter && (
                            <form>
                                <hr />
                                <p style={{ marginBottom: ".5rem" }}>How many overnight stays do you have?</p>
                                <InformationLink
                                    onClick={() => open("", <TooltipModal {...this.overnightStaysModal} />)}
                                    label="Explain overnight stays"
                                />
                                <InputCounter
                                    unitString="stay"
                                    value={dbHostApprovalSubmission.overnightStaysCount}
                                    maxValue={31}
                                    onChange={this.onChange}
                                />
                            </form>
                        )}
                    </div>
                    <ButtonRow>
                        <FormButton label="Back" buttonStyle="no-outline" onClick={this.onBack} />
                        <div />
                        <FormButton type="submit" label="Next" onClick={this.onSave} />
                    </ButtonRow>
                </StyledForm>
            </PageTransition>
        );
    }
}
