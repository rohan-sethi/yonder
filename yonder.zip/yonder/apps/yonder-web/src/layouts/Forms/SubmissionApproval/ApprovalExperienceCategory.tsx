import React from "react";
import styled from "styled-components";
import { observer, inject } from "mobx-react";
import {
    ExperienceCategories,
    getExperienceCategoryLabel,
    HostApprovalSubmissionProgress,
    getExperienceCategoryImageUrl
} from "@yonder/db";

import { IFirebaseStore, IHostApprovalSubmissionStore, IContentModalStore } from "../../../store";
import {
    StyledForm,
    InputChangeEvent,
    InputRadioButtonImage,
    FormButton,
    MouseClickEvent,
    ButtonRow,
    ExitWarning,
    BusinessCategories,
    InformationLink,
    PageTransition
} from "../../../components";
import { enumToInputOptions } from "../../../functions";
import { LabeledEnum } from "../../../interfaces";

type Props = IFirebaseStore & IHostApprovalSubmissionStore & IContentModalStore;
type State = {
    selected?: ExperienceCategories;
};

@inject("firebaseState", "hostApprovalSubmissionState", "contentModalState")
@observer
export class ApprovalExperienceCategory extends React.Component<Props, State> {
    experienceCategories: LabeledEnum[] = enumToInputOptions(ExperienceCategories, getExperienceCategoryLabel);

    onChange = (ev: InputChangeEvent) => {
        const { name } = ev.target;
        const { updateHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        updateHostApprovalSubmission({
            experienceCategory: name
        });
    };

    onSave = async (ev: MouseClickEvent) => {
        ev.preventDefault();

        const { saveOrganization } = this.props.firebaseState!;
        const { saveHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        saveHostApprovalSubmission();

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.OvernightStays
        });
    };

    onBack = async (ev: MouseClickEvent) => {
        ev.preventDefault();

        const { saveOrganization } = this.props.firebaseState!;

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.LetsBegin
        });
    };

    openConfirmDialog = (ev: MouseClickEvent) => {
        ev.preventDefault();

        const { openDialog } = this.props.contentModalState!;
        openDialog(<ExitWarning />, "Save & Exit", "Keep going", undefined, () => this.onBack(ev));
    };

    render() {
        const { dbHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        const selected = dbHostApprovalSubmission.experienceCategory;
        const { open } = this.props.contentModalState!;

        const radioButtons = this.experienceCategories.map((labeledExperienceCategory: LabeledEnum, i: number) => {
            const { name, label } = labeledExperienceCategory;
            return (
                <InputRadioButtonImage
                    groupName="experienceCategory"
                    name={name}
                    label={label}
                    url={getExperienceCategoryImageUrl(name as any)}
                    onChange={this.onChange}
                    checked={selected === name}
                    key={i}
                />
            );
        });

        const submitDisabled: boolean = selected === undefined;

        return (
            <PageTransition>
                <StyledForm>
                    <h2>Experience Categories</h2>
                    <div className="form-container">
                        <p>Which category would best describe your stay or activity?</p>
                        <InformationLink
                            onClick={() => open("", <BusinessCategories />)}
                            label="Explain experience categories"
                        />
                        <StyledExperienceCategories>{radioButtons}</StyledExperienceCategories>
                    </div>

                    <ButtonRow>
                        <FormButton label="Back" buttonStyle="no-outline" onClick={this.openConfirmDialog} />
                        <div />
                        <FormButton type="submit" label="Next" disabled={submitDisabled} onClick={this.onSave} />
                    </ButtonRow>
                </StyledForm>
            </PageTransition>
        );
    }
}

export const StyledExperienceCategories = styled.div`
    margin: 0 -1rem;
    margin-top: 1rem;
    display: block;
`;
