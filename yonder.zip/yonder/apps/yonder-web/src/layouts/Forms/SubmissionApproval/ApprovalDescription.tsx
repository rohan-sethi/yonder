import React from "react";
import { inject, observer } from "mobx-react";
import { HostApprovalSubmissionProgress } from "@yonder/db";

import {
    StyledForm,
    FormChangeEvent,
    FormButton,
    ButtonRow,
    MouseClickEvent,
    InputTextArea,
    limitTextAreaInput,
    PageTransition,
    InformationLink,
    InputYesNo,
    TooltipModal
} from "../../../components";
import { IFirebaseStore, IHostApprovalSubmissionStore, IContentModalStore } from "../../../store";
import { isStringInvalid } from "../../../functions";

type Props = IFirebaseStore & IHostApprovalSubmissionStore & IContentModalStore;

@inject("firebaseState", "hostApprovalSubmissionState", "contentModalState")
@observer
export class ApprovalDescription extends React.Component<Props> {
    scoutPermissionModal = {
        header: "What does this mean?",
        body: `By selecting "Yes", you’re agreeing to allow a Yonder Scout to use your existing online information to begin a listing draft. Don’t worry, you’ll be able to complete and approve this draft before it’s visible.`
    };

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { value } = ev.target;
        const { updateHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        const description = limitTextAreaInput(value);
        //console.log(description);

        updateHostApprovalSubmission({
            description
        });
    };

    onYesNoChange = (ev: MouseClickEvent, name: string, value: boolean) => {
        ev.preventDefault();

        const { updateHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        if (name === "scoutSetupPermission") {
            updateHostApprovalSubmission({
                scoutSetupPermission: value
            });
        }
    };

    onSave = async (ev: MouseClickEvent) => {
        ev.preventDefault();

        const { saveOrganization } = this.props.firebaseState!;
        const { saveHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        saveHostApprovalSubmission();

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.Certificate
        });
    };

    onBack = async (ev: MouseClickEvent) => {
        ev.preventDefault();

        const { saveOrganization } = this.props.firebaseState!;

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.Location
        });
    };

    render() {
        const { dbHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        const invalidDescription = isStringInvalid(dbHostApprovalSubmission.description);
        const { open } = this.props.contentModalState!;

        return (
            <PageTransition>
                <StyledForm>
                    <h2>What's Your Story?</h2>
                    <div className="form-container">
                        <form>
                            <p>
                                Please describe the overall experience you provide to your guests, including your
                                business, its offerings, overnight stays, and/or any activities.
                            </p>
                            <InputTextArea
                                name="propertySummary"
                                value={dbHostApprovalSubmission.description}
                                onChange={this.onChange}
                                rows={10}
                                maxRows={10}
                                placeholder="Example. Our 3 bedroom cabin sits directly on Lake Placid. We offer one overnight stay, and 3 activities - canoeing, fishing, and hiking."
                            />
                            <div className="form-container">
                                <p style={{ marginBottom: ".5rem" }}>
                                    Would you like the Scouts to kick-start your listing set-up?
                                </p>
                                <InformationLink
                                    onClick={() => open("", <TooltipModal {...this.scoutPermissionModal} />)}
                                    label="What does this mean?"
                                />
                                <InputYesNo
                                    name="scoutSetupPermission"
                                    value={dbHostApprovalSubmission.scoutSetupPermission}
                                    onClick={this.onYesNoChange}
                                />
                            </div>
                        </form>
                    </div>
                    <ButtonRow>
                        <FormButton label="Back" buttonStyle="no-outline" onClick={this.onBack} />
                        <div />
                        <FormButton type="submit" label="Next" disabled={invalidDescription} onClick={this.onSave} />
                    </ButtonRow>
                </StyledForm>
            </PageTransition>
        );
    }
}
