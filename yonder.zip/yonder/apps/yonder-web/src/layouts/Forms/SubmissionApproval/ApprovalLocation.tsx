import React from "react";
import { inject, observer } from "mobx-react";
import {
    StatesUS,
    getStateName,
    Countries,
    getCountryName,
    HostApprovalSubmissionProgress,
    LocationAddress,
    ProvincesCanada,
    getProvinceName
} from "@yonder/db";

import { IFirebaseStore, IHostApprovalSubmissionStore } from "../../../store";
import {
    StyledForm,
    FormButton,
    TextInput,
    SelectInput,
    FormChangeEvent,
    reZipCode,
    ButtonRow,
    MouseClickEvent,
    SelectOption,
    SplitInput,
    PageTransition
} from "../../../components";
import { enumToSelectOptions, isStringInvalid } from "../../../functions";

type ValidationErrors = {
    zipCode?: string;
};
type Props = IFirebaseStore & IHostApprovalSubmissionStore;
type State = {
    validationErrors: ValidationErrors;
    zipCode?: string;
};

@inject("firebaseState", "hostApprovalSubmissionState")
@observer
export class ApprovalLocation extends React.Component<Props, State> {
    statesUS: SelectOption[] = enumToSelectOptions(StatesUS, getStateName);
    provincesCanada: SelectOption[] = enumToSelectOptions(ProvincesCanada, getProvinceName);
    countryOptions: SelectOption[] = enumToSelectOptions(Countries, getCountryName, false);

    state: State = {
        validationErrors: {},
        zipCode: undefined
    };

    initLocation = () => {
        const { dbHostApprovalSubmission, updateHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        if (!dbHostApprovalSubmission.location.country) {
            updateHostApprovalSubmission({
                location: {
                    country: Countries.USA
                }
            });
        }
    };

    componentDidMount() {
        this.initLocation();
    }

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();
        const { name, value } = ev.target;

        let validationErrors: ValidationErrors = this.state.validationErrors;

        //TODO: add Canada provinces to drop down if Canada is selected as country

        let location: LocationAddress = {};

        switch (name) {
            case "locationAddress1":
                location.address1 = value;
                break;

            case "locationAddress2":
                location.address2 = value;
                break;

            case "locationCity":
                location.city = value;
                break;

            case "locationState":
                location.state = value !== "none" ? value : undefined;
                break;

            case "locationZipCode":
                let zipCode: string | undefined = value;
                if (location.country === Countries.Other) {
                    location.zipCode = value;
                } else {
                    if (reZipCode.test(value) && value !== "") {
                        validationErrors.zipCode = undefined;
                        zipCode = undefined;
                        location.zipCode = value;
                    } else {
                        validationErrors.zipCode = "Must be a valid zip code.";
                        this.setState({ zipCode, validationErrors });
                        return;
                    }
                    this.setState({ validationErrors });
                }
                break;

            case "locationCountry":
                location.state = "";
                location.country = value !== "none" ? value : undefined;
                break;

            case "locationCountryName":
                location.countryName = value;
                break;

            default:
                return;
        }

        const { dbHostApprovalSubmission, updateHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        updateHostApprovalSubmission({
            location: {
                ...dbHostApprovalSubmission.location,
                ...location
            }
        });
    };

    onSave = async (ev: MouseClickEvent) => {
        ev.preventDefault();
        const { saveOrganization } = this.props.firebaseState!;
        const { saveHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        saveHostApprovalSubmission();

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.Description
        });
    };

    onBack = async (ev: MouseClickEvent) => {
        ev.preventDefault();
        const { saveOrganization } = this.props.firebaseState!;

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.Activities
        });
    };

    render() {
        const { validationErrors, zipCode } = this.state;
        const { dbHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        const { location } = dbHostApprovalSubmission;

        const invalidZipCode = !!validationErrors.zipCode || isStringInvalid(location.zipCode);
        const invalidAddress = isStringInvalid(location.address1);
        const invalidState = isStringInvalid(location.state);
        const invalidCity = isStringInvalid(location.city);
        const invalidCountry = location.country === Countries.Other && isStringInvalid(location.countryName);

        const isInvalid = invalidZipCode || invalidAddress || invalidCity || invalidState || invalidCountry;

        const countryInput = (
            <SelectInput
                name="locationCountry"
                label="Country"
                value={location.country}
                options={this.countryOptions}
                onChange={this.onChange}
            />
        );

        return (
            <PageTransition>
                <StyledForm>
                    <h2>Location</h2>
                    <div className="form-container">
                        <p>Where is your primary business located?</p>

                        <form>
                            <TextInput
                                name="locationAddress1"
                                value={location.address1}
                                onChange={this.onChange}
                                label="Street address"
                            />

                            <TextInput
                                name="locationAddress2"
                                value={location.address2}
                                onChange={this.onChange}
                                label="Suite, unit number (optional)"
                            />

                            <TextInput
                                name="locationCity"
                                value={location.city}
                                onChange={this.onChange}
                                label="City"
                            />
                            <SplitInput error={validationErrors.zipCode}>
                                {location.country !== Countries.Other ? (
                                    <SelectInput
                                        name="locationState"
                                        label={location.country === Countries.Canada ? "Province" : "State"}
                                        value={location.state || "none"}
                                        options={
                                            location.country === Countries.Canada ? this.provincesCanada : this.statesUS
                                        }
                                        onChange={this.onChange}
                                    />
                                ) : (
                                    <TextInput
                                        name="locationState"
                                        label="State/Province"
                                        value={location.state}
                                        onChange={this.onChange}
                                    />
                                )}
                                <TextInput
                                    name="locationZipCode"
                                    label="Zip code"
                                    value={invalidZipCode ? zipCode : location.zipCode}
                                    onChange={this.onChange}
                                />
                            </SplitInput>

                            {location.country !== Countries.Other ? (
                                countryInput
                            ) : (
                                <SplitInput>
                                    {countryInput}

                                    <TextInput
                                        name="locationCountryName"
                                        value={location.countryName}
                                        onChange={this.onChange}
                                    />
                                </SplitInput>
                            )}
                        </form>
                    </div>
                    <ButtonRow>
                        <FormButton label="Back" buttonStyle="no-outline" onClick={this.onBack} />
                        <div />
                        <FormButton type="submit" label="Next" disabled={isInvalid} onClick={this.onSave} />
                    </ButtonRow>
                </StyledForm>
            </PageTransition>
        );
    }
}
