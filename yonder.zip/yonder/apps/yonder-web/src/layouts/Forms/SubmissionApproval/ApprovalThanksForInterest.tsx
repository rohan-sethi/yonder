import React from "react";

import { ContentBlock, StyledForm, PageTransition } from "../../../components";

export class ApprovalThanksForInterest extends React.Component {
    render() {
        return (
            <PageTransition>
                <StyledForm>
                    <ContentBlock
                        header="Thanks for your interest!"
                        body="We're building a community that wants to improve lives through nature-rich experiences. We'll keep you updated throughout our journey."
                        url="/img/icon-hand.svg"
                    />
                </StyledForm>
            </PageTransition>
        );
    }
}
