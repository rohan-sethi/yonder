import React from "react";
import { inject, observer } from "mobx-react";
//import { HostApprovalSubmissionProgress } from "@yonder/db";

import { ContentBlock, StyledForm, FormButton, MouseClickEvent, PageTransition } from "../../../components";
import { IFirebaseStore, IHostApprovalSubmissionStore } from "../../../store";

type Props = IFirebaseStore & IHostApprovalSubmissionStore;

@inject("firebaseState", "hostApprovalSubmissionState")
@observer
export class ApprovalMakingProgress extends React.Component<Props> {
    onBegin = (ev: MouseClickEvent) => {
        ev.preventDefault();
        const { dbOrganization, updateOrganization } = this.props.firebaseState!;
        const { setMakingProgress } = this.props.hostApprovalSubmissionState!;

        updateOrganization({
            //grab current submission progress from state then set current progress equal to that so user is routed back to last screen
            approvalSubmissionProgress: dbOrganization.approvalSubmissionProgress
        });
        setMakingProgress(false);
    };

    render() {
        return (
            <PageTransition>
                <StyledForm>
                    <ContentBlock
                        header="You're making progress!"
                        body="We've been holding your place. Let's pick up where you left off."
                        url="/img/icon-star.svg"
                    />
                    <FormButton type="submit" label="Continue" onClick={this.onBegin} />
                </StyledForm>
            </PageTransition>
        );
    }
}
