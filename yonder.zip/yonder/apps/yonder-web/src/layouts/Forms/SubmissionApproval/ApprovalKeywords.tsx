import React from "react";
import { inject, observer } from "mobx-react";
import { Keywords, getKeywordLabel } from "@yonder/db";

import {
    StyledForm,
    FormSubmitEvent,
    InputCheckbox,
    SubmitButton,
    FormButton,
    FormChangeEvent
} from "../../../components";
import { IAddPropertyStore, IFirebaseStore } from "../../../store";
import { enumToInputOptions } from "../../../functions";
import { LabeledEnum } from "../../../interfaces";

type Props = IAddPropertyStore & IFirebaseStore;

@inject("addPropertyState", "firebaseState")
@observer
export class ApprovalKeywords extends React.Component<Props> {
    keywords: LabeledEnum[] = enumToInputOptions(Keywords, getKeywordLabel);

    update = this.props.addPropertyState!.updateProperty;
    save = this.props.addPropertyState!.saveProperty;

    onSubmit = (ev: FormSubmitEvent) => {
        ev.preventDefault();
        this.save();
    };

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();
        const { value } = ev.target;
        const { addKeyword, removeKeyword } = this.props.addPropertyState!;

        const keyword: Keywords = ev.target.name;
        if (value) {
            addKeyword(keyword);
        } else {
            removeKeyword(keyword);
        }
    };

    onBack = () => {
        console.log("Back");
    };
    render() {
        const { property } = this.props.addPropertyState!;
        const checkboxes = this.keywords.map((keyword: LabeledEnum, i: number) => {
            const { name, label } = keyword;
            let checked: boolean = false;
            if (property.keywords) {
                checked = property.keywords.includes(name as Keywords);
            }
            return (
                <InputCheckbox
                    groupName="keywords"
                    name={name}
                    label={label}
                    onChange={this.onChange}
                    checked={checked}
                    key={i}
                />
            );
        });
        return (
            <StyledForm>
                <h2>Environmental Attributes</h2>
                <h4>Select the keywords that your guests should know apply to your property</h4>
                <form onSubmit={this.onSubmit}>
                    {checkboxes}
                    <SubmitButton label="Save and Continue" />
                </form>
                <FormButton label="Back" buttonStyle="no-outline" onClick={this.onBack} />
            </StyledForm>
        );
    }
}
