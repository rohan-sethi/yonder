import React from "react";
import styled from "styled-components";
import { inject, observer } from "mobx-react";

import { PageTransition, StyledForm, FormButton, MouseClickEvent } from "../../../components";
import { IFirebaseStore } from "../../../store";
import { HostTypes } from "@yonder/db";
import { TellUsAboutYourBusiness } from ".";

type Props = IFirebaseStore;
type State = {
    isHost: boolean;
};
@inject("firebaseState")
@observer
export class ApprovalHostOrGuest extends React.Component<Props, State> {
    state: State = {
        isHost: false
    };

    onSelectHost = async (ev: MouseClickEvent) => {
        ev.preventDefault();
        this.setState({
            isHost: true
        });
    };

    onSelectGuest = async (ev: MouseClickEvent) => {
        ev.preventDefault();
        const { saveUserProfile } = this.props.firebaseState!;

        saveUserProfile({
            hostType: HostTypes.Guest
        });
    };
    render() {
        const { isHost } = this.state;

        if (isHost) {
            return <TellUsAboutYourBusiness />;
        }

        return (
            <PageTransition>
                <StyledForm>
                    <h2>We're excited that you are here!</h2>

                    <ButtonWithDescription>
                        <p>Do you currently operate any stays or activities?</p>
                        <FormButton
                            label="Yes, I'm a host. Let's begin"
                            onClick={this.onSelectHost}
                            buttonStyle="solid"
                        />
                    </ButtonWithDescription>

                    <ButtonWithDescription>
                        <p>Or are you a future guest and interested in learning more about Yonder?</p>
                        <FormButton
                            label="I'm a guest. Tell me more"
                            onClick={this.onSelectGuest}
                            buttonStyle="outline-color"
                        />
                    </ButtonWithDescription>
                </StyledForm>
            </PageTransition>
        );
    }
}

const ButtonWithDescription = styled.div`
    display: block;
    margin: 3rem 0;

    .form-button {
        margin-top: 0.5rem;
    }
`;
