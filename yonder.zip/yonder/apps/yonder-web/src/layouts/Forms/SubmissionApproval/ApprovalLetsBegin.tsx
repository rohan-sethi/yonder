import React from "react";
import { inject, observer } from "mobx-react";
import { HostApprovalSubmissionProgress, HostTypes } from "@yonder/db";

import { ContentBlock, StyledForm, FormButton, PageTransition, MouseClickEvent } from "../../../components";
import { IFirebaseStore, IHostApprovalSubmissionStore } from "../../../store";

type Props = IFirebaseStore & IHostApprovalSubmissionStore;

@inject("firebaseState")
@observer
export class ApprovalLetsBegin extends React.Component<Props> {
    onBegin = async (ev: MouseClickEvent) => {
        ev.preventDefault();

        const { dbUser, saveOrganization } = this.props.firebaseState!;
        const mgmt: boolean = dbUser.hostType === HostTypes.PropertyManagement;
        const approvalSubmissionProgress = mgmt
            ? HostApprovalSubmissionProgress.OvernightStays
            : HostApprovalSubmissionProgress.ExperienceCategory;

        await saveOrganization({
            approvalSubmissionProgress
        });
    };

    render() {
        return (
            <PageTransition>
                <StyledForm>
                    <ContentBlock
                        header="We're excited that you are here!"
                        body="Thanks for your interest in Yonder. We'd love to get to know you and your business better. Please complete the following questions."
                        url="/img/icon-nature.svg"
                    />
                    <FormButton label="Let's Begin" onClick={this.onBegin} />
                </StyledForm>
            </PageTransition>
        );
    }
}
