import React from "react";
import { inject, observer } from "mobx-react";
import {
    ActivityCountRanges,
    getActivityCountRangeLabel,
    getActivityLabel,
    getActivityTypesByCategory,
    ActivityTypes,
    getActivityCategories
} from "@yonder/db";

import { IHostApprovalSubmissionStore, IFirebaseStore } from "../../../../store";
import {
    FormChangeEvent,
    InputRadioButton,
    CategoryCheckboxes,
    CheckboxCategoryAccordion
} from "../../../../components";
import { enumToInputOptions } from "../../../../functions";
import { LabeledEnum } from "../../../../interfaces";

type ActivityCategory = {
    name: string;
    activityTypes: LabeledEnum[];
};

type Props = IHostApprovalSubmissionStore & IFirebaseStore;

@inject("firebaseState", "hostApprovalSubmissionState")
@observer
export class ActivityForm extends React.Component<Props> {
    activityCountRanges: LabeledEnum[] = enumToInputOptions(ActivityCountRanges, getActivityCountRangeLabel);

    categorizedActivityTypes: ActivityCategory[] = getActivityCategories().map((category: string) => {
        const activityTypes: ActivityTypes[] = getActivityTypesByCategory(category);
        return {
            name: category,
            activityTypes: enumToInputOptions(ActivityTypes, getActivityLabel).filter((activity: LabeledEnum) =>
                activityTypes.includes(activity.name as ActivityTypes)
            )
        } as ActivityCategory;
    });

    onActivityCountChange = (ev: FormChangeEvent) => {
        const { name } = ev.target;
        const { updateHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        updateHostApprovalSubmission({
            activityCountRange: name
        });
    };

    onActivityChange = (ev: FormChangeEvent) => {
        const { value } = ev.target;
        const { addActivity, removeActivity } = this.props.hostApprovalSubmissionState!;

        const activity: ActivityTypes = ev.target.name;
        if (value) {
            addActivity(activity);
        } else {
            removeActivity(activity);
        }
    };

    render() {
        const { dbHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        const activityCountRange = dbHostApprovalSubmission.activityCountRange;

        const radioButtons = this.activityCountRanges.map((labeledActivityCountRange: LabeledEnum, i: number) => {
            const { name, label } = labeledActivityCountRange;
            if (name === "zero") return false;

            return (
                <InputRadioButton
                    groupName="activityCountRange"
                    name={name}
                    label={label}
                    onChange={this.onActivityCountChange}
                    checked={activityCountRange === name}
                    key={i}
                />
            );
        });

        const categoryCheckboxes = this.categorizedActivityTypes.map((category: ActivityCategory, i: number) => {
            if (category) {
                return (
                    <CheckboxCategoryAccordion header={category.name} key={i}>
                        <CategoryCheckboxes
                            categoryName={category.name}
                            categoryEnums={category.activityTypes}
                            collection={dbHostApprovalSubmission.activities}
                            onChange={this.onActivityChange}
                            columns="two"
                            key={i}
                            hideCategoryName
                        />
                    </CheckboxCategoryAccordion>
                );
            }
            return undefined;
        });

        return (
            <>
                <hr />
                <div className="category-checkboxes">
                    <p>Around how many activities do you offer?</p>
                    <div className="checkboxes two">{radioButtons}</div>
                </div>
                <hr />

                <p>Select the activities you offer on your property. (optional)</p>
                {categoryCheckboxes}
            </>
        );
    }
}
