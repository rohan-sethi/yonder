import React from "react";
import { inject, observer } from "mobx-react";
import { HostApprovalSubmissionProgress, ActivityCountRanges } from "@yonder/db";

import { IFirebaseStore, IHostApprovalSubmissionStore } from "../../../store";
import { MouseClickEvent, FormButton, StyledForm, ButtonRow, InputYesNo, PageTransition } from "../../../components";
import { ActivityForm } from "./Activities/ActivityForm";

type Props = IFirebaseStore &
    IHostApprovalSubmissionStore & {
        managementHostActivityDescriptor?: string;
    };
type State = {
    displayActivityForm: boolean;
};

@inject("firebaseState", "hostApprovalSubmissionState")
@observer
export class ApprovalActivities extends React.Component<Props, State> {
    componentDidMount() {
        const { dbHostApprovalSubmission, updateHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        if (!dbHostApprovalSubmission.activityCountRange || !dbHostApprovalSubmission.activities) {
            updateHostApprovalSubmission({
                activityCountRange: ActivityCountRanges.Zero,
                activities: []
            });
        }
    }

    onYesNoChange = (ev: MouseClickEvent, name: string, value: boolean) => {
        ev.preventDefault();

        const { dbHostApprovalSubmission, updateHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        if (name === "displayActivityForm") {
            if (value) {
                updateHostApprovalSubmission({
                    activityCountRange: ActivityCountRanges.OneToThree
                });
            } else {
                if (dbHostApprovalSubmission.activityCountRange || dbHostApprovalSubmission.activities) {
                    updateHostApprovalSubmission({
                        activityCountRange: ActivityCountRanges.Zero,
                        activities: []
                    });
                }
            }
        }
    };

    onSave = async (ev: MouseClickEvent) => {
        ev.preventDefault();
        const { saveOrganization } = this.props.firebaseState!;
        const { saveHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        saveHostApprovalSubmission();

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.Location
        });
    };

    onBack = async (ev: MouseClickEvent) => {
        ev.preventDefault();
        const { saveOrganization } = this.props.firebaseState!;

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.OvernightStays
        });
    };

    render() {
        const { dbHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        const displayActivityForm: boolean = dbHostApprovalSubmission.activityCountRange !== ActivityCountRanges.Zero;
        const descriptor =
            this.props.managementHostActivityDescriptor || "Do you host or offer any activities on your property?";

        return (
            <PageTransition>
                <StyledForm>
                    <h2>Activities</h2>
                    <form className="form-container">
                        <InputYesNo
                            name="displayActivityForm"
                            descriptor={descriptor}
                            value={displayActivityForm}
                            onClick={this.onYesNoChange}
                        />

                        {displayActivityForm && <ActivityForm />}
                    </form>
                    <ButtonRow>
                        <FormButton label="Back" buttonStyle="no-outline" onClick={this.onBack} />
                        <div />
                        <FormButton type="submit" label="Next" onClick={this.onSave} />
                    </ButtonRow>
                </StyledForm>
            </PageTransition>
        );
    }
}
