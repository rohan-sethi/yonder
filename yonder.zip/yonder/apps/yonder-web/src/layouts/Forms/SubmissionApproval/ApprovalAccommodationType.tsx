import React from "react";
import styled from "styled-components";
import { observer, inject } from "mobx-react";
import { PropertyTypes, getPropertyTypeLabel } from "@yonder/db";

import { IAddPropertyStore, IFirebaseStore } from "../../../store";
import {
    StyledForm,
    FormChangeEvent,
    InputCheckbox,
    SubmitButton,
    FormSubmitEvent,
    FormButton
} from "../../../components";
import { enumToInputOptions } from "../../../functions";
import { LabeledEnum } from "../../../interfaces";

type Props = IAddPropertyStore & IFirebaseStore;

@inject("addPropertyState", "firebaseState")
@observer
export class ApprovalAccommodationType extends React.Component<Props> {
    propertyTypes: LabeledEnum[] = enumToInputOptions(PropertyTypes, getPropertyTypeLabel);

    update = this.props.addPropertyState!.updateProperty;
    save = this.props.addPropertyState!.saveProperty;

    onSubmit = async (ev: FormSubmitEvent) => {
        ev.preventDefault();
    };

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();
    };

    onSave = () => {
        console.log("Save & Continue");
    };

    onBack = () => {
        console.log("Back");
    };

    render() {
        const { property } = this.props.addPropertyState!;
        const selected = property.propertyType;

        const checkboxes = this.propertyTypes.map((propertyType: LabeledEnum, i: number) => {
            const { name, label } = propertyType;
            return (
                <InputCheckbox
                    groupName="accomodationTypes"
                    name={name}
                    label={label}
                    onChange={this.onChange}
                    checked={name === selected}
                    key={i}
                />
            );
        });

        const submitDisabled: boolean = selected === undefined;

        const saveLabel = "Save & Continue";

        return (
            <StyledForm>
                <form onSubmit={this.onSubmit}>
                    <h2>Accommodation Type</h2>
                    <p>
                        What type of stay do you offer?
                        <br />
                        Please check all that apply.
                    </p>
                    <StyledCheckboxGroup>{checkboxes}</StyledCheckboxGroup>

                    <SubmitButton label={saveLabel} disabled={submitDisabled} />
                </form>

                <FormButton label="Back" buttonStyle="no-outline" onClick={this.onBack} />
            </StyledForm>
        );
    }
}

const StyledCheckboxGroup = styled.div`
    padding: 2rem 0;
`;
