import React from "react";
import styled from "styled-components";
import { observer, inject } from "mobx-react";
import { ImageAsset, ID, HostApprovalSubmissionProgress, UserPermissions } from "@yonder/db";

import {
    IFirebaseStore,
    IListingPhotoUploadStore,
    IContentModalStore,
    IHostApprovalSubmissionStore
} from "../../../store";
import {
    PhotoThumbnail,
    MouseClickEvent,
    PageTransition,
    StyledForm,
    ButtonRow,
    FormButton,
    InputTextArea,
    FormChangeEvent,
    limitTextAreaInput
} from "../../../components";
import { spaceSeparateStringArray } from "../../../functions";

export type ImageUploadCallback = (id: ID) => Promise<void>;
export type PhotoGroup = {
    descriptor?: React.ReactNode;
    category?: string;
};

type Props = IHostApprovalSubmissionStore & IFirebaseStore & IListingPhotoUploadStore & IContentModalStore;

@inject("hostApprovalSubmissionState", "firebaseState", "listingPhotoUploadState", "contentModalState")
@observer
export class ApprovalPhotos extends React.Component<Props> {
    update = this.props.hostApprovalSubmissionState!.updateHostApprovalSubmission;
    save = this.props.hostApprovalSubmissionState!.saveHostApprovalSubmission;

    notEnoughPhotos: boolean = true;

    galleryMin: number = 6;
    galleryMax: number = 7;
    uploadedOverGalleryMaxMessage: string = "";

    samplePhotos: ImageAsset[] = [];

    thumbDefaults = {
        name: "new",
        size: 0,
        file: "",
        showDropZone: true
    };

    initializePhotos = () => {
        const {
            dbHostApprovalSubmission,
            dbPhotos,
            getPhoto,
            photosInitialized
        } = this.props.hostApprovalSubmissionState!;

        if (!photosInitialized) return;

        // Get the gallery photo assets from the property.galleryPhotos object
        this.samplePhotos = dbHostApprovalSubmission.samplePhotos
            .filter((id: ID) => {
                let asset: ImageAsset | null = getPhoto(id);
                return asset !== null;
            })
            .map((id: ID) => getPhoto(id)!);

        // Get any leftover unsorted photos
        let unsorted: ImageAsset[] = dbPhotos.filter(
            (photo) => !dbHostApprovalSubmission.samplePhotos.includes(photo.id!)
        );
        this.samplePhotos = this.samplePhotos.concat(unsorted);
        this.notEnoughPhotos = this.samplePhotos.length < this.galleryMin;
    };

    onFilesAdded = async (files: File[], max: number, callback?: ImageUploadCallback) => {
        if (files.length < 1) return;

        const { firebase } = this.props.firebaseState!;
        const { uploadFiles } = this.props.listingPhotoUploadState!;
        const { addPendingPhoto } = this.props.hostApprovalSubmissionState!;
        const remainingSlots = max - this.samplePhotos.length;

        if (files.length <= remainingSlots) {
            try {
                for (let file of files) {
                    addPendingPhoto(file);
                }

                await uploadFiles(files, firebase, (uploadedFile: File, url: string, uuid: string) => {
                    this.onUpload(uploadedFile, url, uuid, callback);
                });
            } catch (err) {
                throw err;
            }
        } else {
            const willUpload = files.slice(0, remainingSlots);
            const willNotUpload = files.slice(remainingSlots);
            const notUploadedPhotoNames = willNotUpload.map((file) => file.name);

            try {
                for (let file of willUpload) {
                    addPendingPhoto(file);
                }

                await uploadFiles(willUpload, firebase, (uploadedFile: File, url: string, uuid: string) => {
                    this.onUpload(uploadedFile, url, uuid, callback);
                });

                this.uploadedOverGalleryMaxMessage = `You uploaded over ${
                    this.galleryMax
                } photos. Files${spaceSeparateStringArray(notUploadedPhotoNames)} weren't uploaded.`;
            } catch (err) {
                throw err;
            }
        }
    };

    // This is called after a file has completed
    onUpload = async (uploadedFile: File, url: string, uuid: string, callback?: ImageUploadCallback) => {
        const { addPhoto } = this.props.hostApprovalSubmissionState!;

        let photoId = await addPhoto(uploadedFile, uuid, url);
        if (callback) {
            await callback(photoId);
        }
    };

    onPhotoDelete = (photo: ImageAsset) => {
        const { firebase } = this.props.firebaseState!;
        const { deletePhoto, removeGalleryPhoto } = this.props.hostApprovalSubmissionState!;
        const { openDialog } = this.props.contentModalState!;

        openDialog(`Are you sure you want to delete "${photo.name}?"`, "Cancel", "Okay", async () => {
            try {
                removeGalleryPhoto(photo.id!);
                await deletePhoto(photo, firebase);
                await this.save();
            } catch (err) {
                throw err;
            }
        });
    };

    photoThumbFromAsset = (photo: ImageAsset, index: number) => {
        const id = `${index}-${photo.file}`;
        return <PhotoThumbnail {...photo} key={id} onDelete={() => this.onPhotoDelete(photo)} />;
    };

    addEmptyPhotos = (array: JSX.Element[], max: number, callback?: ImageUploadCallback) => {
        if (array.length < max) {
            array.push(
                <PhotoThumbnail
                    {...this.thumbDefaults}
                    key={array.length}
                    onFilesAdded={(file) => {
                        this.onFilesAdded(file, max, callback);
                    }}
                    showPending
                />
            );
        }
    };

    addGalleryPhoto = async (id: ID) => {
        const { addGalleryPhoto } = this.props.hostApprovalSubmissionState!;
        addGalleryPhoto(id);
        await this.save();
    };

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;
        const { updateHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        if (name === "socialLinks") {
            const socialLinks = limitTextAreaInput(value);

            updateHostApprovalSubmission({
                socialLinks
            });
        }
    };

    onSave = async (ev: MouseClickEvent) => {
        ev.preventDefault();
        const { saveOrganization, saveUserProfile } = this.props.firebaseState!;
        const { saveHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        saveHostApprovalSubmission();

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.Completed
        });
        await saveUserProfile({
            permissions: UserPermissions.HostApprovalSubmitted
        });
    };

    onBack = async (ev: MouseClickEvent) => {
        ev.preventDefault();
        const { saveOrganization } = this.props.firebaseState!;

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.Certificate
        });
    };

    render() {
        this.initializePhotos();

        // Render the gallery photos
        let galleryPhotos: JSX.Element[] = this.samplePhotos.map(this.photoThumbFromAsset);
        this.addEmptyPhotos(galleryPhotos, this.galleryMax, this.addGalleryPhoto);

        const galleries = [galleryPhotos];

        const lists = galleries.map((gallery: JSX.Element[], i: number) => {
            return (
                <div className="list-category" key={i}>
                    <div className="list">{gallery}</div>
                </div>
            );
        });

        const { dbHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        return (
            <PageTransition>
                <StyledForm>
                    <h2>Yonder wants to promote your listings.</h2>
                    <div className="form-container">
                        <h4>Please upload a few of your favorite photos to be featured on Yonder’s social media.</h4>
                        <br />
                        <p>
                            Did you capture a stunning photo of the lake by your cabin at sunset? How about any adorable
                            animals on your farm? Any close-ups of the juicy grapes on your vineyard? We want to see it
                            all!
                        </p>
                        {/* TODO, this isn't true, yet */}
                        {/*<p>Need time to gather your photos? Don’t worry! You can come back to this later.</p>*/}
                        <StyledPhotoGroup>{lists}</StyledPhotoGroup>

                        {/*this.notEnoughPhotos && (
                            <p className="success-message">
                                To complete this section, please upload between 6-7 photos.
                            </p>
                        )}
                        <br />*/}
                        <p>
                            <span className="note">
                                By uploading and submitting these photos, you grant Yonder permission to promote and
                                share these photos across all of our social media platforms. If you feature any people
                                in these photos, you must have permission to use them and their like-ness.
                            </span>
                        </p>
                        <h4>
                            Yonder will credit you by adding your handle and link to listings on all social media
                            promotions. Please add all available social media handles.
                        </h4>
                        <InputTextArea
                            name="socialLinks"
                            value={dbHostApprovalSubmission.socialLinks}
                            onChange={this.onChange}
                            rows={6}
                            maxRows={6}
                            placeholder={`facebook.com/BlisswoodBnB
IG: @blisswoodBnB
Twitter: @blisswoodBnB`}
                        />
                    </div>
                    {this.uploadedOverGalleryMaxMessage && (
                        <p className="success-message">{this.uploadedOverGalleryMaxMessage}</p>
                    )}
                    <ButtonRow>
                        <FormButton label="Back" buttonStyle="no-outline" onClick={this.onBack} />
                        <div />
                        <FormButton label="Next" onClick={this.onSave} />
                    </ButtonRow>
                </StyledForm>
            </PageTransition>
        );
    }
}

export const StyledPhotoGroup = styled.div`
    margin-top: 3rem;

    .list-category {
        width: 100%;
        margin-bottom: 1rem;

        h4 {
            margin-bottom: 1rem;
        }

        .list {
            display: flex;
            flex-wrap: wrap;
            flex-direction: row;
            margin: 0 -1.5rem;

            .photo-thumbnail {
                display: flex;
                flex-basis: 50%;
                flex-direction: column;
            }
        }
    }
`;
