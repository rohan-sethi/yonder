import React from "react";
import { observer, inject } from "mobx-react";
import styled from "styled-components";

import { IContentModalStore, IFirebaseStore } from "../../store";
import { StyledForm, ModalButton, ExternalLink, FirebaseFormRoute, ProviderIconSignIn } from "../../components";
import { SignUpEmailForm } from "./SignUpEmailForm";
import signInModal from "../../modals/SignInConductor";

type Props = IContentModalStore & IFirebaseStore;

@inject("contentModalState", "firebaseState")
@observer
export class SignUpForm extends React.Component<Props> {
    state = {
        signupFormLabel: "Start the approval process now."
    };

    componentDidMount() {
        const { setHeader } = this.props.contentModalState!;
        setHeader("");

        let urlParams = new URLSearchParams(window.location.search);
        const startedSignupEmail = urlParams.get("email");
        if (startedSignupEmail !== null) {
            this.setState({
                signupFormLabel: (
                    <div style={{ marginBottom: "20px" }}>
                        Thanks for your email!
                        <br />
                        Start the approval process now.
                    </div>
                )
            });
        }
    }

    render() {
        const { isOpen } = this.props.contentModalState!;
        const { setRoute } = this.props.firebaseState!;

        return (
            <StyledSignUp className="signup-form">
                <StyledForm>
                    <h2 className="center">{this.state.signupFormLabel}</h2>
                    <p className="secondary-action">
                        Already have an account?{" "}
                        {!!isOpen ? (
                            <button onClick={() => setRoute(FirebaseFormRoute.SignIn)}>Log in</button>
                        ) : (
                            <ModalButton modal={signInModal} label="Log in" buttonStyle="none" />
                        )}
                    </p>
                    <SignUpEmailForm />
                    <p className="secondary-action underline">
                        By signing up, you agree to our{" "}
                        <ExternalLink
                            to="https://help.yonder.com/hc/en-us/articles/360034314273-Terms-of-Service"
                            target="_blank"
                            rel="noopener noreferrer"
                            label="Terms and Conditions."
                        />
                    </p>
                    <hr className="with-text" data-content="Or sign up with" />

                    <ProviderIconSignIn />
                </StyledForm>
            </StyledSignUp>
        );
    }
}

const StyledSignUp = styled.div`
    max-width: 34rem;
    margin: 3rem auto;
    padding: 0 2rem;

    .provider-icons {
        margin-bottom: 2rem;
    }

    h2 {
        font-size: 1.66rem;
        font-weight: 600;
    }

    .input-field,
    .split-input {
        margin-bottom: 2.5rem;
    }

    button.submit {
        margin-top: 1rem;
    }
`;
