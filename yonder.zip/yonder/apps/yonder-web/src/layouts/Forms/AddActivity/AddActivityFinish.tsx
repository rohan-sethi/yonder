import React from "react";
import { observer, inject } from "mobx-react";
import { ListingProgress } from "@yonder/db";

import { IAddActivityStore, IFirebaseStore, IContentModalStore } from "../../../store";
import { StyledDashboard, MouseClickEvent, Button, Congratulations, LoadingSpinner } from "../../../components";
import { history } from "../../../history";
import { StyledAddPropertyActivityActions } from "../AddProperty/AddPropertyActions";

type Props = IFirebaseStore & IAddActivityStore & IContentModalStore;

type State = {
    showSpinner: boolean;
};

@inject("firebaseState", "addActivityState", "contentModalState")
@observer
export class AddActivityFinish extends React.Component<Props> {
    state: State = {
        showSpinner: false
    };

    save = this.props.addActivityState!.saveActivity;

    onSave = async (ev: MouseClickEvent) => {
        ev.preventDefault();

        const { activity, setSectionComplete, setListingInReview } = this.props.addActivityState!;
        const { refreshStaysActivities } = this.props.firebaseState!;

        const prevListingProgress = activity.listingProgress;

        setSectionComplete();
        setListingInReview();
        this.setState({
            showSpinner: true
        });
        try {
            await this.save();
            if (prevListingProgress === ListingProgress.Draft) {
                await refreshStaysActivities(true);
            }

            const { dbUser, organizationStays, organizationActivities } = this.props.firebaseState!;

            const inReviewStays = organizationStays.filter((stay) => stay.listingProgress === ListingProgress.InReview);
            const inReviewActivities = organizationActivities.filter(
                (activity) => activity.listingProgress === ListingProgress.InReview
            );
            let count: number = inReviewStays.length + inReviewActivities.length;

            const { open } = this.props.contentModalState!;
            if (prevListingProgress === ListingProgress.Draft && count === 1) {
                open("", <Congratulations name={dbUser.firstName} />);
            }
            history.push("/dash/listings");
        } catch (err) {
            console.log(err);
        }
    };

    render() {
        //const { getListingComplete } = this.props.addPropertyState!;
        //const submitDisabled: boolean = !getListingComplete();
        return (
            <StyledDashboard>
                <hr />
                {this.state.showSpinner ? (
                    <LoadingSpinner />
                ) : (
                    <StyledAddPropertyActivityActions>
                        <Button
                            label="Finish and submit"
                            //disabled={submitDisabled}
                            onClick={this.onSave}
                            buttonStyle="solid"
                        />
                    </StyledAddPropertyActivityActions>
                )}
            </StyledDashboard>
        );
    }
}
