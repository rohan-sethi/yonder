import React from "react";
import { observer, inject } from "mobx-react";
import { ImageAsset, ID } from "@yonder/db";

import { IAddActivityStore, IFirebaseStore, IListingPhotoUploadStore, IContentModalStore } from "../../../store";
import { StyledDashboard, PhotoThumbnail, MouseClickEvent, FormChangeEvent } from "../../../components";
import { isStringInvalid, spaceSeparateStringArray } from "../../../functions";
import { ImageUploadCallback, ListCategory } from "../AddProperty";
import { AddActivityActions } from "./AddActivityActions";

export type PhotoGroup = {
    descriptor?: React.ReactNode;
    category?: string;
};

type Props = IAddActivityStore & IFirebaseStore & IListingPhotoUploadStore & IContentModalStore;

@inject("addActivityState", "firebaseState", "listingPhotoUploadState", "contentModalState")
@observer
export class AddActivityPhotos extends React.Component<Props> {
    update = this.props.addActivityState!.updateActivity;
    save = this.props.addActivityState!.saveActivity;

    notEnoughPhotos: boolean = true;
    editedCaption: boolean = false;

    galleryMin: number = 7;
    galleryMax: number = 30;
    uploadedOverGalleryMaxMessage: string = "";

    coverPhoto: ImageAsset[] = [];
    galleryPhotos: ImageAsset[] = [];

    thumbDefaults = {
        name: "new",
        size: 0,
        file: "",
        caption: "",
        showDropZone: true,
        onCaptionChange: (ev: FormChangeEvent) => ev.preventDefault()
    };

    photoGroups: PhotoGroup[] = [
        {
            category: "Cover Photo",
            descriptor: (
                <>
                    <h4>Cover Photo (Establishing Shot)</h4>
                    <p>
                        Please upload a landscape or panoramic photo that best showcases your guests enjoying the
                        activity or event.
                    </p>
                    <ul>
                        <li>The image must include 2 or more people</li>
                        <li>It should evoke awe, convey "Can this be real? Where is this place?"</li>
                        <li>Must be larger than 1920 x 1280px, JPG or PNG file only</li>
                    </ul>
                </>
            )
        },
        {
            descriptor: (
                <>
                    <h4>Gallery Photos (Detail Shot)</h4>
                    <p>
                        Please upload at least 7 photos (add up to 30 photos) containing people that are deeply engaged
                        in your Yonder activity or experience.
                    </p>
                    <ul>
                        <li>It should feel like a moment in a story and make the viewer want to find out more</li>
                        <li>It should express connectedness, with family, friends, and the moment</li>
                        <li>It should engage you in the process, or in the education</li>
                        <li>Must be larger than 1024 x 683px, JPG or PNG file only</li>
                    </ul>
                </>
            )
        }
    ];

    initializePhotos = () => {
        const { activity, dbPhotos, getPhoto } = this.props.addActivityState!;

        // Get the cover photo asset (as an array)
        this.coverPhoto = dbPhotos.filter((photo) => photo.id === activity.coverPhoto);

        // Get the gallery photo assets from the activity.galleryPhotos object
        this.galleryPhotos = activity.galleryPhotos
            .filter((id: ID) => {
                let asset: ImageAsset | null = getPhoto(id);
                return asset !== null;
            })
            .map((id: ID) => getPhoto(id)!);

        // Get any leftover unsorted photos
        let unsorted: ImageAsset[] = dbPhotos.filter(
            (photo) => photo.id !== activity.coverPhoto && !activity.galleryPhotos.includes(photo.id!)
        );
        this.galleryPhotos = this.galleryPhotos.concat(unsorted);
        this.notEnoughPhotos = this.galleryPhotos.length < this.galleryMin || isStringInvalid(activity.coverPhoto);
    };

    onFilesAdded = async (files: File[], max: number, callback?: ImageUploadCallback) => {
        if (files.length < 1) return;

        const { firebase } = this.props.firebaseState!;
        const { uploadFiles } = this.props.listingPhotoUploadState!;
        const { addPendingPhoto } = this.props.addActivityState!;
        const remainingSlots = max - this.galleryPhotos.length;

        if (files.length <= remainingSlots) {
            try {
                if (callback !== this.updateCoverPhoto) {
                    for (let file of files) {
                        addPendingPhoto(file);
                    }
                }

                await uploadFiles(files, firebase, (uploadedFile: File, url: string, uuid: string) => {
                    this.onUpload(uploadedFile, url, uuid, callback);
                });
            } catch (err) {
                throw err;
            }
        } else {
            const willUpload = files.slice(0, remainingSlots);
            const willNotUpload = files.slice(remainingSlots);
            const notUploadedPhotoNames = willNotUpload.map((file) => file.name);

            try {
                if (callback !== this.updateCoverPhoto) {
                    for (let file of willUpload) {
                        addPendingPhoto(file);
                    }
                }

                await uploadFiles(willUpload, firebase, (uploadedFile: File, url: string, uuid: string) => {
                    this.onUpload(uploadedFile, url, uuid, callback);
                });

                this.uploadedOverGalleryMaxMessage = `You uploaded over ${
                    this.galleryMax
                } photos. Files${spaceSeparateStringArray(notUploadedPhotoNames)} weren't uploaded.`;
            } catch (err) {
                throw err;
            }
        }
    };

    // This is called after a file has completed
    onUpload = async (uploadedFile: File, url: string, uuid: string, callback?: ImageUploadCallback) => {
        const { addPhoto } = this.props.addActivityState!;

        let photoId = await addPhoto(uploadedFile, uuid, url);
        if (callback) {
            await callback(photoId);
        }
    };

    onPhotoDelete = (photo: ImageAsset) => {
        const { firebase } = this.props.firebaseState!;
        const { activity, deletePhoto, removeGalleryPhoto } = this.props.addActivityState!;
        const { openDialog } = this.props.contentModalState!;

        openDialog(`Are you sure you want to delete "${photo.name}?"`, "Cancel", "Okay", async () => {
            try {
                if (photo.id === activity.coverPhoto) {
                    this.update({
                        coverPhoto: ""
                    });
                } else {
                    removeGalleryPhoto(photo.id!);
                }
                await deletePhoto(photo, firebase);
                await this.save();
            } catch (err) {
                throw err;
            }
        });
    };

    onCaptionChange = (ev: FormChangeEvent, photo: ImageAsset) => {
        ev.preventDefault();

        this.editedCaption = true;

        const { setPhotoCaption } = this.props.addActivityState!;
        const { value } = ev.target;
        photo.caption = value;
        setPhotoCaption(photo);
    };

    photoThumbFromAsset = (photo: ImageAsset, index: number) => {
        const id = `${index}-${photo.file}`;
        return (
            <PhotoThumbnail
                {...photo}
                key={id}
                caption={photo.caption}
                onCaptionChange={(ev) => this.onCaptionChange(ev, photo)}
                onDelete={() => this.onPhotoDelete(photo)}
            />
        );
    };

    addEmptyPhotos = (array: JSX.Element[], max: number, callback?: ImageUploadCallback) => {
        if (array.length < max) {
            array.push(
                <PhotoThumbnail
                    {...this.thumbDefaults}
                    key={array.length}
                    onFilesAdded={(file) => {
                        this.onFilesAdded(file, max, callback);
                    }}
                    showPending
                />
            );
        }
    };

    updateCoverPhoto = async (id: ID) => {
        this.update({
            coverPhoto: id
        });
        await this.save();
    };

    addGalleryPhoto = async (id: ID) => {
        const { addGalleryPhoto } = this.props.addActivityState!;
        addGalleryPhoto(id);
        await this.save();
    };

    onSave = (ev: MouseClickEvent) => {
        ev.preventDefault();

        const { setSectionComplete, nextSection } = this.props.addActivityState!;
        if (!this.notEnoughPhotos) {
            setSectionComplete();
            this.save();
        }
        nextSection();
    };

    render() {
        // Don't re-populate the photos when the captions are edited
        if (!this.editedCaption) {
            this.initializePhotos();
        }
        this.editedCaption = false;

        // Render the cover photo
        let coverPhoto: JSX.Element[] = this.coverPhoto.map(this.photoThumbFromAsset);
        this.addEmptyPhotos(coverPhoto, 1, this.updateCoverPhoto);

        // Render the gallery photos
        let galleryPhotos: JSX.Element[] = this.galleryPhotos.map(this.photoThumbFromAsset);
        this.addEmptyPhotos(galleryPhotos, this.galleryMax, this.addGalleryPhoto);

        const galleries = [coverPhoto, galleryPhotos];

        const lists = this.photoGroups.map((group: PhotoGroup, i: number) => {
            const descriptor = group.descriptor;
            const category = group.category;
            const gallery = galleries[i];

            return (
                <ListCategory className={category && category.toLocaleLowerCase().replace(" ", "-")} key={i}>
                    {descriptor && <>{descriptor}</>}
                    <div className="list">{gallery}</div>
                </ListCategory>
            );
        });

        //const submitDisabled: boolean = isStringInvalid(property.coverPhoto);

        return (
            <StyledDashboard>
                {lists}

                {this.notEnoughPhotos && (
                    <p className="success-message">
                        To complete this section, please upload at least 7 gallery photos and a cover photo.
                    </p>
                )}
                {this.uploadedOverGalleryMaxMessage && (
                    <p className="success-message">{this.uploadedOverGalleryMaxMessage}</p>
                )}

                <AddActivityActions onSave={this.onSave} />
            </StyledDashboard>
        );
    }
}
