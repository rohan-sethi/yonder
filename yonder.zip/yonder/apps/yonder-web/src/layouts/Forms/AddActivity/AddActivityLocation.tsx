import React from "react";
import { observer, inject } from "mobx-react";
import {
    StatesUS,
    getStateName,
    Countries,
    getCountryName,
    PropertyLocation,
    ProvincesCanada,
    getProvinceName
} from "@yonder/db";

import { IAddActivityStore } from "../../../store";
import {
    StyledDashboard,
    SelectInput,
    TextInput,
    FormChangeEvent,
    SplitInput,
    reZipCode,
    SelectOption
} from "../../../components";
import { enumToSelectOptions, isStringInvalid } from "../../../functions";
import { AddActivityActions } from "./AddActivityActions";

type ValidationErrors = {
    zipCode?: string;
};
type Props = IAddActivityStore;
type State = {
    validationErrors: ValidationErrors;
    zipCode?: string;
};

@inject("addActivityState")
@observer
export class AddActivityLocation extends React.Component<Props, State> {
    provincesCanada = enumToSelectOptions(ProvincesCanada, getProvinceName);
    statesUS = enumToSelectOptions(StatesUS, getStateName);
    countryOptions: SelectOption[] = enumToSelectOptions(Countries, getCountryName, false);

    state: State = {
        validationErrors: {},
        zipCode: undefined
    };

    update = this.props.addActivityState!.updateActivity;

    initLocation = () => {
        const { activity } = this.props.addActivityState!;
        if (!activity.location.country) {
            this.update({
                location: {
                    country: Countries.USA
                }
            });
        }
    };

    componentDidMount() {
        this.initLocation();
    }

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;

        let validationErrors: ValidationErrors = this.state.validationErrors;

        let location: PropertyLocation = {};

        switch (name) {
            case "activityLocationAddress1":
                location.address1 = value;
                break;

            case "activityLocationAddress2":
                location.address2 = value;
                break;

            case "activityLocationCity":
                location.city = value;
                break;

            case "activityLocationState":
                location.state = value !== "none" ? value : null;
                break;

            case "activityLocationZipcode":
                let zipCode: string | undefined = value;
                if (location.country === Countries.Other) {
                    location.zipCode = value;
                } else {
                    if (reZipCode.test(value) && value !== "") {
                        validationErrors.zipCode = undefined;
                        zipCode = undefined;
                        location.zipCode = value;
                    } else {
                        validationErrors.zipCode = "Must be a valid zip code.";
                        this.setState({ zipCode, validationErrors });
                        return;
                    }
                    this.setState({ validationErrors });
                }
                break;

            case "activityLocationCountry":
                location.state = "";
                location.country = value !== "none" ? value : undefined;
                break;

            case "activityLocationCountryName":
                location.countryName = value;
                break;
        }

        const { activity } = this.props.addActivityState!;
        this.update({
            location: {
                ...activity.location,
                ...location
            }
        });
    };

    render() {
        const { validationErrors, zipCode } = this.state;
        const { activity } = this.props.addActivityState!;
        const { location } = activity;

        const invalidZipCode = !!validationErrors.zipCode || isStringInvalid(location.zipCode);
        const invalidAddress = isStringInvalid(location.address1);
        const invalidCity = isStringInvalid(location.city);
        const invalidState = isStringInvalid(location.state);
        const invalidCountry = location.country === Countries.Other && isStringInvalid(location.countryName);

        const submitDisabled = invalidZipCode || invalidAddress || invalidCity || invalidState || invalidCountry;

        const countryInput = (
            <SelectInput
                name="activityLocationCountry"
                label="Country"
                value={location.country}
                options={this.countryOptions}
                onChange={this.onChange}
            />
        );

        return (
            <StyledDashboard>
                <form>
                    <TextInput
                        name="activityLocationAddress1"
                        value={location.address1}
                        onChange={this.onChange}
                        label="Street address"
                    />
                    <TextInput
                        name="activityLocationAddress2"
                        value={location.address2}
                        onChange={this.onChange}
                        label="Suite, unit number (optional)"
                    />
                    <TextInput
                        name="activityLocationCity"
                        value={location.city}
                        onChange={this.onChange}
                        label="City"
                    />
                    <SplitInput error={validationErrors.zipCode}>
                        {location.country !== Countries.Other ? (
                            <SelectInput
                                name="activityLocationState"
                                label={location.country === Countries.Canada ? "Province" : "State"}
                                value={location.state || "none"}
                                options={location.country === Countries.Canada ? this.provincesCanada : this.statesUS}
                                onChange={this.onChange}
                            />
                        ) : (
                            <TextInput
                                name="activityLocationState"
                                label="State/Province"
                                value={location.state}
                                onChange={this.onChange}
                            />
                        )}
                        <TextInput
                            name="activityLocationZipcode"
                            label="Zip code"
                            value={invalidZipCode ? zipCode : location.zipCode}
                            onChange={this.onChange}
                        />
                    </SplitInput>

                    {location.country !== Countries.Other ? (
                        countryInput
                    ) : (
                        <SplitInput>
                            {countryInput}
                            <TextInput
                                name="activityLocationCountryName"
                                value={location.countryName}
                                onChange={this.onChange}
                            />
                        </SplitInput>
                    )}

                    <AddActivityActions submitDisabled={submitDisabled} />
                </form>
            </StyledDashboard>
        );
    }
}
