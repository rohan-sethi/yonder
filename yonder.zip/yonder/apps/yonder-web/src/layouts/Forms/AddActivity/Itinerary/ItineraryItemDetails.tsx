import React from "react";
import styled from "styled-components";
import { ActivityItinerary, AvailabilityTimesByHour, getAvailabilityTimeByHourLabel } from "@yonder/db";

import { SplitInput, SelectInput, FormChangeEvent, TextInput, InputTextArea } from "../../../../components";
import { enumToSelectOptions } from "../../../../functions";

type Props = {
    item: ActivityItinerary;
    itemIndex: number;
    onChange: (ev: FormChangeEvent, itemIndex: number) => void;
};

export const ItineraryItemDetails = (props: Props) => {
    const availabilityTimes = enumToSelectOptions(
        AvailabilityTimesByHour,
        getAvailabilityTimeByHourLabel,
        true,
        "time",
        "Time"
    );

    const { item, itemIndex, onChange } = props;

    return (
        <StyledItineraryItem>
            <SplitInput>
                <SelectInput
                    name="itineraryItemTime"
                    onChange={(ev) => onChange(ev, itemIndex)}
                    value={item.time || "time"}
                    options={availabilityTimes}
                />
                <TextInput
                    name="itineraryItemTitle"
                    value={item.title}
                    placeholder="Add a title. E.g. Group Buffet"
                    onChange={(ev) => onChange(ev, itemIndex)}
                />
            </SplitInput>
            <InputTextArea
                name="itineraryItemDescription"
                value={item.description}
                placeholder="Add a description. E.g. Ranch style BBQ at Moose Lodge."
                onChange={(ev) => onChange(ev, itemIndex)}
                rows={6}
                maxRows={8}
            />
            <hr className="thin-hr" />
        </StyledItineraryItem>
    );
};
const StyledItineraryItem = styled.div`
    .split-input {
        margin-bottom: 2rem;
    }
    .input-select {
        width: 27%;
    }
    .input-field {
        width: 73%;
    }
    .thin-hr {
        margin: 2rem 0;
    }
    .input-textarea {
        margin-bottom: 0;
    }
`;
