import React from "react";
import { observer, inject } from "mobx-react";

import { IAddActivityStore } from "../../../store";
import {
    StyledDashboard,
    FormChangeEvent,
    InputTextArea,
    limitTextAreaInput,
    ListTextBox,
    KeyPressEvent,
    MouseClickEvent,
    InputYesNo,
    TwoColumnYesNoInputs
} from "../../../components";
import { AddActivityActions } from "./AddActivityActions";

type Props = IAddActivityStore;

type State = {
    placeholder?: string;
};

@inject("addActivityState")
@observer
export class AddActivityRules extends React.Component<Props, State> {
    state: State = {
        placeholder: ""
    };

    update = this.props.addActivityState!.updateActivity;

    onYesNoChange = (ev: MouseClickEvent, name: string, value: boolean) => {
        ev.preventDefault();

        switch (name) {
            case "suitableForChildren":
                this.update({
                    suitableForChildren: value
                });
                break;
            case "suitableForInfants":
                this.update({
                    suitableForInfants: value
                });
                break;
            case "handicapAccessible":
                this.update({
                    handicapAccessible: value
                });
                break;
            case "petsAllowed":
                this.update({
                    petsAllowed: value
                });
                break;
        }
    };

    onChange = (ev: FormChangeEvent | MouseClickEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;

        switch (name) {
            case "petsAndAnimalsPolicyDescription":
                this.update({
                    petsAndAnimalsPolicyDescription: limitTextAreaInput(value)
                });
                break;
        }
    };

    onFieldAdd = (ev?: KeyPressEvent | MouseClickEvent) => {
        if (ev) {
            ev.preventDefault();
        }

        const { addActivityRule } = this.props.addActivityState!;
        const { activityRules } = this.props.addActivityState!.activity;

        addActivityRule("");

        this.props.addActivityState!.updateActivity({
            activityRules: activityRules
        });
    };

    onFieldRemove = (ev: KeyPressEvent | MouseClickEvent, i?: number) => {
        const { removeActivityRuleIndex, removeLastActivityRule } = this.props.addActivityState!;
        const { activityRules } = this.props.addActivityState!.activity;

        if (activityRules.length > 1) {
            if (i === undefined) {
                removeLastActivityRule();
            } else {
                removeActivityRuleIndex(i);
            }
            this.update({
                activityRules: activityRules
            });
        }
    };

    onRulesChange = (ev: FormChangeEvent, i: number) => {
        ev.preventDefault();

        const { value } = ev.target;

        let activityRules = this.props.addActivityState!.activity.activityRules;

        activityRules[i] = value;

        this.update({
            activityRules: activityRules
        });
    };

    populateActivityRules = () => {
        const { activity } = this.props.addActivityState!;

        if (activity.activityRules.length === 0) {
            this.onFieldAdd();
        }
    };

    render() {
        const { activity } = this.props.addActivityState!;

        return (
            <StyledDashboard>
                <form>
                    <TwoColumnYesNoInputs>
                        <div className="input-yes-no-with-description">
                            <InputYesNo
                                name="suitableForInfants"
                                descriptor="Suitable for babies/toddlers age 4 and under?"
                                value={activity.suitableForInfants}
                                onClick={this.onYesNoChange}
                                padded={false}
                            />
                            <InputTextArea
                                name="suitableForInfantsDescription"
                                value={activity.suitableForInfantsDescription}
                                onChange={this.onChange}
                                rows={4}
                                maxRows={6}
                                placeholder="Any notes for guests?"
                                maxLength={240}
                            />
                        </div>
                        <div className="input-yes-no-with-description">
                            <InputYesNo
                                name="suitableForChildren"
                                descriptor="Suitable for children age 5 and older?"
                                value={activity.suitableForChildren}
                                onClick={this.onYesNoChange}
                                padded={false}
                            />
                            <InputTextArea
                                name="suitableForChildrenDescription"
                                value={activity.suitableForChildrenDescription}
                                onChange={this.onChange}
                                rows={4}
                                maxRows={6}
                                placeholder="Any notes for guests?"
                                maxLength={240}
                            />
                        </div>
                        <div className="input-yes-no-with-description">
                            <InputYesNo
                                name="handicapAccessible"
                                descriptor="Handicap accessible?"
                                value={activity.handicapAccessible}
                                onClick={this.onYesNoChange}
                                padded={false}
                            />
                            <InputTextArea
                                name="handicapAccessibleDescription"
                                value={activity.handicapAccessibleDescription}
                                onChange={this.onChange}
                                rows={4}
                                maxRows={6}
                                placeholder="Any notes for guests?"
                                maxLength={240}
                            />
                        </div>
                        <div className="input-yes-no-with-description">
                            <InputYesNo
                                name="petsAllowed"
                                descriptor="Pets Allowed?"
                                value={activity.petsAllowed}
                                onClick={this.onYesNoChange}
                                padded={false}
                            />
                            <InputTextArea
                                name="petsAndAnimalsPolicyDescription"
                                value={activity.petsAndAnimalsPolicyDescription}
                                onChange={this.onChange}
                                rows={4}
                                maxRows={6}
                                placeholder="Any notes for guests?"
                                maxLength={240}
                            />
                        </div>
                    </TwoColumnYesNoInputs>

                    <ListTextBox
                        name="activityRules"
                        label="Are there any other guest requirements that you would like to include?"
                        collection={activity.activityRules}
                        onFieldAdd={this.onFieldAdd}
                        addLabel="Add another requirement"
                        onFieldRemove={this.onFieldRemove}
                        removeLabel="Remove last requirement"
                        onChange={this.onRulesChange}
                        placeholder="Example: Please wear hiking boots."
                        className="three-quarter"
                        maxLength={240}
                    />

                    <AddActivityActions />
                </form>
            </StyledDashboard>
        );
    }
}
