import React from "react";
import { observer, inject } from "mobx-react";
import { ExperienceCategories, getExperienceCategoryLabel, getExperienceCategoryImageUrl } from "@yonder/db";

import { IAddActivityStore, IContentModalStore } from "../../../store";
import {
    StyledDashboard,
    FormChangeEvent,
    InputCheckboxImage,
    InformationLink,
    ActivityCategories
} from "../../../components";
import { LabeledEnum } from "../../../interfaces";
import { enumToInputOptions } from "../../../functions";
import { StyledExperienceCategories } from "../SubmissionApproval";
import { AddActivityActions } from "./AddActivityActions";

type Props = IAddActivityStore & IContentModalStore;

@inject("addActivityState", "contentModalState")
@observer
export class AddActivityExperienceCategories extends React.Component<Props> {
    experienceCategories: LabeledEnum[] = enumToInputOptions(ExperienceCategories, getExperienceCategoryLabel);

    update = this.props.addActivityState!.updateActivity;

    onChange = (ev: FormChangeEvent) => {
        const { value } = ev.target;
        const { addExperienceCategory, removeExperienceCategory } = this.props.addActivityState!;
        const { experienceCategories } = this.props.addActivityState!.activity;
        const experienceCategory: ExperienceCategories = ev.target.name;

        if (value) {
            if (experienceCategories.length <= 1) {
                addExperienceCategory(experienceCategory);
            }
        } else {
            removeExperienceCategory(experienceCategory);
        }
    };

    render() {
        const { activity } = this.props.addActivityState!;
        const { open } = this.props.contentModalState!;

        const experienceCategoryCheckboxes = this.experienceCategories.map((category: LabeledEnum, i: number) => {
            const { name, label } = category;
            const checked: boolean = activity.experienceCategories.includes(name as ExperienceCategories);

            return (
                <InputCheckboxImage
                    groupName="experienceCategory"
                    name={name}
                    label={label}
                    url={getExperienceCategoryImageUrl(name as any)}
                    onChange={this.onChange}
                    checked={checked}
                    key={i}
                />
            );
        });

        const submitDisabled = experienceCategoryCheckboxes.every((checkbox) => checkbox.props.checked === false);

        return (
            <StyledDashboard>
                <form>
                    <p>What Experience Category best describes your activity? You can choose two.</p>
                    <InformationLink
                        onClick={() => open("", <ActivityCategories />)}
                        label="Explain experience categories"
                    />
                    <StyledExperienceCategories>{experienceCategoryCheckboxes}</StyledExperienceCategories>

                    <AddActivityActions submitDisabled={submitDisabled} />
                </form>
            </StyledDashboard>
        );
    }
}
