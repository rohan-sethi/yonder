import React from "react";
import { observer, inject } from "mobx-react";

import { IAddActivityStore } from "../../../store";
import {
    StyledDashboard,
    InputTextArea,
    FormChangeEvent,
    MouseClickEvent,
    ListTextBox,
    KeyPressEvent
} from "../../../components";
import { AddActivityActions } from "./AddActivityActions";

type Props = IAddActivityStore;

@inject("addActivityState")
@observer
export class AddActivityDescription extends React.Component<Props> {
    update = this.props.addActivityState!.updateActivity;

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;

        switch (name) {
            case "activitySummary":
                this.update({
                    summary: value
                });
                break;
            case "whatWeLove":
                this.update({
                    whatWeLove: value
                });
                break;
        }
    };

    onKeyThingToKnowChange = (ev: FormChangeEvent, i: number) => {
        const { value } = ev.target;

        let keyThingsToKnow = this.props.addActivityState!.activity.keyThingsToKnow;

        keyThingsToKnow[i] = value;

        this.update({
            keyThingsToKnow: keyThingsToKnow
        });
    };

    onKeyThingToKnowAdd = async (ev?: KeyPressEvent | MouseClickEvent) => {
        if (ev) {
            ev.preventDefault();
        }

        const { addKeyThingToKnow } = this.props.addActivityState!;
        const { keyThingsToKnow } = this.props.addActivityState!.activity;

        addKeyThingToKnow("");

        this.update({
            keyThingsToKnow: keyThingsToKnow
        });
    };

    onKeyThingToKnowRemove = (ev: KeyPressEvent | MouseClickEvent, i?: number) => {
        ev.preventDefault();

        const { removeKeyThingToKnowIndex, removeLastKeyThingToKnow } = this.props.addActivityState!;
        const { keyThingsToKnow } = this.props.addActivityState!.activity;

        if (keyThingsToKnow.length > 1) {
            if (i === undefined) {
                removeLastKeyThingToKnow();
            } else {
                removeKeyThingToKnowIndex(i);
            }
            this.update({
                keyThingsToKnow: keyThingsToKnow
            });
        }
    };

    render() {
        const { activity } = this.props.addActivityState!;

        return (
            <StyledDashboard>
                <form>
                    <InputTextArea
                        name="activitySummary"
                        value={activity.summary}
                        onChange={this.onChange}
                        rows={5}
                        maxRows={5}
                        descriptor="Write a brief description of your activity experience."
                        placeholder="E.g. Come and join us on a foraging experience at the Enchanted Cabin located in the beautiful, Woodsy Forest, you will believe you have just stepped into a fairytale. If you look closely, you may discover plants and animals you may have never seen before."
                        maxLength={240}
                    />
                    <InputTextArea
                        name="whatWeLove"
                        value={activity.whatWeLove}
                        onChange={this.onChange}
                        rows={12}
                        maxRows={12}
                        descriptor="Showcase everything that sets your activity apart! What will guests remember most about their visit? "
                        placeholder={`E.g. Foraging for food is something anyone can do, and is an excellent way to feel connected to the natural environment. We will guide you on all of the best places to find tasty, safe-to-eat mushrooms in the Woodsy Forest. We will also be teaching you the many ways you can be respectful to the natural ecosystem if you ever decide to venture out on your own foraging trips in the future.

Foraging in the Woodsy Forest is sure to be an experience you won’t forget. Everyone’s foraging adventure is unique, as there are always different plants to be found depending on the season and time of day. We will primarily be searching for mushrooms, but we will also gather any nuts, berries, and herbs we discover along the way.

After rummaging through the Forest, we will return to the Enchanted Cabin to cook our findings together. Using our own recipe book that has been in our family for generations, we will cook delectable dishes you can then easily recreate at home. We can adjust our recipes accordingly to fit any dietary restrictions or allergies, so everyone is guaranteed to enjoy the experience.
                            `}
                    />
                    <ListTextBox
                        name="keyThingsToKnow"
                        label="Share some fun facts you would like guests to know about your activity."
                        collection={activity.keyThingsToKnow}
                        onFieldAdd={this.onKeyThingToKnowAdd}
                        onFieldRemove={this.onKeyThingToKnowRemove}
                        onChange={this.onKeyThingToKnowChange}
                        placeholder="The best time of the year to visit is around Springtime, following a rainy season. This is when you’ll find the largest variety of mushrooms."
                        inputType="text-area"
                        rows={5}
                        maxRows={5}
                        maxLength={240}
                        addLabel="Add another fact"
                        removeLabel="Remove last fact"
                    />

                    <AddActivityActions />
                </form>
            </StyledDashboard>
        );
    }
}
