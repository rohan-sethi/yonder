import React from "react";
import { inject, observer } from "mobx-react";

import { IAddActivityStore } from "../../../store";
import {
    InputCounter,
    StyledDashboard,
    FormChangeEvent,
    ButtonRow,
    MouseClickEvent,
    LabeledPlusMinusButton
} from "../../../components";
import { ItineraryItemDetails } from "./Itinerary/ItineraryItemDetails";
import { AddActivityActions } from "./AddActivityActions";

type Props = IAddActivityStore;

@inject("addActivityState")
@observer
export class AddActivityItinerary extends React.Component<Props> {
    componentDidMount() {
        const { itinerary } = this.props.addActivityState!.activity;

        if (itinerary.length === 0) {
            this.onAddItineraryItem();
        }
    }

    update = this.props.addActivityState!.updateActivity;

    onDurationChange = async (count: number) => {
        this.update({
            durationCountByHour: count
        });
    };

    onItineraryItemChange = (ev: FormChangeEvent, itemIndex: number) => {
        const { name, value } = ev.target;
        const { itinerary } = this.props.addActivityState!.activity;

        switch (name) {
            case "itineraryItemTime":
                itinerary[itemIndex].time = value !== "time" ? value : undefined;
                break;
            case "itineraryItemTitle":
                itinerary[itemIndex].title = value;
                break;
            case "itineraryItemDescription":
                itinerary[itemIndex].description = value;
        }

        this.update({
            itinerary: itinerary
        });
    };

    onAddItineraryItem = (ev?: MouseClickEvent) => {
        const { addItineraryItem } = this.props.addActivityState!;
        if (ev) {
            ev.preventDefault();
        }

        addItineraryItem();
    };

    onRemoveItineraryItem = (ev: MouseClickEvent) => {
        const { removeItineraryItem } = this.props.addActivityState!;

        ev.preventDefault();

        removeItineraryItem();
    };

    render() {
        const { activity } = this.props.addActivityState!;

        const itineraryItems = activity.itinerary.map((item, i) => {
            return <ItineraryItemDetails key={i} item={item} itemIndex={i} onChange={this.onItineraryItemChange} />;
        });

        return (
            <StyledDashboard>
                <form>
                    <InputCounter
                        descriptor="What is the duration of this activity?"
                        unitString="Hour"
                        value={activity.durationCountByHour}
                        minValue={1}
                        maxValue={12}
                        onChange={this.onDurationChange}
                    />
                    <p>If your activity is more than 3 hours, please create an itinerary.</p>

                    {itineraryItems}

                    <ButtonRow>
                        <LabeledPlusMinusButton
                            label="Add next schedule"
                            type="plus"
                            size="small"
                            onClick={this.onAddItineraryItem}
                        />

                        {itineraryItems.length > 1 ? (
                            <LabeledPlusMinusButton
                                label="Remove last schedule"
                                type="minus"
                                size="small"
                                onClick={this.onRemoveItineraryItem}
                            />
                        ) : (
                            <div />
                        )}
                    </ButtonRow>

                    <AddActivityActions />
                </form>
            </StyledDashboard>
        );
    }
}
