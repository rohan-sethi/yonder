import React from "react";
import { observer, inject } from "mobx-react";

import { IAddActivityStore } from "../../../store";
import { Button, MouseClickEvent } from "../../../components";
import { StyledAddPropertyActivityActions } from "../AddProperty/AddPropertyActions";

type Props = IAddActivityStore & {
    submitDisabled?: boolean;
    onSave?: (ev: MouseClickEvent) => void;
};

@inject("addActivityState")
@observer
export class AddActivityActions extends React.Component<Props> {
    onSave = (ev: MouseClickEvent) => {
        ev.preventDefault();

        const { setSectionComplete, nextSection, saveActivity } = this.props.addActivityState!;
        setSectionComplete();
        saveActivity();
        nextSection();
    };

    render() {
        const { submitDisabled, onSave } = this.props;
        return (
            <StyledAddPropertyActivityActions>
                <Button
                    label="Save and Continue"
                    disabled={submitDisabled || false}
                    onClick={onSave || this.onSave}
                    buttonStyle="solid"
                />
            </StyledAddPropertyActivityActions>
        );
    }
}
