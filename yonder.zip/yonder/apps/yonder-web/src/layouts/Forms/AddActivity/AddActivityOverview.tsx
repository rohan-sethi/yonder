import React from "react";
import { observer, inject } from "mobx-react";
import {
    getActivityCategories,
    ActivityTypes,
    getActivityTypesByCategory,
    getActivityLabel,
    PhysicalActivityLevels,
    getPhysicalActivityLevel
} from "@yonder/db";

import { IAddActivityStore } from "../../../store";
import {
    StyledDashboard,
    FormChangeEvent,
    SelectInput,
    SelectOption,
    ButtonRow,
    FormButton,
    TextInput,
    CheckboxCategoryAccordion,
    CategoryCheckboxes,
    ExternalLink
} from "../../../components";
import { LabeledEnum } from "../../../interfaces";
import { enumToInputOptions, enumToSelectOptions } from "../../../functions";
import { AddActivityActions } from "./AddActivityActions";

type ActivityCategory = {
    name: string;
    activityTypes: LabeledEnum[];
};

type Props = IAddActivityStore;

@inject("addActivityState")
@observer
export class AddActivityOverview extends React.Component<Props> {
    physicalActivityLevels: SelectOption[] = enumToSelectOptions(PhysicalActivityLevels, getPhysicalActivityLevel);
    hostOptions: SelectOption[] = this.props.addActivityState!.hosts.map((user) => {
        return {
            value: user.id,
            label: `${user.firstName} ${user.lastName}`
        } as SelectOption;
    });

    categorizedActivityTypes: ActivityCategory[] = getActivityCategories().map((category: string) => {
        const activityTypes: ActivityTypes[] = getActivityTypesByCategory(category);
        return {
            name: category,
            activityTypes: enumToInputOptions(ActivityTypes, getActivityLabel).filter((activity: LabeledEnum) =>
                activityTypes.includes(activity.name as ActivityTypes)
            )
        } as ActivityCategory;
    });

    update = this.props.addActivityState!.updateActivity;
    save = this.props.addActivityState!.saveActivity;

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;

        switch (name) {
            case "activityName":
                this.update({
                    name: value
                });
                break;
            case "selectHost":
                this.update({
                    hostId: value
                });
                break;
            case "physicalActivityLevel":
                this.update({
                    physicalActivityLevel: value !== "none" ? value : null
                });
                break;
        }
    };

    onActivityChange = (ev: FormChangeEvent) => {
        const { value } = ev.target;
        const { addActivityType, removeActivityType } = this.props.addActivityState!;
        const { activityTypes } = this.props.addActivityState!.activity;

        const activity: ActivityTypes = ev.target.name;
        if (value) {
            if (activityTypes.length === 0) {
                addActivityType(activity);
            }
        } else {
            removeActivityType(activity);
        }
    };

    render() {
        const { activity } = this.props.addActivityState!;

        const categoryCheckboxes = this.categorizedActivityTypes.map((category: ActivityCategory, i: number) => {
            if (category) {
                return (
                    <CheckboxCategoryAccordion header={category.name} key={i}>
                        <CategoryCheckboxes
                            categoryName={category.name}
                            categoryEnums={category.activityTypes}
                            collection={activity.activityTypes}
                            onChange={this.onActivityChange}
                            columns="two"
                            hideCategoryName
                        />
                    </CheckboxCategoryAccordion>
                );
            }
            return undefined;
        });

        return (
            <StyledDashboard>
                <form>
                    <TextInput
                        name="activityName"
                        descriptor="Give your activity listing a unique name"
                        onChange={this.onChange}
                        value={activity.name}
                        placeholder="Example: Italian Farm-to-table Cooking Class"
                    />
                    <SelectInput
                        name="selectHost"
                        descriptor="Who is the host for this activity?"
                        value={activity.hostId || (this.hostOptions[0] && this.hostOptions[0].value)}
                        onChange={this.onChange}
                        options={this.hostOptions}
                    />
                    <ButtonRow className="invite-button">
                        <ExternalLink to="/my-business" target="_blank" rel="noopener noreferrer">
                            <FormButton label="Invite a Co-host" onClick={this.save} buttonStyle="outline-color" />
                        </ExternalLink>
                    </ButtonRow>

                    <SelectInput
                        name="physicalActivityLevel"
                        descriptor={
                            <>
                                On a scale of 1 to 10, please rate your activity's level of physical intensity.
                                <br />( 1 = very easy, 10 = extremely difficult )
                            </>
                        }
                        value={activity.physicalActivityLevel || "none"}
                        options={this.physicalActivityLevels}
                        onChange={this.onChange}
                    />
                    <div className="checkboxes-with-descriptor">
                        <p className="descriptor">
                            Please select an activity category. This is the general category type your activity will
                            live under.
                        </p>
                        {categoryCheckboxes}
                    </div>

                    <AddActivityActions />
                </form>
            </StyledDashboard>
        );
    }
}
