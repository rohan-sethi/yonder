import React from "react";
import styled from "styled-components";
import { observer, inject } from "mobx-react";
import {
    getCancellationPolicyLabel,
    getCancellationPolicyDescription,
    getCancellationPolicyUrl,
    PricingUnits,
    CancellationPolicies,
    getPricingUnitLabel
} from "@yonder/db";

import { IAddActivityStore } from "../../../store";
import {
    StyledDashboard,
    FormChangeEvent,
    InputCheckbox,
    InformationLink,
    TextInput,
    SplitInput,
    SelectInput,
    SelectOption,
    InputTextArea
} from "../../../components";
import { enumToInputOptions, stringToMonetary, enumToSelectOptions } from "../../../functions";
import { AddActivityActions } from "./AddActivityActions";
import { Props as AlertProps, Alert } from "../../../components/Alert";
import { LabeledEnum } from "../../../interfaces";

const alertsArray: AlertProps[] = [{ body: "Advanced pricing and availability options will be available soon." }];

export const ActivityPricingAlerts = alertsArray.map((alert: AlertProps, i: number) => {
    return <Alert {...alert} key={i} />;
});

type Props = IAddActivityStore;

@inject("addActivityState")
@observer
export class AddActivityPolicyPricing extends React.Component<Props> {
    cancellationPolicies: LabeledEnum[] = enumToInputOptions(CancellationPolicies, getCancellationPolicyLabel);
    pricingUnits: SelectOption[] = enumToSelectOptions(PricingUnits, getPricingUnitLabel, false);

    update = this.props.addActivityState!.updateActivity;

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;

        switch (name) {
            case "activityPricing":
                this.update({
                    pricing: stringToMonetary(value)
                });
                break;
            case "pricingUnits":
                this.update({
                    pricingUnits: value
                });
                break;
            case "pricingDescription":
                this.update({
                    pricingDescription: value
                });
        }
    };

    onChangeCancellationPolicy = async (ev: FormChangeEvent) => {
        this.update({
            cancellationPolicy: ev.target.name
        });
    };

    render() {
        const { activity } = this.props.addActivityState!;

        const selectedCancellationPolicy = activity.cancellationPolicy;

        const cancellationPolicies = this.cancellationPolicies.map((policy: LabeledEnum, i: number) => {
            const { name, label } = policy;
            const policyEnum: CancellationPolicies = name as CancellationPolicies;
            const policyUrl = getCancellationPolicyUrl(policyEnum);
            const policyDescription = getCancellationPolicyDescription(policyEnum);

            return (
                <React.Fragment key={i}>
                    <InputCheckbox
                        groupName="cancellationPolicy"
                        name={name}
                        label={`${label} ${policyDescription}`}
                        onChange={this.onChangeCancellationPolicy}
                        checked={selectedCancellationPolicy === name}
                        key={i}
                    />
                    <div className="policy-description">
                        <InformationLink
                            to={policyUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            label={`Read full ${label} policy here`}
                            external
                        />
                    </div>
                </React.Fragment>
            );
        });

        return (
            <StyledDashboard>
                <StyledPolicyPricing>
                    <div className="cancellation-policies">
                        <p>Please select your cancellation policy.</p>
                        {cancellationPolicies}
                    </div>
                    <SplitInput descriptor="Please enter the cost of this activity.">
                        <TextInput
                            name="activityPricing"
                            value={activity.pricing}
                            placeholder="Numeric value only"
                            onChange={this.onChange}
                        />
                        <SelectInput
                            name="pricingUnits"
                            value={activity.pricingUnits}
                            options={this.pricingUnits}
                            onChange={this.onChange}
                        />
                    </SplitInput>
                    <InputTextArea
                        name="pricingDescription"
                        descriptor="Pricing description (optional)"
                        value={activity.pricingDescription}
                        placeholder="E.g. This price is for two people and includes the meal and horseback ride."
                        onChange={this.onChange}
                        rows={6}
                        maxRows={6}
                    />

                    <AddActivityActions />
                </StyledPolicyPricing>
            </StyledDashboard>
        );
    }
}

const StyledPolicyPricing = styled.form`
    .cancellation-policies {
        padding-bottom: 3rem;

        p {
            margin-bottom: 2rem;
        }

        .policy-description {
            display: block;
            margin-left: 2rem;
            margin-bottom: 1.5rem;
        }

        .input-checkbox {
            margin-left: 0.5rem;
        }
    }
    .split-input {
        width: 90%;
    }
    .input-textarea {
        p {
            margin-bottom: 1rem;
        }
    }
`;
