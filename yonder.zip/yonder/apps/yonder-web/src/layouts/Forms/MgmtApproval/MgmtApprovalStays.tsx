import React from "react";
import { inject, observer } from "mobx-react";
import { HostApprovalSubmissionProgress } from "@yonder/db";

import {
    StyledForm,
    FormButton,
    ButtonRow,
    InputCounter,
    MouseClickEvent,
    PageTransition,
    InformationLink,
    TooltipModal,
    ExitWarning
} from "../../../components";
import { IFirebaseStore, IHostApprovalSubmissionStore, IContentModalStore } from "../../../store";

type Props = IFirebaseStore & IHostApprovalSubmissionStore & IContentModalStore;

@inject("firebaseState", "hostApprovalSubmissionState", "contentModalState")
@observer
export class MgmtApprovalStays extends React.Component<Props> {
    overnightStaysModal = {
        header: "Overnight Stay",
        body:
            "An overnight stay is a fully-furnished structure guests can sleep in. Your property can offer more than one structure for guests to choose from. This is the total number of structures located on your property, and is not to be confused with the number of rooms in each structure."
    };

    onChange = (count: number) => {
        const { updatePropertyManagementHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        updatePropertyManagementHostApprovalSubmission({
            overnightStayPropertiesCount: count
        });
    };

    onSave = async (ev: MouseClickEvent) => {
        ev.preventDefault();
        const { saveOrganization } = this.props.firebaseState!;
        const { saveHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        saveHostApprovalSubmission();

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.Activities
        });
    };

    onBack = async (ev: MouseClickEvent) => {
        ev.preventDefault();
        const { saveOrganization } = this.props.firebaseState!;

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.LetsBegin
        });
    };

    openConfirmDialog = (ev: MouseClickEvent) => {
        ev.preventDefault();

        const { openDialog } = this.props.contentModalState!;
        openDialog(<ExitWarning />, "Save & Exit", "Keep going", undefined, () => this.onBack(ev));
    };

    render() {
        const { dbHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        const { open } = this.props.contentModalState!;
        const { overnightStayPropertiesCount } = dbHostApprovalSubmission.propertyManagementHost!;

        return (
            <PageTransition>
                <StyledForm>
                    <h2>Overnight Stay Properties</h2>
                    <div className="form-container">
                        <form>
                            <p style={{ marginBottom: ".5rem" }}>How many overnight stay properties do you manage?</p>
                            <InformationLink
                                onClick={() => open("", <TooltipModal {...this.overnightStaysModal} />)}
                                label="Explain overnight stays"
                            />
                            <InputCounter
                                unitString="stay"
                                value={overnightStayPropertiesCount}
                                maxValue={31}
                                onChange={this.onChange}
                            />
                        </form>
                    </div>

                    <ButtonRow>
                        <FormButton label="Back" buttonStyle="no-outline" onClick={this.openConfirmDialog} />
                        <div />
                        <FormButton type="submit" label="Next" onClick={this.onSave} />
                    </ButtonRow>
                </StyledForm>
            </PageTransition>
        );
    }
}
