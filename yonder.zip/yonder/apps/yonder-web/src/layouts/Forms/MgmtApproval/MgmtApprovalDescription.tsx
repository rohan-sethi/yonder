import React from "react";
import { inject, observer } from "mobx-react";
import { HostApprovalSubmissionProgress } from "@yonder/db";

import {
    StyledForm,
    FormChangeEvent,
    FormButton,
    ButtonRow,
    MouseClickEvent,
    InputTextArea,
    PageTransition,
    InformationLink,
    InputYesNo,
    TooltipModal,
    TextInput
} from "../../../components";
import { IFirebaseStore, IHostApprovalSubmissionStore, IContentModalStore } from "../../../store";
import { isStringInvalid } from "../../../functions";

type Props = IFirebaseStore & IHostApprovalSubmissionStore & IContentModalStore;

@inject("firebaseState", "hostApprovalSubmissionState", "contentModalState")
@observer
export class MgmtApprovalDescription extends React.Component<Props> {
    scoutPermissionModal = {
        header: "What does this mean?",
        body: `By selecting "Yes", you’re agreeing to allow a Yonder Scout to use your existing online information to begin a listing draft. Don’t worry, you’ll be able to complete and approve this draft before it’s visible.`
    };

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;
        const { updatePropertyManagementHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        switch (name) {
            case "managementCompanyDescription":
                updatePropertyManagementHostApprovalSubmission({
                    managementCompanyDescription: value
                });
                break;
            case "channelManagerSoftware":
                updatePropertyManagementHostApprovalSubmission({
                    channelManagerSoftware: value
                });
                break;
        }
    };

    onYesNoChange = (ev: MouseClickEvent, name: string, value: boolean) => {
        ev.preventDefault();

        const { updatePropertyManagementHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        switch (name) {
            case "scoutImportPermission":
                updatePropertyManagementHostApprovalSubmission({
                    scoutImportPermission: value
                });
                break;
            case "useChannelManagerSoftware":
                updatePropertyManagementHostApprovalSubmission({
                    useChannelManagerSoftware: value
                });
                break;
        }
    };

    onSave = async (ev: MouseClickEvent) => {
        ev.preventDefault();

        const { saveOrganization } = this.props.firebaseState!;
        const { saveHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;

        saveHostApprovalSubmission();

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.Certificate
        });
    };

    onBack = async (ev: MouseClickEvent) => {
        ev.preventDefault();

        const { saveOrganization } = this.props.firebaseState!;

        await saveOrganization({
            approvalSubmissionProgress: HostApprovalSubmissionProgress.Location
        });
    };

    render() {
        const { dbHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        const invalidDescription = isStringInvalid(
            dbHostApprovalSubmission.propertyManagementHost!.managementCompanyDescription
        );
        const { open } = this.props.contentModalState!;

        return (
            <PageTransition>
                <StyledForm>
                    <h2>What's Your Story?</h2>
                    <div className="form-container">
                        <form>
                            <p>Please describe your company's overall mission and what type of properties you offer.</p>
                            <InputTextArea
                                name="managementCompanyDescription"
                                value={dbHostApprovalSubmission.propertyManagementHost!.managementCompanyDescription}
                                onChange={this.onChange}
                                rows={10}
                                maxRows={10}
                                placeholder="We are Yonder.com Property Management company. We help property owners with amazing mountain cabins manage their stays. We are here to help guests find their perfect getaway in big sky country. All of our properties are safe, clean, as advertised and ready for your arrival."
                            />
                            <div>
                                <p style={{ marginBottom: ".5rem" }}>
                                    Would you like the Scouts to help import your listings?
                                </p>
                                <InformationLink
                                    onClick={() => open("", <TooltipModal {...this.scoutPermissionModal} />)}
                                    label="What does this mean?"
                                />
                                <InputYesNo
                                    name="scoutImportPermission"
                                    value={dbHostApprovalSubmission.propertyManagementHost!.scoutImportPermission}
                                    onClick={this.onYesNoChange}
                                />
                            </div>
                            <InputYesNo
                                name="useChannelManagerSoftware"
                                descriptor="Do you use a Channel Manager Software?"
                                value={dbHostApprovalSubmission.propertyManagementHost!.useChannelManagerSoftware}
                                onClick={this.onYesNoChange}
                            />
                            <TextInput
                                name="channelManagerSoftware"
                                descriptor="What is the name of the software?"
                                value={dbHostApprovalSubmission.propertyManagementHost!.channelManagerSoftware}
                                onChange={this.onChange}
                            />
                        </form>
                    </div>
                    <ButtonRow>
                        <FormButton label="Back" buttonStyle="no-outline" onClick={this.onBack} />
                        <div />
                        <FormButton type="submit" label="Next" disabled={invalidDescription} onClick={this.onSave} />
                    </ButtonRow>
                </StyledForm>
            </PageTransition>
        );
    }
}
