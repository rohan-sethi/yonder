import React from "react";
import styled from "styled-components";
import { inject, observer } from "mobx-react";

import { IFirebaseStore, IPaymentMethodStore, IContentModalStore } from "../../store";
import { FormButton } from "../../components";

type Props = IFirebaseStore & IPaymentMethodStore & IContentModalStore;
type State = {
    success: { message?: string } | null;
    error: { message?: string } | null;
};

@inject("firebaseState", "paymentMethodState", "contentModalState")
@observer
export class MyCards extends React.Component<Props, State> {
    state: State = {
        success: null,
        error: null
    };

    componentDidMount() {
        // const { dbUser } = this.props.firebaseState!;
        const { getPaymentMethods } = this.props.paymentMethodState!;

        getPaymentMethods();
    }

    onDelete = (cardId?: string) => {
        // const { dbUser } = this.props.firebaseState!;
        const { deletePaymentMethod } = this.props.paymentMethodState!;

        deletePaymentMethod(cardId);
    };

    render() {
        let myCards: JSX.Element[] | string;
        const { cards } = this.props.paymentMethodState!;
        const { openDialog } = this.props.contentModalState!;

        if (cards.length > 0) {
            myCards = cards.map((card) => {
                return (
                    <FlexDiv key={card.id}>
                        <StyledCCProps>
                            <p>{card.ccExpireYear}</p>
                            <p>
                                {card.ccType} ****{card.ccLastDigits}
                            </p>
                        </StyledCCProps>

                        <FormButton
                            buttonStyle="outline"
                            label="Delete"
                            onClick={() =>
                                openDialog(`Are you sure you want to delete this card?`, "Cancel", "Okay", () =>
                                    this.onDelete(card.id)
                                )
                            }
                        />
                    </FlexDiv>
                );
            });
        } else {
            myCards = "You currently have no cards.";
        }

        return <div>{myCards}</div>;
    }
}

// TODO: Remove !important tags, find out why these styles are getting overridden
const StyledCCProps = styled.div`
    display: block;

    p {
        margin: 0 !important;
        padding: 0 !important;
        font-size: 1.125rem !important;
        line-height: 1.5 !important;
    }
`;

const FlexDiv = styled.div`
    display: flex;
    justify-content: space-between;
    padding-left: 0;
    margin-bottom: 1.5rem;

    p {
        margin-top: 0 !important;
    }

    button.form-button {
        width: auto !important;
    }
`;
