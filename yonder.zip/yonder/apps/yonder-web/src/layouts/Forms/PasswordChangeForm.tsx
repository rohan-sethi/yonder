import React from "react";
import { observer, inject } from "mobx-react";

import {
    StyledForm,
    PasswordInput,
    SubmitButton,
    FormChangeEvent,
    FormSubmitEvent,
    rePassword
} from "../../components";
import { IFirebaseStore } from "../../store";
import { isStringInvalid } from "../../functions";

type Props = IFirebaseStore;

type ValidationErrors = {
    password?: string;
};
const INITIAL_STATE = {
    currentPassword: "",
    passwordOne: "",
    passwordTwo: "",
    success: null as { message?: string } | null,
    error: null as { message?: string } | null,
    validationErrors: {
        password: undefined
    } as ValidationErrors
};

@inject("firebaseState")
@observer
export class PasswordChangeForm extends React.Component<Props> {
    state = INITIAL_STATE;

    onSubmit = async (ev: FormSubmitEvent) => {
        ev.preventDefault();

        const { currentPassword, passwordOne } = this.state;
        const { firebase } = this.props.firebaseState!;

        try {
            await firebase.doUserReauthenticate(currentPassword);
            await firebase.doPasswordUpdate(passwordOne);

            // refs aren't allowed in stateless components (PasswordInput) so this is done instead
            let fields = [
                document.querySelector('input[name="currentPassword"]'),
                document.querySelector('input[name="passwordOne"]'),
                document.querySelector('input[name="passwordTwo"]')
            ];
            fields.forEach((field: Element | null) => {
                if (field) {
                    (field as HTMLInputElement).value = "";
                }
            });

            this.setState({
                ...INITIAL_STATE,
                success: {
                    message: "Successfully changed password!"
                }
            });
        } catch (error) {
            this.setState({ error });
        }
    };

    onChange = (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;
        const { passwordOne } = this.state;

        let validationErrors: ValidationErrors = this.state.validationErrors;

        switch (name) {
            case "passwordOne":
                if (rePassword.test(value) && value !== "") {
                    validationErrors.password = undefined;
                } else {
                    validationErrors.password =
                        "Password should contain at least 8 characters and either one number or special character (!@#$%^&*)";
                }
                break;

            case "passwordTwo":
                if (passwordOne === value && value !== "") {
                    validationErrors.password = undefined;
                } else {
                    validationErrors.password = "Passwords must match";
                }
                break;
        }

        this.setState({ [name]: value, validationErrors });
    };

    render() {
        const { currentPassword, passwordOne, passwordTwo, success, error, validationErrors } = this.state;

        const invalidCurrentPassword = isStringInvalid(currentPassword);
        const invalidPasswordOne = isStringInvalid(passwordOne) || !!validationErrors.password;
        const invalidPasswordTwo = isStringInvalid(passwordTwo);
        const isInvalid = invalidCurrentPassword || invalidPasswordOne || invalidPasswordTwo;

        return (
            <StyledForm>
                {success && <p className="success-message">{success.message}</p>}
                <form onSubmit={this.onSubmit}>
                    <PasswordInput name="currentPassword" label="Current Password" onChange={this.onChange} required />
                    <PasswordInput name="passwordOne" label="New Password" onChange={this.onChange} required />
                    <PasswordInput name="passwordTwo" label="Confirm New Password" onChange={this.onChange} required />
                    {validationErrors && <p className="error-message">{validationErrors.password}</p>}
                    {error && <p className="error-message">{error.message}</p>}
                    <SubmitButton label="Change Password" disabled={isInvalid} />
                </form>
            </StyledForm>
        );
    }
}
