import React from "react";
import styled from "styled-components";

import { Page, Section } from "../components";

export class LayoutPageNotFound extends React.Component {
    render() {
        return (
            <Page>
                <StyledHome>
                    <Section>Page Not Found</Section>
                </StyledHome>
            </Page>
        );
    }
}

const StyledHome = styled.div`
    margin: 0;
`;
