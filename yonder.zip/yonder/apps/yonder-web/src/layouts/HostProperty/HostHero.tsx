import React from "react";
import styled from "styled-components";
import pluralize from "pluralize";
import { PropertyLocation, PropertyPricing, StatesUS, getStateName } from "@yonder/db";

import { ImageBackground, Icon, RouterLink, Button, ArrowButton } from "../../components";
import { color } from "../../variables";

type Props = {
    image: any;
    title: string;
    rating: number;
    propertyType: string;
    pricing: PropertyPricing;
    location: PropertyLocation;
    onGalleryClick?: () => void;
};

type State = {
    mobile: boolean;
};

export default class HostHero extends React.Component<Props, State> {
    state: State = {
        mobile: false
    };

    componentDidMount() {
        this.updateDimensions();
        window.addEventListener("resize", this.updateDimensions);
    }

    componentWillUnmount() {
        window.removeEventListener("resize", this.updateDimensions);
    }

    updateDimensions = () => {
        let mobile = window.innerWidth < 960;

        if (this.state.mobile !== mobile) {
            this.setState({
                mobile
            });
        }
    };

    render() {
        const state = getStateName(this.props.location.state as StatesUS);

        if (this.state.mobile) {
            return (
                <HomeSectionMobile>
                    <div className="property-controls">
                        <RouterLink className="navigation-return">
                            <Icon type="back" size="2rem" color={color.pureWhite} />
                        </RouterLink>
                    </div>
                    <div className="property-details">
                        <h3>
                            {this.props.location.city}, {state}
                        </h3>
                        <h1>{this.props.title}</h1>
                        <div className="rating">
                            <Icon type="star" size="1.625rem" color="#ee7d23" /> {this.props.rating}
                        </div>
                    </div>
                    <div className="image-container">
                        <ImageBackground {...this.props.image} maxHeight />
                    </div>
                </HomeSectionMobile>
            );
        } else {
            return (
                <HomeSection>
                    <div className="property-details">
                        <RouterLink className="navigation-return">
                            <Icon type="back" size="2rem" color="#585858" />
                            <h3>
                                {pluralize(this.props.propertyType)} in {state}
                            </h3>
                        </RouterLink>
                        <div className="property-name">
                            <h1>{this.props.title}</h1>
                            <div className="lower-container">
                                <span className="rating">
                                    {this.props.rating} <Icon type="star" size="1.625rem" color="#ee7d23" />
                                </span>
                                <h3>
                                    {this.props.location.city}, {state}
                                </h3>
                            </div>
                        </div>
                        <div className="book-info">
                            <Button buttonStyle="outline" label="Book Now" />
                            <div className="cost">
                                <span>${this.props.pricing.defaultWeekday}</span> per night
                            </div>
                        </div>
                    </div>
                    <div className="image-container">
                        <ImageBackground {...this.props.image} maxHeight />
                    </div>
                    <ArrowButton color={color.pureWhite} onClick={this.props.onGalleryClick} />
                </HomeSection>
            );
        }
    }
}

const HomeSectionMobile = styled.section`
    position: relative;
    overflow: hidden;
    height: calc(100vh - 4rem);

    .property-controls {
        position: absolute;
        display: block;
        width: 100%;
        z-index: 11;
        padding: 2rem;
    }

    .property-details {
        position: absolute;
        display: block;
        width: 100%;
        z-index: 11;
        padding: 2rem;
        left: 0;
        bottom: 0;
        background-color: ${color.pureWhite};

        h1 {
            width: 80%;
            font-size: 3rem;
            font-weight: 500;
            line-height: 1.25;
        }

        h3 {
            display: inline-block;
            width: 80%;
            font-size: 1.125rem;
            font-weight: 300;
        }

        .rating {
            display: block;
            position: absolute;
            font-size: 1.125rem;
            font-weight: 400;
            right: 2rem;
            bottom: 2rem;

            svg {
                display: inline-block;
                vertical-align: middle;
                margin-top: -0.375rem;
            }
        }
    }

    .image-container {
        position: relative;
        display: block;
        width: 100%;
        height: 100%;
        margin: 0;
        padding: 0;
    }
`;

const HomeSection = styled.section`
    position: relative;
    overflow: hidden;
    height: 38rem;

    .property-details {
        position: relative;
        display: inline-block;
        vertical-align: top;
        width: 50%;
        max-width: 25rem;
        height: 100%;
        background-color: #f8f8f8;

        .navigation-return,
        .lower-container,
        .book-info {
            display: block;
            position: absolute;
        }

        .navigation-return {
            padding: 3rem 2rem;

            svg,
            h3 {
                display: inline-block;
                vertical-align: middle;
            }

            svg {
                margin-top: -0.1rem;
            }

            h3 {
                font-size: 1.125rem;
                font-weight: 300;
                margin-left: 0.75rem;
            }
        }

        .property-name {
            display: block;
            position: absolute;
            top: calc(50% - 4rem);
            transform: translateY(-50%);
            padding: 4rem 3rem;

            h1 {
                max-width: 50%;
                font-size: 3rem;
                font-weight: 500;
                line-height: 1.25;
            }

            .lower-container {
                margin-top: 1rem;

                .rating {
                    font-size: 1.125rem;
                    font-weight: 400;

                    svg {
                        display: inline-block;
                        vertical-align: middle;
                        margin-top: -0.375rem;
                    }
                }

                h3 {
                    display: inline-block;
                    font-size: 1.125rem;
                    font-weight: 300;
                    margin-left: 0.75rem;
                }
            }
        }

        .book-info {
            padding: 3rem 3rem;
            bottom: 0;

            .button,
            .cost {
                display: inline-block;
                vertical-align: middle;
            }

            .button {
                font-weight: 500;
            }

            .cost {
                font-size: 1.125rem;
                font-weight: 300;
                margin-left: 2rem;

                span {
                    font-weight: 500;
                }
            }
        }

        h3 {
            font-size: 1.25rem;
            font-weight: 300;
        }
    }

    .image-container {
        position: relative;
        display: inline-block;
        vertical-align: top;
        width: calc(100% - 25rem);
        height: 40rem;
        margin: 0;
        padding: 0;
    }

    .button-arrow {
        .icon-container {
            position: absolute;
            display: block;
            right: 6rem;
            bottom: 2rem;
            transform: translateY(-50%);
            padding: 1.125rem;
            border-radius: 50%;
            border: 0.125rem solid ${color.pureWhite};

            svg {
                transform: translate(-50%, -50%);
            }
        }
    }
`;
