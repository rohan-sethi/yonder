import React from "react";
import { Property, yonderGet } from "@yonder/db";

import { color } from "../../variables";
import {
    Page,
    Section,
    ImageTileCarousel,
    GuestbookEntryCarousel,
    MapEmbed,
    LoadingSpinner,
    markdowntoJsx
} from "../../components";

import HostHero from "./HostHero";
import PropertyDetails from "./PropertyDetails";
import WhatWeLove from "./WhatWeLove";
import HostDetails from "./HostDetails";
import PhotoGallery from "./PhotoGallery";
import { getHostData } from "./_content";
import { Redirect } from "react-router";

type Props = {};

type State = {
    galleryShown: boolean;
    hasLoaded: boolean;
    loadFailed: boolean;
};

export default class HostProperty extends React.Component<Props, State> {
    listingId: string = window.location.pathname.split("/")[2] || "template";
    property: Property = new Property();

    constructor(props: Props) {
        super(props);

        this.state = {
            galleryShown: false,
            hasLoaded: false,
            loadFailed: false
        };
    }

    componentDidMount() {
        if (this.listingId !== "template") {
            yonderGet(`/properties/${this.listingId}`)
                .then((res: any) => {
                    this.property = res;
                    this.setState({
                        hasLoaded: true
                    });
                })
                .catch((err) => {
                    this.setState({
                        loadFailed: true
                    });
                    throw err;
                });
        } else {
            this.setState({
                hasLoaded: true
            });
        }
    }

    onGalleryOpen = () => {
        this.setState({
            galleryShown: true
        });
    };

    onGalleryClose = () => {
        this.setState({
            galleryShown: false
        });
    };

    render() {
        if (this.state.loadFailed) {
            return <Redirect to="/404" />;
        }
        if (!this.state.hasLoaded) {
            return (
                <Page>
                    <LoadingSpinner />
                </Page>
            );
        }

        const {
            hero,
            title,
            pricing,
            location,
            rating,
            summary,
            details,
            propertyType,
            whatWeLove,
            hostInfo,
            thingsToDo,
            nearby,
            photoGallery,
            guestbookEntries
        } = getHostData(this.property);

        const hostHeroProps = {
            ...hero,
            title,
            location,
            propertyType,
            rating,
            pricing
        };

        /*const outSummary = summary.content
            .split(title)
            .map((segment, i) => (!(i % 2) ? <span key={i}>{title}</span> : segment));*/

        return (
            <>
                <Page>
                    <HostHero {...hostHeroProps} onGalleryClick={this.onGalleryOpen} />
                    <Section backgroundColor={color.pureWhite}>{markdowntoJsx(summary.content)}</Section>
                    <PropertyDetails {...details} location={location} />
                    <WhatWeLove {...whatWeLove} />
                    <HostDetails {...hostInfo} />
                    <ImageTileCarousel tiles={thingsToDo} title="Things to Do" />
                    <ImageTileCarousel tiles={nearby} title="Nearby" />
                    <GuestbookEntryCarousel entries={guestbookEntries} />
                    <MapEmbed title={title} location={location} pricing={pricing} />
                </Page>
                {this.state.galleryShown && (
                    <PhotoGallery onClose={this.onGalleryClose} title={title} photos={photoGallery} />
                )}
            </>
        );
    }
}
