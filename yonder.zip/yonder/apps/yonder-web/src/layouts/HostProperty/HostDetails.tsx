import React from "react";
import styled from "styled-components";

import { Section, Button, RouterLink, ImageBackground, Row, Column } from "../../components";
import { IImageElement } from "../../interfaces";

type Props = {
    children?: React.ReactNode;
    image?: IImageElement;
    highlight?: string;
    content?: string;
    color?: string;
};

export default (props: Props) => {
    let content =
        props.highlight && props.content ? (
            <>
                <p>
                    <span>{props.highlight}</span>
                    {" " + props.content}
                    <RouterLink label="see more" />
                </p>
                <Button buttonStyle="outline" label="Book Now" />
            </>
        ) : (
            undefined
        );
    return (
        <Section backgroundColor={props.color}>
            <StyledRow>
                <Row>
                    <Column size="6">
                        <StyledContainer>{content || props.children}</StyledContainer>
                    </Column>
                    <Column size="6">
                        <ImageBackground {...props.image || { alt: "" }} />
                    </Column>
                </Row>
            </StyledRow>
        </Section>
    );
};

const StyledRow = styled.div`
    @media only screen and (max-width: 60rem) {
        .column {
            width: 75%;
        }
    }
`;

const StyledContainer = styled.div`
    p {
        margin-top: 1rem;
        font-size: 1rem;
        line-height: 2.25;
        margin: 0 auto;
        white-space: pre-wrap;

        span {
            font-size: 1.5rem;
            font-weight: 500;
        }

        .router-link {
            font-weight: 500;
            text-decoration: underline;
            color: #3871a3;
            margin-left: 0.5rem;
            white-space: nowrap;

            :hover {
                color: #1e4c74;
            }
        }
    }

    h3 {
        text-transform: uppercase;
        margin-bottom: 1rem;
    }

    .button {
        margin-top: 1.5rem;
        margin-bottom: 2.5rem;
    }

    @media only screen and (min-width: 40rem) {
        p {
            font-size: 1.125rem;

            span {
                font-size: 1.625rem;
            }
        }
    }

    @media only screen and (min-width: 60rem) {
        p {
            font-size: 1.25rem;

            span {
                font-size: 1.75rem;
            }
        }
    }
`;
