import React from "react";
import styled from "styled-components";

import { Row, Column, ImageBackground } from "../../components";
import { IImageElement } from "../../interfaces";
import { color } from "../../variables";

type Props = {
    children?: React.ReactNode;
    image?: IImageElement;
    content?: {
        header?: string;
        body?: string;
        list?: string[];
    }[];
    backgroundColor?: string;
};

export default (props: Props) => {
    let content = props.content
        ? props.content.map((item, i) => {
              let listItems = item.list
                  ? item.list.map((listItem, j) => {
                        return <li key={j}>{listItem}</li>;
                    })
                  : undefined;

              return (
                  <StyledWhatWeLove key={i}>
                      {item.header && <h3>{item.header}</h3>}
                      {item.body && <p>{item.body}</p>}
                      {listItems && <ul>{listItems}</ul>}
                  </StyledWhatWeLove>
              );
          })
        : undefined;

    return (
        <StyledSection style={{ backgroundColor: props.backgroundColor || color.pureWhite }}>
            <Row>
                <Column size="5">
                    {/* Slider Goes Here eventually */}
                    <ImageBackground {...props.image || { alt: "" }} />
                </Column>
                <Column size="7">
                    <StyledContainer>{content || props.children}</StyledContainer>
                </Column>
            </Row>
        </StyledSection>
    );
};

const StyledWhatWeLove = styled.div`
    display: block;
    margin-bottom: 2rem;

    &:last-child {
        margin-bottom: 0;
    }
`;

const StyledSection = styled.section`
    .image-background {
        height: 30rem;
    }

    @media only screen and (max-width: 60rem) {
        .column {
            width: 100%;
            padding: 0;
        }
    }
    @media only screen and (min-width: 60rem) {
        .image-background {
            height: 100%;
        }
    }
    @media only screen and (min-width: 80rem) {
        /**/
    }
`;

const StyledContainer = styled.div`
    padding: 3rem 2rem;

    p,
    li {
        font-size: 1rem;
    }

    p {
        margin-top: 1rem;
        line-height: 2.25;
        margin: 0 auto;
        white-space: pre-wrap;

        span {
            font-size: 1.5rem;
            font-weight: 500;
        }
    }

    h3 {
        text-transform: uppercase;
        margin-bottom: 1rem;
    }

    @media only screen and (min-width: 40rem) {
        p,
        li {
            font-size: 1.125rem;
        }
        p {
            span {
                font-size: 1.625rem;
            }
        }
    }

    @media only screen and (min-width: 60rem) {
        padding: 3rem;
        padding-left: 1rem;

        p,
        li {
            font-size: 1.25rem;
        }

        p {
            span {
                font-size: 1.75rem;
            }
        }
    }
`;
