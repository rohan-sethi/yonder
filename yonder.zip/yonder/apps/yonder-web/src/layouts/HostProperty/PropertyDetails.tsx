import React from "react";
import styled from "styled-components";
//import request from "request";
import { PropertyLocation } from "@yonder/db";

import { Container, Row, Column, Placeholder } from "../../components";
import { shortenListString } from "../../functions";

type Props = {
    location: PropertyLocation;
    sleeps: {
        total: number;
        types: string[];
    };
    amenities: {
        total: number;
        types: string[];
    };
    weather: {
        celsius: boolean;
        elevation: number;
    };
    medals: string[];
};

type State = {
    temp: string;
    desc: string;
};

export default class PropertyDetails extends React.Component<Props, State> {
    state: State = {
        temp: "...",
        desc: "..."
    };

    componentDidMount() {
        //const apiKey = "6d6c4c783fc851f16b3e027154e84296";
        const { city, country } = this.props.location;
        const units = this.props.weather.celsius ? "metric" : "imperial";
        //const url = `http://api.openweathermap.org/data/2.5/weather?q=${city},${country}&appid=${apiKey}&units=${units}`;

        /*request(url, (err, res, body) => {
            let parsed = JSON.parse(body);
            if (parsed.cod !== 200) {
                console.log(parsed);
            } else {
                let temp = parsed.main ? parsed.main.temp : 0;
                let desc = parsed.weather ? parsed.weather[0].description : "";
                this.setState({
                    temp: `${parseInt(temp, 10)}`,
                    desc
                });
            }
        });*/
    }

    render() {
        let sleeps = this.props.sleeps.types.map((sleep, i) => {
            return (
                <p className="larger" key={i}>
                    {sleep}
                </p>
            );
        });
        let amenities = shortenListString(this.props.amenities.types.join(", "), 70);
        let medals = this.props.medals.map((medal, i) => {
            return (
                <div className="medal" key={i}>
                    <Placeholder size="50" />
                    <p>{medal}</p>
                </div>
            );
        });

        return (
            <StyledPropertyDetails>
                <Container size="md">
                    <Row>
                        <Column size="3">
                            <h3>Sleeps {this.props.sleeps.total}</h3>
                            <div className="column-content">{sleeps}</div>
                        </Column>
                        <div className="vsep" />
                        <Column size="3">
                            <h3>{this.props.amenities.total} Amenities</h3>
                            <div className="column-content">
                                <p className="larger">{amenities}</p>
                            </div>
                        </Column>
                        <div className="vsep" />
                        <Column size="3">
                            <h3>Weather</h3>
                            <div className="column-content">
                                <h3>
                                    {this.state.temp}&deg;{this.props.weather.celsius ? "C" : "F"}
                                </h3>
                                <p>{this.state.desc}</p>
                            </div>
                            <div className="column-content">
                                <h3>{this.props.weather.elevation.toLocaleString()} ft</h3>
                                <p>elevation</p>
                            </div>
                        </Column>
                        <div className="vsep" />
                        <Column size="3">
                            <div className="column-content medals">{medals}</div>
                        </Column>
                    </Row>
                </Container>
            </StyledPropertyDetails>
        );
    }
}

const StyledPropertyDetails = styled.section`
    padding: 2.5rem 1rem;

    .row {
        .vsep {
            display: block;
            width: 50%;
            margin: 0 auto;
            padding: 0;
            margin-bottom: -0.065rem;
            padding-bottom: 0.065rem;
            background-color: #ebebeb;
        }
    }

    .column {
        padding: 1.5rem;
        max-width: 75%;
        margin: 0 auto;
        text-align: center;

        > h3 {
            text-transform: uppercase;
        }

        .column-content {
            padding-top: 1.25rem;

            &.medals {
                padding-top: 0;
            }

            h3,
            .larger {
                font-size: 1.125rem;
            }

            .larger {
                margin: 0 auto;
            }

            .medal {
                display: block;
                max-width: 10rem;
                margin: 0 auto;
                text-align: left;

                img,
                p {
                    display: inline-block;
                    vertical-align: middle;
                    margin: 1rem 0;
                    margin-top: 0;
                }

                img {
                    width: 2rem;
                    height: 2rem;
                }

                p {
                    font-size: 0.625rem;
                    margin-left: 0.5rem;
                    text-transform: uppercase;
                }
            }
        }
    }

    @media only screen and (min-width: 40rem) {
        .row {
            flex-direction: row;

            .column {
                padding: 0 1.5rem;

                &:first-child {
                    padding-left: 0;
                }

                &:last-child {
                    padding-right: 0;
                }
            }
            .vsep {
                display: block;
                width: auto;
                margin: 0;
                padding: 0;
                margin-left: -0.065rem;
                padding-right: 0.065rem;

                &:nth-child(4) {
                    display: none;
                }

                margin-bottom: 3rem;

                &:nth-child(6),
                &:nth-child(8) {
                    margin-bottom: 0;
                }
            }
        }
        .column {
            max-width: none;
            margin-bottom: 3rem;

            &:nth-child(5),
            &:nth-child(7) {
                margin-bottom: 0;
            }
        }
    }
    @media only screen and (min-width: 60rem) {
        .row {
            .vsep {
                &:nth-child(4) {
                    display: block;
                }

                margin-bottom: 0;
            }
        }
        .column {
            margin-bottom: 0;

            .column-content {
                .larger {
                    max-width: 14rem;
                }
            }
        }
    }
    @media only screen and (min-width: 80rem) {
        /**/
    }
`;
