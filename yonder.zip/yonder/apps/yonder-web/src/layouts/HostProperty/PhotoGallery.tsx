import React from "react";
import styled from "styled-components";

import { slideUp, slideDown } from "../../animations";
import { ImageBackground, ArrowButton } from "../../components";
import { IImageElement } from "../../interfaces";
import { color } from "../../variables";

type PhotoWidth = 12 | 8 | 6 | 4;

export interface IGalleryPhoto extends IImageElement {
    grid?: PhotoWidth;
}

type Props = {
    photos: IGalleryPhoto[];
    title?: string;
    onClose?: () => void;
};

type State = {
    isClosing: boolean;
    isOpening: boolean;
};

export default class PhotoGallery extends React.Component<Props, State> {
    state: State = {
        isClosing: false,
        isOpening: true
    };

    componentDidMount() {
        document.addEventListener("keyup", this.handleKeyPress);
    }

    componentWillUnmount() {
        document.removeEventListener("keyup", this.handleKeyPress);
    }

    handleKeyPress = (ev: KeyboardEvent) => {
        if (ev.keyCode === 27) this.startClose();
    };

    startClose = () => {
        this.setState({ isClosing: true });
    };

    close = () => {
        if (this.state.isClosing) {
            this.setState({ isClosing: false });
            this.props.onClose
                ? this.props.onClose()
                : console.log("onClose() called from PhotoGallery, but was undefined");
        } else {
            if (this.state.isOpening) {
                this.setState({ isOpening: false });
            }
        }
    };

    render() {
        let photoJsx = (id: number, className?: string) => {
            return (
                <GalleryPhoto key={id} className={className || ""}>
                    <ImageBackground {...this.props.photos[id]} />
                </GalleryPhoto>
            );
        };

        let photos: JSX.Element[] = [];
        let propPhotos = this.props.photos;
        for (let i = 0; i < propPhotos.length; i++) {
            let grid = propPhotos[i].grid;
            let gridClassName = `photo-${grid || 12}`;

            let col =
                grid === 4 &&
                propPhotos[i + 1].grid === 4 &&
                (propPhotos[i - 1].grid === 8 || propPhotos[i + 2].grid === 8);

            if (col && i + 1 < this.props.photos.length) {
                photos.push(
                    <div className={`photo-stack ${gridClassName}`} key={i}>
                        {photoJsx(i)}
                        {photoJsx(i + 1)}
                    </div>
                );
                i++;
            } else {
                photos.push(photoJsx(i, gridClassName));
            }
        }

        let isClosing = this.state.isClosing ? " is-closing" : "";
        let isOpening = this.state.isOpening ? " is-opening" : "";

        let buttonSettings = {
            color: "#333",
            hoverColor: "rgba(0, 0, 0, 0.1)"
        };

        return (
            <StyledPhotoGallery className={isClosing + isOpening} onAnimationEnd={this.close}>
                <div className="gallery">
                    <div className="gallery-header">
                        <ArrowButton type="arrow-left" {...buttonSettings} onClick={this.startClose} />
                        <h1>{this.props.title || "Gallery"}</h1>
                    </div>
                    <div className="gallery-container">{photos}</div>
                </div>
            </StyledPhotoGallery>
        );
    }
}

const photoPadding = 1;
const headerHeight = 4.875;

const GalleryPhoto = styled.div`
    display: flex;
    position: relative;
    height: 100%;
    padding: ${photoPadding / 2}rem;

    .image-background {
        /* 4:3 */
        width: 100%;
        height: 100%; /* important! */
        padding-bottom: 75%;
    }

    &:before {
        display: block;
        padding: 1rem;
    }

    &.photo-4,
    &.photo-6,
    &.photo-8,
    &.photo-12 {
        width: 100%;
    }

    @media only screen and (min-width: 40rem) and (max-width: 60rem) {
        &.photo-6 {
            width: 50%;
        }
    }

    @media only screen and (min-width: 60rem) {
        &.photo-6 {
            width: 50%;
        }
        &.photo-8 {
            width: 66.66667%;
        }
        &.photo-4 {
            width: 33.33333%;
        }
    }
`;

const StyledPhotoGallery = styled.div`
    display: block;
    position: absolute;
    background-color: ${color.pureWhite};
    width: 100%;
    min-height: 100%;
    top: 0;
    left: 0;
    z-index: 150;
    animation: ${slideUp} 0.25s forwards;

    &.is-closing,
    &.is-opening {
        .gallery {
            overflow: hidden;
        }
    }

    &.is-closing {
        animation-name: ${slideDown};

        .gallery .gallery-header {
            animation: ${slideDown} 0.25s forwards;
        }
    }

    &.is-opening {
        .gallery {
            height: 100vh;
            margin-top: 0;
            padding-top: ${headerHeight}rem;

            .gallery-header {
                position: absolute;
            }
        }
    }

    .gallery {
        position: absolute;
        width: 100%;
        height: calc(100vh - ${headerHeight}rem);
        overflow: auto;
        padding: ${photoPadding}rem;
        padding-top: 0;
        margin-top: ${headerHeight}rem;

        .gallery-header {
            position: fixed;
            padding: ${photoPadding}rem ${photoPadding * 2}rem;
            background-color: ${color.pureWhite};
            width: 100%;
            height: ${headerHeight}rem;
            top: 0;
            left: 0;
            z-index: 200;
            word-wrap: normal;

            .button-arrow,
            h1 {
                display: inline-block;
                vertical-align: middle;
            }

            h1 {
                font-size: 5vw;
                font-weight: 500;
                margin-left: 2.5vw;

                color: #333;
            }

            .button-arrow .icon-container {
                vertical-align: middle;
            }
        }

        .gallery-container {
            display: flex;
            position: relative;
            flex-direction: row;
            flex-wrap: wrap;
            align-content: flex-start;
            width: calc(100% - ${photoPadding * 2}rem);
            max-width: calc(100vw - ${photoPadding * 2}rem);
            margin: 0 auto;
            margin-top: -${photoPadding / 2}rem;

            .photo-stack {
                display: flex;
                flex-direction: column;
                align-content: flex-start;
                width: 100%;

                > ${GalleryPhoto} {
                    width: 100%;
                }
            }
        }
    }

    @media only screen and (min-width: 40rem) {
        .gallery .gallery-header {
            h1 {
                font-size: 2rem;
                margin-left: 1rem;
            }
        }
    }

    @media only screen and (min-width: 60rem) {
        .gallery .gallery-container .photo-stack {
            &.photo-6 {
                width: 50%;
            }
            &.photo-4 {
                width: 33.33333%;
            }

            > ${GalleryPhoto} {
                .image-background {
                    padding-bottom: 74%;
                }
            }
        }
    }
`;
