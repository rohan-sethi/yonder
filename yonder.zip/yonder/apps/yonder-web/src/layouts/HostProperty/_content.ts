import { Property, PropertyLocation, PropertyTypes, getPropertyTypeLabel, PricingRates } from "@yonder/db";

import { Props as IImageBackground } from "../../components/ImageBackground";
import { IGalleryPhoto } from "./PhotoGallery";
import { Props as IImageTile } from "../../components/ImageTile";
import { Props as IGuestbookEntry } from "../../components/GuestbookEntry";
import { randomImage } from "../../functions";

import hostImage from "./img/hero3.jpg";

export const getHostData = (property: Property) => {
    return {
        title: property.name || "The Bluebonnet Bungalow",
        location: {
            address1: property.location.address1 || "13597 Frantz Rd",
            address2: property.location.address2 || "",
            city: property.location.city || "Cat Spring",
            state: property.location.state || "TX",
            zipCode: property.location.zipCode || "00000",
            country: property.location.country || "USA",
            lat: property.location.lat || "29.8361856",
            long: property.location.long || "-96.364005",
            description:
                property.location.description ||
                "Cat Spring is about an hour and a half east of Austin and about an hour west of Houstin. It's a one stop light town. You know, the kind if you blink... you miss. Serene, hospitable, relaxing and amazing."
        } as PropertyLocation,
        rating: 4.8,
        pricing: {
            defaultWeekday: property.pricing.defaultWeekday || 149,
            defaultWeekend: property.pricing.defaultWeekend || 189,
            cleaningFee: property.pricing.cleaningFee || 10,
            rate: PricingRates.Night
        },
        propertyType: getPropertyTypeLabel(property.propertyType || PropertyTypes.Ranch),
        hero: {
            image: {
                src: hostImage,
                alt: "",
                position: "50% 0%"
            } as IImageBackground
        },
        summary: {
            content:
                property.summary ||
                "The Bluebonnet Bungalow is an authentic Texas experience like no other. Unwind in the peaceful country setting amidst majestic live oaks, open ranch land, and our fully stocked fishing pond. Enjoy simple life in the calming surroundings of our working Texas Hill Country guest ranch."
        },
        details: {
            sleeps: {
                total: 5,
                types: ["2 queen", "1 sleeper sofa"]
            },
            amenities: {
                total: 38,
                types: [
                    "bathtub",
                    "full kitchen",
                    "air conditioning",
                    "front porch rocking chair",
                    "other 1",
                    "other 2"
                ]
            },
            weather: {
                celsius: false,
                elevation: 3570
            },
            medals: ["natural environment", "built environment", "social wellbeing"]
        },
        whatWeLove: {
            color: "#f8f8f8",
            image: {
                src: randomImage(),
                alt: "test"
            } as IImageBackground,
            content: [
                {
                    header: "What We Love",
                    body:
                        "Enjoy the simple life in the calming surroundings of this magnificent Cat Springs, Texas ranch, where animals abound, including horses, cattle, miniature donkeys and even American Bison. Relax with catch & release bass fishing in our stocked lakes. Watch swans, ducks and geese glide by on the pond. Rekindle a romance with romantic getaways in Texas, or having a picnic at the gazebo overlooking the Enchanted Lake. Take a midnight stroll through the meadows and moonbeams, gaze at the stars, do nothing or do it all!"
                },
                {
                    header: "Things to Know",
                    list: [
                        "A 500-acre working ranch an hour west of Houston",
                        "Award-winning Carol's at Cat Spring Restaurant, just minutes from BlissWood",
                        "Plenty of places for a leisurely hike",
                        "Huff Brewing Company is a 20 minute scenic drive away",
                        "Bikes for rent"
                    ]
                }
            ]
        },
        hostInfo: {
            image: {
                src: randomImage(800)
            } as IImageBackground,
            contactUrl: "contact@bluebonnet.biz",
            highlight: "Your Host Carol Davis",
            content:
                "is a Native of Texas. Carol Davis was born and reared on a Warda farm and ranch owned by her family since 1875. Warda is one of the state's many German-American communities, and Carol spoke only German before she started school in a one-room parochial school..."
        },
        thingsToDo: [
            {
                image: {
                    src: randomImage()
                } as IImageBackground,
                label: "Fishing Excursion",
                activityCost: 60
            } as IImageTile,
            {
                image: {
                    src: randomImage()
                } as IImageBackground,
                label: "Livestock Feeding",
                activityCost: 5
            } as IImageTile,
            {
                image: {
                    src: randomImage()
                } as IImageBackground,
                label: "Hot Air Balloon Ride",
                activityCost: 199
            } as IImageTile
        ],
        nearby: [
            {
                image: {
                    src: randomImage()
                } as IImageBackground,
                label: "Horseback Rides",
                activityCost: 75
            } as IImageTile,
            {
                image: {
                    src: randomImage()
                } as IImageBackground,
                label: "Day on the Ranch",
                activityCost: 45
            } as IImageTile,
            {
                image: {
                    src: randomImage()
                } as IImageBackground,
                label: "Outdoor Spa",
                activityCost: 130
            } as IImageTile,
            {
                image: {
                    src: randomImage()
                } as IImageBackground,
                label: "Pinot Wine Tasting",
                activityCost: 23
            } as IImageTile,
            {
                image: {
                    src: randomImage()
                } as IImageBackground,
                label: "Livestock Duties",
                activityCost: 12
            } as IImageTile,
            {
                image: {
                    src: randomImage()
                } as IImageBackground,
                label: "Other",
                activityCost: 10
            } as IImageTile
        ],
        guestbookEntries: [
            {
                name: "Cheryl B.",
                rating: 5,
                added: "3 days ago",
                comment:
                    "What a wonderful experience! We eloped at the ranch and every detail was handled perfectly for us. Big shout out to Carol for making our day extra special."
            } as IGuestbookEntry,
            {
                name: "Lisett M.",
                rating: 5,
                added: "1 week ago",
                comment:
                    "Blisswood Bed and Breakfast Ranch is such an amazing place, so peaceful. Carol was so helpful, even when I had multiple questions. As soon as you arrive, Blisswood welcomes you with a serene and magical view. I've fallen in love with this place. We had a wonderful stay, this place is overall breath taking-beautiful. I will definitely be back! Thank you so much for having us!"
            } as IGuestbookEntry,
            {
                name: "David H.",
                rating: 4,
                added: "1 week ago",
                comment:
                    "Very nice venue. We were there for a friend's wedding and were very impressed with the ambiance, accomodations, and night skies."
            } as IGuestbookEntry,
            {
                name: "Paul B.",
                rating: 4,
                added: "2 weeks ago",
                comment: "Wonderful."
            } as IGuestbookEntry,
            {
                name: "Will F.",
                rating: 4,
                added: "2 weeks ago",
                comment: "Great."
            } as IGuestbookEntry
        ],
        photoGallery: [
            {
                src: randomImage(1600, 1200),
                grid: 12
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 6
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 6
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 8
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 4
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 4
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 4
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 4
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 4
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 4
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 4
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 8
            } as IGalleryPhoto,
            //
            {
                src: randomImage(1600, 1200),
                grid: 12
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 6
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 6
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 8
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 4
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 4
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 4
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 4
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 4
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 4
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 4
            } as IGalleryPhoto,
            {
                src: randomImage(1600, 1200),
                grid: 8
            } as IGalleryPhoto
        ]
    };
};
