import React from "react";

import { Page, Section, withAuthorization } from "../components";
import { inject, observer } from "mobx-react";
import { IFirebaseStore } from "../store";
import { ID } from "@yonder/db";

// Use for testing layouts &  such

type Props = IFirebaseStore;

@inject("firebaseState")
@observer
class LayoutTestComponent extends React.Component<Props> {
    id: ID = "";

    render() {
        return (
            <Page>
                <Section></Section>
            </Page>
        );
    }
}

export const LayoutTest = withAuthorization(LayoutTestComponent);
