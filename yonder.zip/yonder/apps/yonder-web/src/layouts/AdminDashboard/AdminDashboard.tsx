import React from "react";
import { inject, observer } from "mobx-react";
import styled from "styled-components";

import { IFirebaseStore, IAdminStore } from "../../store";
import { Page, withAdminAuthorization, Section } from "../../components";
import { history } from "../../history";

import Users from "./components/Users";
import Orgs from "./components/Orgs";
//import Subs from "./components/Subs";
import Listings from "./components/Listings";
import { LayoutPageNotFound } from "../PageNotFound";
import { AddOrganization } from "./components/AddOrganization";
import { ID } from "@yonder/db";
import { EditOrganization } from "./components/EditOrganization";
import { EditUser } from "./components/EditUser";

enum AdminSection {
    None = "none",
    Users = "users",
    EditUser = "edit-user",
    Organizations = "organizations",
    AddOrganization = "add-organization",
    EditOrganization = "edit-organization",
    Submissions = "submissions",
    Listings = "listings"
}

type Props = IFirebaseStore & IAdminStore;

type State = {
    section: AdminSection | null;
    id: ID | null;
};

@inject("firebaseState", "adminState")
@observer
export class AdminDashboardComponent extends React.Component<Props> {
    state: State = {
        section: AdminSection.None,
        id: null
    };
    sections = Object.values(AdminSection) as string[];

    initialize = async () => {
        const { getOverviewStats } = this.props.adminState!;
        try {
            await getOverviewStats();
        } catch (err) {
            console.log(err);
        }
    };

    setSection = () => {
        // Assumes /admin/:section/:id
        let pathname = window.location.pathname.split("/");
        const section = pathname[2];
        const id = pathname[3];

        if (section !== undefined && section !== this.state.section) {
            if (this.sections.includes(section)) {
                this.setState({ section });
                return;
            }
            if (this.state.section !== null) {
                this.setState({ section: null });
            }
        }
        if (id !== undefined && id !== this.state.id) {
            this.setState({ id });
        }
    };

    componentDidMount() {
        this.initialize();
        this.setSection();
    }

    componentDidUpdate() {
        this.setSection();
    }

    onUsersClick = () => {
        history.push("/admin/users");
    };

    onOrganizationsClick = () => {
        history.push("/admin/organizations");
    };

    onAllListingsClick = () => {
        history.push("/admin/listings");
    };

    renderPage = () => {
        switch (this.state.section) {
            case AdminSection.Users:
                return <Users />;
            case AdminSection.EditUser:
                return <EditUser id={this.state.id} />;
            case AdminSection.AddOrganization:
                return <AddOrganization />;
            case AdminSection.EditOrganization:
                return <EditOrganization id={this.state.id} />;
            case AdminSection.Organizations:
                return <Orgs />;
            case AdminSection.Listings:
                return <Listings />;
            default:
                return "";
        }
    };

    render() {
        const { stats } = this.props.adminState!;

        if (this.state.section === null) {
            return <LayoutPageNotFound />;
        }

        return (
            <Page>
                <Section>
                    <OverviewStatsWrapper>
                        <div>
                            <OverviewStatsItemLabel onClick={this.onUsersClick}>Users</OverviewStatsItemLabel>:{" "}
                            {stats.usersCount}
                        </div>
                        <div>
                            <OverviewStatsItemLabel onClick={this.onOrganizationsClick}>
                                Organizations
                            </OverviewStatsItemLabel>
                            : {stats.orgsCount}
                        </div>
                        <div>
                            <OverviewStatsItemLabel onClick={this.onAllListingsClick}>
                                All Listings
                            </OverviewStatsItemLabel>
                        </div>
                    </OverviewStatsWrapper>

                    <ContentWrapper>{this.renderPage()}</ContentWrapper>
                </Section>
            </Page>
        );
    }
}

export const AdminDashboard = withAdminAuthorization(AdminDashboardComponent);

const OverviewStatsWrapper = styled.div``;

const ContentWrapper = styled.div`
    margin-top: 30px;
`;

const OverviewStatsItemLabel = styled.span`
    font-weight: bold;
    cursor: pointer;
`;
