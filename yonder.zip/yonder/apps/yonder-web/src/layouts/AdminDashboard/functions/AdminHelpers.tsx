import { ListingProgress, ID } from "@yonder/db";

export const listingProgressCounter = (fetchById: any, listingIds?: string[]) => {
    let listingProgressCounts: number[] = [...Array(4)].fill(0);

    if (listingIds) {
        listingIds.map((id: ID) => {
            let listing = fetchById[id];

            if (listing) {
                if (listing.listingProgress === ListingProgress.Ready) {
                    listingProgressCounts[3]++;
                } else if (listing.listingProgress === ListingProgress.InReviewByHost) {
                    listingProgressCounts[2]++;
                } else if (listing.listingProgress === ListingProgress.InReview) {
                    listingProgressCounts[1]++;
                } else {
                    listingProgressCounts[0]++;
                }
            }
            return null;
        });
    }

    return listingProgressCounts;
};
