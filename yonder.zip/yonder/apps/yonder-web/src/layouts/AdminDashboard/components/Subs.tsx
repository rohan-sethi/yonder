import React from "react";
import { inject, observer } from "mobx-react";
import styled from "styled-components";

import { IFirebaseStore, IAdminStore } from "../../../store";
import { withAdminAuthorization } from "../../../components";
import { HostApprovalSubmissionProgress } from "@yonder/db";
import { toJS } from "mobx";

type Props = IFirebaseStore & IAdminStore;

type State = {
    showApprovalStatus: HostApprovalSubmissionProgress | "all";
};

@inject("firebaseState", "adminState")
@observer
class Orgs extends React.Component<Props, State> {
    state: State = {
        showApprovalStatus: "all"
    };

    initialize = async () => {
        const { getSubmissions } = this.props.adminState!;
        try {
            await getSubmissions();
        } catch (err) {
            console.log(err);
        }
    };

    componentDidMount() {
        this.initialize();
    }

    onUserClick = () => {};

    render() {
        const { submissions } = this.props.adminState!;

        const renderTableRows = () => {
            let rows: any = [];

            toJS(submissions).forEach((sub) => {
                //if (org.approvalSubmissionProgress !== HostApprovalSubmissionProgress.Certificate) return;
                let location = sub.location || {};

                let activitiesArray: any[] = sub.activities || [];
                let certificatesArray: any[] = sub.certificates || [];

                let activities = activitiesArray.join(", ");
                let certificates = certificatesArray.join(", ");

                rows.push(
                    <TableRow key={sub.id}>
                        <TableCell>{sub.experienceCategory}</TableCell>
                        <TableCell>{sub.overnightStaysCount}</TableCell>
                        <TableCell>{sub.activityCountRange}</TableCell>
                        <TableCell>{activities}</TableCell>
                        <TableCell>{certificates}</TableCell>
                        <TableCell>{sub.description}</TableCell>
                        <TableCell>
                            {location.city}, {location.state}, {location.countryName}
                        </TableCell>
                    </TableRow>
                );
            });

            return rows;
        };

        return (
            <Wrapper>
                <Table>
                    <thead>
                        <tr>
                            <TableHeader>category</TableHeader>
                            <TableHeader>stay count</TableHeader>
                            <TableHeader>activity range</TableHeader>
                            <TableHeader>activities</TableHeader>
                            <TableHeader>certificates</TableHeader>
                            <TableHeader>description</TableHeader>
                            <TableHeader>location</TableHeader>
                        </tr>
                    </thead>
                    <tbody>{renderTableRows()}</tbody>
                </Table>
            </Wrapper>
        );
    }
}

export default withAdminAuthorization(Orgs);

const Table = styled.table`
    width: 100%;
    border-collapse: collapse;
    border-spacing: 0;
`;

const TableHeader = styled.td`
    font-weight: bold;
    background: #002000;
    color: #ffffff;
    padding: 6px 0;
`;

const TableRow = styled.tr`
    :hover {
        background: #f3f3f3;
    }
`;

const TableCell = styled.td`
    min-width: 100px;
    padding: 10px 20px;
    border-bottom: 1px solid #f1f1f1;
`;

const Wrapper = styled.div``;
