import React from "react";
import { observer, inject } from "mobx-react";
import styled from "styled-components";
//import { Redirect } from "react-router";
import { User, yonderPatch, ID } from "@yonder/db";

import {
    StyledForm,
    SubmitButton,
    FormSubmitEvent,
    FormChangeEvent,
    TextInput,
    FormGroup,
    LoadingSpinner,
    reSpecialChars,
    reNumbers
} from "../../../components";
import { IAdminStore } from "../../../store";
//import { isStringInvalid } from "../../../functions";

type ValidationErrors = {
    businessPhone?: string;
    name?: string;
    email?: string;
};

type Props = IAdminStore & {
    id: ID | null;
};
type State = {
    validationErrors: ValidationErrors;
    user?: User;
    isUpdating?: boolean;
    invalidId?: boolean;
    success?: { message?: string } | null;
    error?: { message?: string } | null;
};

const INITIAL_STATE: State = {
    validationErrors: {},
    isUpdating: true,
    invalidId: false,
    success: null,
    error: null
};

@inject("adminState")
@observer
class EditUser extends React.Component<Props, State> {
    state: State = INITIAL_STATE;

    initialize = async () => {
        try {
            this.setState({ isUpdating: true });
            const { getUsers, usersLoaded } = this.props.adminState!;
            if (!usersLoaded) {
                await getUsers();
            }
            const { userById } = this.props.adminState!;
            if (this.props.id !== null && userById[this.props.id]) {
                const user: User = userById[this.props.id];
                this.setState({ user, isUpdating: false });
            } else {
                this.setState({ invalidId: true });
            }
        } catch (err) {
            console.log(err);
        }
    };

    componentDidMount() {
        this.initialize();
    }

    componentDidUpdate(prevProps: Props) {
        if (this.props.id !== prevProps.id) {
            this.initialize();
        }
    }

    onSubmit = async (ev: FormSubmitEvent) => {
        ev.preventDefault();
        const { user } = this.state;

        if (user) {
            try {
                this.setState({ isUpdating: true });
                await yonderPatch(`/users/${user.id}`, { ...user, email: undefined });
                this.setState({
                    isUpdating: false,
                    success: {
                        message: "User changes saved sucessfully."
                    }
                });
            } catch (err) {
                console.log(err);
                this.setState({
                    isUpdating: false,
                    error: {
                        message: "There was an error updating this user."
                    }
                });
            }
        }
    };

    onChange = async (ev: FormChangeEvent) => {
        const { name, value } = ev.target;
        let validationErrors: ValidationErrors = this.state.validationErrors;

        if (this.state.user) {
            switch (name) {
                // eslint-disable-next-line
                case "firstName":
                case "lastName":
                    if (!reSpecialChars.test(value) && !reNumbers.test(value) && value !== "") {
                        validationErrors.name = undefined;
                    } else {
                        validationErrors.name = "First or last name must not contain special characters or numbers";
                    }
                    break;
            }
            this.setState({
                validationErrors,
                user: {
                    ...this.state.user,
                    [name]: value
                }
            });
        }
    };

    getFormattedDate = (date?: string): string | void => {
        if (!date) return;

        let dob: Date = new Date(date);
        return `${dob.getMonth() + 1}/${dob.getDate()}/${dob.getFullYear()}`;
    };

    render() {
        const { success, error, isUpdating, user, invalidId } = this.state;

        /*if (invalidId) {
            return <Redirect to="/admin/users" />;
        }*/

        if (invalidId || isUpdating || !user) {
            return <LoadingSpinner />;
        }

        /*
        const invalidEmail = isStringInvalid(email);
        const invalidName = isStringInvalid(businessName);
        const invalidWebsite = isStringInvalid(businessWebsite);
        const invalidPhone = !!validationErrors.businessPhone || isStringInvalid(businessPhone);

        const isInvalid = invalidName || invalidWebsite || invalidPhone || (showUser && invalidEmail);
        */

        const isInvalid = false;

        if (window.scrollTo) {
            window.scrollTo(0, 0);
        }

        return (
            <StyledEditUser>
                <StyledForm>
                    <h2>Edit User</h2>
                    <form onSubmit={this.onSubmit}>
                        <FormGroup>
                            {success && <p className="success-message">{success.message}</p>}
                            {error && <p className="error-message">{error.message}</p>}

                            <TextInput
                                name="firstName"
                                value={user.firstName}
                                label="First Name"
                                onChange={this.onChange}
                                required
                            />
                            <TextInput
                                name="lastName"
                                value={user.lastName}
                                label="Last Name"
                                onChange={this.onChange}
                                required
                            />

                            <h4>View Only</h4>
                            <p>Type of user: {user.hostType}</p>
                            <p>Phone number: {user.phoneNumber}</p>
                            <p>Email: {user.email}</p>
                            <p>Date of Birth: {this.getFormattedDate(user.dateOfBirth)}</p>
                            <p>Gender: {user.gender}</p>
                            <p>Location: {user.userLocation}</p>
                            <p>About: {user.about}</p>
                        </FormGroup>

                        <SubmitButton label="Save Changes" disabled={isInvalid} />
                    </form>
                </StyledForm>
            </StyledEditUser>
        );
    }
}

export { EditUser };

const StyledEditUser = styled.div`
    margin: 0 auto;
    max-width: 30rem;
`;
