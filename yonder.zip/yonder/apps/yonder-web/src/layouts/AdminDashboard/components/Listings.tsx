import React from "react";
import { inject, observer } from "mobx-react";
import styled from "styled-components";
import { ListingProgress, getListingProgressLabel } from "@yonder/db";

import { IAdminStore, IContentModalStore } from "../../../store";
import {
    withAdminAuthorization,
    FormChangeEvent,
    SelectInput,
    SelectOption,
    LoadingSpinner
} from "../../../components";
import { HostApprovalSubmissionProgress, Organization, Property, Activity, ID } from "@yonder/db";
import { enumToSelectOptions } from "../../../functions";
import { listingProgressCounter } from "../functions";
import { color } from "../../../variables";

type Props = IAdminStore & IContentModalStore;

type State = {
    showApprovalStatus: HostApprovalSubmissionProgress | "all" | "unfinished";
    showListingStatus: ListingProgress | "all" | "unfinished";
    hasLoaded: boolean;
    cloningListing: boolean;
};

@inject("adminState", "contentModalState")
@observer
class Orgs extends React.Component<Props, State> {
    state: State = {
        showApprovalStatus: HostApprovalSubmissionProgress.Completed,
        showListingStatus: "all",
        hasLoaded: false,
        cloningListing: false
    };
    listingProgressOptions: SelectOption[] = enumToSelectOptions(ListingProgress, getListingProgressLabel);

    componentDidMount() {
        this.loadAll();
    }

    loadAll = async () => {
        const { getUsers, getOrganizations, getListings, getSubmissions } = this.props.adminState!;
        try {
            await getUsers();
            await getOrganizations();
            await getListings();
            await getSubmissions();
            this.setState({
                hasLoaded: true
            });
        } catch (err) {
            console.log(err);
        }
    };

    onUserClick = () => {};

    onFilterClick = (filter: HostApprovalSubmissionProgress | "all" | "unfinished") => {
        return () => {
            this.setState({ showApprovalStatus: filter });
        };
    };

    onListingProgressFilterClick = (filter: ListingProgress | "all" | "unfinished") => {
        return () => {
            this.setState({ showListingStatus: filter });
        };
    };

    onChange = (ev: FormChangeEvent, org: Organization) => {
        const { updateOrganizationStatus } = this.props.adminState!;
        const { name, value } = ev.target;

        ev.preventDefault();

        if (value === "") {
            window.alert('Sorry, just selecting "--" doesn\'t do anything.');
            return;
        }

        if (name === "progress") {
            org.approvalSubmissionProgress = value;

            if (window.confirm("Are you sure you want to change this organization's progress?")) {
                updateOrganizationStatus(org.id!, org.approvalSubmissionProgress!);
            }
        }
    };

    onAddPropertyClick = async (org: Organization) => {
        const { addProperty } = this.props.adminState!;
        if (window.confirm(`Are you sure you want to add a new stay to: ${org.name}?`)) {
            try {
                await addProperty(org);
            } catch (err) {
                console.log(err);
            }
        }
    };

    onAddActivityClick = async (org: Organization) => {
        const { addActivity } = this.props.adminState!;
        if (window.confirm(`Are you sure you want to add a new activity to: ${org.name}?`)) {
            try {
                await addActivity(org);
            } catch (err) {
                console.log(err);
            }
        }
    };

    onDeleteProperty = async (stay: Property) => {
        const { deleteProperty } = this.props.adminState!;
        if (window.confirm(`Are you sure you want to delete the stay: ${stay.name || "New Stay"}?`)) {
            try {
                await deleteProperty(stay.id!);
                return true;
            } catch (err) {
                console.log(err);
            }
        }
        return false;
    };

    onDuplicateProperty = async (org: Organization, stay: Property) => {
        const { duplicateProperty } = this.props.adminState!;
        if (window.confirm(`Are you sure you want to duplicate the stay: ${stay.name || "New Stay"}?`)) {
            try {
                this.setState({
                    cloningListing: true
                });
                await duplicateProperty(org.id!, stay.id!);
                this.setState({
                    cloningListing: false
                });
                return true;
            } catch (err) {
                this.setState({
                    cloningListing: false
                });
                console.log(err);
            }
        }
        return false;
    };

    onDeleteActivity = async (activity: Activity) => {
        const { deleteActivity } = this.props.adminState!;
        if (window.confirm(`Are you sure you want to delete the activity: ${activity.name || "New Activity"}?`)) {
            try {
                await deleteActivity(activity.id!);
                return true;
            } catch (err) {
                console.log(err);
            }
        }
        return false;
    };

    onDuplicateActivity = async (org: Organization, activity: Activity) => {
        const { duplicateActivity } = this.props.adminState!;
        if (window.confirm(`Are you sure you want to duplicate the activity: ${activity.name || "New Activity"}?`)) {
            try {
                this.setState({
                    cloningListing: true
                });
                await duplicateActivity(org.id!, activity.id!);
                this.setState({ cloningListing: false });
                return true;
            } catch (err) {
                this.setState({ cloningListing: false });
                console.log(err);
            }
        }
        return false;
    };
    renderListingsCount = () => {
        const { organizations, staysById, activitiesById } = this.props.adminState!;
        let staysCount = 0;
        let activitiesCount = 0;
        let stayProgressCounts: number[] = [...Array(4)].fill(0);
        let activityProgressCounts: number[] = [...Array(4)].fill(0);

        organizations
            .filter(
                (org) =>
                    org.approvalSubmissionProgress === HostApprovalSubmissionProgress.Approved ||
                    org.approvalSubmissionProgress === HostApprovalSubmissionProgress.ApprovedAndWaiting
            )
            .forEach((org) => {
                let stayCountTemp = (org.propertyIds || []).length;
                let activityCountTemp = (org.activityIds || []).length;

                staysCount += stayCountTemp;
                activitiesCount += activityCountTemp;

                let stayProgressCountTemp = listingProgressCounter(staysById, org.propertyIds);
                stayProgressCounts = stayProgressCounts.map((count, i) => {
                    return (count += stayProgressCountTemp[i]);
                });

                let activityProgressCountTemp = listingProgressCounter(activitiesById, org.activityIds);
                activityProgressCounts = activityProgressCounts.map((count, i) => {
                    return (count += activityProgressCountTemp[i]);
                });
            });

        let estimatedTestStaysCount = 0;
        let estimatedTestActivitiesCount = 0;

        return (
            <div className="total-counts">
                <h2>Total Stays Count: {staysCount - estimatedTestStaysCount}</h2>
                <h3>Unfinished: {stayProgressCounts[0]}</h3>
                <h3>Yonder Review: {stayProgressCounts[1]}</h3>
                <h3>Host Review: {stayProgressCounts[2]}</h3>
                <h3>Ready: {stayProgressCounts[3]}</h3>
                <h2>Total Activities Count: {activitiesCount - estimatedTestActivitiesCount}</h2>
                <h3>Unfinished: {activityProgressCounts[0]}</h3>
                <h3>Yonder Review: {activityProgressCounts[1]}</h3>
                <h3>Host Review: {activityProgressCounts[2]}</h3>
                <h3>Ready: {activityProgressCounts[3]}</h3>
            </div>
        );
    };

    renderListings = (org: Organization) => {
        const { staysById, activitiesById, getListings } = this.props.adminState!;
        const { showListingStatus, cloningListing } = this.state;

        const stays = (org.propertyIds || []).map((id: ID) => {
            if (this.props.adminState!.stays.length === 0) return null;

            let stay: Property | undefined = staysById[id];
            if (stay) {
                if (showListingStatus === "unfinished") {
                    if (
                        stay.listingProgress === ListingProgress.Ready ||
                        stay.listingProgress === ListingProgress.InReview ||
                        stay.listingProgress === ListingProgress.InReviewByHost
                    ) {
                        return null;
                    }
                } else if (showListingStatus !== "all") {
                    if (stay.listingProgress !== showListingStatus) {
                        return null;
                    }
                }

                const { updateSaveProperty } = this.props.adminState!;
                return (
                    <div key={stay.id}>
                        (stay) {stay.name || "New Stay"} {}
                        {"   "}
                        <SelectInput
                            name="progress"
                            label="Status:"
                            value={stay.listingProgress!}
                            //options={this.progressOptions}
                            options={this.listingProgressOptions}
                            onChange={(ev) => {
                                ev.preventDefault();

                                if (stay) {
                                    const { value } = ev.target;
                                    stay.listingProgress = value;
                                    updateSaveProperty(stay.id!, {
                                        listingProgress: value
                                    });
                                }
                            }}
                        />
                        {"   "}
                        <a href={`/dash/listings/stays/${stay.id}`} target="_blank" rel="noopener noreferrer">
                            edit
                        </a>
                        <button
                            style={{ color: "#2394b7", paddingLeft: "0.5rem", paddingRight: "0.5rem" }}
                            onClick={(ev) => this.onDeleteProperty(stay!)}
                        >
                            delete
                        </button>
                        <button
                            style={{ color: "#2394b7", paddingLeft: "0", paddingRight: "0.5rem" }}
                            onClick={(ev) => this.onDuplicateProperty(org, stay!)}
                        >
                            duplicate
                        </button>
                    </div>
                );
            }

            if (cloningListing) {
                return (
                    <div key={id} style={{ color: "#aaaaaa" }}>
                        (stay) Loading clone...
                    </div>
                );
            }

            return (
                <div key={id} style={{ color: color.wintersGray }}>
                    (stay) Not found in DB ({id})
                    <button
                        style={{ color: "#2394b7", paddingLeft: "0.5rem", paddingRight: "0.5rem" }}
                        onClick={async (ev) => {
                            try {
                                let deleted = await this.onDeleteProperty({
                                    ...new Property(),
                                    id
                                });
                                if (deleted) {
                                    await getListings();
                                }
                            } catch (err) {
                                console.log(err);
                            }
                        }}
                    >
                        delete
                    </button>
                </div>
            );
        });

        const activities = (org.activityIds || []).map((id: ID) => {
            if (this.props.adminState!.activities.length === 0) return null;

            let activity: Activity | undefined = activitiesById[id];

            if (activity) {
                if (showListingStatus === "unfinished") {
                    if (
                        activity.listingProgress === ListingProgress.Ready ||
                        activity.listingProgress === ListingProgress.InReview ||
                        activity.listingProgress === ListingProgress.InReviewByHost
                    ) {
                        return null;
                    }
                } else if (showListingStatus !== "all") {
                    if (activity.listingProgress !== showListingStatus) {
                        return null;
                    }
                }

                const { updateSaveActivity } = this.props.adminState!;
                return (
                    <div key={activity.id}>
                        (acti) {activity.name || "New Activity"}
                        {"   "}
                        <SelectInput
                            name="progress"
                            label="Status:"
                            value={activity.listingProgress!}
                            options={this.listingProgressOptions}
                            onChange={(ev) => {
                                ev.preventDefault();

                                if (activity) {
                                    const { value } = ev.target;
                                    activity.listingProgress = value;
                                    updateSaveActivity(activity.id!, {
                                        listingProgress: value
                                    });
                                }
                            }}
                        />
                        {"   "}
                        <a href={`/dash/listings/activities/${activity.id}`} target="_blank" rel="noopener noreferrer">
                            edit
                        </a>
                        <button
                            style={{ color: "#2394b7", paddingLeft: "0.5rem", paddingRight: "0.5rem" }}
                            onClick={(ev) => this.onDeleteActivity(activity!)}
                        >
                            delete
                        </button>
                        <button
                            style={{ color: "#2394b7", paddingLeft: "0", paddingRight: "0.5rem" }}
                            onClick={(ev) => this.onDuplicateActivity(org, activity!)}
                        >
                            duplicate
                        </button>
                    </div>
                );
            }

            if (cloningListing) {
                return (
                    <div key={id} style={{ color: "#aaaaaa" }}>
                        (activity) Loading clone...
                    </div>
                );
            }

            return (
                <div key={id} style={{ color: color.wintersGray }}>
                    (stay) Not found in DB ({id})
                    <button
                        style={{ color: "#2394b7", paddingLeft: "0.5rem", paddingRight: "0.5rem" }}
                        onClick={async (ev) => {
                            let deleted = await this.onDeleteActivity({
                                ...new Activity(),
                                id
                            });
                            if (deleted) {
                                await getListings();
                            }
                        }}
                    >
                        delete
                    </button>
                </div>
            );
        });

        const filteredStays = stays.filter((el) => el !== null);
        const filteredActivities = activities.filter((el) => el !== null);

        return (
            <div>
                <span>{`Filtered Result Totals - stays: ${filteredStays.length}, activities: ${filteredActivities.length}`}</span>
                <hr />
                {stays}
                {activities}
            </div>
        );
    };

    renderOrgs = () => {
        const { organizations, submissionById } = this.props.adminState!;
        return organizations
            .filter(
                (org: Organization) =>
                    org.approvalSubmissionProgress === HostApprovalSubmissionProgress.Approved ||
                    org.approvalSubmissionProgress === HostApprovalSubmissionProgress.ApprovedAndWaiting
            )
            .map((org: Organization) => {
                let stayCount = (org.propertyIds || []).length;
                let activityCount = (org.activityIds || []).length;

                let tags = "";
                let submission = submissionById[org.approvalSubmissionId!];

                if (submission !== undefined && submission.scoutSetupPermission) {
                    tags += "(M) ";
                }

                return (
                    <div key={org.id} style={{ marginBottom: "50px" }}>
                        <span style={{ borderBottom: "2px solid #333", minWidth: "300px" }}>
                            {`${tags}${org.name} - total stays: ${stayCount}, total activities: ${activityCount}`} (
                            <button
                                style={{ color: "#2394b7", padding: 0 }}
                                onClick={(ev) => this.onAddPropertyClick(org)}
                            >
                                add new stay
                            </button>
                            )(
                            <button
                                style={{ color: "#2394b7", padding: 0 }}
                                onClick={(ev) => this.onAddActivityClick(org)}
                            >
                                add new activity
                            </button>
                            )
                        </span>
                        {this.renderListings(org)}
                    </div>
                );
            });
    };

    render() {
        if (!this.state.hasLoaded) {
            return <LoadingSpinner size={2} />;
        }
        return (
            <Wrapper>
                {this.renderListingsCount()}

                <div style={{ marginBottom: 25 }}>
                    <b>Filter By:</b>
                    <TableFilter
                        onClick={this.onListingProgressFilterClick("all")}
                        style={{ fontWeight: this.state.showListingStatus === "all" ? "bold" : "inherit" }}
                    >
                        All
                    </TableFilter>
                    <TableFilter
                        onClick={this.onListingProgressFilterClick("unfinished")}
                        style={{ fontWeight: this.state.showListingStatus === "unfinished" ? "bold" : "inherit" }}
                    >
                        In Draft
                    </TableFilter>
                    <TableFilter
                        onClick={this.onListingProgressFilterClick(ListingProgress.InReview)}
                        style={{
                            fontWeight: this.state.showListingStatus === ListingProgress.InReview ? "bold" : "inherit"
                        }}
                    >
                        Yonder Review
                    </TableFilter>
                    <TableFilter
                        onClick={this.onListingProgressFilterClick(ListingProgress.InReviewByHost)}
                        style={{
                            fontWeight:
                                this.state.showListingStatus === ListingProgress.InReviewByHost ? "bold" : "inherit"
                        }}
                    >
                        Host Review
                    </TableFilter>
                    <TableFilter
                        onClick={this.onListingProgressFilterClick(ListingProgress.Ready)}
                        style={{
                            fontWeight: this.state.showListingStatus === ListingProgress.Ready ? "bold" : "inherit"
                        }}
                    >
                        Ready
                    </TableFilter>
                </div>

                {this.renderOrgs()}
            </Wrapper>
        );
    }
}

export default withAdminAuthorization(Orgs);

const Wrapper = styled.div`
    white-space: pre-wrap;

    .total-counts {
        margin-bottom: 2rem;
    }

    .input-select {
        display: inline-block;

        > label,
        > select {
            display: inherit;
            width: auto;
        }
        > select {
            padding: 0 0.5rem;
        }

        .select-arrow,
        .input-flare {
            display: none;
        }
    }
`;

const TableFilter = styled.span`
    padding: 20px 5px;
    cursor: pointer;
`;
