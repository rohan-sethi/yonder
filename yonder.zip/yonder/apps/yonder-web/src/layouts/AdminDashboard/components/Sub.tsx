import React from "react";
import styled from "styled-components";

import {
    HostApprovalSubmission,
    Organization,
    ExperienceCategories,
    HostApprovalSubmissionProgress,
    getHostApprovalSubmissionProgressLabel
} from "@yonder/db";
import { SelectInput, FormChangeEvent } from "../../../components";
import { enumToSelectOptions } from "../../../functions";

type Props = {
    submission: HostApprovalSubmission;
    organization: Organization;
    onChange: (ev: FormChangeEvent, org: Organization) => void;
};

type State = {
    progress?: string;
};

let getCategoryTypeName = (catType: ExperienceCategories) => {
    let cat = "";

    switch (catType) {
        case ExperienceCategories.Farm:
            cat = "Farm";
            break;
        case ExperienceCategories.Ranch:
            cat = "Ranch";
            break;
        case ExperienceCategories.Vineyard:
            cat = "Vineyard";
            break;
        case ExperienceCategories.Escape:
            cat = "Escape";
            break;
    }

    return cat;
};

let DataField = (props: { label: string; val: any; isLongform?: boolean }) => {
    let isLongform = props.isLongform ? true : false;

    return (
        <div>
            <Label>{props.label}</Label>: {isLongform ? <div>{props.val}</div> : props.val}
        </div>
    );
};

class Sub extends React.Component<Props, State> {
    progressOptions = enumToSelectOptions(
        HostApprovalSubmissionProgress,
        getHostApprovalSubmissionProgressLabel,
        //pass in false to remove placeholder in select dropdown
        false
    );

    state: State = {
        progress: this.props.organization.approvalSubmissionProgress
    };

    componentDidMount() {}

    render() {
        const {
            experienceCategory,
            overnightStaysCount,
            activityCountRange,
            activities,
            location,
            description,
            certificates,
            scoutSetupPermission
        } = this.props.submission;

        const {
            name,
            businessPhone,
            website //,
            //propertyIds,
            //activityIds
        } = this.props.organization;

        const { address1, address2, city, state, zipCode, country } = location;

        let address = `
            ${address1}${address2 ? ", " + address2 : ""}
            ${city || ""}${state ? ", " + state : ""} ${zipCode}
            ${country}
        `;

        return (
            <Wrapper>
                <BusinessName>{name}</BusinessName>
                <DataField label="Status" val={this.state.progress} />

                <ChangeStatusWrapper>
                    <SelectInput
                        name="progress"
                        descriptor="Change To:"
                        value={this.state.progress!}
                        //options={this.progressOptions}
                        options={[
                            { label: "--", value: "" },
                            { label: "Approved", value: HostApprovalSubmissionProgress.Approved },
                            { label: "Approved & Waiting", value: HostApprovalSubmissionProgress.ApprovedAndWaiting },
                            { label: "Completed", value: HostApprovalSubmissionProgress.Completed },
                            { label: "Denied", value: HostApprovalSubmissionProgress.Denied },
                            { label: "In Review", value: HostApprovalSubmissionProgress.InReview },
                            { label: "International Hold", value: HostApprovalSubmissionProgress.InternationalHold },
                            { label: "Test Submission", value: HostApprovalSubmissionProgress.YonderTestingSubmission }
                        ]}
                        onChange={(ev) => {
                            ev.preventDefault();
                            this.props.onChange(ev, this.props.organization);
                            this.setState({
                                progress: ev.target.value
                            });
                        }}
                    />
                </ChangeStatusWrapper>

                <DataField label="Category" val={getCategoryTypeName(experienceCategory!)} />
                <DataField label="Manual Entry Approved by Host" val={scoutSetupPermission ? "Yes" : "No"} />

                <hr />

                <DataField label="Location" val={address} isLongform />
                <DataField label="Website" val={website} />
                <DataField label="Phone" val={businessPhone} />

                <hr />

                <DataField label="Overnight Stays" val={overnightStaysCount} />
                <DataField label="Activities Range" val={activityCountRange} />
                <DataField label="Activities" val={activities.join(", ")} />
                <DataField label="Certifications" val={certificates.join(", ")} />
                <DataField label="Description" val={description} isLongform />
            </Wrapper>
        );
    }
}

export default Sub;

const BusinessName = styled.div`
    font-size: 2em;
    font-weight: bold;
`;

const Label = styled.span`
    font-weight: bold;
`;

const Wrapper = styled.div`
    .input-select {
        display: table;
        p {
            font-weight: bold;
        }
        select {
            cursor: pointer;
        }
    }
`;

const ChangeStatusWrapper = styled.div`
    margin-left: 50px;
    padding: 15px 0;
`;
