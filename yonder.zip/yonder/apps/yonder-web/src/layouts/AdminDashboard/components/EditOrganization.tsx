import React from "react";
import { inject, observer } from "mobx-react";
import styled from "styled-components";
//import { Redirect } from "react-router";
import { Organization, yonderPatch, ID } from "@yonder/db";

import {
    StyledForm,
    SubmitButton,
    FormSubmitEvent,
    FormChangeEvent,
    TextInput,
    FormGroup,
    LoadingSpinner
} from "../../../components";
import { IAdminStore } from "../../../store";
//import { isStringInvalid } from "../../../functions";

type ValidationErrors = {
    businessPhone?: string;
    name?: string;
    email?: string;
};

type Props = IAdminStore & {
    id: ID | null;
};
type State = {
    validationErrors: ValidationErrors;
    organization?: Organization;
    isUpdating?: boolean;
    invalidId?: boolean;
    success?: { message?: string } | null;
    error?: { message?: string } | null;
};

const INITIAL_STATE: State = {
    validationErrors: {},
    isUpdating: true,
    invalidId: false,
    success: null,
    error: null
};

@inject("adminState")
@observer
class EditOrganization extends React.Component<Props, State> {
    state: State = INITIAL_STATE;

    initialize = async () => {
        try {
            this.setState({ isUpdating: true });
            const { getOrganizations, organizationsLoaded } = this.props.adminState!;
            if (!organizationsLoaded) {
                await getOrganizations();
            }
            const { organizationById } = this.props.adminState!;
            if (!!this.props.id && organizationById[this.props.id]) {
                const organization: Organization = organizationById[this.props.id];
                this.setState({ organization, isUpdating: false });
            } else {
                this.setState({ invalidId: true });
            }
        } catch (err) {
            console.log(err);
        }
    };

    componentDidMount() {
        this.initialize();
    }

    componentDidUpdate(prevProps: Props) {
        if (this.props.id !== prevProps.id) {
            this.initialize();
        }
    }

    onSubmit = async (ev: FormSubmitEvent) => {
        ev.preventDefault();
        const { organization } = this.state;

        if (organization) {
            try {
                this.setState({ isUpdating: true });
                await yonderPatch(`/organizations/${organization.id}`, organization);
                this.setState({
                    isUpdating: false,
                    success: {
                        message: "Organization changes saved sucessfully."
                    }
                });
            } catch (err) {
                console.log(err);
                this.setState({
                    isUpdating: false,
                    error: {
                        message: "There was an error updating this organization."
                    }
                });
            }
        }
    };

    onChange = async (ev: FormChangeEvent) => {
        const { name, value } = ev.target;
        let validationErrors: ValidationErrors = this.state.validationErrors;

        if (this.state.organization) {
            switch (name) {
                case "name":
                    this.setState({
                        validationErrors,
                        organization: {
                            ...this.state.organization,
                            name: value
                        }
                    });
                    break;
            }
        }
    };

    render() {
        const { success, error, isUpdating, organization, invalidId } = this.state;

        /*if (invalidId) {
            return <Redirect to="/admin/organizations" />;
        }*/

        if (invalidId || isUpdating || !organization) {
            return <LoadingSpinner />;
        }

        /*
        const invalidEmail = isStringInvalid(email);
        const invalidName = isStringInvalid(businessName);
        const invalidWebsite = isStringInvalid(businessWebsite);
        const invalidPhone = !!validationErrors.businessPhone || isStringInvalid(businessPhone);

        const isInvalid = invalidName || invalidWebsite || invalidPhone || (showUser && invalidEmail);
        */

        const isInvalid = false;

        if (window.scrollTo) {
            window.scrollTo(0, 0);
        }

        return (
            <StyledEditOrganization>
                <StyledForm>
                    <h2>Edit Organization</h2>
                    <form onSubmit={this.onSubmit}>
                        <FormGroup>
                            {success && <p className="success-message">{success.message}</p>}
                            {error && <p className="error-message">{error.message}</p>}

                            <TextInput
                                name="name"
                                value={organization.name}
                                label="Business Name"
                                placeholder="E.g. Yonder Lakeside Cabin"
                                onChange={this.onChange}
                                required
                            />

                            <h4>View Only</h4>
                            <p>Submission Progress: {organization.approvalSubmissionProgress}</p>
                            <p>Website: {organization.website}</p>
                            <p>Business phone: {organization.businessPhone}</p>
                            <p>Referral write-in: {organization.referralWriteIn}</p>
                        </FormGroup>

                        <SubmitButton label="Save Changes" disabled={isInvalid} />
                    </form>
                </StyledForm>
            </StyledEditOrganization>
        );
    }
}

export { EditOrganization };

const StyledEditOrganization = styled.div`
    margin: 0 auto;
    max-width: 30rem;
`;
