import React from "react";
//import { toJS } from "mobx";
import { inject, observer } from "mobx-react";
import styled from "styled-components";
import { HostApprovalSubmissionProgress, Organization } from "@yonder/db";

import { IFirebaseStore, IAdminStore, IContentModalStore } from "../../../store";
import { withAdminAuthorization, InformationLink, FormChangeEvent, Button } from "../../../components";
import { history } from "../../../history";

import Sub from "./Sub";
import { color } from "../../../variables";

type Props = IFirebaseStore & IAdminStore & IContentModalStore;

type State = {
    showApprovalStatus: HostApprovalSubmissionProgress | "all" | "unfinished";
};

@inject("firebaseState", "adminState", "contentModalState")
@observer
class Orgs extends React.Component<Props, State> {
    state: State = {
        showApprovalStatus: HostApprovalSubmissionProgress.Completed
    };

    initialize = async () => {
        const { getUsers, getOrganizations, getSubmissions } = this.props.adminState!;
        try {
            await getUsers();
            await getOrganizations();
            await getSubmissions();
        } catch (err) {
            console.log(err);
        }
    };

    componentDidMount() {
        this.initialize();
    }

    onUserClick = () => {};

    onFilterClick = (filter: HostApprovalSubmissionProgress | "all" | "unfinished") => {
        return () => {
            this.setState({ showApprovalStatus: filter });
        };
    };

    onChange = (ev: FormChangeEvent, org: Organization) => {
        const { updateOrganizationStatus } = this.props.adminState!;
        const { name, value } = ev.target;

        ev.preventDefault();

        if (value === "") {
            window.alert('Sorry, just selecting "--" doesn\'t do anything.');
            return;
        }

        if (name === "progress") {
            org.approvalSubmissionProgress = value;

            if (window.confirm("Are you sure you want to change this organization's progress?")) {
                updateOrganizationStatus(org.id!, org.approvalSubmissionProgress!);
            }
        }
    };

    editOrg = async (org: Organization) => {
        history.push(`/admin/edit-organization/${org.id!}`);
    };

    deleteOrg = async (org: Organization) => {
        const { deleteOrganization } = this.props.adminState!;
        if (window.confirm(`Are you sure you want to delete the organization: ${org.name}?`)) {
            try {
                await deleteOrganization(org.id!);
                return true;
            } catch (err) {
                console.log(err);
            }
        }
        return false;
    };

    render() {
        const { organizations, submissionById, adminOrganizations } = this.props.adminState!;
        const { open } = this.props.contentModalState!;

        const renderTableRows: any = () => {
            let rows: any = [];

            organizations.forEach((org) => {
                if (this.state.showApprovalStatus === "unfinished") {
                    if (
                        org.approvalSubmissionProgress === HostApprovalSubmissionProgress.Completed ||
                        org.approvalSubmissionProgress === HostApprovalSubmissionProgress.InReview ||
                        org.approvalSubmissionProgress === HostApprovalSubmissionProgress.InternationalHold ||
                        org.approvalSubmissionProgress === HostApprovalSubmissionProgress.Approved ||
                        org.approvalSubmissionProgress === HostApprovalSubmissionProgress.ApprovedAndWaiting ||
                        org.approvalSubmissionProgress === HostApprovalSubmissionProgress.Denied ||
                        org.approvalSubmissionProgress === HostApprovalSubmissionProgress.YonderTestingSubmission
                    ) {
                        return;
                    }
                } else if (this.state.showApprovalStatus !== "all") {
                    if (org.approvalSubmissionProgress !== this.state.showApprovalStatus) return;
                }

                //let stayCount = (org.propertyIds || []).length;
                //let activityCount = (org.activityIds || []).length;

                let viewSubmission: any = "";
                let submission = submissionById[org.approvalSubmissionId!];

                if (submission !== undefined) {
                    viewSubmission = (
                        <InformationLink
                            onClick={() =>
                                open("", <Sub submission={submission} organization={org} onChange={this.onChange} />)
                            }
                            label={submission.scoutSetupPermission ? "View submission (M)" : "View submission"}
                        />
                    );
                }

                let showEditDelete = !adminOrganizations.includes(org.id!);

                rows.push(
                    <TableRow key={org.id}>
                        <TableCell>{org.name}</TableCell>
                        <TableCell>{org.website}</TableCell>
                        <TableCell>{org.id}</TableCell>
                        <TableCell>{org.approvalSubmissionProgress}</TableCell>
                        <TableCell>{viewSubmission}</TableCell>
                        <TableCell>
                            {showEditDelete && (
                                <>
                                    <ActionButton
                                        onClick={(ev) => {
                                            ev.preventDefault();
                                            this.editOrg(org);
                                        }}
                                    >
                                        edit
                                    </ActionButton>
                                    <ActionButton
                                        onClick={(ev) => {
                                            ev.preventDefault();
                                            this.deleteOrg(org);
                                        }}
                                    >
                                        delete
                                    </ActionButton>
                                </>
                            )}
                        </TableCell>
                        {/*}<TableCell>{stayCount === 1 ? `1 stay` : `${stayCount} stays`}</TableCell>{*/}
                        {/*}<TableCell>{activityCount === 1 ? `1 activity` : `${activityCount} activites`}</TableCell>{*/}
                    </TableRow>
                );
            });

            return rows;
        };

        return (
            <Wrapper>
                <div>
                    <Button
                        label="Add an Organization"
                        buttonStyle="outline-color"
                        onClick={() => {
                            history.push("/admin/add-organization");
                        }}
                    />
                </div>
                <div style={{ marginTop: "2rem", marginBottom: "2rem" }}>
                    <b>Filter By:</b>
                    <TableFilter
                        onClick={this.onFilterClick("all")}
                        style={{ fontWeight: this.state.showApprovalStatus === "all" ? "bold" : "inherit" }}
                    >
                        All
                    </TableFilter>
                    <TableFilter
                        onClick={this.onFilterClick("unfinished")}
                        style={{ fontWeight: this.state.showApprovalStatus === "unfinished" ? "bold" : "inherit" }}
                    >
                        Unfinished
                    </TableFilter>
                    <TableFilter
                        onClick={this.onFilterClick(HostApprovalSubmissionProgress.Completed)}
                        style={{
                            fontWeight:
                                this.state.showApprovalStatus === HostApprovalSubmissionProgress.Completed
                                    ? "bold"
                                    : "inherit"
                        }}
                    >
                        Complete
                    </TableFilter>
                    <TableFilter
                        onClick={this.onFilterClick(HostApprovalSubmissionProgress.InReview)}
                        style={{
                            fontWeight:
                                this.state.showApprovalStatus === HostApprovalSubmissionProgress.InReview
                                    ? "bold"
                                    : "inherit"
                        }}
                    >
                        In Review
                    </TableFilter>
                    <TableFilter
                        onClick={this.onFilterClick(HostApprovalSubmissionProgress.InternationalHold)}
                        style={{
                            fontWeight:
                                this.state.showApprovalStatus === HostApprovalSubmissionProgress.InternationalHold
                                    ? "bold"
                                    : "inherit"
                        }}
                    >
                        International Hold
                    </TableFilter>
                    <TableFilter
                        onClick={this.onFilterClick(HostApprovalSubmissionProgress.Approved)}
                        style={{
                            fontWeight:
                                this.state.showApprovalStatus === HostApprovalSubmissionProgress.Approved
                                    ? "bold"
                                    : "inherit"
                        }}
                    >
                        Approved
                    </TableFilter>
                    <TableFilter
                        onClick={this.onFilterClick(HostApprovalSubmissionProgress.ApprovedAndWaiting)}
                        style={{
                            fontWeight:
                                this.state.showApprovalStatus === HostApprovalSubmissionProgress.ApprovedAndWaiting
                                    ? "bold"
                                    : "inherit"
                        }}
                    >
                        Approved-and-Waiting
                    </TableFilter>
                    <TableFilter
                        onClick={this.onFilterClick(HostApprovalSubmissionProgress.Denied)}
                        style={{
                            fontWeight:
                                this.state.showApprovalStatus === HostApprovalSubmissionProgress.Denied
                                    ? "bold"
                                    : "inherit"
                        }}
                    >
                        Denied
                    </TableFilter>
                    <TableFilter
                        onClick={this.onFilterClick(HostApprovalSubmissionProgress.YonderTestingSubmission)}
                        style={{
                            fontWeight:
                                this.state.showApprovalStatus === HostApprovalSubmissionProgress.YonderTestingSubmission
                                    ? "bold"
                                    : "inherit"
                        }}
                    >
                        Testing
                    </TableFilter>
                </div>

                <Table>
                    <thead>
                        <tr>
                            <TableHeader>name</TableHeader>
                            <TableHeader>website</TableHeader>
                            <TableHeader>org id</TableHeader>
                            <TableHeader>status</TableHeader>
                            <TableHeader>submission</TableHeader>
                            <TableHeader>actions</TableHeader>
                        </tr>
                    </thead>
                    <tbody>{renderTableRows()}</tbody>
                </Table>
            </Wrapper>
        );
    }
}

export default withAdminAuthorization(Orgs);

const ActionButton = styled.button`
    color: ${color.primaryDark};
`;

const TableFilter = styled.span`
    padding: 20px 5px;
`;

const Table = styled.table`
    width: 100%;
    border-collapse: collapse;
    border-spacing: 0;
`;

const TableHeader = styled.td`
    font-weight: bold;
    background: #002000;
    color: #ffffff;
    padding: 6px 0;
`;

const TableRow = styled.tr`
    :hover {
        background: #f3f3f3;
    }
`;

const TableCell = styled.td`
    padding: 10px 0;
    border-bottom: 1px solid #f1f1f1;
`;

const Wrapper = styled.div``;
