import React from "react";
import styled from "styled-components";
import {
    Organization,
    HostApprovalSubmissionProgress,
    User,
    HostApprovalSubmission,
    yonderPost,
    UserPermissions,
    HostTypes
} from "@yonder/db";

import {
    StyledForm,
    SubmitButton,
    FormSubmitEvent,
    FormChangeEvent,
    TextInput,
    rePhoneNumber,
    PhoneInput,
    reSpecialChars,
    reNumbers,
    reEmail,
    MouseClickEvent,
    InputYesNo,
    FormGroup,
    InputCheckbox,
    InputChangeEvent,
    LoadingSpinner
} from "../../../components";
import { IFirebaseStore } from "../../../store";
import { isStringInvalid } from "../../../functions";

type ValidationErrors = {
    businessPhone?: string;
    name?: string;
    email?: string;
};

type Props = IFirebaseStore;
type State = {
    validationErrors: ValidationErrors;
    firstName?: string;
    lastName?: string;
    email?: string;
    businessName?: string;
    businessPhone?: string;
    businessWebsite?: string;
    businessReferralWriteIn?: string;
    isSending?: boolean;
    showUser?: boolean;
    sendWelcomeEmail?: boolean;
    propertyManagement?: boolean;
    success?: { message?: string } | null;
};

const INITIAL_STATE: State = {
    validationErrors: {},
    firstName: "",
    lastName: "",
    email: "",
    businessName: "",
    businessPhone: "",
    businessWebsite: "",
    businessReferralWriteIn: "",
    isSending: false,
    showUser: false,
    sendWelcomeEmail: false,
    propertyManagement: false,
    success: null
};

class AddOrganization extends React.Component<Props, State> {
    state: State = INITIAL_STATE;

    componentDidMount() {
        this.setState(INITIAL_STATE);
    }

    onSubmit = async (ev: FormSubmitEvent) => {
        ev.preventDefault();

        const {
            firstName,
            lastName,
            email,
            businessName,
            businessWebsite,
            businessPhone,
            businessReferralWriteIn,
            showUser,
            sendWelcomeEmail,
            propertyManagement
        } = this.state;

        this.setState({
            isSending: true
        });

        try {
            // save a new host approval (it exists solely for the location in my business)
            let hostApproval: HostApprovalSubmission = new HostApprovalSubmission();
            hostApproval.scoutSetupPermission = true;
            hostApproval.description = "Created by Yonder Scout on host's behalf.";
            hostApproval = await yonderPost(`/host-approval-submissions`, hostApproval);
            console.log("host approval: ", hostApproval.id);

            let organization: Organization = new Organization();
            organization.approvalSubmissionId = hostApproval.id;
            organization.approvalSubmissionProgress = HostApprovalSubmissionProgress.Approved;
            organization.name = businessName || "";
            organization.website = businessWebsite;
            organization.businessPhone = businessPhone;
            organization.referralWriteIn = businessReferralWriteIn;
            organization = await yonderPost(`/organizations`, organization);
            console.log("organization: ", organization.id);
            // save the organization

            const saveHost = !!firstName && !!lastName && !!email && email !== undefined;
            if (showUser && saveHost) {
                let user = new User();
                user.firstName = firstName;
                user.lastName = lastName;
                user.email = email!;
                user.permissions = UserPermissions.Host;
                user.organizationId = organization.id;
                if (propertyManagement) {
                    user.hostType = HostTypes.PropertyManagement;
                }

                user = await yonderPost(`/users${!sendWelcomeEmail ? "?noEmail=1" : ""}`, user);
                if (user.id === undefined) {
                    this.setState({
                        ...INITIAL_STATE,
                        isSending: false,
                        success: {
                            message:
                                "Organization successfully created, but the user could not be created (already exists)"
                        }
                    });
                }
                console.log("user: ", user.id);
            }

            // set the organizationId for the host
            // set the permission to host
            // save the new host

            this.setState({
                ...INITIAL_STATE,
                isSending: false,
                success: {
                    message: "Organization successfully created!"
                }
            });
            if (window.scrollTo) {
                window.scrollTo(0, 0);
            }
        } catch (err) {
            console.log(err);
        }
    };

    onChange = async (ev: FormChangeEvent) => {
        ev.preventDefault();

        const { name, value } = ev.target;
        let validationErrors: ValidationErrors = this.state.validationErrors;

        // User - firstName, lastName, email

        switch (name) {
            case "firstName":
            case "lastName":
                if (!reSpecialChars.test(value) && !reNumbers.test(value) && value !== "") {
                    validationErrors.name = undefined;
                } else {
                    validationErrors.name = "First or last name must not contain special characters or numbers";
                }
                break;

            case "email":
                if (reEmail.test(value) && value !== "") {
                    validationErrors.email = undefined;
                } else {
                    validationErrors.email = "Must be a valid email address";
                }
                break;

            case "businessPhone":
                if (rePhoneNumber.test(value) && value !== "") {
                    validationErrors.businessPhone = undefined;
                } else {
                    validationErrors.businessPhone = "Must be a valid phone number.";
                }
                this.setState({ validationErrors });
                break;
        }

        this.setState({ [name]: value, success: null, validationErrors });
    };

    toggleCheckbox = (ev: InputChangeEvent) => {
        const { name, value } = ev.target;
        const { validationErrors } = this.state;

        this.setState({ [name]: value, validationErrors });
    };

    onYesNoChange = (ev: MouseClickEvent, name: string, value: boolean) => {
        ev.preventDefault();

        if (name === "displayActivityForm") {
            this.setState({
                showUser: value
            });
        }
    };

    render() {
        const {
            firstName,
            lastName,
            email,
            businessName,
            businessWebsite,
            businessPhone,
            businessReferralWriteIn,
            validationErrors,
            isSending,
            showUser,
            sendWelcomeEmail,
            success,
            propertyManagement
        } = this.state;

        if (isSending) {
            return <LoadingSpinner />;
        }

        const invalidEmail = isStringInvalid(email);
        const invalidName = isStringInvalid(businessName);
        const invalidWebsite = isStringInvalid(businessWebsite);
        const invalidPhone = !!validationErrors.businessPhone || isStringInvalid(businessPhone);

        const isInvalid = invalidName || invalidWebsite || invalidPhone || (showUser && invalidEmail);

        return (
            <StyledAddOrganization>
                <StyledForm>
                    <h2>Add New Organization</h2>
                    <form onSubmit={this.onSubmit}>
                        <FormGroup>
                            {success && <p className="success-message">{success.message}</p>}
                            <TextInput
                                name="businessName"
                                value={businessName}
                                label="Business Name"
                                placeholder="E.g. Yonder Lakeside Cabin"
                                onChange={this.onChange}
                                required
                            />
                            <TextInput
                                name="businessWebsite"
                                value={businessWebsite}
                                label="Business Website"
                                placeholder="E.g. www.yonderlakesidecabin.com"
                                onChange={this.onChange}
                                required
                            />
                            <PhoneInput
                                name="businessPhone"
                                value={businessPhone}
                                label="Business Phone"
                                onChange={this.onChange}
                                error={validationErrors.businessPhone}
                                required
                            />
                            <TextInput
                                name="businessReferralWriteIn"
                                value={businessReferralWriteIn}
                                label="Referral Write-In"
                                placeholder="E.g. Cindy Ruth at Yonder Vineyards"
                                onChange={this.onChange}
                            />
                            <InputYesNo
                                name="displayActivityForm"
                                descriptor="Add a host to this organization?"
                                value={showUser}
                                onClick={this.onYesNoChange}
                                padded={false}
                            />
                            {showUser && (
                                <>
                                    <InputCheckbox
                                        name="propertyManagement"
                                        label="Property management?"
                                        checked={propertyManagement}
                                        onChange={this.toggleCheckbox}
                                    />
                                    <InputCheckbox
                                        name="sendWelcomeEmail"
                                        label="Send welcome email?"
                                        checked={sendWelcomeEmail}
                                        onChange={this.toggleCheckbox}
                                    />
                                    <TextInput
                                        name="firstName"
                                        value={firstName}
                                        label="Host's First Name"
                                        placeholder="First Name"
                                        onChange={this.onChange}
                                    />
                                    <TextInput
                                        name="lastName"
                                        value={lastName}
                                        label="Host's Last Name"
                                        placeholder="Last Name"
                                        onChange={this.onChange}
                                    />
                                    <TextInput
                                        name="email"
                                        value={email}
                                        label="Host's Email"
                                        placeholder="Email Address"
                                        onChange={this.onChange}
                                        required
                                    />
                                </>
                            )}
                        </FormGroup>

                        <SubmitButton label="Continue" disabled={isInvalid} />
                    </form>
                </StyledForm>
            </StyledAddOrganization>
        );
    }
}

export { AddOrganization };

const StyledAddOrganization = styled.div`
    margin: 0 auto;
    max-width: 30rem;
`;
