import React from "react";
import { inject, observer } from "mobx-react";
import styled from "styled-components";

import { IFirebaseStore, IAdminStore } from "../../../store";
import { withAdminAuthorization } from "../../../components";
//import { toJS } from "mobx";
import { User, UserPermissions } from "@yonder/db";
import { color } from "../../../variables";
import { history } from "../../../history";

type Props = IFirebaseStore & IAdminStore;

type State = {};

@inject("firebaseState", "adminState")
@observer
class Users extends React.Component<Props, State> {
    state: State = {};

    initialize = async () => {
        try {
            const { getUsers, getOrganizations } = this.props.adminState!;
            await getUsers();
            await getOrganizations();
        } catch (err) {
            console.log(err);
        }
    };

    componentDidMount() {
        this.initialize();
    }

    onUserClick = () => {};

    editUser = async (user: User) => {
        history.push(`/admin/edit-user/${user.id!}`);
    };

    deleteUser = async (user: User) => {
        const { deleteUser } = this.props.adminState!;
        if (window.confirm(`Are you sure you want to delete the user: ${user.firstName} ${user.lastName}?`)) {
            try {
                await deleteUser(user.id!);
                return true;
            } catch (err) {
                console.log(err);
            }
        }
        return false;
    };

    renderTableRows = () => {
        const { users, organizationById } = this.props.adminState!;
        let rows: any = [];

        users.forEach((user: User, i: number) => {
            let orgName = "";
            let orgNotFound: boolean = false;

            if (user.organizationId && organizationById[user.organizationId]) {
                orgName = organizationById[user.organizationId].name;
            } else {
                orgName = user.organizationId!;
                orgNotFound = true;
            }

            rows.push(
                <TableRow key={`user-${i}`}>
                    <TableCell>{user.photoURL ? <ProfileImage src={user.photoURL} /> : <div />}</TableCell>
                    <TableCell>
                        {user.firstName} {user.lastName}
                    </TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>{user.phoneNumber}</TableCell>
                    <TableCell>{user.userLocation}</TableCell>
                    <TableCell style={orgNotFound ? { color: color.wintersGray } : {}}>{orgName}</TableCell>
                    <TableCell>
                        {user.permissions !== UserPermissions.Admin && (
                            <>
                                <ActionButton
                                    onClick={(ev) => {
                                        ev.preventDefault();
                                        this.editUser(user);
                                    }}
                                >
                                    edit
                                </ActionButton>
                                <ActionButton
                                    onClick={(ev) => {
                                        ev.preventDefault();
                                        this.deleteUser(user);
                                    }}
                                >
                                    delete
                                </ActionButton>
                            </>
                        )}
                    </TableCell>
                </TableRow>
            );
        });

        return rows;
    };

    render() {
        return (
            <Wrapper>
                <Table>
                    <thead>
                        <tr>
                            <TableHeader>&nbsp;</TableHeader>
                            <TableHeader>name</TableHeader>
                            <TableHeader>email</TableHeader>
                            <TableHeader>phone</TableHeader>
                            <TableHeader>location</TableHeader>
                            <TableHeader>organization</TableHeader>
                            <TableHeader>actions</TableHeader>
                        </tr>
                    </thead>
                    <tbody>{this.renderTableRows()}</tbody>
                </Table>
            </Wrapper>
        );
    }
}

export default withAdminAuthorization(Users);

const ActionButton = styled.button`
    color: ${color.primaryDark};
`;

const Table = styled.table`
    width: 100%;
    border-collapse: collapse;
    border-spacing: 0;
`;

const TableHeader = styled.td`
    font-weight: bold;
    background: #002000;
    color: #ffffff;
    padding: 6px 0;
`;

const TableRow = styled.tr`
    :hover {
        background: #f3f3f3;
    }
`;

const TableCell = styled.td`
    padding: 10px 0;
    border-bottom: 1px solid #f1f1f1;
`;

const ProfileImage = styled.img`
    max-width: 60px;
`;

const Wrapper = styled.div``;
