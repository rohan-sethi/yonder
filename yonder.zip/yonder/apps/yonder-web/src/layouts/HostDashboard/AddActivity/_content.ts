import { EditNavigationMap } from "../../../components/EditNavigation";
import {
    AddActivityOverview,
    AddActivityExperienceCategories,
    AddActivityLocation,
    AddActivityPolicyPricing,
    AddActivityRules,
    AddActivityPhotos,
    AddActivityItinerary,
    AddActivityFinish,
    ActivityPricingAlerts
} from "../../Forms/AddActivity";
import { AddActivityDescription } from "../../Forms/AddActivity/AddActivityDescription";

export type AddActivityOptions = {
    length: number;
    map: EditNavigationMap;
};

// prettier-ignore
const _options: EditNavigationMap = {
    "experience-category": {
        label: "Experience Category",
        component: AddActivityExperienceCategories,
        layout: "small"
    },
    "activity-overview": {
        label: "Activity Overview",
        component: AddActivityOverview,
        layout: "small"
    },
    "location": {
        label: "Location of Activity",
        component: AddActivityLocation,
        layout: "small"
    },
    "pricing-and-policy": {
        label: "Pricing and Policy",
        alerts: ActivityPricingAlerts,
        component: AddActivityPolicyPricing,
        layout: "small"
    },
    "itinerary": {
        label: "Itinerary",
        component: AddActivityItinerary,
        layout: "small"
    },
    "rules-and-safety": {
        label: "Rules and Safety",
        component: AddActivityRules,
        layout: "large"
    },
    "description": {
        label: "Description",
        component: AddActivityDescription,
        layout: "medium"
    },
    "photos": {
        label: "Photos",
        component: AddActivityPhotos,
        layout: "large"
    },
    "finish": {
        label: "Finish and Submit",
        component: AddActivityFinish,
        layout: "small"
    }
};

const options: AddActivityOptions = {
    length: Object.keys(_options).length,
    map: _options
};

export default options;
