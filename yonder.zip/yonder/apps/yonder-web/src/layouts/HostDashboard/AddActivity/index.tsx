import React from "react";
import styled from "styled-components";
import { Redirect } from "react-router-dom";
import { observer, inject } from "mobx-react";
import { getSectionProgressKey, SectionProgress, ListingProgress, UserPermissions } from "@yonder/db";

import {
    Page,
    EditNavigationFrame,
    navHeight,
    withHostAuthorization,
    IEditNavigationOption,
    FullPageSpinner
} from "../../../components";
//import HostDashboardNavigation from "../HostDashboardNavigation";
import { IAddActivityStore, IFirebaseStore } from "../../../store";
import { history } from "../../../history";
import { LayoutPageNotFound } from "../../PageNotFound";

type Props = IAddActivityStore & IFirebaseStore;

@inject("addActivityState", "firebaseState")
@observer
class HostDashboardAddActivity extends React.Component<Props> {
    baseUrl: string = "";
    slug: string = "";
    mapKeys = Object.keys(this.props.addActivityState!.options.map);
    currentOption: IEditNavigationOption = {
        label: "",
        component: null,
        layout: "small"
    };

    onOptionClick = (slug: string) => {
        this.slug = slug;
        history.push(this.baseUrl + slug);
        this.setSection(slug);
    };

    setSection = (slug: string) => {
        const { options, activity, saveNextRoute } = this.props.addActivityState!;
        this.currentOption = options.map[slug];

        const keys: string[] = Object.keys(options.map);
        const nextIndex: number = keys.indexOf(slug) + 1;
        const section: string = getSectionProgressKey(this.currentOption.label);
        const nextRoute: string = keys[nextIndex];
        saveNextRoute(section, this.baseUrl + nextRoute);

        if (slug === "finish") return;

        // Initialize the section progress if it hasn't already been done.
        const sectionKey: string = getSectionProgressKey(this.currentOption.label);
        if (activity.sectionProgress[sectionKey] === undefined) {
            activity.sectionProgress[sectionKey] = SectionProgress.Started;
            activity.listingProgress = ListingProgress.Draft;
        }
    };

    render() {
        // Assumes /dash/listings/stays/:id/:slug
        let pathname = window.location.pathname.split("/");
        const id = pathname[4];
        const slug = pathname[5];
        pathname[5] = "";
        this.baseUrl = pathname.join("/");

        if (slug !== "" && slug !== undefined) {
            if (!this.mapKeys.includes(slug)) {
                return <LayoutPageNotFound />;
            }
        } else {
            return <Redirect to={this.baseUrl + this.mapKeys[0]} />;
        }

        const { options, activity, createOrLoadActivity, isLoading } = this.props.addActivityState!;
        const { dbUser, dbOrganization } = this.props.firebaseState!;

        if (!dbOrganization.activityIds.includes(id) && dbUser.permissions !== UserPermissions.Admin) {
            return <Redirect to="/dash/listings" />;
        }

        if (activity.id !== id) {
            createOrLoadActivity(id);
            return <FullPageSpinner />;
        }

        if (isLoading) {
            return <FullPageSpinner />;
        }

        if (this.slug !== slug) {
            this.slug = slug;
            this.setSection(slug);
        }

        return (
            <Page>
                {/*<HostDashboardNavigation />*/}
                <Styles>
                    <EditNavigationFrame
                        label="Creating New Activity"
                        currentOption={this.currentOption}
                        options={options.map}
                        activeTab={slug}
                        onOptionClick={this.onOptionClick}
                        sectionProgress={activity.sectionProgress}
                    />
                </Styles>
            </Page>
        );
    }
}

const Styles = styled.div`
    display: block;
    height: calc(100vh - (${navHeight}));
`;

export default withHostAuthorization(HostDashboardAddActivity);
