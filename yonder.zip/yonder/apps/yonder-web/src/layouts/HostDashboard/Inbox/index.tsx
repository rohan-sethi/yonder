import React from "react";
import styled from "styled-components";
import { observer, inject } from "mobx-react";

import { Page, Section, InboxFrame, navHeight, subNavHeight, withHostAuthorization } from "../../../components";
import HostDashboardNavigation from "../HostDashboardNavigation";
import { IHostDashboardStore } from "../../../store";

type Props = IHostDashboardStore;

@inject("hostDashboardState")
@observer
class HostDashboardIndex extends React.Component<Props> {
    render() {
        const { inboxConversations, onConversationClick, currentConversation } = this.props.hostDashboardState!;
        return (
            <Page noTransition>
                <HostDashboardNavigation />
                <Section noPadding>
                    <StyledHostDashboardIndex>
                        <InboxFrame
                            conversations={inboxConversations}
                            onConversationClick={onConversationClick}
                            currentConversation={currentConversation}
                        />
                    </StyledHostDashboardIndex>
                </Section>
            </Page>
        );
    }
}

const StyledHostDashboardIndex = styled.div`
    display: block;
    height: calc(100vh - (${navHeight} + ${subNavHeight}));
`;

export default withHostAuthorization(HostDashboardIndex);
