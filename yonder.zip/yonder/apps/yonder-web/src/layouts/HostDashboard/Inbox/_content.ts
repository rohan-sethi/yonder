import { Props as IInboxConversation } from "../../../components/Inbox/InboxSidePanel/InboxConversation";

export default {
    conversations: [
        {
            displayName: "Victoria",
            lastMessage:
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut dignissim nunc quis metus aliquam, in tempor leo ultricies. Donec pretium fringilla vestibulum.",
            lastReceived: new Date(),
            unread: true
        } as IInboxConversation,
        {
            displayName: "Bethany",
            lastMessage:
                "Maecenas egestas semper risus, quis feugiat ligula molestie nec. Nullam dapibus lobortis diam at posuere.",
            lastReceived: new Date(),
            unread: true
        } as IInboxConversation,
        {
            displayName: "Roberto",
            lastMessage:
                "Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Morbi a efficitur mi. Nulla sit amet porttitor libero.",
            lastReceived: new Date(),
            unread: true
        } as IInboxConversation,
        {
            displayName: "Gloria",
            lastMessage: "Donec eget mollis libero.",
            lastReceived: new Date(),
            unread: true
        } as IInboxConversation,
        {
            displayName: "Jessica",
            lastMessage: "Thanks! I really appreciate your help with the thing, and the other thing.",
            lastReceived: new Date(),
            unread: true
        } as IInboxConversation,
        {
            displayName: "Gloria",
            lastMessage: "Donec eget mollis libero.",
            lastReceived: new Date(),
            unread: true
        } as IInboxConversation,
        {
            displayName: "Gloria",
            lastMessage: "Donec eget mollis libero.",
            lastReceived: new Date(),
            unread: true
        } as IInboxConversation,
        {
            displayName: "Gloria",
            lastMessage: "Donec eget mollis libero.",
            lastReceived: new Date(),
            unread: false
        } as IInboxConversation
    ] as IInboxConversation[]
};
