import React from "react";
import styled from "styled-components";
import { inject, observer } from "mobx-react";
import { Property, Activity, ID } from "@yonder/db";

import { IFirebaseStore, IAddPropertyStore, IAddActivityStore } from "../../../store";
import { HostListing, PropsHostListing } from "./HostListing";
import { FullPageSpinner, Button, Page, Section, withHostAuthorization, Alert } from "../../../components";
import { history } from "../../../history";
import { isStringInvalid } from "../../../functions";
import { Props as AlertProps } from "../../../components/Alert";

type Props = IFirebaseStore & IAddPropertyStore & IAddActivityStore;
type State = {
    addedNewListing: boolean;
};

@inject("addPropertyState", "addActivityState", "firebaseState")
@observer
class HostListingsComponent extends React.Component<Props, State> {
    state: State = {
        addedNewListing: false
    };
    alerts: AlertProps[] = [
        {
            title: "Coming soon: Calendar Sync.",
            body:
                "Do you use other booking platforms? Not to worry, Yonder is working hard on implementing our Calendar Sync functions so that all of your booking calendars will be in sync prior to our platform launch!"
        },
        {
            title: "Friendly reminder: Insurance Coverage.",
            body:
                "All stays and activities on Yonder are required to have proper insurance coverage. Let us know if you don’t have insurance, you may qualify for the Yonder Host Policy. Yonder also has you covered with a Host Guarantee Policy, stay tuned for details."
        }
    ];
    componentDidMount() {
        const { refreshStaysActivities } = this.props.firebaseState!;
        refreshStaysActivities(true);
    }

    createNewStay = async () => {
        const { refreshOrganization } = this.props.firebaseState!;
        const { createOrLoadProperty } = this.props.addPropertyState!;
        this.setState({
            addedNewListing: true
        });

        try {
            const id = await createOrLoadProperty();
            await refreshOrganization();
            if (id) {
                history.push(`/dash/listings/stays/${id}`);
            }
        } catch (err) {
            console.log(err);
            this.setState({
                addedNewListing: false
            });
        }
    };

    createNewActivity = async () => {
        const { refreshOrganization } = this.props.firebaseState!;
        const { createOrLoadActivity } = this.props.addActivityState!;

        this.setState({
            addedNewListing: true
        });

        try {
            const id = await createOrLoadActivity();
            await refreshOrganization();
            if (id) {
                history.push(`/dash/listings/activities/${id}`);
            }
        } catch (err) {
            console.log(err);
            this.setState({
                addedNewListing: false
            });
        }
    };

    //
    onViewStay = (id: ID) => {
        history.push(`/listing/${id}`);
    };

    onEditStay = (id: ID) => {
        history.push(`/dash/listings/stays/${id}`);
    };

    //
    onViewActivity = (id: ID) => {
        history.push(`/listing/${id}`);
    };

    onEditActivity = (id: ID) => {
        history.push(`/dash/listings/activities/${id}`);
    };

    render() {
        const { dbOrganization, organizationStays, organizationActivities } = this.props.firebaseState!;

        if (this.state.addedNewListing) {
            return <FullPageSpinner />;
        }

        let stays = organizationStays.map((stay: Partial<Property>, i: number) => {
            const id = stay.id!;
            const label: string = !isStringInvalid(stay.name) ? stay.name! : "New Stay";
            const outProps: PropsHostListing = {
                label,
                coverPhoto: stay.coverPhoto,
                progress: stay.listingProgress,
                onEdit: () => this.onEditStay(id),
                onView: () => this.onViewStay(id)
            };
            return <HostListing {...outProps} key={i} />;
        });

        let activities = organizationActivities.map((activity: Partial<Activity>, i: number) => {
            const id = activity.id!;
            const label: string = !isStringInvalid(activity.name) ? activity.name! : "New Activity";
            const outProps: PropsHostListing = {
                label,
                coverPhoto: activity.coverPhoto,
                progress: activity.listingProgress,
                onEdit: () => this.onEditActivity(id),
                onView: () => this.onViewActivity(id)
            };
            return <HostListing {...outProps} key={i} />;
        });

        const staysLoading = stays.length === 0 && dbOrganization.propertyIds && dbOrganization.propertyIds.length > 0;
        const activitiesLoading =
            activities.length === 0 && dbOrganization.activityIds && dbOrganization.activityIds.length > 0;

        if (staysLoading || activitiesLoading) {
            return <FullPageSpinner />;
        }

        const noListing: boolean = organizationStays.length === 0 && organizationActivities.length === 0;
        const alerts = this.alerts.map((alert: AlertProps, i: number) => {
            return <Alert {...alert} key={i} />;
        });

        return (
            <Page>
                {/*<HostDashboardNavigation />*/}
                <Section noPadding>
                    {alerts.length > 0 && <StyledAlertBox>{alerts}</StyledAlertBox>}
                    <StyledHostListingsFrame>
                        <h1>Listings</h1>
                        {noListing && (
                            <div className="no-listings">
                                Let’s get started! Click one of the options below to create a new listing. Don’t worry
                                if you can’t finish your listing, it will save as a draft and you can continue right
                                where you left off.
                            </div>
                        )}
                        <div className="listings-main-controls">
                            <Button onClick={this.createNewStay} label="Create New Stay" buttonStyle="outline-color" />
                            <Button
                                onClick={this.createNewActivity}
                                label="Create New Activity"
                                buttonStyle="outline-color"
                            />
                        </div>
                        <div className="listings-wrapper">
                            <div className="listing-group">
                                {stays.length > 0 && (
                                    <>
                                        <h3>Stays</h3>
                                        {stays}
                                    </>
                                )}
                            </div>
                            <div className="listing-group">
                                {activities.length > 0 && (
                                    <>
                                        <h3>Activities</h3>
                                        {activities}
                                    </>
                                )}
                            </div>
                        </div>
                    </StyledHostListingsFrame>
                </Section>
            </Page>
        );
    }
}

export default withHostAuthorization(HostListingsComponent);
//export default HostDashboardListings;

const StyledAlertBox = styled.div`
    display: block;
    position: relative;
    margin-top: 1rem;

    .alert {
        margin-bottom: 1rem;
    }
`;

const StyledHostListingsFrame = styled.div`
    display: block;
    position: relative;
    width: 100%;
    height: 100%;
    margin-top: 3.5rem;

    .no-listings {
        margin-top: 2rem;
        font-size: 1.1875rem;
        font-weight: 300;
        margin-bottom: 2rem;
    }

    .listings-main-controls {
        display: block;
        width: auto;
        max-width: 16rem;
        margin-bottom: 2rem;
        text-align: center;

        button {
            display: block;
            width: 100%;
            margin: 1rem 0;

            &:first-child {
                margin-left: 0;
            }
            &:last-child {
                margin-right: 0;
            }
        }
    }

    .listings-wrapper {
        display: inline-block;
        position: relative;
        width: 100%;
        height: 100%;

        .listing-group {
            margin-bottom: 4rem;

            h3 {
                font-size: 1.125rem;
                font-weight: 400;
                margin-bottom: 0.5rem;
            }
        }
    }

    @media only screen and (min-width: 40rem) {
        .listings-main-controls {
            display: inline-block;
            width: auto;
            max-width: none;
            margin-top: 2rem;
            margin-bottom: 5.5rem;
            text-align: center;

            button {
                display: inline-block;
                width: auto;
                margin: 0 1rem;

                &:first-child {
                    margin-left: 0;
                }
                &:last-child {
                    margin-right: 0;
                }
            }
        }
    }
`;
