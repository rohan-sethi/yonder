import React from "react";
import styled from "styled-components";
import { inject, observer } from "mobx-react";
import {
    ID,
    getListingProgressLabel,
    ListingProgress,
    getListingProgressDescription,
    yonderGet,
    ImageAsset
} from "@yonder/db";

import { IFirebaseStore, IContentModalStore } from "../../../store";
import { color } from "../../../variables";
import { Button, Icon, LoadingSpinner } from "../../../components";
import { imgSourcesFromAsset } from "../../../functions";

export type PropsHostListing = {
    label: string;
    coverPhoto?: ID;
    progress?: ListingProgress;
    onView: () => void;
    onEdit: () => void;
    onDelete?: () => void;
};

type Props = PropsHostListing & IFirebaseStore & IContentModalStore;

type State = {
    photoLoaded: boolean;
};

@inject("firebaseState", "contentModalState")
@observer
export class HostListing extends React.Component<Props, State> {
    photo: HTMLImageElement | null = null;
    state: State = {
        photoLoaded: false
    };

    componentDidMount() {
        this.initializePhoto();
    }

    componentWillUnmount() {
        if (this.photo) {
            this.photo.onload = () => {};
        }
    }

    initializePhoto = async () => {
        if (!this.props.coverPhoto) return;

        try {
            let res: ImageAsset = await yonderGet(`/assets/${this.props.coverPhoto}`);
            this.photo = new Image();
            this.photo.src = res.file;

            const sources = imgSourcesFromAsset(res.renders);
            if (sources !== null) {
                this.photo.srcset = sources.srcSet;
                this.photo.sizes = sources.sizes;
            }
            this.photo.alt = "";
            this.photo.onload = () => {
                this.setState({ photoLoaded: true });
            };
        } catch (err) {
            console.log(err);
        }
    };

    confirmDelete = () => {
        const { openDialog } = this.props.contentModalState!;
        openDialog(`Are you sure you want to delete ${this.props.label}?`, "Cancel", "Okay", this.props.onDelete);
    };

    listingAction = (id: ListingProgress) => {
        const { onEdit } = this.props;
        switch (id) {
            case ListingProgress.InReview:
                return <Button label="View" onClick={onEdit} buttonStyle="none" />;
            case ListingProgress.Ready:
                return <Button label="Edit" onClick={onEdit} buttonStyle="none" />;
        }
        return <Button label="Continue" onClick={onEdit} buttonStyle="none" />;
    };

    render() {
        const { label } = this.props;
        const progress = this.props.progress || ListingProgress.Draft;
        const listingStatus = {
            label: getListingProgressLabel(progress),
            description: getListingProgressDescription(progress)
        };

        const progressClass = progress.replace("_", "-");

        return (
            <StyledHostListing>
                <div className="photo-container">
                    {this.props.coverPhoto ? (
                        this.photo && this.state.photoLoaded ? (
                            <img
                                src={this.photo!.src}
                                srcSet={this.photo!.srcset !== "" ? this.photo!.srcset : undefined}
                                sizes={this.photo!.sizes !== "" ? this.photo!.sizes : undefined}
                                alt={this.photo!.alt}
                            />
                        ) : (
                            <LoadingSpinner size={2} />
                        )
                    ) : (
                        <Icon type="photo-upload" size="3.25rem" color={color.charcoal} />
                    )}
                </div>
                <div className="listing-info-block">
                    <div className="listing-status">
                        <h2 className={progressClass}>{listingStatus.label}</h2>
                    </div>
                    <h2 className="listing-label">{label}</h2>
                    <div className="listing-controls">{this.listingAction(progress)}</div>
                </div>
                <h2 className="listing-label desktop">{label}</h2>
                <div className="listing-status desktop">
                    <h2 className={progressClass}>{listingStatus.label}</h2>
                    <p>{listingStatus.description}</p>
                </div>
                <div className="listing-controls desktop">{this.listingAction(progress)}</div>
            </StyledHostListing>
        );
    }
}

export const StyledHostListing = styled.div`
    position: relative;
    border-bottom: 1px solid ${color.metal};

    .desktop {
        display: none;
    }

    .listing-info-block {
        display: inline-block;
        position: absolute;
        height: 5rem;
        width: 50%;
        margin: 1rem;
    }

    .photo-container {
        display: inline-block;
        margin: 1rem 0;
        margin-right: 1.5rem;
        position: relative;
        width: 7.5rem;
        height: 5rem;
        background-color: ${color.fog};
        text-align: center;
        overflow: hidden;
        border-radius: 0.125rem;

        img {
            width: 100%;
            height: auto;
        }

        img,
        .icon-container {
            display: block;
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
        }
    }

    h2 {
        font-size: 1.125rem;
        font-weight: 300;

        &.listing-label {
            width: 100%;
            margin-top: 0.3rem;
            margin-bottom: 0.4rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
    }

    .listing-status {
        position: relative;

        h2 {
            font-size: 0.875rem;
            color: ${color.metal};
        }
        p {
            font-size: 0.875rem;
            padding-left: 1rem;
            color: ${color.metal};
        }
    }

    .listing-controls {
        width: 100%;

        button {
            padding: 0;
            font-size: 1rem;
            font-weight: 600;
            color: ${color.primary};
            transition: color 0.25s linear;

            &:hover {
                color: ${color.primaryDark};
            }
        }
    }

    @media only screen and (min-width: 40rem) {
        .photo-container {
            width: 9.5rem;
            height: 6.5rem;
            margin-right: 2rem;
        }

        .listing-info-block {
            display: inline-flex;
            justify-content: space-between;
            flex-direction: column;
            height: 6.5rem;
        }

        .listing-status,
        .listing-controls {
            h2 {
                font-size: 1rem;
            }
        }

        h2.listing-label {
            white-space: normal;
            line-height: 1.5rem;
        }

        .listing-controls {
            display: flex;
        }

        .desktop {
            display: none;
        }
    }

    @media only screen and (min-width: 68rem) {
        padding: 2rem 0;

        .listing-info-block {
            display: none;
        }

        h2.listing-label,
        .photo-container,
        .listing-status,
        .listing-controls {
            display: inline-block;
            vertical-align: middle;
            margin: 0;
        }

        .photo-container {
            margin-right: 4rem;
        }

        h2 {
            &.listing-label {
                width: 30%;
                margin-right: 2rem;
                white-space: normal;
            }
        }

        .listing-status {
            h2 {
                color: ${color.blackInk};
                font-size: 1.125rem;
                padding-left: 1rem;

                &:before {
                    content: " ";
                    width: 0.5rem;
                    height: 0.5rem;
                    background-color: black;
                    border-radius: 50%;
                    display: block;
                    position: absolute;
                    top: 0.66rem;
                    left: 0;
                }

                &.draft:before {
                    background-color: ${color.indicatorOrange};
                }
                &.in-review:before,
                &.in-review-by-host:before {
                    background-color: ${color.indicatorYellow};
                }
                &.ready:before {
                    background-color: ${color.indicatorBlue};
                }
            }
        }

        .listing-controls {
            position: absolute;
            width: auto;
            right: 0;
            top: 50%;
            transform: translateY(-50%);

            button {
                width: 8rem;
                margin: 0.25rem;
                padding: 1rem;
            }
        }
    }
`;
