import React from "react";
import styled from "styled-components";
import { inject, observer } from "mobx-react";

import { IHostDashboardStore } from "../../store";
import { RouterLink, Badge, StyledBadge, Container, subNavHeight } from "../../components";
import { color } from "../../variables";

type Props = IHostDashboardStore;

@inject("hostDashboardState")
@observer
export default class HostDashboardNavigation extends React.Component<Props> {
    navElem: React.RefObject<any> = React.createRef();

    componentDidMount() {
        window.addEventListener("scroll", this.handleScroll);
    }

    componentWillUnmount() {
        window.removeEventListener("scroll", this.handleScroll);
    }

    handleScroll = (_e: any) => {
        if (window.pageYOffset > 0) {
            this.navElem.current.classList.add("scroll");
        } else {
            this.navElem.current.classList.remove("scroll");
        }
    };

    render() {
        const tabs = [
            {
                children: (
                    <>
                        Inbox
                        <Badge count={this.props.hostDashboardState!.unreadCount} />
                    </>
                ),
                to: "/dash/inbox"
            },
            {
                label: "Reservations",
                to: "/dash/reservations"
            },
            {
                label: "Calendar",
                to: "/dash/calendar"
            },
            {
                label: "Listings",
                to: "/dash/listings"
            }
        ];
        let tabLinks = tabs.map((tab, i) => {
            return <RouterLink {...tab} key={i} />;
        });
        return (
            <StyledHostDashboardNavigation ref={this.navElem}>
                <div className="tab-container">
                    <Container size="md">{tabLinks}</Container>
                </div>
                <div className="spacer" />
            </StyledHostDashboardNavigation>
        );
    }
}

const StyledHostDashboardNavigation = styled.div`
    display: block;
    position: relative;

    .tab-container {
        display: flex;
        flex-direction: row;
        position: fixed;
        z-index: 100;
        width: 100%;
        background-color: ${color.pureWhite};
        border-bottom: 0.0625rem solid #efefef;
        padding: 0 2rem;

        .container {
            display: inherit;
            align-self: center;
            height: 100%;

            .router-link {
                display: block;
                padding: 0 1.5rem;
                margin: 0 0.25rem;
                height: 100%;
                line-height: ${subNavHeight};
                border-bottom: 0.0625rem solid transparent;
                color: ${color.blackInk};
                transition: border 0.125s linear, color 0.125s linear;

                &:first-child {
                    margin-left: 0;
                }
                &:last-child {
                    margin-right: 0;
                }

                &.active {
                    color: ${color.primary};

                    :hover {
                        border-bottom: 0.25rem solid ${color.primaryDark};
                    }
                }

                :hover {
                    color: ${color.dark};
                    background-color: transparent;
                    border-bottom: 0.25rem solid ${color.dark};

                    &.active {
                        color: ${color.primary};
                        border-color: ${color.primary};
                    }

                    ${StyledBadge} {
                        background-color: ${color.primary};
                    }
                }
            }
        }
    }

    .spacer {
        position: relative;
        display: block;
    }

    .tab-container,
    .spacer {
        height: ${subNavHeight};
    }

    &.scroll {
        background-color: ${color.pureWhite};
        border-bottom-color: #efefef;
    }
`;
