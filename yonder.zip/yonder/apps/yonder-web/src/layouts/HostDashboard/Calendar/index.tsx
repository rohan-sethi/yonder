import React from "react";
import styled from "styled-components";

import { Page, Section, withHostAuthorization } from "../../../components";
import HostDashboardNavigation from "../HostDashboardNavigation";

class HostDashboardCalendar extends React.Component {
    render() {
        return (
            <Page noTransition>
                <HostDashboardNavigation />
                <Section>
                    <StyledHostDashboardCalendar>Calendar</StyledHostDashboardCalendar>
                </Section>
            </Page>
        );
    }
}

const StyledHostDashboardCalendar = styled.div`
    display: block;
`;

export default withHostAuthorization(HostDashboardCalendar);
