import React from "react";
import styled from "styled-components";
import { Redirect } from "react-router-dom";
import { observer, inject } from "mobx-react";
import { getSectionProgressKey, SectionProgress, ListingProgress, UserPermissions } from "@yonder/db";

import {
    Page,
    EditNavigationFrame,
    navHeight,
    withHostAuthorization,
    IEditNavigationOption,
    FullPageSpinner
} from "../../../components";
//import HostDashboardNavigation from "../HostDashboardNavigation";
import { IAddPropertyStore, IFirebaseStore } from "../../../store";
import { history } from "../../../history";
import { LayoutPageNotFound } from "../../PageNotFound";

type Props = IAddPropertyStore & IFirebaseStore;

@inject("addPropertyState", "firebaseState")
@observer
class HostDashboardAddProperty extends React.Component<Props> {
    baseUrl: string = "";
    slug: string = "";
    mapKeys = Object.keys(this.props.addPropertyState!.options.map);
    currentOption: IEditNavigationOption = {
        label: "",
        component: null,
        layout: "small"
    };

    onOptionClick = (slug: string) => {
        this.slug = slug;
        history.push(this.baseUrl + slug);
        this.setSection(slug);
    };

    setSection = (slug: string) => {
        const { options, property, saveNextRoute } = this.props.addPropertyState!;
        this.currentOption = options.map[slug];

        const keys: string[] = Object.keys(options.map);
        const nextIndex: number = keys.indexOf(slug) + 1;
        const section: string = getSectionProgressKey(this.currentOption.label);
        const nextRoute: string = keys[nextIndex];
        saveNextRoute(section, this.baseUrl + nextRoute);

        if (slug === "finish") return;

        // Initialize the section progress if it hasn't already been done.
        const sectionKey: string = getSectionProgressKey(this.currentOption.label);
        if (property.sectionProgress[sectionKey] === undefined) {
            property.sectionProgress[sectionKey] = SectionProgress.Started;
            property.listingProgress = ListingProgress.Draft;
        }
    };

    render() {
        // Assumes /dash/listings/stays/:id/:slug
        let pathname = window.location.pathname.split("/");
        const id = pathname[4];
        const slug = pathname[5];
        pathname[5] = "";
        this.baseUrl = pathname.join("/");

        if (slug !== "" && slug !== undefined) {
            if (!this.mapKeys.includes(slug)) {
                return <LayoutPageNotFound />;
            }
        } else {
            return <Redirect to={this.baseUrl + this.mapKeys[0]} />;
        }

        const { options, property, createOrLoadProperty, isLoading } = this.props.addPropertyState!;
        const { dbUser, dbOrganization } = this.props.firebaseState!;

        if (!dbOrganization.propertyIds.includes(id) && dbUser.permissions !== UserPermissions.Admin) {
            return <Redirect to="/dash/listings" />;
        }

        if (property.id !== id) {
            createOrLoadProperty(id);
            return <FullPageSpinner />;
        }

        if (isLoading) {
            return <FullPageSpinner />;
        }

        if (this.slug !== slug) {
            this.slug = slug;
            this.setSection(slug);
        }

        return (
            <Page>
                {/*<HostDashboardNavigation />*/}
                <Styles>
                    <EditNavigationFrame
                        label="Creating New Stay"
                        currentOption={this.currentOption}
                        options={options.map}
                        activeTab={this.slug}
                        onOptionClick={this.onOptionClick}
                        sectionProgress={property.sectionProgress}
                    />
                </Styles>
            </Page>
        );
    }
}

const Styles = styled.div`
    display: block;
    height: calc(100vh - (${navHeight}));
`;

export default withHostAuthorization(HostDashboardAddProperty);
