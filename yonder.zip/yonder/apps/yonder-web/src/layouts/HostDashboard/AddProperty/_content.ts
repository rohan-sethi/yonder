import { EditNavigationMap } from "../../../components/EditNavigation";
import {
    AddPropertyAmenities,
    AddPropertyBathrooms,
    AddPropertyBedrooms,
    AddPropertyDescription,
    AddPropertyOverview,
    AddPropertyPhotos,
    AddPropertyPolicy,
    AddPropertyPricing,
    AddPropertyRules,
    AddPropertyExperienceCategories,
    AddPropertyActivities,
    AddPropertyFinish,
    AddPropertyFacts,
    AddPropertyCertifications,
    PropertyPricingAlerts
    //AddPropertyKeywords,
} from "../../Forms/AddProperty";
//import { BusinessCategories } from "../../../components";
/*import {
    TellUsAboutYourBusiness,
    ApprovalLetsBegin,
    ApprovalAccommodationType,
    ApprovalActivities,
    ApprovalCertifications,
    ApprovalExperienceCategory,
    ApprovalLocation,
    ApprovalDescription,
    ApprovalPhotoUpload,
    ApprovalKeywords,
    ApprovalFinish,
    ApprovalStays,
    ApprovalMakingProgress
} from "../../Forms/SubmissionApproval";*/

export type AddPropertyOptions = {
    length: number;
    map: EditNavigationMap;
};

// prettier-ignore
const _options: EditNavigationMap = {
    "experience-category": {
        label: "Experience Categories",
        component: AddPropertyExperienceCategories,
        layout: "small"
    },
    "stay-overview": {
        label: "Stay Overview",
        component: AddPropertyOverview,
        layout: "small"
    },
    // Sleeping Arrangements
    "bedrooms": {
        label: "Bedrooms",
        component: AddPropertyBedrooms,
        layout: "small"
    },
    "bathrooms": {
        label: "Bathrooms",
        component: AddPropertyBathrooms,
        layout: "small"
    },
    "pricing": {
        label: "Pricing",
        alerts: PropertyPricingAlerts,
        component: AddPropertyPricing,
        layout: "small"
    },
    "booking-options": {
        label: "Booking Options",
        component: AddPropertyPolicy,
        layout: "small"
    },
    "rules-and-safety": {
        label: "Rules and Safety",
        component: AddPropertyRules,
        layout: "large"
    },
    "property-story": {
        label: "Property Story",
        component: AddPropertyDescription,
        layout: "medium"
    },
    "photos": {
        label: "Photos",
        component: AddPropertyPhotos,
        layout: "large"
    },
    // Availability
    "amenities": {
        label: "Amenities",
        component: AddPropertyAmenities,
        layout: "small"
    },
    "property-facts": {
        label: "Property Facts",
        component: AddPropertyFacts,
        layout: "small"
    },
    "certifications-and-sustainability": {
        label: "Sustainability Efforts",
        component: AddPropertyCertifications,
        layout: "small"
    },
    /*{
        label: "Keywords",
        component: AddPropertyKeywords,
        layout: "small"
    }*/
    "activities": {
        label: "Activities",
        component: AddPropertyActivities,
        layout: "small"
    },
    "finish": {
        label: "Finish and Submit",
        component: AddPropertyFinish,
        layout: "small"
    }
};

/*
TODO: Make some kind of "Debug" or "Dev" menu in the future for this kind of thing
const submissionApprovalOptions: IEditNavigationOption[] = [
    // TODO:
    // Submission Approval
    // (Temporary until these forms have a home)
    {
        label: "Let us get to know you!",
        component: TellUsAboutYourBusiness,
        layout: "small"
    },
    {
        label: "Let's Get Started",
        component: ApprovalLetsBegin,
        layout: "small"
    },
    {
        label: "Host Type",
        component: ApprovalExperienceCategory,
        layout: "small"
    },
    {
        label: "Overnight Stays",
        component: ApprovalStays,
        layout: "small"
    },
    {
        label: "Accommodation Type",
        component: ApprovalAccommodationType,
        layout: "small"
    },
    {
        label: "Activities",
        component: ApprovalActivities,
        layout: "small"
    },
    {
        label: "Location",
        component: ApprovalLocation,
        layout: "small"
    },
    {
        label: "Property Description",
        component: ApprovalDescription,
        layout: "small"
    },
    {
        label: "Certificates",
        component: ApprovalCertifications,
        layout: "small"
    },
    {
        label: "Photos",
        component: ApprovalPhotoUpload,
        layout: "small"
    },
    {
        label: "Environmental Attributes",
        component: ApprovalKeywords,
        layout: "small"
    },
    {
        label: "Finish",
        component: ApprovalFinish,
        layout: "small"
    },
    {
        label: "Making Progress",
        component: ApprovalMakingProgress,
        layout: "small"
    }
];*/

const options: AddPropertyOptions = {
    length: Object.keys(_options).length,
    map: _options
};

export default options;
