import React from "react";
import styled from "styled-components";

import { Page, Section, withHostAuthorization } from "../../../components";
import HostDashboardNavigation from "../HostDashboardNavigation";

type Props = {
    children?: React.ReactNode;
};

export class HostDashboardReservations extends React.Component<Props> {
    render() {
        return (
            <Page noTransition>
                <HostDashboardNavigation />
                <Section>
                    <StyledHostDashboardReservations>Reservations</StyledHostDashboardReservations>
                </Section>
            </Page>
        );
    }
}

const StyledHostDashboardReservations = styled.div`
    display: block;
`;

export default withHostAuthorization(HostDashboardReservations);
