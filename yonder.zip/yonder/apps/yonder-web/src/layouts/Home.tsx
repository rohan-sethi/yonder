import React from "react";
import styled from "styled-components";
import { inject, observer } from "mobx-react";
import { Redirect } from "react-router-dom";
import { UserPermissions, HostTypes } from "@yonder/db";

import { Page, Section } from "../components";
import { SignUpForm } from "./Forms";
import { color, html } from "../variables";
import { IFirebaseStore } from "../store";

const backgroundHeight = 44;
const backgroundHeightPixels = html.fontSize * 26; // about where the top of sign-up form is

type Props = IFirebaseStore;

@inject("firebaseState")
@observer
export class LayoutHome extends React.Component<Props> {
    render() {
        const { isSignedIn, dbUser } = this.props.firebaseState!;

        if (isSignedIn) {
            if (dbUser.permissions === UserPermissions.Admin) {
                return <Redirect to="/admin" />;
            } else if (dbUser.permissions === UserPermissions.Host) {
                return <Redirect to="/dash/listings" />;
            }

            if (dbUser.hostType === HostTypes.PropertyManagement) {
                return <Redirect to="/new-mgmt" />;
            }

            return <Redirect to="/new-host" />;
        }
        return (
            <Page swapNavStyleAt={backgroundHeightPixels} clearNavigation showFooter>
                <StyledHome>
                    <Background style={{ backgroundImage: "url(/img/cabin-on-lake-bg.jpg)" }} />
                    <Section>
                        <div className="yonder-headline">
                            <img className="yonder-logo" src="/img/yonder-minimal-light.svg" alt="yonder logo" />
                        </div>
                        <div className="sign-up-container">
                            <SignUpForm />
                        </div>
                        <div className="bottom-cta">
                            <h1>We are grounded in one purpose</h1>
                            <p>
                                To create a harmonious world by connecting people to experiences in nature. We believe
                                that nature, and the benefits it offers, are critically important to the survival of us
                                all– people, plants, and animals alike.
                            </p>
                        </div>
                    </Section>
                </StyledHome>
            </Page>
        );
    }
}

const StyledHome = styled.div`
    display: block;
    position: relative;
    margin: 0;
    background: #f9f9f9;

    .section {
        position: relative;
        z-index: 5;
        width: 100%;
        height: auto;
    }

    .yonder-headline {
        margin: 8rem 0 5rem;

        .yonder-logo {
            display: block;
            margin: 0rem auto;
            margin-bottom: 2rem;
        }

        p {
            text-align: center;
        }
    }

    .sign-up-container {
        background: ${color.pureWhite};
        padding: 0 1rem;
        max-width: 41rem;
        margin: 0 auto;

        .signup-form {
            border-radius: 0.125rem;
            max-width: 30rem;
            margin: 3rem auto;
            padding: 3rem 2rem;
        }
    }

    .bottom-cta {
        margin-top: 1.5rem;
        margin-bottom: 3rem;

        h1 {
            text-align: center;
            margin-bottom: 1rem;
        }

        p {
            font-size: 1.125rem;
            line-height: 1.5;
            max-width: 58rem;
            margin: 0 auto;
        }
    }
`;

const Background = styled.div`
    display: block;
    position: absolute;
    background-size: cover;
    background-repeat: no-repeat;
    background-position: 50% 80%;
    width: 100%;
    height: ${backgroundHeight}rem;
`;
