import React from "react";
import styled from "styled-components";
import { inject, observer } from "mobx-react";
import { Redirect } from "react-router-dom";
import { HostApprovalSubmissionProgress, UserPermissions, HostTypes } from "@yonder/db";

import { Page, Section, StepCounter, FullPageSpinner } from "../../components";
import {
    ApprovalFinish,
    ApprovalMakingProgress,
    ApprovalHostOrGuest,
    ApprovalThanksForInterest
} from "../Forms/SubmissionApproval";
import { IFirebaseStore, IHostApprovalSubmissionStore } from "../../store";

export type ProgressMap = {
    [id: string]: {
        step?: number;
        route: React.ReactChild;
    };
};

export type PropsNewHostLayout = {
    progressMap: ProgressMap;
    maxProgress: number;
};

type Props = IFirebaseStore & IHostApprovalSubmissionStore & PropsNewHostLayout;

@inject("firebaseState", "hostApprovalSubmissionState")
@observer
class NewHostLayout extends React.Component<Props> {
    from: number = 0;
    to: number = 0;
    max: number = this.props.maxProgress;
    initializing: boolean = false;
    progress?: HostApprovalSubmissionProgress = undefined;

    init = async () => {
        const { dbUser, dbOrganization, saveOrganization } = this.props.firebaseState!;
        const { createOrLoadApproval } = this.props.hostApprovalSubmissionState!;
        this.initializing = true;
        //console.log("initializing host approval submission store. Should only trigger once per session...");
        await createOrLoadApproval(
            saveOrganization,
            dbOrganization.approvalSubmissionId,
            dbOrganization.approvalSubmissionProgress,
            dbUser.hostType === HostTypes.PropertyManagement
        );
    };

    checkForInit = () => {
        const { dbOrganization } = this.props.firebaseState!;
        const { dbHostApprovalSubmission } = this.props.hostApprovalSubmissionState!;
        const orgDefined: boolean = dbOrganization.id !== undefined;
        const initNeeded: boolean = orgDefined && dbHostApprovalSubmission.id === undefined;
        if (initNeeded) {
            if (!this.initializing) this.init();
        }
    };

    componentDidMount() {
        this.checkForInit();
    }

    componentDidUpdate() {
        this.checkForInit();
    }

    submissionProgressAsNumber = (): number => {
        this.from = this.to;

        const { dbOrganization } = this.props.firebaseState!;

        if (
            !dbOrganization.approvalSubmissionProgress ||
            !this.props.progressMap[dbOrganization.approvalSubmissionProgress]
        )
            return 0;

        return this.props.progressMap[dbOrganization.approvalSubmissionProgress].step || 0;
    };

    renderPage = () => {
        const { dbOrganization, dbUser } = this.props.firebaseState!;
        const { showMakingProgress } = this.props.hostApprovalSubmissionState!;
        if (showMakingProgress) {
            return <ApprovalMakingProgress />;
        }

        if (dbUser.hostType === HostTypes.Guest) return <ApprovalThanksForInterest />;

        if (dbOrganization.approvalSubmissionProgress === undefined) return <ApprovalHostOrGuest />;

        if (this.props.progressMap[dbOrganization.approvalSubmissionProgress] === undefined) return <ApprovalFinish />;

        return this.props.progressMap[dbOrganization.approvalSubmissionProgress].route;
    };

    render() {
        const { authUser, dbUser, dbOrganization, isSignedIn } = this.props.firebaseState!;
        if (!isSignedIn || dbUser.permissions === UserPermissions.Host) {
            return <Redirect to="/" />;
        }

        const {
            dbHostApprovalSubmission,
            showMakingProgress,
            isLoading: approvalLoading
        } = this.props.hostApprovalSubmissionState!;
        // NOTE: dbHostApprovalSubmission doesn't exist until after TellUsAboutYourBusiness
        const orgDefined: boolean = dbOrganization.id !== undefined;
        const initNeeded: boolean = orgDefined && dbHostApprovalSubmission.id === undefined;

        if (!authUser || approvalLoading || initNeeded) {
            return <FullPageSpinner />;
        }

        this.to = this.submissionProgressAsNumber();
        if (this.progress !== dbOrganization.approvalSubmissionProgress) {
            // make sure IE works!
            if (window.scrollTo) {
                window.scrollTo(0, 0);
            }

            this.progress = dbOrganization.approvalSubmissionProgress;
        }

        const renderStepCounter: boolean = this.to !== 0 && !showMakingProgress;

        return (
            <Page>
                <Section>
                    <StyledNewHostLayout>
                        {renderStepCounter && (
                            <StepCounter
                                label={`Step ${this.to} of ${this.max}`}
                                from={this.from}
                                to={this.to}
                                max={this.max}
                            />
                        )}
                        {this.renderPage()}
                    </StyledNewHostLayout>
                </Section>
            </Page>
        );
    }
}

export { NewHostLayout };

const StyledNewHostLayout = styled.div`
    margin: 0 auto;
    max-width: 26rem;
`;
