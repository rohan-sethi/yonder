import React from "react";
import { HostApprovalSubmissionProgress } from "@yonder/db";

import {
    ApprovalActivities,
    ApprovalExperienceCategory,
    ApprovalLocation,
    ApprovalDescription,
    ApprovalCertifications,
    ApprovalStays
} from "../Forms/SubmissionApproval";
import { ProgressMap, NewHostLayout, PropsNewHostLayout } from "./NewHostLayout";
import { withAuthorization } from "../../components";

const progressMap: ProgressMap = {
    [HostApprovalSubmissionProgress.ExperienceCategory]: {
        step: 1,
        route: <ApprovalExperienceCategory />
    },
    [HostApprovalSubmissionProgress.OvernightStays]: {
        step: 2,
        route: <ApprovalStays />
    },
    [HostApprovalSubmissionProgress.Activities]: {
        step: 3,
        route: <ApprovalActivities />
    },
    [HostApprovalSubmissionProgress.Location]: {
        step: 4,
        route: <ApprovalLocation />
    },
    [HostApprovalSubmissionProgress.Description]: {
        step: 5,
        route: <ApprovalDescription />
    },
    [HostApprovalSubmissionProgress.Certificate]: {
        step: 6,
        route: <ApprovalCertifications />
    }
};

const props: PropsNewHostLayout = {
    progressMap,
    maxProgress: 6
};

export const HostRouteNormal = withAuthorization(NewHostLayout, props);
