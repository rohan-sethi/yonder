import React from "react";
import { HostApprovalSubmissionProgress } from "@yonder/db";

import { ApprovalActivities, ApprovalLocation, ApprovalCertifications } from "../Forms/SubmissionApproval";
import { ProgressMap, NewHostLayout, PropsNewHostLayout } from "./NewHostLayout";
import { withAuthorization } from "../../components";
import { MgmtApprovalDescription, MgmtApprovalStays } from "../Forms/MgmtApproval";

const progressMap: ProgressMap = {
    [HostApprovalSubmissionProgress.OvernightStays]: {
        step: 1,
        route: <MgmtApprovalStays />
    },
    [HostApprovalSubmissionProgress.Activities]: {
        step: 2,
        route: (
            <ApprovalActivities managementHostActivityDescriptor="Do you host or offer any bookable activities on your properties?" />
        )
    },
    [HostApprovalSubmissionProgress.Location]: {
        step: 3,
        route: <ApprovalLocation />
    },
    [HostApprovalSubmissionProgress.Description]: {
        step: 4,
        route: <MgmtApprovalDescription />
    },
    [HostApprovalSubmissionProgress.Certificate]: {
        step: 5,
        route: (
            <ApprovalCertifications
                managementHostCertificationsDescriptor="Do any of your properties have the following certifications or sustainability efforts?"
                sustainabilityEffortsDescriptor={false}
            />
        )
    }
};

const props: PropsNewHostLayout = {
    progressMap,
    maxProgress: 5
};

export const HostRouteMgmt = withAuthorization(NewHostLayout, props);
