import React from "react";
import { inject, observer } from "mobx-react";
import styled from "styled-components";

import { IFirebaseStore } from "../../store";
import { Page, withAuthorization, FormGroup, Section } from "../../components";
import { /*EmailChangeForm, */ PasswordChangeForm } from "../Forms";

type Props = IFirebaseStore;

@inject("firebaseState")
@observer
class AccountSettings extends React.Component<Props> {
    render() {
        return (
            <Page>
                <Section>
                    <StyledAccountSettings>
                        <h2>Log In & Security</h2>
                        <p>View and update your login info</p>

                        {/*}
                        <FormGroup>
                            <EmailChangeForm />
                        </FormGroup>
                        {*/}

                        <FormGroup>
                            <PasswordChangeForm />
                        </FormGroup>
                    </StyledAccountSettings>
                </Section>
            </Page>
        );
    }
}

export default withAuthorization(AccountSettings);

const StyledAccountSettings = styled.div`
    margin: 0 auto;
    max-width: 30rem;

    h2 {
        margin-bottom: 3rem;
    }
`;
