import React from "react";
import styled from "styled-components";
import { inject, observer } from "mobx-react";
//import { Elements } from "react-stripe-elements";

import { Page, withAuthorization, FormGroup, Section } from "../../components";
import {
    ProfileInfoForm
    //PaymentForm
} from "../Forms";
import { ProfilePhotoUpload } from ".";
import { IFirebaseStore } from "../../store";
import { HostTypes } from "@yonder/db";

type Props = IFirebaseStore;

@inject("firebaseState")
@observer
class UserProfile extends React.Component<Props> {
    render() {
        const { hostType } = this.props.firebaseState!.dbUser;
        const profileLabel = hostType === HostTypes.Guest ? "Profile" : "Host Profile";
        return (
            <Page>
                <Section>
                    <StyledUserProfile>
                        <h2>{profileLabel}</h2>
                        <ProfilePhotoUpload />
                        <FormGroup>
                            <ProfileInfoForm />
                        </FormGroup>
                        {/*<FormGroup>
                            <h2>My Cards</h2>
                            <Elements>
                                <PaymentForm />
                            </Elements>
                        </FormGroup>*/}
                    </StyledUserProfile>
                </Section>
            </Page>
        );
    }
}

const StyledUserProfile = styled.div`
    margin: 0 auto;
    max-width: 30rem;
`;

export default withAuthorization(UserProfile);
//export default UserProfile;
