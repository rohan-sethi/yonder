import React from "react";
import styled from "styled-components";

import { Page, withAuthorization, Section } from "../../components";
import { MyBusinessForm } from "../Forms";
import { IFirebaseStore } from "../../store";
import { inject, observer } from "mobx-react";
import { HostTypes } from "@yonder/db";
import { Redirect } from "react-router";

type Props = IFirebaseStore;
@inject("firebaseState")
@observer
class MyBusiness extends React.Component<Props> {
    render() {
        const { hostType } = this.props.firebaseState!.dbUser;

        if (hostType === HostTypes.Guest) {
            return <Redirect to="/profile" />;
        }

        return (
            <Page>
                <Section>
                    <StyledMyBusiness>
                        <MyBusinessForm />
                    </StyledMyBusiness>
                </Section>
            </Page>
        );
    }
}

export default withAuthorization(MyBusiness);

const StyledMyBusiness = styled.div`
    margin: 0 auto;
    max-width: 30rem;
`;
