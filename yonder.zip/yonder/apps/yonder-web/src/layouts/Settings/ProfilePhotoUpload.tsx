import React from "react";
import { inject, observer } from "mobx-react";
import styled from "styled-components";

import { IFirebaseStore, IUserPhotoUploadStore } from "../../store";
import { Avatar, FormChangeEvent, LoadingSpinner } from "../../components";
import { UploadCallback } from "../../store/UserPhotoUploadState";
import { color, thin } from "../../variables";

type Props = IFirebaseStore & IUserPhotoUploadStore;
type State = {
    profilePhotoLoading: boolean;
    fileTypeError: { message?: string };
};

@inject("firebaseState", "userPhotoUploadState")
@observer
export class ProfilePhotoUpload extends React.Component<Props, State> {
    fileInputRef = React.createRef<HTMLInputElement>();
    state = {
        profilePhotoLoading: false,
        fileTypeError: {
            message: undefined
        }
    };

    openFileDialog = () => {
        this.fileInputRef.current!.click();
    };

    onChange = (ev: FormChangeEvent) => {
        //list of files containing only the one allowed image
        const fileList = ev.target.files;
        const imageFormats = ["image/png", "image/jpeg", "image/gif"];
        this.setState({
            fileTypeError: {
                message: undefined
            }
        });

        if (fileList.length === 1) {
            if (imageFormats.every((type) => fileList.item(0).type !== type)) {
                this.setState({
                    fileTypeError: {
                        message: `${fileList.item(0).type} is not a supported format`
                    }
                });
                return console.log(this.state.fileTypeError.message);
            }

            this.setState({
                profilePhotoLoading: true
            });
            this.addFile(fileList);

            // this ensures onChange gets triggered again if the same file(s) are chosen
            ev.target.value = null;
        }
    };

    addFile = (files: FileList) => {
        const { firebase } = this.props.firebaseState!;
        const { uploadFile } = this.props.userPhotoUploadState!;
        if (files.length === 1) {
            let imageFile = files.item(0);
            //sets progress, adds file to db, fires callback
            uploadFile(imageFile!, firebase, this.onUpload);
        }
    };

    onUpload: UploadCallback = async (url: string) => {
        const { saveUserProfile } = this.props.firebaseState!;
        //updates user object profile image by setting user's photoUrl to url of image previously added to db
        saveUserProfile({
            photoURL: url
        });

        this.setState({
            profilePhotoLoading: false
        });
    };

    render() {
        const { dbUser, authUser } = this.props.firebaseState!;
        const { profilePhotoLoading } = this.state;

        return (
            <StyledProfilePhotoUpload>
                <div className="image-wrapper">
                    <div className="profile-image" onClick={this.openFileDialog}>
                        {profilePhotoLoading ? (
                            <LoadingSpinner size={2} />
                        ) : (
                            <Avatar
                                file={dbUser.photoURL || ""}
                                text={dbUser.photoURL ? "" : authUser!.displayInitials}
                                title="Profile"
                                background="#eee"
                            />
                        )}
                    </div>
                    <input
                        className="file-input"
                        type="file"
                        accept="image/*"
                        id="avatar-upload"
                        ref={this.fileInputRef}
                        onChange={this.onChange}
                    />
                    <div className="button edit-button" onClick={this.openFileDialog}>
                        Update photo
                    </div>
                </div>
            </StyledProfilePhotoUpload>
        );
    }
}

const StyledProfilePhotoUpload = styled.div`
    display: flex;
    flex-direction: column;
    margin: 0 auto;
    max-width: 30rem;
    position: relative;

    .image-wrapper {
        display: block;
        margin: 4rem auto 1rem;
        align-self: center;
        align-items: center;

        .profile-image {
            height: 9rem;
            width: 9rem;
            border-radius: 50%;
            background: ${color.fog};
            overflow: hidden;
            border: ${thin} solid transparent;
            box-shadow: 0 0 0 0 ${color.pureWhite};
            transition: border-color 0.125s linear, box-shadow 0.125s linear;
            cursor: pointer;

            &:hover,
            &:active {
                border-color: ${color.primaryDark};
                box-shadow: 0 0 ${thin} 0 ${color.primaryDark};
            }
        }

        .file-input {
            opacity: 0;
            position: absolute;
            pointer-events: none;
            width: 1px;
            height: 1px;
        }

        .button {
            user-select: none;
            display: block;
            margin: auto;
            text-align: center;
            color: ${color.primary};
            cursor: pointer;
            transition: color 0.125s linear;

            &:hover,
            &:active {
                color: ${color.primaryDark};
            }
        }

        .edit-button {
            margin-top: 0.75rem;
            font-size: 0.875rem;
        }
    }
`;
