# Yonder

1. Install npm & yarn (yarn can be done via homebrew). Use sudo where applicable

2. In your home directory (~), create a new folder called "creds". Add firebase config json files (get contents from Andrew/Derek)
```
mkdir ~/creds
code ~/creds/firebase-testprojectone.json
code ~/creds/firestore-coastal-fiber.json
```

3. Edit ~/.bash_profile and add the following environment variable:
```
#!/bin/sh
export FURY_AUTH=(Get from Andrew/Derek)
```

4. Open yonder.code-workspace in VS Code. Then open yonder-api. Add a ".env" file with the following:
```
PORT=4000
DEVELOPMENT=true
GOOGLE_APPLICATION_CREDENTIALS="/Users/(you)/creds/firestore-testprojectone.json"
GCP_PROJECT=testprojectone
# GOOGLE_APPLICATION_CREDENTIALS="/Users/(you)/creds/firestore-coastal-fiber.json"
# GCP_PROJECT=coastal-fiber-224802
JWT_SECRET=(anything)
```

5. Open yonder-web. Add a ".env" file with the following:
```
PORT=3001
REACT_APP_FIREBASE_API_KEY=(get from Andrew/Derek)
REACT_APP_FIREBASE_PROJECT_ID=testprojectone
REACT_APP_FIREBASE_APP_ID=(get from Andrew/Derek)
REACT_APP_YONDER_API_URL=http://localhost:4000/api
REACT_APP_FILESTACK_API_KEY=(get from Andrew/Derek)
REACT_APP_GMAPS_API_KEY=(get from Andrew/Derek)
```

6. Open a terminal and run:
```
npm config set registry https://npm-proxy.fury.io/23horizonway/
npm config set always-auth true
npm login
```
7. Next, run:
```
npm i -g lerna typescript create-react-app
cd (where yonder was cloned)
yarn install
yarn start
```

8. You should have localhost:3001 open in the browser. It may not render the first time. If it doesn't, just hit refresh.

## Note

The "deprecated" folder is intended for projects that still have some value (to refer back to) but should be excluded from the yarn workspace (defined in "workspaces" within the package.json)
