import Express from "express";

import { GET, POST, PUT, PATCH, ROUTE, USE, DELETE, OPTIONS, HEAD, RouteType } from "./RouteType";
import { RouteFunction } from "./RouteFunctionTypes";
import { IRoute } from "./IRoute";

export const expandRoutes = (routes: IRoute[]): Express.Router => {
    let router = Express.Router();
    const handleRoute = (path: string, type: RouteType, handler: RouteFunction) => {
        switch (type) {
            case GET:
                router.get(path, handler);
                break;
            case POST:
                router.post(path, handler);
                break;
            case PUT:
                router.put(path, handler);
                break;
            case PATCH:
                router.patch(path, handler);
                break;
            case DELETE:
                router.delete(path, handler);
                break;
            case OPTIONS:
                router.options(path, handler);
                break;
            case HEAD:
                router.head(path, handler);
                break;
            case ROUTE:
            case USE:
                router.use(path, handler);
                break;
            default:
                throw new Error(`Invalid protocol type: ${type}`);
        }
    };

    for (let { path, type, handler } of routes) {
        if (type instanceof Array) {
            for (let t of type) {
                handleRoute(path, t, handler);
            }
        } else {
            handleRoute(path, type, handler);
        }
    }

    return router;
};
