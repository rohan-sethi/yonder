import { RouteType } from "./RouteType";
import { RouteFunction } from "./RouteFunctionTypes";

export interface IRoute {
    path: string;
    type: RouteType | RouteType[];
    handler: RouteFunction;
}
