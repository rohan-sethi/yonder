import { ApiPath } from "@yonder/db";

import { Booking } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesBooking: IRoute[] = [
    routeCreateOne(Booking),
    routeReadAll(Booking),
    routeReadOne(Booking),
    routeUpdateOne(Booking),
    routeDeleteOne(Booking)
];

export default {
    path: `/${ApiPath.Booking}`,
    type: ROUTE,
    handler: expandRoutes(routesBooking)
} as IRoute;
