import { ApiPath } from "@yonder/db";

import { PromoCode } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesPromoCode: IRoute[] = [
    routeCreateOne(PromoCode),
    routeReadAll(PromoCode),
    routeReadOne(PromoCode),
    routeUpdateOne(PromoCode),
    routeDeleteOne(PromoCode)
];

export default {
    path: `/${ApiPath.PromoCode}`,
    type: ROUTE,
    handler: expandRoutes(routesPromoCode)
} as IRoute;
