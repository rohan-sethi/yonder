import { ApiPath } from "@yonder/db";

import { GuestbookEntry } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesGuestbookEntry: IRoute[] = [
    routeCreateOne(GuestbookEntry),
    routeReadAll(GuestbookEntry),
    routeReadOne(GuestbookEntry),
    routeUpdateOne(GuestbookEntry),
    routeDeleteOne(GuestbookEntry)
];

export default {
    path: `/${ApiPath.GuestbookEntry}`,
    type: ROUTE,
    handler: expandRoutes(routesGuestbookEntry)
} as IRoute;
