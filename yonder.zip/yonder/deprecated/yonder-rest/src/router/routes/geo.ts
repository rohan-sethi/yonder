import Geonames from "geonames.js";

export async function geoCache() {
    const geonames = new Geonames({ username: "myusername", lan: "en", encoding: "JSON" });

    try {
        const countries = await geonames.countryInfo({}); //get continents

        let countriesCache: any[] = countries.geonames.map((item: any) => {
            return {
                id: item.geonameId,
                name: item.countryName,
                countryCode: item.countryCode,
                continent: item.continentName,
                currencyCode: item.currencyCode,
                languages: item.languages
                //capital: item.capital
            };
        });

        let unitedStatesId: number = 0;
        for (let country of countriesCache) {
            if (country.countryCode === "US") {
                console.log(country);
                unitedStatesId = country.id;
            }
        }

        const states = await geonames.children({ geonameId: unitedStatesId });
        let statesCache: any[] = states.geonames.map((item: any) => {
            return {
                id: item.geonameId,
                name: item.name,
                countryId: Number(item.countryId),
                stateCode: item.adminCode1
                //lat: item.lat,
                //lng: item.lng
                //capital: item.capital
            };
        });

        console.log(statesCache[0]);

        // Probably don't need county/city information (would lead to a huge cache)

        let state = statesCache[0];
        const counties = await geonames.children({ geonameId: state.id });
        let countiesCache: any[] = counties.geonames.map((item: any) => {
            return {
                id: item.geonameId,
                name: item.name,
                toponymName: item.toponymName,
                stateId: state.id,
                state: item.adminCode1
            };
        });

        console.log(countiesCache[0]);

        let county = countiesCache[0];
        const cities = await geonames.children({ geonameId: county.id });
        let citiesCache: any[] = cities.geonames.map((item: any) => {
            return {
                id: item.geonameId,
                name: item.name,
                toponymName: item.toponymName,
                countyId: county.id,
                state: item.adminCode1,
                stateId: state.id
            };
        });

        console.log(citiesCache[0]);

        return {
            usStates: statesCache,
            alabamaCities: citiesCache,
            countriesCache
        };
    } catch (err) {
        console.error(err);
        return {
            error: "Something went wrong. Check console."
        };
    }
}
/*
    continent: 'EU',
    capital: 'Budapest',
    languages: 'hu-HU',
    geonameId: 719819,
    south: 45.7370495590001,
    isoAlpha3: 'HUN',
    north: 48.585336,
    fipsCode: 'HU',
    population: '9982000',
    east: 22.896564336,
    isoNumeric: '348',
    areaInSqKm: '93030.0',
    countryCode: 'HU',
    west: 16.113795,
    countryName: 'Hungary',
    continentName: 'Europe',
    currencyCode: 'HUF' },
*/
/*
    'astergdem',
    'children',
    'cities',
    'contains',
    'countryCode',
    'countryInfo',
    'countrySubdivision',
    'earthquakes',
    'extendedFindNearby',
    'findNearby',
    'findNearbyPlaceName',
    'findNearbyPostalCodes',
    'findNearbyStreets', //only USA
    'findNearbyStreetsOSM',
    'findNearByWeather',
    'findNearbyWikipedia',
    'findNearestAddress', //only USA
    'findNearestIntersection', //only USA
    'findNearestIntersectionOSM',
    'findNearbyPOIsOSM',
    'geocode', //only USA
    'get',
    'gtopo30',
    'hierarchy',
    'neighbourhood', //only USA
    'neighbours',
    'ocean',
    'postalCodeCountryInfo',
    'postalCodeLookup',
    'postalCodeSearch',
    'rssToGeo',
    'search',
    'siblings',
    'srtm1',
    'srtm3',
    'timezone',
    'weather',
    'weatherIcao',
    'wikipediaBoundingBox',
    'wikipediaSearch'
*/
