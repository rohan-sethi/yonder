import { ApiPath } from "@yonder/db";

import { BookingTransaction } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesBookingTransaction: IRoute[] = [
    routeCreateOne(BookingTransaction),
    routeReadAll(BookingTransaction),
    routeReadOne(BookingTransaction),
    routeUpdateOne(BookingTransaction),
    routeDeleteOne(BookingTransaction)
];

export default {
    path: `/${ApiPath.BookingTransaction}`,
    type: ROUTE,
    handler: expandRoutes(routesBookingTransaction)
} as IRoute;
