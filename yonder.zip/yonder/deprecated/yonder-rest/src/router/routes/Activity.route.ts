import { ApiPath } from "@yonder/db";

import { Activity } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesActivity: IRoute[] = [
    routeCreateOne(Activity),
    routeReadAll(Activity),
    routeReadOne(Activity),
    routeUpdateOne(Activity),
    routeDeleteOne(Activity)
];

export default {
    path: `/${ApiPath.Activity}`,
    type: ROUTE,
    handler: expandRoutes(routesActivity)
} as IRoute;
