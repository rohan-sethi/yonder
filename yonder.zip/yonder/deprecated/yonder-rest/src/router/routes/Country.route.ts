import { ApiPath } from "@yonder/db";

import { Country } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesCountry: IRoute[] = [
    routeCreateOne(Country),
    routeReadAll(Country),
    routeReadOne(Country),
    routeUpdateOne(Country),
    routeDeleteOne(Country)
];

export default {
    path: `/${ApiPath.Country}`,
    type: ROUTE,
    handler: expandRoutes(routesCountry)
} as IRoute;
