import { ApiPath } from "@yonder/db";

import { Accommodation } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesAccommodation: IRoute[] = [
    routeCreateOne(Accommodation),
    routeReadAll(Accommodation),
    routeReadOne(Accommodation),
    routeUpdateOne(Accommodation),
    routeDeleteOne(Accommodation)
];

export default {
    path: `/${ApiPath.Accommodation}`,
    type: ROUTE,
    handler: expandRoutes(routesAccommodation)
} as IRoute;
