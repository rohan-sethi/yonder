import { ApiPath } from "@yonder/db";

import { User } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesUser: IRoute[] = [
    routeCreateOne(User),
    routeReadAll(User),
    routeReadOne(User),
    routeUpdateOne(User),
    routeDeleteOne(User)
];

export default {
    path: `/${ApiPath.User}`,
    type: ROUTE,
    handler: expandRoutes(routesUser)
} as IRoute;
