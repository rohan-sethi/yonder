import { ApiPath } from "@yonder/db";

import { Location } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesLocation: IRoute[] = [
    routeCreateOne(Location),
    routeReadAll(Location),
    routeReadOne(Location),
    routeUpdateOne(Location),
    routeDeleteOne(Location)
];

export default {
    path: `/${ApiPath.Location}`,
    type: ROUTE,
    handler: expandRoutes(routesLocation)
} as IRoute;
