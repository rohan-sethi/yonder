import { ApiPath } from "@yonder/db";

import { PropertyPhoto } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesPropertyPhoto: IRoute[] = [
    routeCreateOne(PropertyPhoto),
    routeReadAll(PropertyPhoto),
    routeReadOne(PropertyPhoto),
    routeUpdateOne(PropertyPhoto),
    routeDeleteOne(PropertyPhoto)
];

export default {
    path: `/${ApiPath.PropertyPhoto}`,
    type: ROUTE,
    handler: expandRoutes(routesPropertyPhoto)
} as IRoute;
