import { ApiPath } from "@yonder/db";

import { City } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesCity: IRoute[] = [
    routeCreateOne(City),
    routeReadAll(City),
    routeReadOne(City),
    routeUpdateOne(City),
    routeDeleteOne(City)
];

export default {
    path: `/${ApiPath.City}`,
    type: ROUTE,
    handler: expandRoutes(routesCity)
} as IRoute;
