import { ApiPath } from "@yonder/db";

import { Medal } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesMedal: IRoute[] = [
    routeCreateOne(Medal),
    routeReadAll(Medal),
    routeReadOne(Medal),
    routeUpdateOne(Medal),
    routeDeleteOne(Medal)
];

export default {
    path: `/${ApiPath.Medal}`,
    type: ROUTE,
    handler: expandRoutes(routesMedal)
} as IRoute;
