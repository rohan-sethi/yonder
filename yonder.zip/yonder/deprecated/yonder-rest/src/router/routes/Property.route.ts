import { ApiPath } from "@yonder/db";

import { Property } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesProperty: IRoute[] = [
    routeCreateOne(Property),
    routeReadAll(Property),
    routeReadOne(Property),
    routeUpdateOne(Property),
    routeDeleteOne(Property)
];

export default {
    path: `/${ApiPath.Property}`,
    type: ROUTE,
    handler: expandRoutes(routesProperty)
} as IRoute;
