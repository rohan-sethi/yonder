import { ApiPath } from "@yonder/db";

import { PropertyCategory } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesPropertyCategory: IRoute[] = [
    routeCreateOne(PropertyCategory),
    routeReadAll(PropertyCategory),
    routeReadOne(PropertyCategory),
    routeUpdateOne(PropertyCategory),
    routeDeleteOne(PropertyCategory)
];

export default {
    path: `/${ApiPath.PropertyCategory}`,
    type: ROUTE,
    handler: expandRoutes(routesPropertyCategory)
} as IRoute;
