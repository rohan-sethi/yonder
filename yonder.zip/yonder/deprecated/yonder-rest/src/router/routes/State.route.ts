import { ApiPath } from "@yonder/db";

import { State } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesState: IRoute[] = [
    routeCreateOne(State),
    routeReadAll(State),
    routeReadOne(State),
    routeUpdateOne(State),
    routeDeleteOne(State)
];

export default {
    path: `/${ApiPath.State}`,
    type: ROUTE,
    handler: expandRoutes(routesState)
} as IRoute;
