import { ApiPath } from "@yonder/db";

import { PropertyContent } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesPropertyContent: IRoute[] = [
    routeCreateOne(PropertyContent),
    routeReadAll(PropertyContent),
    routeReadOne(PropertyContent),
    routeUpdateOne(PropertyContent),
    routeDeleteOne(PropertyContent)
];

export default {
    path: `/${ApiPath.PropertyContent}`,
    type: ROUTE,
    handler: expandRoutes(routesPropertyContent)
} as IRoute;
