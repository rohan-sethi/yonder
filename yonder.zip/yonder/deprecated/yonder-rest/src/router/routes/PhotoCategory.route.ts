import { ApiPath } from "@yonder/db";

import { PhotoCategory } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesPhotoCategory: IRoute[] = [
    routeCreateOne(PhotoCategory),
    routeReadAll(PhotoCategory),
    routeReadOne(PhotoCategory),
    routeUpdateOne(PhotoCategory),
    routeDeleteOne(PhotoCategory)
];

export default {
    path: `/${ApiPath.PhotoCategory}`,
    type: ROUTE,
    handler: expandRoutes(routesPhotoCategory)
} as IRoute;
