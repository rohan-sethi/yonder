import { ApiPath } from "@yonder/db";

import { Amenity } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesAmenity: IRoute[] = [
    routeCreateOne(Amenity),
    routeReadAll(Amenity),
    routeReadOne(Amenity),
    routeUpdateOne(Amenity),
    routeDeleteOne(Amenity)
];

export default {
    path: `/${ApiPath.Amenity}`,
    type: ROUTE,
    handler: expandRoutes(routesAmenity)
} as IRoute;
