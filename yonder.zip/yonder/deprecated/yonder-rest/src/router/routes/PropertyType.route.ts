import { ApiPath } from "@yonder/db";

import { PropertyType } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesPropertyType: IRoute[] = [
    routeCreateOne(PropertyType),
    routeReadAll(PropertyType),
    routeReadOne(PropertyType),
    routeUpdateOne(PropertyType),
    routeDeleteOne(PropertyType)
];

export default {
    path: `/${ApiPath.PropertyType}`,
    type: ROUTE,
    handler: expandRoutes(routesPropertyType)
} as IRoute;
