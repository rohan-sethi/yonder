import { ApiPath } from "@yonder/db";

import { Organization } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesOrganization: IRoute[] = [
    routeCreateOne(Organization),
    routeReadAll(Organization),
    routeReadOne(Organization),
    routeUpdateOne(Organization),
    routeDeleteOne(Organization)
];

export default {
    path: `/${ApiPath.Organization}`,
    type: ROUTE,
    handler: expandRoutes(routesOrganization)
} as IRoute;
