import { ApiPath } from "@yonder/db";

import { RoomType } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesRoomType: IRoute[] = [
    routeCreateOne(RoomType),
    routeReadAll(RoomType),
    routeReadOne(RoomType),
    routeUpdateOne(RoomType),
    routeDeleteOne(RoomType)
];

export default {
    path: `/${ApiPath.RoomType}`,
    type: ROUTE,
    handler: expandRoutes(routesRoomType)
} as IRoute;
