import { ApiPath } from "@yonder/db";

import { Currency } from "../../controllers/models";
import {
    expandRoutes,
    IRoute,
    ROUTE,
    routeCreateOne,
    routeReadAll,
    routeReadOne,
    routeUpdateOne,
    routeDeleteOne
} from "../helpers";

const routesCurrency: IRoute[] = [
    routeCreateOne(Currency),
    routeReadAll(Currency),
    routeReadOne(Currency),
    routeUpdateOne(Currency),
    routeDeleteOne(Currency)
];

export default {
    path: `/${ApiPath.Currency}`,
    type: ROUTE,
    handler: expandRoutes(routesCurrency)
} as IRoute;
