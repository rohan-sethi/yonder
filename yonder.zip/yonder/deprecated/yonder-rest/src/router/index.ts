import addSwagger from "../middleware/SwaggerUi";

import env from "../util/Environment";
import root from "../util/Root";
import { errorResponse } from "../util/ErrorHandlers";
import { expandRoutes } from "./helpers/RouteHandler";
import routeApi from "./routes/root";

export default function(app: any) {
    app.use("/api", expandRoutes(routeApi));

    // Swagger UI in the /docs route
    if (env.isDevelopment) {
        addSwagger(app, "/docs", root);
    }

    // 404 route
    app.get("*", async (_req: any, _res: any, next: any) => {
        next(errorResponse(404, "Not found"));
    });
}
