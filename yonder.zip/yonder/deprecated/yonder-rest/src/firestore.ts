import "reflect-metadata";
import { Firestore } from "@google-cloud/firestore";
import env from "./util/Environment";

const firestore = new Firestore({
    projectId: env.GCP_PROJECT
});

export default firestore;
