import { IsOptional, IsString, MaxLength, IsArray } from "class-validator";
import { Organization as IOrganization } from "@yonder/db";

import { BaseModel, ClassID, DAO, STRMAX_LINE } from "../index";
import { User, Activity } from ".";

export class Organization extends BaseModel implements IOrganization {
    @IsString()
    @MaxLength(STRMAX_LINE)
    name: string;

    @IsOptional()
    @IsArray()
    users?: User[];
    @IsOptional()
    @IsArray()
    users_id?: ClassID[];

    @IsOptional()
    @IsArray()
    activities?: Activity[];
    @IsOptional()
    @IsArray()
    activities_id?: ClassID[];

    async beforeCreate() {
        if (this.users) {
            for (let item of this.users) {
                const response = await DAO.findOrCreate(User.name, item, User);
                if (this.users_id === undefined) this.users_id = [];
                this.users_id.push(response.id);
            }
            delete this.users;
        }

        if (this.activities) {
            for (let item of this.activities) {
                const response = await DAO.findOrCreate(Activity.name, item, Activity);
                if (this.activities_id === undefined) this.activities_id = [];
                this.activities_id.push(response.id);
            }
            delete this.activities;
        }
    }

    async afterFind() {
        if (this.users_id) {
            for (let id of this.users_id) {
                const response = await DAO.findOneByID(User.name, id, User);
                if (this.users === undefined) this.users = [];
                this.users.push(Object.assign(new User(), response));
            }
            delete this.users_id;
        }

        if (this.activities_id) {
            for (let id of this.activities_id) {
                const response = await DAO.findOneByID(Activity.name, id, Activity);
                if (this.activities === undefined) this.activities = [];
                this.activities.push(Object.assign(new User(), response));
            }
            delete this.activities_id;
        }
    }
}
