import { IsString, IsOptional, IsUrl, MaxLength, Length } from "class-validator";
import { Currency as ICurrency } from "@yonder/db";

import { BaseModel, STRMAX_LINE } from "../index";

export class Currency extends BaseModel implements ICurrency {
    @IsString()
    @MaxLength(STRMAX_LINE)
    name: string;

    @Length(2, 5)
    code: string;

    @IsOptional()
    @IsString()
    @IsUrl()
    image?: string;
}
