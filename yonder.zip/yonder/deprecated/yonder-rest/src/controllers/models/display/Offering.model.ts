import { OfferingDisplay as IOfferingDisplay } from "@yonder/db";

export class OfferingDisplay extends IOfferingDisplay {

    transform(orig?: any) {

        this.name = 'The Bluebonnet Bungalow';

        this.featuredImages = {
            desktop: [
                { url: '' }
            ],
            mobile: [
                { url: '' }
            ]
        };

        this.location = 'Cat Spring, Texas';
        this.locationSummary = 'Cat Spring is about an hour and a half east of Austin and about an hour west of Houstin. It\'s a one stop light town. You know, the kind if you blink... you miss. Serene, hospitable, relaxing and amazing.';

        this.gps = {
            long: '29.839454',
            lat: '-96.358553'
        };

        this.rating = '4.8';

        this.summary = {
            prefix: '',
            body: 'is an authentic Texas experience like no other. Unwind in the peaceful country setting amidst majestic live oaks, open ranch land, and our fully stocked fishing pond. Enjoy simple life in the calming surroundings of our working Texas Hill Country guest ranch.'
        };

        this.medals = [
            { label: 'NATURAL ENVIRONMENT', imageUrl: '', id: '' },
            { label: 'BUILT ENVIRONMENT', imageUrl: '', id: '' },
            { label: 'SOCIAL WELLBEING', imageUrl: '', id: '' }
        ];

        this.bedArrangements = ['2 queen', '1 sleeper sofa'];
        this.bedCount = 5;
        this.bathroomCount = 3;

        this.amenities = [
            { label: 'bathtub' },
            { label: 'full kitchen' },
            { label: 'air conditioning' },
            { label: 'front porch rocking chair' }
        ];

        this.guestbookEntries = [
            {
                rating: 5,
                date: '3 days ago',
                message: 'What a wonderful experience! We eloped at the ranch and every detail was handled perfectly for us. Big shout out to Carol for making our day extra special.',
                name: 'Cheryl B.'
            },
            {
                rating: 4,
                date: '1 week ago',
                message: 'Very nice venue. We were there for a friend\'s wedding and were very impressed with the ambiance, accomodations, and night skies.',
                name: 'David H.'
            },
            {
                rating: 5,
                date: '1 week ago',
                message: 'Blisswood Bed and Breakfast Ranch is such an amazing place, so peaceful. Carol was so helpful, even when I had multiple questions. As soon as you arrive, Blisswood welcomes you with a serene and magical view. I\'ve fallen in love with this place. We had a wonderful stay, this place is overall breath taking-beautiful. I will definitely be back! Thank you so much for having us!',
                name: 'Lisett M.'
            },
            {
                rating: 4,
                date: '2 weeks ago',
                message: 'Wonderful.',
                name: 'Paul B.'
            },
            {
                rating: 5,
                date: '2 weeks ago',
                message: 'Great.',
                name: 'Will F.'
            },
        ];

        this.price = 237;
        this.baseCurrency = 'usd';

        this.host = {
            id: '54fdhfdf',
            name: 'Carol Davis',
            prefix: 'Your Host',
            summary: 'is a Native of Texas. Carol Davis was born and reared on a Warda farm and ranch owned by her family since 1875. Warda is one of the state\'s many German-American communities, and Carol spoke only German before she started school in a one-room parochial school...',
            imageUrl: ''
        };
        this.propertyType = '';
        this.minimumStay = 2;
        this.thingsToDo = [];
        this.nearby = [];

    }
}
