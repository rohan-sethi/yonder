import { IsString, IsOptional, IsUrl, MaxLength, IsNumber } from "class-validator";
import { Activity as IActivity } from "@yonder/db";

import { BaseModel, STRMAX_LINE, IModelCallbacks, ClassID, DAO } from "../index";
import { Property, Organization, User } from ".";

export class Activity extends BaseModel implements IActivity, IModelCallbacks {
    @IsString()
    @MaxLength(STRMAX_LINE)
    name: string;

    @IsOptional()
    host: User;
    @IsOptional()
    @IsString()
    host_id?: ClassID;

    @IsOptional()
    property: Property;
    @IsOptional()
    @IsString()
    property_id?: ClassID;

    @IsOptional()
    organization?: Organization;
    @IsOptional()
    @IsString()
    organization_id?: ClassID;

    @IsOptional()
    @IsString()
    @IsUrl()
    image?: string;

    @IsOptional()
    @IsNumber()
    cost?: number;

    async beforeCreate() {
        if (this.property) {
            const response = await DAO.findOrCreate(Property.name, this.property, Property);
            delete this.property;
            this.property_id = response.id;
        }

        if (this.organization) {
            const response = await DAO.findOrCreate(Organization.name, this.organization, Organization);
            delete this.organization;
            this.organization_id = response.id;
        }

        if (this.host) {
            const response = await DAO.findOrCreate(User.name, this.host, User);
            delete this.host;
            this.host_id = response.id;
        }
    }

    async afterFind() {
        if (this.property_id) {
            const response = await DAO.findOneByID(Property.name, this.property_id, Property);
            delete this.property_id;
            this.property = new Property();
            Object.assign(this.property, response);
        }

        if (this.organization_id) {
            const response = await DAO.findOneByID(Organization.name, this.organization_id, Organization);
            delete this.organization_id;
            this.organization = new Organization();
            Object.assign(this.organization, response);
        }

        if (this.host_id) {
            const response = await DAO.findOneByID(User.name, this.host_id, User);
            delete this.host_id;
            this.host = new User();
            Object.assign(this.host, response);
        }
    }
}
