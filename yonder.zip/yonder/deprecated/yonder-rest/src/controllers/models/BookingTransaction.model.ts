import { IsOptional, IsNumber, IsString, IsDateString } from "class-validator";
import { BookingTransaction as IBookingTransaction } from "@yonder/db";

import { BaseModel, IModelCallbacks, ClassID, DAO } from "../index";
import { Property, User, Booking, Currency, PromoCode } from ".";

export class BookingTransaction extends BaseModel implements IBookingTransaction, IModelCallbacks {
    @IsOptional()
    property: Property;
    @IsOptional()
    @IsString()
    property_id?: ClassID;

    @IsOptional()
    payer: User;
    @IsOptional()
    @IsString()
    payer_id?: ClassID;

    @IsOptional()
    payee: User;
    @IsOptional()
    @IsString()
    payee_id?: ClassID;

    @IsOptional()
    @IsString()
    booking_id?: ClassID;

    @IsNumber()
    guestCount: number;

    @IsNumber()
    siteFees: number;

    @IsNumber()
    amount: number;

    @IsDateString()
    transferOn: Date;

    @IsOptional()
    currency?: Currency;
    @IsOptional()
    @IsString()
    currency_id?: ClassID;

    @IsOptional()
    promoCode?: PromoCode;
    @IsOptional()
    @IsString()
    promoCode_id?: ClassID;

    @IsOptional()
    @IsNumber()
    discountAmount?: number;

    async beforeCreate() {
        if (this.property) {
            const response = await DAO.findOrCreate(Property.name, this.property, Property);
            delete this.property;
            this.property_id = response.id;
        }

        if (this.payer) {
            const response = await DAO.findOrCreate(User.name, this.payer, User);
            delete this.payer;
            this.payer_id = response.id;
        }

        if (this.payee) {
            const response = await DAO.findOrCreate(User.name, this.payee, User);
            delete this.payee;
            this.payee_id = response.id;
        }

        if (this.currency) {
            const response = await DAO.findOrCreate(Currency.name, this.currency, Currency);
            delete this.currency;
            this.currency_id = response.id;
        }

        if (this.promoCode) {
            const response = await DAO.findOrCreate(PromoCode.name, this.promoCode, PromoCode);
            delete this.promoCode;
            this.promoCode_id = response.id;
        }
    }

    async afterFind() {
        if (this.property_id) {
            const response = await DAO.findOneByID(Property.name, this.property_id, Property);
            delete this.property_id;
            this.property = new Property();
            Object.assign(this.property, response);
        }

        if (this.payer_id) {
            const response = await DAO.findOneByID(User.name, this.payer_id, User);
            delete this.payer_id;
            this.payer = new User();
            Object.assign(this.payer, response);
        }

        if (this.payee_id) {
            const response = await DAO.findOneByID(User.name, this.payee_id, User);
            delete this.payee_id;
            this.payee = new User();
            Object.assign(this.payee, response);
        }

        if (this.currency_id) {
            const response = await DAO.findOneByID(Currency.name, this.currency_id, Currency);
            delete this.currency_id;
            this.currency = new Currency();
            Object.assign(this.currency, response);
        }

        if (this.promoCode_id) {
            const response = await DAO.findOneByID(PromoCode.name, this.promoCode_id, PromoCode);
            delete this.promoCode_id;
            this.promoCode = new PromoCode();
            Object.assign(this.promoCode, response);
        }
    }
}
