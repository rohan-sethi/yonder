import { IsString, IsOptional, IsNumber, Length, MaxLength } from "class-validator";
import { PromoCode as IPromoCode } from "@yonder/db";

import { BaseModel, STRMAX_LINE } from "../index";

export class PromoCode extends BaseModel implements IPromoCode {
    @IsString()
    @MaxLength(STRMAX_LINE)
    name: string;

    @IsOptional()
    @IsString()
    description?: string;

    @IsString()
    @Length(5)
    code: string;

    @IsNumber()
    discount: number;
}
