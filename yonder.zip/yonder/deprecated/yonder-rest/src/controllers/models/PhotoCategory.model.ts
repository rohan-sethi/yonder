import { IsString, IsOptional, MaxLength } from "class-validator";
import { PhotoCategory as IPhotoCategory } from "@yonder/db";

import { BaseModel, STRMAX_LINE } from "../index";

export class PhotoCategory extends BaseModel implements IPhotoCategory {
    @IsString()
    @MaxLength(STRMAX_LINE)
    name: string;
}
