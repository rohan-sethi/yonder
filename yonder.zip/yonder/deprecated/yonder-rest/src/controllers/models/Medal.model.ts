import { IsString, IsOptional, IsUrl, MaxLength } from "class-validator";
import { Medal as IMedal } from "@yonder/db";

import { BaseModel, STRMAX_LINE } from "../index";

export class Medal extends BaseModel implements IMedal {
    @IsString()
    @MaxLength(STRMAX_LINE)
    name: string;

    @IsOptional()
    @IsString()
    @IsUrl()
    image?: string;
}
