import { IsString, IsOptional, MaxLength, IsNumber } from "class-validator";
import { GuestbookEntry as IGuestbookEntry } from "@yonder/db";

import { BaseModel, STRMAX_LINE, STRMAX_TEXTAREA, IModelCallbacks, ClassID, DAO } from "../index";
import { Property, User, Booking } from ".";

export class GuestbookEntry extends BaseModel implements IGuestbookEntry, IModelCallbacks {
    @IsOptional()
    property: Property;
    @IsOptional()
    @IsString()
    property_id?: ClassID;

    @IsOptional()
    reviewedByUser: User;
    @IsOptional()
    @IsString()
    reviewedByUser_id?: ClassID;

    @IsOptional()
    booking: Booking;
    @IsOptional()
    @IsString()
    booking_id?: ClassID;

    @IsString()
    @MaxLength(STRMAX_LINE)
    title: string;

    @IsOptional()
    @IsString()
    comment?: string;

    @IsNumber()
    @MaxLength(STRMAX_TEXTAREA)
    rating: number;

    async beforeCreate() {
        if (this.property) {
            const response = await DAO.findOrCreate(Property.name, this.property, Property);
            delete this.property;
            this.property_id = response.id;
        }

        if (this.reviewedByUser) {
            const response = await DAO.findOrCreate(User.name, this.reviewedByUser, User);
            delete this.reviewedByUser;
            this.reviewedByUser_id = response.id;
        }

        if (this.booking) {
            const response = await DAO.findOrCreate(Booking.name, this.booking, Booking);
            delete this.booking;
            this.booking_id = response.id;
        }
    }

    async afterFind() {
        if (this.property_id) {
            const response = await DAO.findOneByID(Property.name, this.property_id, Property);
            delete this.property_id;
            this.property = new Property();
            Object.assign(this.property, response);
        }

        if (this.reviewedByUser_id) {
            const response = await DAO.findOneByID(User.name, this.reviewedByUser_id, User);
            delete this.reviewedByUser_id;
            this.reviewedByUser = new User();
            Object.assign(this.reviewedByUser, response);
        }

        if (this.booking_id) {
            const response = await DAO.findOneByID(Booking.name, this.booking_id, Booking);
            delete this.booking_id;
            this.booking = new Booking();
            Object.assign(this.booking, response);
        }
    }
}
