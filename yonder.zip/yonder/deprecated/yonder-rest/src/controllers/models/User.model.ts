import { IsEmail, IsBoolean, IsString, IsDateString, IsEnum, IsOptional, MaxLength, Length } from "class-validator";
import { User as IUser, Language } from "@yonder/db";

import { BaseModel, STRMAX_LINE } from "../index";
import { IsUnique } from "../validators/IsUnique";

export class User extends BaseModel implements IUser {
    @IsString()
    @Length(1, STRMAX_LINE)
    firstName: string;

    @IsString()
    @Length(1, STRMAX_LINE)
    lastName: string;

    @IsBoolean()
    isHost: boolean;

    @IsEmail()
    @IsString()
    @IsUnique()
    email: string;

    @IsDateString()
    dateOfBirth: Date;

    @IsOptional()
    @IsEnum(Language)
    preferredLanguage?: Language;

    @IsOptional()
    @IsString()
    authZeroId?: string;

    @IsOptional()
    @MaxLength(1000)
    @IsString()
    about?: string;

    @IsOptional()
    @IsString()
    receiveCoupon?: string;
}
