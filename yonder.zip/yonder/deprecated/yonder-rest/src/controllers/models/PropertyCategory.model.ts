import { IsString, IsOptional, MaxLength } from "class-validator";
import { PropertyCategory as IPropertyCategory } from "@yonder/db";

import { BaseModel, STRMAX_LINE } from "../index";

export class PropertyCategory extends BaseModel implements IPropertyCategory {
    @IsString()
    @MaxLength(STRMAX_LINE)
    name: string;

    @IsOptional()
    @IsString()
    description?: string;
}
