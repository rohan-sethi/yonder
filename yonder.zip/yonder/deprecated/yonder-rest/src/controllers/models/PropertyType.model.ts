import { IsString, IsOptional, IsUrl, MaxLength } from "class-validator";
import { PropertyType as IPropertyType } from "@yonder/db";

import { BaseModel, STRMAX_LINE } from "../index";

export class PropertyType extends BaseModel implements IPropertyType {
    @IsString()
    @MaxLength(STRMAX_LINE)
    name: string;

    @IsOptional()
    @IsString()
    @IsUrl()
    image?: string;
}
