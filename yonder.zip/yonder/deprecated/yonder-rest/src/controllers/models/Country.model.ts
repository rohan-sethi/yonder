import { IsString, IsOptional, MaxLength, Length } from "class-validator";
import { Country as ICountry } from "@yonder/db";

import { BaseModel, STRMAX_LINE } from "../index";

export class Country extends BaseModel implements ICountry {
    @MaxLength(STRMAX_LINE)
    name: string;

    @IsString()
    @Length(2, 5)
    code: string;
}
