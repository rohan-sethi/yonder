import { IsString, IsOptional, MaxLength, IsBoolean, Length } from "class-validator";
import { State as IState } from "@yonder/db";

import { BaseModel, ClassID, DAO, STRMAX_LINE, IModelCallbacks } from "../index";
import { Country } from ".";
import { IsUnique } from "../validators/IsUnique";

export class State extends BaseModel implements IState, IModelCallbacks {
    @IsString()
    @MaxLength(STRMAX_LINE)
    name: string;

    @IsString()
    @Length(2, 5)
    @IsUnique()
    code: string;

    @IsOptional()
    @IsBoolean()
    isProvince?: boolean;

    @IsOptional()
    country?: Country;
    @IsOptional()
    @IsString()
    country_id?: ClassID;

    async beforeCreate() {
        if (this.country) {
            const response = await DAO.findOrCreate(Country.name, this.country, Country);
            delete this.country;
            this.country_id = response.id;
        }
    }

    async afterFind() {
        if (this.country_id) {
            const response = await DAO.findOneByID(Country.name, this.country_id, Country);
            delete this.country_id;
            this.country = new Country();
            Object.assign(this.country, response);
        }
    }
}
