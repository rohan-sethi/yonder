import { IsString, IsOptional, MaxLength } from "class-validator";
import { PropertyContent as IPropertyContent } from "@yonder/db";

import { BaseModel, STRMAX_LINE } from "../index";

export class PropertyContent extends BaseModel implements IPropertyContent {
    @IsString()
    @MaxLength(STRMAX_LINE)
    title: string;

    @IsString()
    content: string;
}
