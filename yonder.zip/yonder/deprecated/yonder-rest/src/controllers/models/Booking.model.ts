import { IsOptional, IsDateString, IsNumber, IsBoolean, IsString } from "class-validator";
import { Booking as IBooking } from "@yonder/db";

import { BaseModel, IModelCallbacks, ClassID, DAO } from "../index";
import { Property, User, BookingTransaction } from ".";

export class Booking extends BaseModel implements IBooking, IModelCallbacks {
    @IsOptional()
    property: Property;
    @IsOptional()
    @IsString()
    property_id?: ClassID;

    @IsOptional()
    user: User;
    @IsOptional()
    @IsString()
    user_id?: ClassID;

    @IsDateString()
    checkInDate: Date;

    @IsDateString()
    checkOutDate: Date;

    @IsNumber()
    pricePerDay: number;

    @IsNumber()
    priceForStay: number;

    @IsNumber()
    taxPaid: number;

    @IsNumber()
    siteFees: number;

    @IsOptional()
    @IsBoolean()
    isRefund?: boolean;

    @IsOptional()
    @IsNumber()
    refundPaid?: number;

    @IsOptional()
    transaction: BookingTransaction;
    @IsOptional()
    @IsString()
    transaction_id?: ClassID;

    @IsOptional()
    @IsNumber()
    effectiveAmount?: number;

    @IsOptional()
    @IsDateString()
    bookingDate?: Date;

    async beforeCreate() {
        if (this.property) {
            const response = await DAO.findOrCreate(Property.name, this.property, Property);
            delete this.property;
            this.property_id = response.id;
        }

        if (this.user) {
            const response = await DAO.findOrCreate(User.name, this.user, User);
            delete this.user;
            this.user_id = response.id;
        }

        if (this.transaction) {
            const response = await DAO.findOrCreate(BookingTransaction.name, this.transaction, BookingTransaction);
            delete this.transaction;
            this.transaction_id = response.id;
        }
    }

    async afterFind() {
        if (this.property_id) {
            const response = await DAO.findOneByID(Property.name, this.property_id, Property);
            delete this.property_id;
            this.property = new Property();
            Object.assign(this.property, response);
        }

        if (this.user_id) {
            const response = await DAO.findOneByID(User.name, this.user_id, User);
            delete this.user_id;
            this.user = new User();
            Object.assign(this.user, response);
        }

        if (this.transaction_id) {
            const response = await DAO.findOneByID(BookingTransaction.name, this.transaction_id, BookingTransaction);
            delete this.transaction_id;
            this.transaction = new BookingTransaction();
            Object.assign(this.transaction, response);
        }
    }
}
