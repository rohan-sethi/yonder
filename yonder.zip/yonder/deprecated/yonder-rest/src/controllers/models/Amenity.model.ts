import { IsString, IsOptional, IsUrl, MaxLength } from "class-validator";
import { Amenity as IAmenity } from "@yonder/db";

import { BaseModel, STRMAX_LINE } from "../index";

export class Amenity extends BaseModel implements IAmenity {
    @IsString()
    @MaxLength(STRMAX_LINE)
    name: string;

    @IsOptional()
    @IsString()
    @IsUrl()
    image?: string;
}
