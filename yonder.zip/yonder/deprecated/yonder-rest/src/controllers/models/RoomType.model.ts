import { IsString, IsOptional, IsUrl, MaxLength } from "class-validator";
import { RoomType as IRoomType } from "@yonder/db";

import { BaseModel, STRMAX_LINE } from "../index";

export class RoomType extends BaseModel implements IRoomType {
    @IsString()
    @MaxLength(STRMAX_LINE)
    name: string;

    @IsOptional()
    @IsString()
    @IsUrl()
    image?: string;
}
