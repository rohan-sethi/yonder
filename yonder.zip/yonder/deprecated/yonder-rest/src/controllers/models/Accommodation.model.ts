import { IsString, IsOptional, MaxLength } from "class-validator";
import { Accommodation as IAccommodation } from "@yonder/db";

import { BaseModel, STRMAX_LINE, IModelCallbacks, DAO, ClassID } from "../index";
import { RoomType } from ".";

export class Accommodation extends BaseModel implements IAccommodation, IModelCallbacks {
    @IsString()
    @MaxLength(STRMAX_LINE)
    name: string;

    @IsOptional()
    roomType: RoomType;
    @IsOptional()
    @IsString()
    roomType_id?: ClassID;

    async beforeCreate() {
        if (this.roomType) {
            const response = await DAO.findOrCreate(RoomType.name, this.roomType, RoomType);
            delete this.roomType;
            this.roomType_id = response.id;
        }
    }

    async afterFind() {
        if (this.roomType_id) {
            const response = await DAO.findOneByID(RoomType.name, this.roomType_id, RoomType);
            delete this.roomType_id;
            this.roomType = new RoomType();
            Object.assign(this.roomType, response);
        }
    }
}
