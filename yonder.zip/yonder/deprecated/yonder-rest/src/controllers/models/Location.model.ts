import { IsString, IsOptional, MaxLength } from "class-validator";
import { Location as ILocation } from "@yonder/db";

import { BaseModel, STRMAX_FORM_LINE, STRMAX_LINE, IModelCallbacks, ClassID, DAO } from "../index";
import { City, State, Country } from ".";

export class Location extends BaseModel implements ILocation, IModelCallbacks {
    @IsString()
    @MaxLength(STRMAX_FORM_LINE)
    address1: string;

    @IsOptional()
    @IsString()
    @MaxLength(STRMAX_FORM_LINE)
    address2?: string;

    @IsOptional()
    city: City;
    @IsOptional()
    @IsString()
    city_id?: ClassID;

    @IsOptional()
    state: State;
    @IsOptional()
    @IsString()
    state_id?: ClassID;

    @IsOptional()
    country: Country;
    @IsOptional()
    @IsString()
    country_id?: ClassID;

    @IsOptional()
    @IsString()
    @MaxLength(STRMAX_FORM_LINE)
    lattitude?: string;

    @IsOptional()
    @IsString()
    @MaxLength(STRMAX_FORM_LINE)
    longitude?: string;

    @IsOptional()
    @IsString()
    @MaxLength(STRMAX_LINE)
    description?: string;

    async beforeCreate() {
        if (this.city) {
            const response = await DAO.findOrCreate(City.name, this.city, City);
            delete this.city;
            this.city_id = response.id;
        }

        if (this.state) {
            const response = await DAO.findOrCreate(State.name, this.state, State);
            delete this.state;
            this.state_id = response.id;
        }

        if (this.country) {
            const response = await DAO.findOrCreate(Country.name, this.country, Country);
            delete this.country;
            this.country_id = response.id;
        }
    }

    async afterFind() {
        if (this.city_id) {
            const response = await DAO.findOneByID(City.name, this.city_id, City);
            delete this.city_id;
            this.city = new City();
            Object.assign(this.city, response);
        }

        if (this.state_id) {
            const response = await DAO.findOneByID(State.name, this.state_id, State);
            delete this.state_id;
            this.state = new State();
            Object.assign(this.state, response);
        }

        if (this.country_id) {
            const response = await DAO.findOneByID(Country.name, this.country_id, Country);
            delete this.country_id;
            this.country = new Country();
            Object.assign(this.country, response);
        }
    }
}
