import { IsString, IsOptional, IsUrl } from "class-validator";
import { PropertyPhoto as IPropertyPhoto } from "@yonder/db";

import { BaseModel, IModelCallbacks, ClassID, DAO } from "../index";
import { Property, PropertyCategory, User } from ".";

export class PropertyPhoto extends BaseModel implements IPropertyPhoto, IModelCallbacks {
    @IsOptional()
    property: Property;
    @IsOptional()
    @IsString()
    property_id?: ClassID;

    @IsOptional()
    category: PropertyCategory;
    @IsOptional()
    @IsString()
    category_id?: ClassID;

    @IsOptional()
    addedByUser: User;
    @IsOptional()
    @IsString()
    addedByUser_id?: ClassID;

    @IsString()
    @IsUrl()
    image: string;

    async beforeCreate() {
        if (this.property) {
            const response = await DAO.findOrCreate(Property.name, this.property, Property);
            delete this.property;
            this.property_id = response.id;
        }

        if (this.category) {
            const response = await DAO.findOrCreate(PropertyCategory.name, this.category, PropertyCategory);
            delete this.category;
            this.category_id = response.id;
        }

        if (this.addedByUser) {
            const response = await DAO.findOrCreate(User.name, this.addedByUser, User);
            delete this.addedByUser;
            this.addedByUser_id = response.id;
        }
    }

    async afterFind() {
        if (this.property_id) {
            const response = await DAO.findOneByID(Property.name, this.property_id, Property);
            delete this.property_id;
            this.property = new Property();
            Object.assign(this.property, response);
        }

        if (this.category_id) {
            const response = await DAO.findOneByID(PropertyCategory.name, this.category_id, PropertyCategory);
            delete this.category_id;
            this.category = new PropertyCategory();
            Object.assign(this.category, response);
        }

        if (this.addedByUser_id) {
            const response = await DAO.findOneByID(User.name, this.addedByUser_id, User);
            delete this.addedByUser_id;
            this.addedByUser = new User();
            Object.assign(this.addedByUser, response);
        }
    }
}
