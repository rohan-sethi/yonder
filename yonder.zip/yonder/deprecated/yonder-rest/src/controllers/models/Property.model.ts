import { IsString, IsOptional, MaxLength, IsNumber, IsDateString, IsArray } from "class-validator";
import { Property as IProperty, Language } from "@yonder/db";

import { BaseModel, STRMAX_LINE, IModelCallbacks, ClassID, DAO } from "../index";
import {
    PropertyContent,
    PropertyPhoto,
    User,
    Organization,
    Location,
    Medal,
    PropertyType,
    Accommodation,
    PropertyCategory,
    Activity,
    Amenity,
    Currency,
    Booking,
    GuestbookEntry
} from ".";

export class Property extends BaseModel implements IProperty, IModelCallbacks {
    @IsString()
    @MaxLength(STRMAX_LINE)
    name: string;

    @IsOptional()
    location: Location;
    @IsOptional()
    @IsString()
    location_id?: ClassID;

    @IsString()
    headline: string;

    @IsString()
    summary: string;

    @IsOptional()
    @IsArray()
    content?: PropertyContent[];
    @IsOptional()
    @IsArray()
    content_id?: ClassID[];

    @IsOptional()
    @IsArray()
    photos?: PropertyPhoto[];
    @IsOptional()
    @IsArray()
    photos_id?: ClassID[];

    @IsOptional()
    host: User;
    @IsOptional()
    @IsString()
    host_id?: ClassID;

    @IsOptional()
    organization: Organization;
    @IsOptional()
    @IsString()
    organization_id?: ClassID;

    @IsOptional()
    @IsArray()
    medals?: Medal[];
    @IsOptional()
    @IsArray()
    medals_id?: ClassID[];

    @IsOptional()
    propertyType?: PropertyType;
    @IsOptional()
    @IsString()
    propertyType_id?: ClassID;

    @IsOptional()
    @IsArray()
    accommodations?: Accommodation[];
    @IsOptional()
    @IsArray()
    accommodations_id?: ClassID[];

    @IsOptional()
    category?: PropertyCategory;
    @IsOptional()
    @IsString()
    category_id?: ClassID;

    @IsOptional()
    @IsNumber()
    bedroomCount?: number;

    @IsOptional()
    @IsNumber()
    bedCount?: number;

    @IsOptional()
    @IsNumber()
    bathroomCount?: number;

    @IsOptional()
    @IsArray()
    activities?: Activity[];
    @IsOptional()
    @IsArray()
    activities_id?: ClassID[];

    @IsOptional()
    @IsArray()
    amenities?: Amenity[];
    @IsOptional()
    @IsArray()
    amenities_id?: ClassID[];

    @IsOptional()
    @IsNumber()
    availabilityType?: number;

    @IsOptional()
    @IsDateString()
    startDate?: Date;

    @IsOptional()
    @IsDateString()
    endDate?: Date;

    @IsOptional()
    @IsNumber()
    price?: number;

    @IsOptional()
    currency?: Currency;
    @IsOptional()
    @IsString()
    currency_id?: ClassID;

    @IsOptional()
    @IsArray()
    languages?: Language[];

    @IsOptional()
    @IsNumber()
    minimumStay?: number;

    @IsOptional()
    @IsNumber()
    minimumStayType?: number;

    @IsOptional()
    @IsArray()
    bookings?: Booking[];
    @IsOptional()
    @IsArray()
    bookings_id?: ClassID[];

    @IsOptional()
    @IsArray()
    guestbook?: GuestbookEntry[];
    @IsOptional()
    @IsArray()
    guestbook_id?: ClassID[];

    async beforeCreate() {
        if (this.location) {
            const response = await DAO.findOrCreate(Location.name, this.location, Location);
            delete this.location;
            this.location_id = response.id;
        }

        if (this.content) {
            for (let item of this.content) {
                const response = await DAO.findOrCreate(PropertyContent.name, item, PropertyContent);
                if (this.content_id === undefined) this.content_id = [];
                this.content_id.push(response.id);
            }
            delete this.content;
        }

        if (this.photos) {
            for (let item of this.photos) {
                const response = await DAO.findOrCreate(PropertyPhoto.name, item, PropertyPhoto);
                if (this.photos_id === undefined) this.photos_id = [];
                this.photos_id.push(response.id);
            }
            delete this.photos;
        }

        if (this.host) {
            const response = await DAO.findOrCreate(User.name, this.host, User);
            delete this.host;
            this.host_id = response.id;
        }

        if (this.organization) {
            const response = await DAO.findOrCreate(Organization.name, this.organization, Organization);
            delete this.organization;
            this.organization_id = response.id;
        }

        if (this.medals) {
            for (let item of this.medals) {
                const response = await DAO.findOrCreate(Medal.name, item, Medal);
                if (this.medals_id === undefined) this.medals_id = [];
                this.medals_id.push(response.id);
            }
            delete this.medals;
        }

        if (this.propertyType) {
            const response = await DAO.findOrCreate(PropertyType.name, this.propertyType, PropertyType);
            delete this.propertyType;
            this.propertyType_id = response.id;
        }

        if (this.accommodations) {
            for (let item of this.accommodations) {
                const response = await DAO.findOrCreate(Accommodation.name, item, Accommodation);
                if (this.accommodations_id === undefined) this.accommodations_id = [];
                this.accommodations_id.push(response.id);
            }
            delete this.accommodations;
        }

        if (this.category) {
            const response = await DAO.findOrCreate(PropertyCategory.name, this.category, PropertyCategory);
            delete this.category;
            this.category_id = response.id;
        }

        if (this.activities) {
            for (let item of this.activities) {
                const response = await DAO.findOrCreate(Activity.name, item, Activity);
                if (this.activities_id === undefined) this.activities_id = [];
                this.activities_id.push(response.id);
            }
            delete this.activities;
        }

        if (this.amenities) {
            for (let item of this.amenities) {
                const response = await DAO.findOrCreate(Amenity.name, item, Amenity);
                if (this.amenities_id === undefined) this.amenities_id = [];
                this.amenities_id.push(response.id);
            }
            delete this.amenities;
        }

        if (this.currency) {
            const response = await DAO.findOrCreate(Currency.name, this.currency, Currency);
            delete this.currency;
            this.currency_id = response.id;
        }

        if (this.bookings) {
            for (let item of this.bookings) {
                const response = await DAO.findOrCreate(Booking.name, item, Booking);
                if (this.bookings_id === undefined) this.bookings_id = [];
                this.bookings_id.push(response.id);
            }
            delete this.bookings;
        }

        if (this.guestbook) {
            for (let item of this.guestbook) {
                const response = await DAO.findOrCreate(GuestbookEntry.name, item, GuestbookEntry);
                if (this.guestbook_id === undefined) this.guestbook_id = [];
                this.guestbook_id.push(response.id);
            }
            delete this.guestbook;
        }
    }

    async afterFind() {
        if (this.location_id) {
            const response = await DAO.findOneByID(Location.name, this.location_id, Location);
            delete this.location_id;
            this.location = new Location();
            Object.assign(this.location, response);
        }

        if (this.content_id) {
            for (let id of this.content_id) {
                const response = await DAO.findOneByID(PropertyContent.name, id, PropertyContent);
                if (this.content === undefined) this.content = [];
                this.content.push(Object.assign(new PropertyContent(), response));
            }
            delete this.content_id;
        }

        if (this.photos_id) {
            for (let id of this.photos_id) {
                const response = await DAO.findOneByID(PropertyPhoto.name, id, PropertyPhoto);
                if (this.photos === undefined) this.photos = [];
                this.photos.push(Object.assign(new PropertyPhoto(), response));
            }
            delete this.photos_id;
        }

        if (this.host_id) {
            const response = await DAO.findOneByID(User.name, this.host_id, User);
            delete this.host_id;
            this.host = new User();
            Object.assign(this.host, response);
        }

        if (this.organization_id) {
            const response = await DAO.findOneByID(Organization.name, this.organization_id, Organization);
            delete this.organization_id;
            this.organization = new Organization();
            Object.assign(this.organization, response);
        }

        if (this.medals_id) {
            for (let id of this.medals_id) {
                const response = await DAO.findOneByID(Medal.name, id, Medal);
                if (this.medals === undefined) this.medals = [];
                this.medals.push(Object.assign(new Medal(), response));
            }
            delete this.medals_id;
        }

        if (this.propertyType_id) {
            const response = await DAO.findOneByID(PropertyType.name, this.propertyType_id, PropertyType);
            delete this.propertyType_id;
            this.propertyType = new PropertyType();
            Object.assign(this.propertyType, response);
        }

        if (this.accommodations_id) {
            for (let id of this.accommodations_id) {
                const response = await DAO.findOneByID(Accommodation.name, id, Accommodation);
                if (this.accommodations === undefined) this.accommodations = [];
                this.accommodations.push(Object.assign(new Accommodation(), response));
            }
            delete this.accommodations_id;
        }

        if (this.category_id) {
            const response = await DAO.findOneByID(PropertyCategory.name, this.category_id, PropertyCategory);
            delete this.category_id;
            this.category = new PropertyCategory();
            Object.assign(this.category, response);
        }

        if (this.activities_id) {
            for (let id of this.activities_id) {
                const response = await DAO.findOneByID(Activity.name, id, Activity);
                if (this.activities === undefined) this.activities = [];
                this.activities.push(Object.assign(new Activity(), response));
            }
            delete this.activities_id;
        }

        if (this.amenities_id) {
            for (let id of this.amenities_id) {
                const response = await DAO.findOneByID(Amenity.name, id, Amenity);
                if (this.amenities === undefined) this.amenities = [];
                this.amenities.push(Object.assign(new Amenity(), response));
            }
            delete this.amenities_id;
        }

        if (this.currency_id) {
            const response = await DAO.findOneByID(Currency.name, this.currency_id, Currency);
            delete this.currency_id;
            this.currency = new Currency();
            Object.assign(this.currency, response);
        }

        if (this.bookings_id) {
            for (let id of this.bookings_id) {
                const response = await DAO.findOneByID(Booking.name, id, Booking);
                if (this.bookings === undefined) this.bookings = [];
                this.bookings.push(Object.assign(new Booking(), response));
            }
            delete this.bookings_id;
        }

        if (this.guestbook_id) {
            for (let id of this.guestbook_id) {
                const response = await DAO.findOneByID(GuestbookEntry.name, id, GuestbookEntry);
                if (this.guestbook === undefined) this.guestbook = [];
                this.guestbook.push(Object.assign(new GuestbookEntry(), response));
            }
            delete this.guestbook_id;
        }
    }
}
