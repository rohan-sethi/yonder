import { IsString, IsOptional, MaxLength } from "class-validator";
import { City as ICity } from "@yonder/db";

import { BaseModel, ClassID, DAO, STRMAX_LINE, IModelCallbacks } from "../index";
import { State } from ".";

export class City extends BaseModel implements ICity, IModelCallbacks {
    @IsOptional()
    state: State;
    @IsOptional()
    @IsString()
    state_id?: ClassID;

    @IsString()
    @MaxLength(STRMAX_LINE)
    name: string;

    async beforeCreate() {
        if (this.state) {
            const response = await DAO.findOrCreate(State.name, this.state, State);
            delete this.state;
            this.state_id = response.id;
        }
    }

    async afterFind() {
        if (this.state_id) {
            const response = await DAO.findOneByID(State.name, this.state_id, State);
            delete this.state_id;
            this.state = new State();
            Object.assign(this.state, response);
        }
    }
}
