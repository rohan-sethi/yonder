export * from "./BaseModel";
export { DataAccessObjectFirestore as DAO } from "./DAO.firestore";

export const STRMAX_LINE: number = 255;
export const STRMAX_TEXTAREA: number = 9999;
export const STRMAX_FORM_LINE: number = 50;

export const FETCH_LIMIT = 25;
