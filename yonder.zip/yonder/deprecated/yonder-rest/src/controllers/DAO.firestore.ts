import { ClassType } from "@yonder/db";
import shortid from "shortid";

import db from "../firestore";
import { BaseModel } from "./BaseModel";
import { FETCH_LIMIT } from "./index";
import { DbError } from "../util/ErrorHandlers";

/**
 * The intention of this class is to consolidate all db access & object validation,
 * along with working around some firestore quirks (can't give set() a class for instance)
 */
export class DataAccessObjectFirestore {
    static async create<T extends BaseModel>(collectionName: string, item: T, classConstructor: ClassType<T>) {
        let newObj: T = new classConstructor();
        Object.assign(newObj, item);

        let err = await newObj.validate();
        if (err != undefined) {
            throw err;
        } else {
            if ((<any>newObj).beforeCreate !== undefined) {
                await (<any>newObj).beforeCreate();
            }
            newObj.id = shortid.generate();

            let collection = db.collection(collectionName);
            await collection.doc(newObj.id).set({ ...newObj });
            return newObj;
        }
    }

    static async findOrCreate<T extends BaseModel>(collectionName: string, item: T, classConstructor: ClassType<T>) {
        const response = await this.findOne(collectionName, item);
        if (response) {
            return response;
        } else {
            return await this.create(collectionName, item, classConstructor);
        }
    }

    static async findOne(collectionName: string, item: any) {
        let query = db.collection(collectionName);
        for (let [key, value] of Object.entries(item)) {
            if (typeof value !== "object") {
                (<any>query) = query.where(key, "==", value);
            }
        }

        const snapshot = await query.get();
        if (snapshot.empty) {
            return false;
        } else {
            if (snapshot.size > 1) {
                console.log("snapshot.size > 1");
                throw new Error(DbError.UniqueObject);
            }
            return snapshot.docs[0].data();
        }
    }

    static async findOneByID<T extends BaseModel>(collectionName: string, id: string, classConstructor: ClassType<T>) {
        if (!shortid.isValid(id)) {
            throw new Error(DbError.InvalidObjectId);
        }

        let collection = db.collection(collectionName);
        const doc = await collection.doc(id).get();
        if (doc.exists) {
            let ret: T = Object.assign(new classConstructor(), doc.data());
            if ((<any>ret).afterFind !== undefined) {
                await (<any>ret).afterFind();
            }
            return ret;
        } else {
            throw new Error(DbError.ObjectIdNotFound);
        }
    }

    static async findMany<T extends BaseModel>(
        collectionName: string,
        classConstructor: ClassType<T>,
        limit: number = FETCH_LIMIT
    ) {
        let collection = db.collection(collectionName);
        const result = await collection.limit(limit).get();

        return await Promise.all(
            result.docs.map(async (doc) => {
                let item: T = Object.assign(new classConstructor(), doc.data());
                if ((<any>item).afterFind !== undefined) {
                    await (<any>item).afterFind();
                }
                return item;
            })
        );
    }

    static async updateOneByID<T extends BaseModel>(
        collectionName: string,
        id: string,
        updatedData: Partial<T>,
        classConstructor: ClassType<T>
    ) {
        if (!shortid.isValid(id)) {
            throw new Error(DbError.InvalidObjectId);
        }

        let collection = db.collection(collectionName);
        const doc = await collection.doc(id).get();
        let data = doc.data();
        if (data !== undefined) {
            let update: T = new classConstructor();
            Object.assign(update, updatedData);
            delete update.id;

            let err = await update.validate({
                skipMissingProperties: true
            });
            if (err !== undefined) {
                throw err;
            } else {
                if ((<any>update).beforeCreate !== undefined) {
                    await (<any>update).beforeCreate();
                }
                await collection.doc(data.id).update({ ...update });
            }
        } else {
            throw new Error(DbError.ObjectIdNotFound);
        }
    }

    static async deleteOneByID(collectionName: string, id: string) {
        if (!shortid.isValid(id)) {
            throw new Error(DbError.InvalidObjectId);
        }

        let collection = db.collection(collectionName);
        const doc = await collection.doc(id).get();
        let data = doc.data();
        if (data !== undefined) {
            await collection.doc(data.id).delete();
        } else {
            throw new Error(DbError.ObjectIdNotFound);
        }
    }
}

/*
    save();
    getAll();
    getById(_id: string);
    getByIds(ids: string[]);
    insert(item: Object);
    insertMany(item: Object[]);
    find(query: Object);
    update(item: Object);
    delete(_id: string);
    deleteMany(ids: string[]);
*/
/*
    getAll({ limit: 25})
*/
