import { ValidatorOptions, validate } from "class-validator";
import { BaseModel as IBaseModel } from "@yonder/db";
import { ErrorMaybe, argumentValidationError } from "../util/ErrorHandlers";

export interface IModelCallbacks {
    beforeCreate?: () => Promise<void>;
    afterFind?: () => Promise<void>;
}

export type ClassID = string;

export abstract class BaseModel implements IBaseModel {
    id: ClassID;
    /**
     * Placed in the BaseModel so that the it always has context to 'this'
     * and we can ensure this function exists before calling it
     */
    async validate(validatorOptions?: ValidatorOptions): Promise<ErrorMaybe> {
        // whitelist & forbidNonWhitelisted sends back a validation error if there are extra properties on the object.
        let errorMaybe = await validate(this, {
            whitelist: true,
            forbidNonWhitelisted: true,
            ...validatorOptions
        }).then(
            (errors): ErrorMaybe => {
                if (errors.length > 0) {
                    return argumentValidationError(errors);
                }
            }
        );
        return errorMaybe;
    }
}
