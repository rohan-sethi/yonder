import jwt from "jsonwebtoken";

import env from "../util/Environment";
import { errorResponse } from "../util/ErrorHandlers";

export default async (req: any, res: any, next: any) => {
    try {
        const token = req.headers.authorization.split(" ")[1];
        console.log(token);
        const decoded = await jwt.verify(req.body.token, env.jwt.secret);
        req.userData = decoded;
        next();
    } catch (err) {
        next(errorResponse(401, "Authentication Failed."));
    }
};
