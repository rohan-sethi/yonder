# yonder-rest

## System Requirements

### GCP Firestore Dev Access
Get a firestore.json credentials file from GCP and update the following environment variable on your machine.

**WARNING: do not commit your firestore.json to the repo!**

```
export GOOGLE_APPLICATION_CREDENTIALS="../firestore.json"
```


### yonder-db private npm 

If you are building the project from the root of the monorepo, private NPM access to the yonder-db project is not necessary. If you require to build the project without access to the rest of the mono-repo, then you will need to authenticate into the private npm repo.

* Request a Gemfury access token for the yonder-db package
* Add the following environment variable:

* ```
export FURY_AUTH=(gemfury token)
```

## Development

1. Run:

```
yarn install
```

2. Create a .env in the root yonder-rest direcotry
3. Add the following:

```ini
PORT=4000
DEVELOPMENT=true
GCP_PROJECT=testprojectone
JWT_SECRET=(some secret)
```

5. Run:

```
yarn start
```

## Build Docker Image

```
docker build -t yonder-rest --build-arg FURY_AUTH=${FURY_AUTH} .
docker run --name yonder-api -p 4006:8080 yonder-rest
```