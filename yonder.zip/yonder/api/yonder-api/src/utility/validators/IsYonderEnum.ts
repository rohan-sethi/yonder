import * as admin from "firebase-admin";
import { ValidationOptions, registerDecorator, ValidationArguments } from "class-validator";

type EnumString = {
    [id: number]: string;
};

// ============================================================================
// Checks if the enum or enum array is valid, but instead of failing the check,
// strips out the invalid value.
// ============================================================================
export function IsYonderEnum(entity: EnumString, rejectInvalid: boolean = false) {
    return function(object: Object, propertyName: string) {
        registerDecorator({
            name: "isYonderEnum",
            target: object.constructor,
            propertyName: propertyName,
            constraints: [entity],
            options: {
                message: `each value in ${propertyName} must be a valid enum value`
            } as ValidationOptions,
            validator: {
                async validate(value: any, args: ValidationArguments) {
                    if (typeof value === "string") {
                        // handle a single enum
                        const enumValues = Object.keys(entity).map((k) => entity[k]);
                        const exists = enumValues.indexOf(value) >= 0;
                        if (!exists) {
                            if (rejectInvalid) {
                                return false;
                            }
                            args.object[propertyName] = admin.firestore.FieldValue.delete();
                        }
                    } else {
                        // bail if the value is not an Array object
                        if (typeof value !== "object" || value.length === undefined) return false;

                        // handle array of enums
                        const enumValues = Object.keys(entity).map((k) => entity[k]);
                        for (let v of value) {
                            const exists = enumValues.indexOf(v) >= 0;
                            if (!exists) {
                                // Splice out the value if it's not a valid enum
                                // const index = value.indexOf(v);
                                // value.splice(index, 1);
                            }
                        }
                    }

                    return true;
                }
            }
        });
    };
}
