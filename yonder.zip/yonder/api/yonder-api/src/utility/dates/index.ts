import moment from "moment";

export const makeDay = (param?: string) => {
    return moment(moment(param).format("YYYY-MM-DD"));
};

export const normalizeDate = (date: string): string => {
    // Yonder preferred date convention == YYYY-MM-DD
    const [YEAR, MONTH, DAY] = date.split(/[-\/]/g).map((dateBlock) => parseInt(dateBlock));

    const padding = (block: number): string => {
        return block <= 9 ? `0${block}` : `${block}`;
    };

    const formattedDate = `${YEAR}-${padding(MONTH)}-${padding(DAY)}`;

    if (moment(formattedDate).isValid()) {
        return formattedDate;
    } else {
        console.log("invalid date format");
        throw "Invalid date format.";
    }
};

export const dateRangeFinder = (day1: Date, day2: Date): number => {
    const day1AsObject = moment(day1);
    const day2AsObject = moment(day2);

    return Math.abs(moment.duration(day2AsObject.diff(day1AsObject)).as("days"));
};

export const normalizeDateFromJSObject = (date: Date): string => {
    return normalizeDate(date.toISOString().split("T")[0]);
};

export const WEEKENDS: string[] = ["Fr", "Sa", "Su"];
