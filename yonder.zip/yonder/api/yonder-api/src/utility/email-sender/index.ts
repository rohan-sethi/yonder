import sgMail from "@sendgrid/mail";
import { DbError } from "../../utility/db/ErrorHandlers";
//import {Environment} from '../system'

// TODO: dirty hack, please fix docker env issues and use the env variable above
const SENDGRID_API_KEY = "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";

//sgMail.setApiKey(Environment.SENDGRID_API_KEY);
sgMail.setApiKey(SENDGRID_API_KEY);

interface StaticEmail {
    template_id: EmailTemplates;
    to: string;
    from: string;
}

interface DynamicEmail {
    template_id: EmailTemplates;
    to: string;
    from: any;
    dynamic_template_data: any;
}

class YonderMail {
    public static defaultYonderReplyTo: string = "no-reply@yonder.com";

    public static async sendCohostInvitationLink(
        to: string,
        orgName: string,
        buttonUrl: string,
        firstName?: string,
        lastName?: string
    ) {
        const formattedRecipient: any = firstName && lastName ? { email: to, name: `${firstName} ${lastName}` } : to;
        const from = { name: "Yonder Scouts", email: "scouts@yonder.com" };

        const dynamicData = {
            subject: `You’re invited to Co-Host on Yonder!`,
            orgName,
            buttonUrl,
            firstName,
            lastName
        };

        return await YonderMail.sendDynamicTransactionalEmail(
            formattedRecipient,
            from,
            dynamicData,
            EmailTemplates.cohostInvite
        );
    }

    public static async sendHostSuccessfullyApproved(
        to: string,
        orgName: string,
        firstName?: string,
        lastName?: string
    ) {
        const formattedRecipient: any = firstName && lastName ? { email: to, name: `${firstName} ${lastName}` } : to;
        const from = { name: "Yonder Scouts", email: "scouts@yonder.com" };

        const dynamicData = {
            subject: `Congratulations: You have been approved as a Yonder Host!`,
            orgName,
            firstName,
            lastName
        };

        return await YonderMail.sendDynamicTransactionalEmail(
            formattedRecipient,
            from,
            dynamicData,
            EmailTemplates.hostSuccessfulApproval
        );
    }

    public static async sendWelcomeYonderHosts(to: string) {
        const from = { name: "Yonder Scouts", email: "scouts@yonder.com" };

        return await YonderMail.sendStaticTransactionalEmail(to, from, EmailTemplates.welcomeYonderHosts);
    }

    private static async sendStaticTransactionalEmail(to: string, from: any, template: EmailTemplates): Promise<any> {
        const msg: StaticEmail = {
            template_id: template,
            to,
            from
        };

        try {
            await sgMail.send(msg);
        } catch (err) {
            throw new Error(DbError.SendGridError);
        }
    }

    private static async sendDynamicTransactionalEmail(
        to: any,
        from: any,
        dynamicData: any,
        template: EmailTemplates
    ): Promise<any> {
        const msg: DynamicEmail = {
            template_id: template,
            to,
            from,
            dynamic_template_data: {
                ...dynamicData
            }
        };

        try {
            await sgMail.send(msg);
        } catch {
            throw new Error(DbError.SendGridError);
        }
    }
}

export default YonderMail;

export enum EmailTemplates {
    _test = "d-1e6a01af80204e6f89e5cbe9e76b5d09",
    welcomeYonderHosts = "d-87cf12c20d3e49b1b7ec528dc94922ee",
    hostSuccessfulApproval = "d-69112676a3314fbba5d4058ac157d9a2",
    cohostInvite = "d-e479df766e8f41f2bdcb2899711dc674"
}
