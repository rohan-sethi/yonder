const isDevelopment: boolean = process.env.DEVELOPMENT === "true";

const Environment = {
    port: Number(process.env.PORT) || 4000,
    isDevelopment,
    isProduction: !isDevelopment,
    GCP_PROJECT: process.env.GCP_PROJECT || "testprojectone",
    jwt: {
        secret: process.env.JWT_SECRET || "0abc921!z5ef0552c-07e5dfd8-440gh23x96bpo"
    },
    SENDGRID_API_KEY: process.env.SENDGRID_API_KEY || ""
};

export { Environment };
