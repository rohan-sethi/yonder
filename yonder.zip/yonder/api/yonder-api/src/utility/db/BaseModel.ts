import { ValidatorOptions, validate, IsOptional, IsString } from "class-validator";
import { ErrorMaybe, argumentValidationError } from "./ErrorHandlers";

export const FETCH_LIMIT = 25;

export abstract class BaseModel {
    id: string;

    @IsOptional()
    @IsString()
    created?: string;

    @IsOptional()
    @IsString()
    modified?: string;

    /**
     * Placed in the BaseModel so that the it always has context to 'this'
     * and we can ensure this function exists before calling it
     */
    async validate(validatorOptions?: ValidatorOptions): Promise<ErrorMaybe> {
        // forbidNonWhitelisted sends back a validation error if there are extra properties on the object. (removed for now)
        const errorMaybe = await validate(this, {
            whitelist: true,
            ...validatorOptions
        }).then(
            (errors): ErrorMaybe => {
                if (errors.length > 0) {
                    return argumentValidationError(errors);
                }
            }
        );
        return errorMaybe;
    }
}
