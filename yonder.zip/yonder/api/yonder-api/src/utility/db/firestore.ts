import "reflect-metadata";
import { Firestore } from "@google-cloud/firestore";
import { Storage } from "@google-cloud/storage";
import { Environment } from "../system";

const projectId = Environment.GCP_PROJECT;
const appUrl = `${projectId}.appspot.com`;

const db = new Firestore({
    projectId
});

const storage = new Storage();
const bucket = storage.bucket(appUrl);
const storageUrl = `https://storage.googleapis.com/${appUrl}`;

export { db, bucket, storageUrl };
