import * as admin from "firebase-admin";
import { ClassType } from "@yonder/db";
import shortid from "shortid";

import { db, bucket } from "./firestore";
import { BaseModel, FETCH_LIMIT } from "./BaseModel";
import { DbError } from "./ErrorHandlers";

function objectToQuery(collectionName: string, item: object) {
    let query = db.collection(collectionName);
    for (let [key, value] of Object.entries(item)) {
        if (typeof value !== "object") {
            (<any>query) = query.where(key, "==", value);
        }
    }

    return query;
}

/**
 * The intention of this class is to consolidate all db access & object validation,
 * along with working around some firestore quirks (can't give set() a class for instance)
 */
export class DataAccessObjectFirestore {
    static async create<T extends BaseModel>(collectionName: string, item: T, classConstructor: ClassType<T>) {
        let newObj: T = new classConstructor();
        Object.assign(newObj, item);
        newObj.created = new Date().toJSON();
        newObj.modified = new Date().toJSON();

        let err = await newObj.validate();
        if (err != undefined) {
            throw err;
        } else {
            newObj.id = shortid.generate();

            let collection = db.collection(collectionName);
            await collection.doc(newObj.id).set({ ...newObj });
            return newObj;
        }
    }

    static async findOrCreate<T extends BaseModel>(collectionName: string, item: T, classConstructor: ClassType<T>) {
        const response = await this.findOne(collectionName, item);
        if (response) {
            return response;
        } else {
            return await this.create(collectionName, item, classConstructor);
        }
    }

    static async findOne<T extends BaseModel>(collectionName: string, item: Partial<T>) {
        let query = objectToQuery(collectionName, item);

        const snapshot = await query.get();
        if (snapshot.empty) {
            return false;
        } else {
            if (snapshot.size > 1) {
                console.log("snapshot.size > 1");
                throw new Error(DbError.UniqueObject);
            }
            let data = snapshot.docs[0].data();
            return {
                ...data
            } as T;
        }
    }

    static async findOneByID<T extends BaseModel>(collectionName: string, id: string): Promise<T> {
        if (!shortid.isValid(id)) {
            throw new Error(DbError.InvalidObjectId);
        }

        let collection = db.collection(collectionName);
        try {
            const doc = await collection.doc(id).get();
            if (doc.exists) {
                return {
                    ...doc.data()
                } as T;
            } else {
                throw new Error(DbError.ObjectIdNotFound);
            }
        } catch (err) {
            throw err;
        }
    }

    static async propertyIdExists(collectionName: string, id: string) {
        const doc = await db
            .collection(collectionName)
            .doc(id)
            .get();

        return doc.exists;
    }

    static async findMany<T extends BaseModel>(
        collectionName: string,
        classConstructor: ClassType<T>,
        limit: number = FETCH_LIMIT
    ): Promise<T[]> {
        let collection = db.collection(collectionName);
        const result = await collection.limit(limit).get();

        try {
            let items: T[] = result.docs.map(
                (doc): T => {
                    return Object.assign(new classConstructor(), doc.data());
                }
            );
            return items;
        } catch (err) {
            console.log(err);
            return [] as T[];
        }
    }

    static async findManyByObject<T extends BaseModel>(
        collectionName: string,
        classConstructor: ClassType<T>,
        item: object
    ) {
        let query = objectToQuery(collectionName, item);
        const results = await query.get();

        return results.docs.map((doc) => {
            return Object.assign(new classConstructor(), doc.data());
        });
    }

    static async findManyByKeyValue<T extends BaseModel>(
        collectionName: string,
        classConstructor: ClassType<T>,
        key: string,
        val: any
    ) {
        let query = db.collection(collectionName).where(key, "==", val);
        const results = await query.get();

        return results.docs.map((doc) => {
            return Object.assign(new classConstructor(), doc.data());
        });
    }

    static async findManyWhereArrayContains<T extends BaseModel>(
        collectionName: string,
        classConstructor: ClassType<T>,
        key: string,
        val: any
    ) {
        let query = db.collection(collectionName).where(key, "array-contains", val);
        const results = await query.get();

        if (results.docs.length === 0) return [];

        return results.docs.map((doc) => {
            return Object.assign(new classConstructor(), doc.data());
        });
    }

    static async updateOneByID<T extends BaseModel>(
        collectionName: string,
        id: string,
        updatedData: Partial<T>,
        classConstructor: ClassType<T>
    ) {
        if (!shortid.isValid(id)) {
            throw new Error(DbError.InvalidObjectId);
        }

        let collection = db.collection(collectionName);
        const doc = await collection.doc(id).get();
        let data = doc.data();
        if (data !== undefined) {
            let update: T = new classConstructor();
            Object.assign(update, updatedData);

            update.modified = new Date().toJSON();
            delete update.id;
            let err = await update.validate({
                skipMissingProperties: true
            });

            //
            Object.entries(updatedData).forEach(([key, value]) => {
                if (key === "id") return;

                if (value === undefined) {
                    console.log(`  Deleting ${key} field from ${collectionName}: ${id}`);
                    update[key] = admin.firestore.FieldValue.delete();
                }
            });

            if (err !== undefined) {
                throw err;
            } else {
                await collection.doc(data.id).update({ ...update });
                return update;
            }
        } else {
            throw new Error(DbError.ObjectIdNotFound);
        }
    }

    static async deleteOneByID(collectionName: string, id: string) {
        if (!shortid.isValid(id)) {
            throw new Error(DbError.InvalidObjectId);
        }

        let collection = db.collection(collectionName);
        const doc = await collection.doc(id).get();
        let data = doc.data();
        if (data !== undefined) {
            collection.doc(data.id).delete();
        } else {
            throw new Error(DbError.ObjectIdNotFound);
        }
    }

    static async deleteFromStorage(path: string): Promise<boolean> {
        try {
            let seg = path.split("/");
            let fileName = seg[seg.length - 1];
            let folderName = seg[seg.length - 2];

            // ensures compatibility with url that comes from // UploadTaskSnapshot.ref.getDownloadURL()
            if (folderName === "o") {
                const pathB = fileName.split("?")[0];
                seg = pathB.split("%2F");
                fileName = seg[seg.length - 1];
                folderName = seg[seg.length - 2];
            }
            const filePath = `${folderName}/${fileName}`;
            const fileRef = bucket.file(filePath);

            await fileRef.delete();
            console.log(`  Deleted: ${filePath}`);
        } catch (err) {
            console.log(err);
            return false;
        } finally {
            return true;
        }
    }

    static async createSessionRecordByID<T extends BaseModel>(collectionName: string, item: T) {
        if (!shortid.isValid(item.id)) {
            throw new Error(DbError.InvalidObjectId);
        }
        let collection = db.collection(collectionName);
        const doc = await collection.doc(item.id).get();

        if (doc.exists) {
            throw new Error(DbError.UniqueObject);
        } else {
            await collection.doc(item.id).set({ ...item });
        }
    }

    static async insertChatByID<T extends BaseModel>(collectionName: string, item: T) {
        if (!shortid.isValid(item.id)) {
            throw new Error(DbError.InvalidObjectId);
        }
        let collection = db.collection(collectionName).doc(item.id);
        try {
            let result = collection.update({
                chat: admin.firestore.FieldValue.arrayUnion({ ...item })
            });
        } catch (Err) {
            throw new Error(DbError.InvalidObjectId);
        }
    }

    static async filterByDateRange<T extends BaseModel>(
        array: Array<any>,
        dateFromSource: string | number,
        dateToSource: string | number
    ) {
        let isAvaiable: boolean = true;
        let dateFrom = +new Date(dateFromSource) / 1000;
        let dateTo = +new Date(dateToSource) / 1000;
        for (let booking of array) {
            let inDate: number = booking.checkInDate._seconds;
            let outDate: number = booking.checkOutDate._seconds;

            if ((inDate >= dateFrom && inDate <= dateTo) || (dateFrom >= inDate && dateFrom <= outDate)) {
                isAvaiable = false;
                break;
            }
        }
        return isAvaiable;
    }

    static async createWithCustomId<T extends BaseModel>(
        collectionName: string,
        item: T,
        classConstructor: ClassType<T>
    ) {
        let newObj: T = new classConstructor();
        Object.assign(newObj, item);
        newObj.created = new Date().toJSON();
        newObj.modified = new Date().toJSON();

        let err = await newObj.validate();
        if (err != undefined) {
            throw err;
        } else {
            let collection = db.collection(collectionName);
            const doc = await collection.doc(item.id).get();

            if (doc.exists) {
                throw new Error(DbError.UniqueObject);
            } else {
                let result = await collection.doc(item.id).set({ ...newObj });
                return result;
            }
        }
    }

    static async getMultipleDocByIdIfExist(collectionName: string, arrReference: Array<string>) {
        let query_data: any = [];

        const isValid = arrReference.map(async (reference) => {
            return { reference, isValid: await DataAccessObjectFirestore.propertyIdExists(collectionName, reference) };
        });

        const resolvedAndValid = await Promise.all(isValid);

        resolvedAndValid.forEach(({ isValid, reference }) => {
            isValid && query_data.push(db.doc(collectionName + "/" + reference));
        });

        let results = await db.getAll(query_data);
        let insert: any = [];
        await Promise.all(results).then((docs) => {
            docs.forEach((doc) => {
                insert.push(doc.data());
            });
        });

        return insert;
    }

    static async getMultipleDocById(collectionName: string, arrReference: Array<string>) {
        let queryData: any = [];
        arrReference.forEach((doc) => {
            queryData.push(db.doc(collectionName + "/" + doc));
        });
        const results = await db.getAll(queryData);
        let insert: any = [];
        await Promise.all(results).then((docs) => {
            docs.forEach((doc) => {
                if (doc.data() !== undefined) {
                    insert.push(doc.data());
                }
            });
        });
        return insert;
    }

    static async getAvailabilitiesBetweenDates<T>(
        classConstructor: ClassType<T>,
        collectionName: string,
        listingId: string,
        startDate: Date,
        endDate: Date
    ): Promise<T[]> {
        const collection = db.collection(collectionName);

        try {
            const bookingAvailsInRange = await collection
                .where("listingId", "==", listingId)
                .where("dateObject", ">=", startDate)
                .where("dateObject", "<", endDate)
                .get();

            const buildBookingAvailsFromDB: T[] = bookingAvailsInRange.docs.map((results) => {
                const typedObject = new classConstructor();
                const booking = results.data();

                Object.assign(typedObject, { ...booking, dateObject: booking.dateObject.toDate() });

                return typedObject;
            });

            return buildBookingAvailsFromDB;
        } catch (err) {
            throw err;
        }
    }

    static async insertBookingAvailability(collectionName: string, updatedAvailability: any) {
        const collection = db.collection(collectionName);

        try {
            const oldBookings = await collection
                .where("listingId", "==", updatedAvailability.listingId)
                .where("date", "==", updatedAvailability.date)
                .get();

            if (!oldBookings.empty) {
                oldBookings.forEach((doc) => doc.ref.delete());
            }

            const bookingAvailabilityObject = {
                ...updatedAvailability,
                id: shortid.generate()
            };

            const result = await collection.doc(bookingAvailabilityObject.id).set(bookingAvailabilityObject);

            return result;
        } catch (err) {
            console.log(err);
            throw err;
        }
    }

    // static async insertBookingAvailibility<T extends BaseModel>(collectionName: string, item: T) {
    //     if (!item.id.match(BookingHandler._REGEX_VALID_DATE_BOOKING)) {
    //         throw new Error(DbError.InvalidObjectId);
    //     }
    //     let collection = db.collection(collectionName).doc(item.id);
    //     try {
    //         delete item.id;
    //         let result = collection.update({
    //             days: admin.firestore.FieldValue.arrayUnion({ ...item })
    //         });
    //         return result;
    //     } catch (Err) {
    //         throw new Error(DbError.InvalidObjectId);
    //     }
    // }

    static async getDocByKeyValueSorted<T extends BaseModel>(
        collectionName: string,
        key: string,
        val: any,
        sortBy: string,
        classConstructor: ClassType<T>
    ) {
        let collection = db.collection(collectionName);
        try {
            let query = collection.where(key, "==", val).orderBy(sortBy, "desc");
            const result = await query.get();
            if (result.docs.length === 0) {
                throw new Error(DbError.ObjectIdNotFound);
            } else {
                return result.docs.map((doc) => {
                    return Object.assign(new classConstructor(), doc.data());
                });
            }
        } catch (Err) {
            return new Error(Err.message);
        }
    }

    static async updateOneByKeyValue<T extends BaseModel>(collectionName: string, item: T, key: string, val: any) {
        let collection = db.collection(collectionName);
        let query = collection.where(key, "==", val);
        const result = await query.get();
        let resultStatus: any = new Object();
        resultStatus.success = true;
        resultStatus.status = 200;
        try {
            if (result.docs.length > 1) {
                throw new Error(DbError.UniqueObject);
            }

            if (result.docs.length === 0) {
                throw new Error(DbError.ObjectIdNotFound);
            }

            let parentId = result.docs[0].data().id;

            if (!shortid.isValid(parentId)) {
                throw new Error(DbError.InvalidObjectId);
            }
            item.modified = new Date().toJSON();

            let updated = await collection.doc(parentId).update(item);
            resultStatus.message = updated;
            return resultStatus;
        } catch (Err) {
            resultStatus.message = Err.message;
            resultStatus.success = false;
            resultStatus.status = 422;
            return resultStatus;
        }
    }

    static async getManyByTwoParams<T extends BaseModel>(
        collectionName: string,
        classConstructor: ClassType<T>,
        key: string,
        val: any,
        key2: string,
        val2: any
    ) {
        let query = db
            .collection(collectionName)
            .where(key, "==", val)
            .where(key2, "==", val2);
        const results = await query.get();
        return results.docs.map((doc) => {
            return Object.assign(new classConstructor(), doc.data());
        });
    }

    static async deleteByTwoParams<T extends BaseModel>(
        collectionName: string,
        classConstructor: ClassType<T>,
        key: string,
        val: any,
        key2: string,
        val2: any
    ) {
        try {
            let collection = db.collection(collectionName);
            let query = db
                .collection(collectionName)
                .where(key, "==", val)
                .where(key2, "==", val2);
            const results = await query.get();
            const doc = await collection.doc(results.docs[0].data().id).get();
            let data = doc.data();
            if (data !== undefined) {
                return await collection.doc(results.docs[0].data().id).delete();
            } else {
                return new Error(DbError.ObjectIdNotFound);
            }
        } catch (err) {
            return new Error(DbError.ObjectIdNotFound);
        }
    }
}
