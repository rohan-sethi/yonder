import { DAO } from "../db";
import { ClassType } from "@yonder/db";

import { Organization } from "../../resources/Organization/Organization.model";
import { ImageAsset } from "../../resources/ImageAsset/ImageAsset.model";
import { UserPermissions } from "@yonder/db";

export interface EndpointPermissionsFunc {
    (req: any, res: any, next: any): any;
}

export interface ReturnedEndpointPermissionsFunc {
    (next: any): EndpointPermissionsFunc;
}

class EndpointPermissions {
    // Naming convention ==> (Enable | Disable)By(Resource)(Parameter)
    public static disableAdminByUserPermission: EndpointPermissionsFunc = (req: any, res: any, next: any) => {
        if (req.body.permissions !== undefined && req.body.permissions.toLowerCase() === UserPermissions.Admin) {
            return res.status(401).send({ message: "Not Authorized" });
        } else {
            next();
        }
    };

    public static disableByUserId: EndpointPermissionsFunc = (req: any, res: any, next: any) => {
        if (req.params.id !== req.userDetails.id && req.userDetails.permissions !== UserPermissions.Admin) {
            return res.status(401).send({ message: "Not Authorized" });
        } else {
            next();
        }
    };

    public static disableByOrgId: EndpointPermissionsFunc = (req: any, res: any, next: any) => {
        if (req.params.id !== req.userDetails.organizationId && req.userDetails.permissions !== UserPermissions.Admin) {
            return res.status(401).send({ message: "Not Authorized" });
        } else {
            next();
        }
    };

    public static disableByUserNotAdmin: EndpointPermissionsFunc = (req: any, res: any, next: any) => {
        if (req.userDetails.permissions !== UserPermissions.Admin) {
            return res.status(401).send({ message: "Not Authorized" });
        } else {
            next();
        }
    };

    public static enableByPropertyActivityByOrgId: EndpointPermissionsFunc = async (req: any, res: any, next: any) => {
        const [firstParam] = Object.values(req.params);
        const { propertyIds, activityIds } = await DAO.findOneByID<Organization>(
            Organization.name,
            req.userDetails.organizationId
        );

        if (
            [...propertyIds, ...activityIds].includes(firstParam) ||
            req.userDetails.permissions === UserPermissions.Admin
        ) {
            next();
        } else {
            return res.status(401).send({ message: "Not Authorized" });
        }
    };

    public static enableByHostApprovalSubmission: EndpointPermissionsFunc = async (req: any, res: any, next: any) => {
        const [firstParam] = Object.values(req.params);
        const { approvalSubmissionId } = await DAO.findOneByID<Organization>(
            Organization.name,
            req.userDetails.organizationId
        );

        if (firstParam === approvalSubmissionId || req.userDetails.permissions === UserPermissions.Admin) {
            next();
        } else {
            return res.status(401).send({ message: "Not Authorized" });
        }
    };

    public static enableHostApprovalSubmissionByOrgId: EndpointPermissionsFunc = async (
        req: any,
        res: any,
        next: any
    ) => {
        const { approvalSubmissionId } = await DAO.findOneByID<Organization>(
            Organization.name,
            req.userDetails.organizationId
        );

        if (approvalSubmissionId === req.params.id) {
            next();
        } else {
            return res.status(401).send({ message: "Not Authorized" });
        }
    };

    public static enableDeleteAssetBySharedOrgId: EndpointPermissionsFunc = async (req: any, res: any, next: any) => {
        const [_, secondParam] = Object.values(req.params);
        const { organizationId: usersOrgId, id: userId } = req.userDetails;

        const { organizationId, uploadedBy } = await DAO.findOneByID<ImageAsset>(ImageAsset.name, secondParam);

        if (usersOrgId === organizationId || userId == uploadedBy) {
            next();
        } else {
            return res.status(401).send({ message: "Not Authorized" });
        }
    };

    public static enableAccessToCollectionAssetById: ReturnedEndpointPermissionsFunc = (collectionName: ClassType) => {
        return async (req: any, res: any, next: any) => {
            const { id: userId } = req.userDetails;
            const { id: paramId } = req.params;

            const collectionDocument = await DAO.findOneByID(collectionName.name, paramId);

            if (collectionDocument.id === userId) {
                next();
            } else {
                return res.status(401).send({ message: "Not Authorized" });
            }
        };
    };

    public static enableAccessIfExists: ReturnedEndpointPermissionsFunc = (collectionName: ClassType) => {
        return async (req: any, res: any, next: any) => {
            const { id } = req.params;

            const collectionDocument = await DAO.propertyIdExists(collectionName.name, id);

            if (collectionDocument) {
                next();
            } else {
                res.status(404).send({ message: "Property ID doesn't exist" });
            }
        };
    };
}

// public static _test: EndpointPermissionsFunc = async (req: any, res: any, next: any) => {
//     console.log('\nauthorization test...');
//     console.log('userDetails:\n' + req.userDetails);
// }

export default EndpointPermissions;
