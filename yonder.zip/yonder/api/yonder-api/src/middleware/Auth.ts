import * as admin from "firebase-admin";
import { DAO } from "../utility/db";
import { User } from "../resources/User/User.model";
admin.initializeApp();

/**
 * @description Auth Validation
 * @param req
 * @param res
 * @param next
 * @returns success and error any encountered
 */

export const Auth = async (req: any, res: any, next: any) => {
    if (!req.headers.authorization) {
        res.status(401).send({ message: "Not Authorized" });
    } else {
        try {
            let idToken = req.headers.authorization.split("Bearer")[1];
            let token = await admin.auth().verifyIdToken(idToken.trim());
            let user: any = await admin.auth().getUser(token.uid);
            let userEmail: string = user.providerData[0].email;

            let userDetails: any = await DAO.findOne(User.name, {
                email: userEmail
            } as User);
            if (!userDetails) {
                return res.status(401).send({ message: "User Not found" });
            }
            userDetails.uid = token.uid;
            req.userDetails = userDetails;
            next();
        } catch (err) {
            console.log(err); // Log the actual error, could be something firebase-related
            res.status(401).send({ message: "Not Authorized" });
            return;
        }
    }
};
