import swaggerUi from "swagger-ui-express";
import YAML from "yamljs";

export default (app: any, route: string, root: string) => {
    const swaggerDocument = YAML.load(`${root}/swagger.yml`);
    const swaggerOptions = {
        customCss: ".swagger-ui .topbar { display: none }",
        customfavIcon: ""
    };

    app.use(route, swaggerUi.serve, swaggerUi.setup(swaggerDocument, swaggerOptions));
};
