import { IsString, IsOptional } from "class-validator";
import { InviteRequest as IInviteRequest, ID } from "@yonder/db";

import { BaseModel } from "../../utility/db";

export class InviteRequest extends BaseModel implements IInviteRequest {
    @IsString()
    @IsOptional()
    email?: string;

    @IsOptional()
    expires?: Date;

    @IsOptional()
    @IsString()
    organizationId?: ID;
}
