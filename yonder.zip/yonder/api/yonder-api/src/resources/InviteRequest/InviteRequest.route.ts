import { UserPermissions } from "@yonder/db";

import { handleError, DAO, DbError } from "../../utility/db";
import { expandRoutes, IRoute, ROUTE, POST, routeReadOne, routeDeleteOne } from "../../utility/routes";
import YonderMail from "../../utility/email-sender";
import { InviteRequest } from "./InviteRequest.model";

import { User } from "../User/User.model";
import { Organization } from "../Organization/Organization.model";
import { Environment } from "../../utility/system";

const publicRoutes: IRoute[] = [routeReadOne(InviteRequest)];

const privateRoutes: IRoute[] = [
    routeDeleteOne(InviteRequest),
    {
        path: "/",
        type: POST,
        handler: async (req, res, next) => {
            try {
                const { organizationId, lastName, firstName } = req.userDetails;
                const organization = (await DAO.findOneByID(Organization.name, organizationId)) as Organization;

                const invite: Partial<InviteRequest> = req.body;
                const inviteRequest = (await DAO.findOne(InviteRequest.name, {
                    email: invite.email
                } as InviteRequest)) as InviteRequest | false;

                const invitedUser = (await DAO.findOne(User.name, {
                    email: invite.email
                } as User)) as User | false;

                if (!!invitedUser) {
                    if (organizationId !== invitedUser.organizationId!) {
                        throw new Error(DbError.Unauthorized);
                    }
                }

                const expireAfterDays = 7;
                const newInvite: InviteRequest = {
                    ...req.body,
                    organizationId,
                    expires: new Date(Date.now() + expireAfterDays * 24 * 60 * 60 * 1000) // now + 1 week
                };

                let response: InviteRequest | undefined;
                if (!!invitedUser) {
                    await DAO.updateOneByID(
                        User.name,
                        invitedUser.id,
                        {
                            permissions: UserPermissions.Invited
                        },
                        User
                    );
                } else {
                    await DAO.create(
                        User.name,
                        {
                            email: invite.email,
                            permissions: UserPermissions.Invited,
                            organizationId
                        } as User,
                        User
                    );
                }

                if (!!inviteRequest) {
                    response = await DAO.updateOneByID(InviteRequest.name, inviteRequest.id, newInvite, InviteRequest);
                    response.id = inviteRequest.id;
                } else {
                    response = await DAO.create(InviteRequest.name, newInvite, InviteRequest);
                }

                const path = Environment.isDevelopment ? "http://localhost:3001" : "https://host.yonder.com";
                const url = `${path}?invite=${response.id}`;
                try {
                    if (Environment.isDevelopment) {
                        console.log(`Invite url: ${url}`);
                    }
                    await YonderMail.sendCohostInvitationLink(
                        invite.email!,
                        organization.name,
                        url,
                        firstName,
                        lastName
                    );
                } catch (err) {
                    console.log(err);
                }

                res.status(201).json(response);
            } catch (err) {
                next(handleError(err));
            }
        }
    }
];

export default {
    path: `/invite`,
    type: ROUTE,
    handler: expandRoutes(publicRoutes, privateRoutes)
} as IRoute;
