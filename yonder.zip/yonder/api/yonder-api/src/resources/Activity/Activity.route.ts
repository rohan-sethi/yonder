import { Activity } from "./Activity.model";

import { IRoute, expandRoutes, ROUTE, GET, PATCH, POST, routeCRUDGenerator, DELETE } from "../../utility/routes";
import { routesImageAssetsHelper } from "../ImageAsset/ImageAsset.route";
import { handleError, DAO } from "../../utility/db";
import EndpointPermissions from "../../utility/endpoint-permissions";
import { Organization, User } from "../models";
import { UserPermissions } from "@yonder/db";

const routesActivity: IRoute[] = [
    ...routesImageAssetsHelper(),
    {
        path: "/",
        type: POST,
        handler: async (req, res, next) => {
            try {
                const response = await DAO.create(Activity.name, req.body, Activity);
                const orgId = req.query.orgId || req.userDetails.organizationId;
                if (orgId) {
                    const org: Organization = await DAO.findOneByID(Organization.name, orgId);
                    if (!org.activityIds) {
                        org.activityIds = [];
                    }
                    if (!org.activityIds.includes(response.id)) {
                        org.activityIds.push(response.id);

                        await DAO.updateOneByID(
                            Organization.name,
                            org.id!,
                            {
                                activityIds: org.activityIds
                            },
                            Organization
                        );
                    }
                }
                res.status(201).json(response);
            } catch (err) {
                next(handleError(err));
            }
        }
    },

    {
        path: "/:id",
        type: PATCH,
        handler: async (req, res, next) => {
            try {
                let objToUpdate = req.body;

                await DAO.updateOneByID(Activity.name, req.params.id, objToUpdate, Activity);
                res.status(207).json({
                    id: req.params.id,
                    ...objToUpdate
                });
            } catch (err) {
                next(handleError(err));
            }
        }
    },
    {
        path: "/:id",
        type: DELETE,
        handler: async (req, res, next) => {
            try {
                const orgs: Partial<Organization>[] = await DAO.findManyWhereArrayContains(
                    Organization.name,
                    Organization,
                    "activityIds",
                    req.params.id
                );
                for (let org of orgs) {
                    if (org.activityIds === undefined || org.id === undefined) continue;

                    const index = org.activityIds.indexOf(req.params.id);
                    org.activityIds.splice(index, 1);
                    await DAO.updateOneByID(
                        Organization.name,
                        org.id!,
                        {
                            activityIds: org.activityIds
                        },
                        Organization
                    );
                }
                await DAO.deleteOneByID(Activity.name, req.params.id);
                res.status(204).json();
            } catch (err) {
                next(handleError(err));
            }
        }
    },
    {
        path: "/:id/users",
        type: GET,
        handler: async (req, res, next) => {
            try {
                const orgs: Partial<Organization>[] = await DAO.findManyWhereArrayContains(
                    Organization.name,
                    Organization,
                    "activityIds",
                    req.params.id
                );
                if (orgs.length === 0) {
                    res.status(200).json([]);
                    return;
                }
                let users: Partial<User>[] = await DAO.findManyByKeyValue(
                    User.name,
                    User,
                    "organizationId",
                    orgs[0].id
                );

                users = users
                    .filter((user) => user.permissions !== UserPermissions.Invited)
                    .map(({ id, firstName, lastName, email }) => ({ id, firstName, lastName, email }));

                res.status(200).json(users);
            } catch (err) {
                next(handleError(err));
            }
        }
    },
    {
        path: "/:activityId/itenerary",
        type: GET,
        handler: async (req, res, next) => {
            try {
                let response = {
                    activityId: req.params.activityId,
                    itenerary: ["step 1", "step 2"]
                };
                res.status(200).json(response);
            } catch (err) {
                next(handleError(err));
            }
        }
    } as IRoute
    // ...routeCRUDGenerator(Activity)
];

const routesActivityPublic: IRoute[] = [
    {
        path: "/:id",
        type: GET,
        handler: async (req, res, next) => {
            try {
                const response = await DAO.findOneByID(Activity.name, req.params.id);
                res.status(200).json(response);
            } catch (err) {
                next(handleError(err));
            }
        }
    }
]

export default {
    path: `/activities`,
    type: ROUTE,
    handler: expandRoutes(routesActivityPublic, routesActivity)
} as IRoute;
