import { IsString, IsOptional, IsNumber, IsArray, IsBoolean } from "class-validator";
import {
    Activity as IActivity,
    ID,
    Price,
    Medals,
    PropertyTypes,
    OfferingCategories,
    Amenities,
    Keywords,
    CurrencyCodes,
    LanguageCodes,
    PropertyLocation,
    PropertyContent,
    TransportationOptions,
    PhysicalActivityLevels,
    AvailabilityTimesByHour,
    ExperienceCategories,
    ActivityTypes,
    CancellationPolicies,
    ListingProgress,
    ListingSectionProgresses,
    ActivityItinerary,
    PricingUnits
} from "@yonder/db";

import { BaseModel } from "../../utility/db";
import { IsYonderEnum } from "../../utility/validators";

export class Activity extends BaseModel implements IActivity {
    @IsString()
    @IsOptional()
    name: string;

    @IsOptional()
    location: PropertyLocation;

    @IsString()
    @IsOptional()
    summary?: string;

    @IsString()
    @IsOptional()
    whatWeLove?: string;

    @IsOptional()
    @IsString({ each: true })
    keyThingsToKnow: string[];

    @IsOptional()
    @IsArray()
    content: PropertyContent[];

    @IsOptional()
    @IsString()
    coverPhoto?: ID;

    @IsOptional()
    @IsString({ each: true })
    galleryPhotos: ID[];

    @IsOptional()
    @IsString()
    hostId?: ID;

    @IsOptional()
    @IsArray()
    medals: Medals[];

    @IsOptional()
    @IsYonderEnum(ExperienceCategories)
    experienceCategories: ExperienceCategories[];

    @IsOptional()
    @IsYonderEnum(ActivityTypes)
    activityTypes: ActivityTypes[];

    @IsOptional()
    @IsYonderEnum(PropertyTypes)
    propertyType?: PropertyTypes;

    @IsOptional()
    category?: OfferingCategories;

    @IsArray()
    @IsYonderEnum(Amenities)
    amenities: Amenities[];

    @IsArray()
    @IsYonderEnum(Keywords)
    keywords: Keywords[];

    @IsOptional()
    @IsYonderEnum(CurrencyCodes)
    currency?: CurrencyCodes;

    @IsOptional()
    @IsNumber()
    pricing?: Price;

    @IsOptional()
    @IsYonderEnum(PricingUnits)
    pricingUnits?: PricingUnits;

    @IsOptional()
    @IsString()
    pricingDescription?: string;

    @IsOptional()
    @IsYonderEnum(LanguageCodes)
    language?: LanguageCodes;

    @IsOptional()
    @IsNumber()
    overallRating?: number | null;

    @IsOptional()
    @IsNumber()
    durationCountByHour: number;

    @IsOptional()
    itinerary: ActivityItinerary[];

    @IsOptional()
    @IsYonderEnum(PhysicalActivityLevels)
    physicalActivityLevel: PhysicalActivityLevels;

    @IsOptional()
    @IsString({ each: true })
    guestRequirements: string[];

    // activity rules
    @IsOptional()
    @IsString({ each: true })
    activityRules: string[];

    @IsOptional()
    @IsYonderEnum(AvailabilityTimesByHour)
    checkInTime?: AvailabilityTimesByHour;

    @IsOptional()
    @IsYonderEnum(AvailabilityTimesByHour)
    checkOutTime?: AvailabilityTimesByHour;

    @IsOptional()
    @IsBoolean()
    suitableForChildren: boolean;

    @IsOptional()
    @IsString()
    suitableForChildrenDescription?: string;

    @IsOptional()
    @IsBoolean()
    suitableForInfants: boolean;

    @IsOptional()
    @IsString()
    suitableForInfantsDescription?: string;

    @IsOptional()
    @IsBoolean()
    petsAllowed: boolean;

    @IsOptional()
    @IsString()
    petsAndAnimalsPolicyDescription?: string;

    @IsOptional()
    @IsBoolean()
    handicapAccessible: boolean;

    @IsOptional()
    @IsString()
    handicapAccessibleDescription?: string;

    @IsOptional()
    @IsBoolean()
    smokingAllowed: boolean;

    @IsOptional()
    @IsString()
    smokingPolicyDescription?: string;

    @IsOptional()
    @IsBoolean()
    potentialForNoise: boolean;

    @IsOptional()
    @IsString()
    potentialNoiseDescription?: string;

    // additional
    @IsOptional()
    @IsYonderEnum(TransportationOptions)
    transportationOptions: TransportationOptions[];

    @IsOptional()
    @IsNumber()
    milesToNearestAirport?: number | null;

    @IsOptional()
    @IsNumber()
    milesToNearestGroceryStore?: number | null;

    @IsOptional()
    milesToNearestGasStation?: number | null;

    @IsOptional()
    @IsBoolean()
    restaurantOnSite: boolean;

    @IsOptional()
    @IsString({ each: true })
    suggestedRestaurantsNearby: string[];

    @IsOptional()
    @IsBoolean()
    gateEntry: boolean;

    @IsOptional()
    @IsString({ each: true })
    keySightseeingPoints: string[];

    @IsOptional()
    @IsBoolean()
    walkingHikingTrailsAdjacentToProperty: boolean;

    @IsOptional()
    @IsString({ each: true })
    recommendedThingsToDoOnProperty: string[];

    @IsOptional()
    @IsNumber()
    winterAverageTemperatorFahrenheit?: number | null;

    @IsOptional()
    @IsNumber()
    summerAverageTemperatorFahrenheit?: number | null;

    @IsOptional()
    @IsBoolean()
    fourWheelDriveSuggestedToGetToProperty: boolean;

    @IsOptional()
    @IsYonderEnum(CancellationPolicies)
    cancellationPolicy?: CancellationPolicies;

    @IsOptional()
    @IsYonderEnum(ListingProgress)
    listingProgress?: ListingProgress;

    @IsOptional()
    sectionProgress: ListingSectionProgresses;
}
