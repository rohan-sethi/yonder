import { IsString, IsOptional, IsNumber } from "class-validator";

import { BaseModel } from "../../utility/db";

export class GuestbookEntry extends BaseModel {
    // TODO : Change Max Length - userId / fcmToken
    //@IsString()
    //id: string

    @IsString()
    userId: string;

    @IsString()
    listingId: string;

    @IsString()
    bookingId: string;

    @IsString()
    @IsOptional()
    title?: string;

    @IsString()
    @IsOptional()
    message?: string;

    @IsOptional()
    @IsNumber()
    rating?: number;

    @IsNumber()
    @IsOptional()
    ratingCategory1?: number;

    @IsNumber()
    @IsOptional()
    ratingCategory2?: number;

    @IsNumber()
    @IsOptional()
    ratingCategory3?: number;

    @IsNumber()
    @IsOptional()
    ratingCategory4?: number;

    @IsNumber()
    @IsOptional()
    ratingCategory5?: number;

    @IsNumber()
    @IsOptional()
    ratingCategory6?: number;
}
