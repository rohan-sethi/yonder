import { DAO } from "../../utility/db";
import { BaseModel } from "../../utility/db";
import { GuestbookEntry } from "./GuestbookEntry.model";

export class GuestbookHandler extends BaseModel {
    static async newEntry(details: any) {
        let result: GuestbookEntry;
        try {
            result = await DAO.create(GuestbookEntry.name, details, GuestbookEntry);
        } catch (Err) {
            return new Error(Err.message);
        }
        return result;
    }

    static async updateById(details: any, bookId: string) {
        let result: GuestbookEntry;
        try {
            result = await DAO.updateOneByKeyValue(GuestbookEntry.name, details, "id", bookId);
        } catch (Err) {
            return new Error(Err.message);
        }
        return result;
    }
}
