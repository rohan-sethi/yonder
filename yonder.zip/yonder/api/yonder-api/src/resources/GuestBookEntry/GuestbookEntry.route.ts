import EndpointPermissions from '../../utility/endpoint-permissions'

import { expandRoutes, IRoute, ROUTE, GET, POST, PUT, DELETE } from "../../utility/routes";
import { DAO, handleError } from "../../utility/db";
import { GuestbookHandler } from "./GuestbookEntry.handler";
import { GuestbookEntry } from "./GuestbookEntry.model";

const routesSettingsPublic: IRoute[] = [

    // return a single guestbook by guestbookEntryId
    // /guestbook-entries/:guestbookEntryId
    {
        // TODO: should it only get reviews from same user id? — similar to favorites using getManyByTwoParams()
        path: "/:id",
        type: GET,
        handler: async (req: any, res: any, next: any) => {
            try {
                const { id: bookId } = req.params;
                const results = await DAO.findManyByKeyValue(GuestbookEntry.name, GuestbookEntry, "id", bookId);

                if (results.length) {
                    res.status(200).json(results[0]);
                } else res.status(404).json(`No reviews with ID ${bookId} found`)

            } catch (err) {
                next(handleError(err));
            }
        }
    },

    // returns all guestbook entries by listingId
    // /guestbook-entries/listings/:listingId
    {
        path: "/listings/:id",
        type: GET,
        handler: async (req: any, res: any, next: any) => {
            try {
                const { id: listId } = req.params;
                const results = await DAO.findManyByKeyValue(GuestbookEntry.name, GuestbookEntry,
                    "listingId", listId);
                res.status(200).json(results);
            } catch (err) {
                next(handleError(err));
            }
        }
    },
]


const routesSettingsPrivate: IRoute[] = [
    // Gets all GuestbookEntry entries for given userId
    // /guestbook-entries
    {
        path: "/",
        type: GET,
        handler: async (req: any, res: any, next: any) => {
            try {
                const { id: userId } = req.userDetails;
                const results = await DAO.findManyByKeyValue(GuestbookEntry.name, GuestbookEntry, "userId", userId);
                if (results.length === 0) { res.status(404).json({ message: "No records found" }); return; }
                else
                    res.status(200).json(results);
            } catch (err) {
                next(handleError(err));
            }
        }
    },

    // Sets new guestbook-entry
    // /guestbook-entries
    {
        path: "/",
        type: POST,
        handler: async (req: any, res: any, next: any) => {
            try {
                const { id: userId } = req.userDetails;
                const payload = { ...req.body, userId: userId };
                const response = await GuestbookHandler.newEntry(payload);

                if (response instanceof Error) { res.status(422).json({ message: response.message }); return; }
                else
                    res.status(201).json(response);
            } catch (err) {
                next(handleError(err));
            }
        }
    },

    // updates guestbookEntryId entry
    // /guestbook-entries/:guestbookEntryId
    {
        path: "/:id",
        type: PUT,
        permissions: [EndpointPermissions.enableAccessToCollectionAssetById(GuestbookEntry)],
        handler: async (req: any, res: any, next: any) => {
            try {
                const { id: bookId } = req.params;

                const response = await GuestbookHandler.updateById(req.body, bookId);
                if (response instanceof Error) { res.status(422).json({ message: response.message }); return; }
                res.status(200).json(response);
            } catch (err) {
                next(handleError(err));
            }
        }
    },

    // Deletes guestbookEntryId entry
    // /guestbook-entries/:guestbookEntryId
    {
        // TODO: userId is userId in this class— outlier???
        path: "/:id",
        type: DELETE,
        permissions: [
            EndpointPermissions.enableAccessIfExists(GuestbookEntry),
            EndpointPermissions.enableAccessToCollectionAssetById(GuestbookEntry)
        ],
        handler: async (req: any, res: any, next: any) => {
            try {
                const { id: bookId } = req.params;
                const { id: userId } = req.userDetails;

                const response = await DAO.deleteByTwoParams(GuestbookEntry.name, GuestbookEntry, "id", bookId, 'userId', userId);
                if (response instanceof Error) {
                    return res.status(422).json({ message: response.message });
                }
                res.status(204).json();
            } catch (err) {
                next(handleError(err));
            }
        }
    },

    //  return a single guestbook by listingId that belong to a specific userId
    // /guestbook-entries/listings/:listingId/user/:userId
    {
        path: "/listings/:listingId/user/:userId",
        type: GET,
        handler: async (req: any, res: any, next: any) => {
            try {
                const { listingId, userId } = req.params;

                const results = await DAO.getManyByTwoParams(GuestbookEntry.name, GuestbookEntry,
                    "listingId", listingId, "userId", userId);

                res.status(200).json(results);
            } catch (err) {
                next(handleError(err));
            }
        }
    },

]

export default {
    path: `/guestbook-entries`,
    type: ROUTE,
    handler: expandRoutes(routesSettingsPublic, routesSettingsPrivate)
} as IRoute;
