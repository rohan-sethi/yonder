import { User } from "./User.model";

import { expandRoutes, IRoute, ROUTE, GET, POST, PATCH, DELETE } from "../../utility/routes";
import { DAO, handleError } from "../../utility/db";
import EndpointPermissions from "../../utility/endpoint-permissions";
import YonderMail from "../../utility/email-sender";
import axios from "axios";
import { Environment } from "../../utility/system";

const routesUserPublic: IRoute[] = [
    // Creates a user
    // api/users
    {
        path: "/",
        type: POST,
        permissions: [EndpointPermissions.disableAdminByUserPermission],
        handler: async (req, res, next) => {
            try {
                const { noEmail } = req.query;
                // if (typeof req.body.permissions != "undefined"
                //     && req.body.permissions.toLowerCase() === 'admin') {
                //     return res.status(401).send({ message: "Not Authorized" });
                // }
                // check for duplicate
                let dups = await DAO.findManyByKeyValue(User.name, User, "email", req.body.email);
                if (dups.length > 0) {
                    // console.log('********** dup diverted');
                    return res.status(201).json(dups[1]);
                }
                const response = await DAO.create(User.name, req.body, User);
                if (noEmail !== "1") {
                    try {
                        response && response.email && (await YonderMail.sendWelcomeYonderHosts(response.email));
                    } catch (err) {
                        // TODO: needs unique error handling case
                        // console.log(err.message)
                    }
                }
                // console.log(JSON.stringify(response));

                if (Environment.isProduction) {
                    // Zapier for the win
                    try {
                        let payload: any = {
                            id: response.id || "",
                            firstName: response.firstName || "",
                            lastName: response.lastName || "",
                            email: response.email || ""
                        };
                        const zapierWebhookUrl = "https://hooks.zapier.com/hooks/catch/4542863/obaodbh/";
                        await axios.post(zapierWebhookUrl, payload);
                    } catch (err) {
                        console.log(err);
                    }
                }
                res.status(201).json(response);
            } catch (err) {
                next(handleError(err));
            }
        }
    }
];

const routesUserPrivate: IRoute[] = [
    // Gets a user by Email
    // api/users/info/email
    // {
    //     path: "/info/email",
    //     type: GET,
    //     handler: async (req, res, next) => {
    //         try {
    //             const response = await DAO.findOne(User.name, {
    //                 email: req.query.email
    //             });
    //             res.status(200).json(response);
    //         } catch (err) {
    //             next(handleError(err));
    //         }
    //     }
    // },
    // Gets a user by Auth
    // api/users/info/me
    {
        path: "/info/me",
        type: GET,
        handler: async (req, res, next) => {
            try {
                res.status(200).json(req.userDetails);
            } catch (err) {
                next(handleError(err));
            }
        }
    },
    // Get  users by data
    // api/users
    // {
    //     path: "/",
    //     type: GET,
    //     handler: async (req, res, next) => {
    //         try {
    //             const response = await DAO.findMany(User.name, User);
    //             res.status(200).json(response);
    //         } catch (err) {
    //             next(handleError(err));
    //         }
    //     }
    // },
    // Get  users by id
    // api/users/{id}
    // {
    //     path: "/:id",
    //     type: GET,
    //     handler: async (req, res, next) => {
    //         try {
    //             const response: User = await DAO.findOneByID(User.name, req.params.id);
    //             res.status(200).json(response);
    //         } catch (err) {
    //             next(handleError(err));
    //         }
    //     }
    // },
    // Updates  users by data
    // api/users/{id}
    {
        path: "/:id",
        type: PATCH,
        permissions: [
            EndpointPermissions.disableByUserId
            //EndpointPermissions.disableAdminByUserPermission // YWEB-221
        ],
        handler: async (req, res, next) => {
            try {
                // if (typeof req.body.permissions != "undefined"
                //     && req.body.permissions.toLowerCase() === 'admin') {
                //     return res.status(401).send({ message: "Not Authorized" });
                // }
                // if (req.params.id !== req.userDetails.id) {
                //     return res.status(401).send({ message: "Not Authorized" });
                // }
                let objToUpdate: any = req.body;
                await DAO.updateOneByID(User.name, req.params.id, objToUpdate, User);
                res.status(207).json({
                    id: req.params.id,
                    ...objToUpdate
                });
            } catch (err) {
                next(handleError(err));
            }
        }
    }
    // Delete user by id
    // api/users/{id}
    // {
    //     path: "/:id",
    //     type: DELETE,
    //     handler: async (req, res, next) => {
    //         try {
    //             await DAO.deleteOneByID(User.name, req.params.id);
    //             res.status(204).json();
    //         } catch (err) {
    //             next(handleError(err));
    //         }
    //     }
    // }
];

export default {
    path: `/users`,
    type: ROUTE,
    permissions: [],
    handler: expandRoutes(routesUserPublic, routesUserPrivate)
} as IRoute;
