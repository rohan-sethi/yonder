import { IsEmail, IsString, IsOptional } from "class-validator";
import { User as IUser, Genders, LanguageCodes, UserPermissions, HostTypes, ID } from "@yonder/db";

import { BaseModel } from "../../utility/db";
import { IsUnique, IsYonderEnum } from "../../utility/validators";

export class User extends BaseModel implements IUser {
    @IsOptional()
    @IsString()
    firstName?: string;

    @IsOptional()
    @IsString()
    lastName?: string;

    @IsOptional()
    @IsString()
    phoneNumber?: string;

    @IsOptional()
    @IsString()
    userLocation?: string;

    @IsOptional()
    @IsString()
    organizationId?: ID;

    @IsOptional()
    @IsYonderEnum(UserPermissions)
    permissions: UserPermissions;

    @IsOptional()
    @IsYonderEnum(HostTypes)
    hostType?: HostTypes;

    @IsEmail()
    @IsString()
    @IsUnique()
    email: string;

    @IsOptional()
    @IsString() // Note: IsDateString validates a full ISO string. We want just the date in MM/DD/YYYY format
    dateOfBirth?: string;

    @IsOptional()
    @IsYonderEnum(LanguageCodes)
    preferredLanguage?: LanguageCodes;

    @IsOptional()
    @IsString()
    about?: string;

    @IsOptional()
    @IsYonderEnum(Genders)
    gender?: Genders;

    @IsOptional()
    @IsString()
    receiveCoupon?: string;

    @IsOptional()
    @IsString()
    photoURL?: string;
}
