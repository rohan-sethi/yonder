import { User } from "../User/User.model";
import { Organization } from "../Organization/Organization.model";
import { Activity } from "../Activity/Activity.model";
import { Property } from "../Property/Property.model";
import { HostApprovalSubmission } from "../HostApprovalSubmission/HostApprovalSubmission.model";

import { expandRoutes, IRoute, ROUTE, GET, POST, DELETE } from "../../utility/routes";
import { DAO, handleError } from "../../utility/db";
import EndpointPermissions from "../../utility/endpoint-permissions";
import YonderMail from "../../utility/email-sender";
import { ID, HostApprovalSubmissionProgress, UserPermissions } from "@yonder/db";

// import { UserPermissions } from "@yonder/db";

const routesAdminPrivate: IRoute[] = [
    {
        path: "/stats",
        type: GET,
        permissions: [EndpointPermissions.disableByUserNotAdmin],
        handler: async (req, res, next) => {
            try {
                const users = await DAO.findMany(User.name, User, 99999);
                const orgs = await DAO.findMany(Organization.name, Organization, 99999);
                const submissions = await DAO.findMany(HostApprovalSubmission.name, HostApprovalSubmission, 99999);

                const usersCount = users.length;
                const orgsCount = orgs.length;
                const subsCount = submissions.length;

                res.status(200).json({
                    usersCount,
                    orgsCount,
                    subsCount
                });
            } catch (err) {
                next(handleError(err));
            }
        }
    },
    {
        path: "/users/:userId",
        type: DELETE,
        permissions: [EndpointPermissions.disableByUserNotAdmin],
        handler: async (req, res, next) => {
            try {
                const { userId } = req.params;
                await DAO.deleteOneByID(User.name, userId);
                console.log("  Deleted user: ", userId);
                res.status(204).json();
            } catch (err) {
                next(handleError(err));
            }
        }
    },
    {
        path: "/users",
        type: GET,
        permissions: [EndpointPermissions.disableByUserNotAdmin],

        handler: async (req, res, next) => {
            try {
                const users = await DAO.findMany(User.name, User, 9999);

                res.status(200).json(users);
            } catch (err) {
                next(handleError(err));
            }
        }
    },

    {
        path: "/orgs",
        type: GET,
        permissions: [EndpointPermissions.disableByUserNotAdmin],

        handler: async (req, res, next) => {
            try {
                const users = await DAO.findMany(Organization.name, Organization, 9999);

                res.status(200).json(users);
            } catch (err) {
                next(handleError(err));
            }
        }
    },

    {
        path: "/subs",
        type: GET,
        permissions: [EndpointPermissions.disableByUserNotAdmin],

        handler: async (req, res, next) => {
            try {
                const submissions = await DAO.findMany(HostApprovalSubmission.name, HostApprovalSubmission, 9999);

                res.status(200).json(submissions);
            } catch (err) {
                next(handleError(err));
            }
        }
    },
    {
        path: "/orgs/:organizationId",
        type: DELETE,
        permissions: [EndpointPermissions.disableByUserNotAdmin],
        handler: async (req, res, next) => {
            try {
                const { organizationId } = req.params;
                const org: Organization = await DAO.findOneByID(Organization.name, organizationId);
                const { approvalSubmissionId } = org;
                if (approvalSubmissionId !== undefined) {
                    await DAO.deleteOneByID(HostApprovalSubmission.name, approvalSubmissionId);
                    console.log("  Deleted approval submission: ", approvalSubmissionId);
                }
                const users: User[] = await DAO.findManyByKeyValue(User.name, User, "organizationId", org.id);
                users.forEach(async (user: User) => {
                    await DAO.updateOneByID(
                        User.name,
                        user.id,
                        {
                            permissions: UserPermissions.Basic,
                            organizationId: undefined
                        },
                        User
                    );
                    console.log("  Updated user: ", user.id);
                });
                await DAO.deleteOneByID(Organization.name, organizationId);
                console.log("  Deleted organization: ", organizationId);
                res.status(204).json();
            } catch (err) {
                next(handleError(err));
            }
        }
    },
    {
        path: "/orgs/:organizationId/status",
        type: POST,
        permissions: [EndpointPermissions.disableByUserNotAdmin],

        handler: async (req, res, next) => {
            try {
                let id: ID = req.params.organizationId;
                let objToUpdate: Partial<Organization> = req.body;
                await DAO.updateOneByID(Organization.name, id, objToUpdate, Organization);

                if (objToUpdate.approvalSubmissionProgress) {
                    let users: User[] = await DAO.findManyByKeyValue(User.name, User, "organizationId", id);

                    if (objToUpdate.approvalSubmissionProgress === HostApprovalSubmissionProgress.Approved) {
                        for (const user of users) {
                            await DAO.updateOneByID(
                                User.name,
                                user.id,
                                {
                                    permissions: UserPermissions.Host
                                },
                                User
                            );
                            try {
                                // this conditional evals to TRUE if call is being made outside of Yonder's frontend
                                if (!Object.keys(objToUpdate).includes("name")) {
                                    objToUpdate.name = "";
                                }

                                await YonderMail.sendHostSuccessfullyApproved(
                                    user.email,
                                    objToUpdate.name!,
                                    user.firstName,
                                    user.lastName
                                );
                            } catch (err) {
                                // TODO: needs unique error handling case
                                // console.log(err.message)
                            }
                        }
                    } else {
                        for (const user of users) {
                            await DAO.updateOneByID(
                                User.name,
                                user.id,
                                {
                                    permissions: UserPermissions.HostApprovalSubmitted
                                },
                                User
                            );
                        }
                    }
                }

                res.status(207).json({
                    id,
                    ...objToUpdate
                });
            } catch (err) {
                next(handleError(err));
            }
        }
    },

    {
        path: "/listings",
        type: GET,
        permissions: [EndpointPermissions.disableByUserNotAdmin],

        handler: async (req, res, next) => {
            try {
                const partialListingsBuilder = (response: any[]) => {
                    return response.map((listing) => ({
                        name: listing.name ? listing.name : undefined,
                        id: listing.id ? listing.id : undefined,
                        listingProgress: listing.listingProgress ? listing.listingProgress : undefined,
                        coverPhoto: listing.coverPhoto ? listing.coverPhoto : undefined
                    }));
                };

                const stays = await DAO.findMany(Property.name, Property, 9999).then((response) =>
                    partialListingsBuilder(response)
                );

                const activities = await DAO.findMany(Activity.name, Activity, 9999).then((response) =>
                    partialListingsBuilder(response)
                );

                const allListings = { stays, activities };

                res.status(200).json(allListings);
            } catch (err) {
                next(handleError(err));
            }
        }
    }
];

export default {
    path: `/ap`,
    type: ROUTE,
    handler: expandRoutes([], routesAdminPrivate)
} as IRoute;
