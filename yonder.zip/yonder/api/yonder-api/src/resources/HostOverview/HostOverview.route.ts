import { expandRoutes, IRoute, ROUTE, GET, POST, routeCRUDGenerator } from "../../utility/routes";
import { handleError } from "../../utility/db";
import { HostHandler } from "./HostOverview.handler";
// import { HostOverview } from "./HostOverview.model";

const routesHost: IRoute[] = [
    {
        path: "/listings",
        type: GET,
        handler: async (req: any, res: any, next: any) => {
            const { organizationId } = req.userDetails;
            try {
                const allListings = await HostHandler.getOrgsAcitivitesProperties(organizationId);
                res.status(200).json(allListings);
            } catch (err) {
                next(handleError(err));
            }
        }
    }

    // get all reviews for Host
    // /api/host/reviews
    // {
    //     path: "/reviews",
    //     type: GET,
    //     handler: async (req: any, res: any, next: any) => {
    //         try {
    //             console.log(req.organizationId)
    //             let holderObject: Object;
    //             let propertyId: string = req.query.propertyId || "test-prop-id";
    //             let listingId: string | undefined = req.query.listingId;
    //             // TODO - Extract Org Id from middleware
    //             let organizationId: string = req.organizationId || "org-1-id";
    //             if (typeof listingId !== 'undefined')
    //                 holderObject = await HostHandler.getListing(organizationId, listingId);
    //             else
    //                 holderObject = await HostHandler.getAllListings(propertyId, organizationId);
    //             res.status(200).json(holderObject);
    //         } catch (err) {
    //             next(handleError("Something went wrong"));
    //         }
    //     }
    // }
];

const publicHostRoutes: IRoute[] = [
    // ...routeCRUDGenerator(HostOverview)
];

export default {
    path: `/host`,
    type: ROUTE,
    handler: expandRoutes([], routesHost)
} as IRoute;
