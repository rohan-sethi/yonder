import { IsString, IsNumber } from "class-validator";
import { BaseModel } from "../../utility/db";
import { HostOverview as IHostOverview, ID } from "@yonder/db";

export class HostOverview extends BaseModel implements IHostOverview {
    @IsNumber()
    overallRating: number;

    @IsString()
    organizationId: ID;
}
