import { DAO } from "../../utility/db";
import { BaseModel } from "../../utility/db";
import { GuestbookEntry } from "../GuestBookEntry/GuestbookEntry.model";
import { Booking } from "../Booking/Booking.model";
import { HostOverview } from "./HostOverview.model";
import { User } from "../User/User.model";
import { Organization } from "../Organization/Organization.model";
import { Property } from "../Property/Property.model";
import { Activity } from "../Activity/Activity.model";

export class HostHandler extends BaseModel {
    static async getOrgsAcitivitesProperties(organizationId: string) {
        const partialListingsBuilder = (response: any[]) => {
            return response.map((listing) => ({
                name: listing.name ? listing.name : undefined,
                id: listing.id ? listing.id : undefined,
                listingProgress: listing.listingProgress ? listing.listingProgress : undefined,
                coverPhoto: listing.coverPhoto ? listing.coverPhoto : undefined
            }));
        };
        const { activityIds, propertyIds } = await DAO.findOneByID<Organization>(Organization.name, organizationId);

        const activities = await DAO.getMultipleDocById(Activity.name, activityIds).then((response) =>
            partialListingsBuilder(response)
        );

        const properties = await DAO.getMultipleDocById(Property.name, propertyIds).then((response) =>
            partialListingsBuilder(response)
        );

        return { activities, properties };
    }

    static async getAllListings(propertyId: string, organizationId: string) {
        // TODO: MAKE SURE GUESTBOOK-ENTRY COLLECTION WORKS WITH USERID NOT REVIEWEDBY

        try {
            let bookings: any = await DAO.findManyByKeyValue(Booking.name, Booking, "propertyId", propertyId);
            let entries: any[] = [];
            let results = await Promise.all(
                bookings.map(async (element) => {
                    let entry: any = await DAO.findManyByKeyValue(
                        GuestbookEntry.name,
                        GuestbookEntry,
                        "userId",
                        element.userId
                    );
                    if (entry.length > 0) {
                        let userId = {
                            userId: element.userId,
                            name: await HostHandler.getUserName(element.userId)
                        };
                        let newObj: any = {};
                        newObj = Object.assign(newObj, entry[0]);
                        delete newObj.userId;
                        delete newObj.id;
                        newObj.userId = userId;
                        entries = entries.concat(newObj);
                    }
                })
            );
            let host: any = await DAO.findManyByKeyValue(
                HostOverview.name,
                HostOverview,
                "organizationId",
                organizationId
            );
            return HostHandler.getDecoratedObj("all", entries, host);
        } catch (err) {
            throw new Error(err.message);
        }
    }

    static async getListing(organizationId: string, listingId: string) {
        // TODO: MAKE SURE GUESTBOOK-ENTRY COLLECTION WORKS WITH USERID NOT REVIEWEDBY

        try {
            let entries: any[] = [];
            let entry: any = await DAO.findManyByKeyValue(GuestbookEntry.name, GuestbookEntry, "listingId", listingId);
            if (entry.length > 0) {
                let userId = {
                    userId: entry[0].userId,
                    name: await HostHandler.getUserName(entry[0].userId)
                };
                let newObj: any = {};
                newObj = Object.assign(newObj, entry[0]);
                delete newObj.userId;
                delete newObj.id;
                newObj.userId = userId;
                entries = entries.concat(newObj);
            }
            let host: any = await DAO.findManyByKeyValue(
                HostOverview.name,
                HostOverview,
                "organizationId",
                organizationId
            );
            return HostHandler.getDecoratedObj(listingId, entries, host);
        } catch (err) {
            throw new Error(err.message);
        }
    }

    private static async getUserName(id: string) {
        let user: any = await DAO.findOne(User.name, { id });
        return `${user.firstName} ${user.lastName.charAt(0) || ""}.`;
    }

    private static async getDecoratedObj(listingId, entries: any[], host: any[]) {
        return {
            selectedListingId: listingId,
            totalGuestbookEntryCount: entries.length,
            overallRating: host[0].overallRating,
            guestbookEntries: entries
        };
    }
}
