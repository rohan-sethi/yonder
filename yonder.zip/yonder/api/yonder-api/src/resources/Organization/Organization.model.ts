import { IsOptional, IsString, IsArray } from "class-validator";
import { Organization as IOrganization, HostApprovalSubmissionProgress, ID } from "@yonder/db";

import { BaseModel } from "../../utility/db";
import { IsYonderEnum } from "../../utility/validators";

export class Organization extends BaseModel implements IOrganization {
    @IsString()
    name: string;

    @IsOptional()
    @IsString()
    businessPhone: string;

    @IsOptional()
    approvalSubmissionId?: ID;

    @IsOptional()
    @IsYonderEnum(HostApprovalSubmissionProgress)
    approvalSubmissionProgress?: HostApprovalSubmissionProgress;

    @IsString()
    website?: string;

    @IsString()
    @IsOptional()
    referralWriteIn?: string;

    @IsOptional()
    @IsArray()
    propertyIds: ID[];

    @IsOptional()
    @IsArray()
    activityIds: ID[];
}
