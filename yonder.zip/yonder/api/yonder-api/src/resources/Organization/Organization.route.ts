import { Organization } from "./Organization.model";
import { User } from "../User/User.model";

import { DAO, handleError } from "../../utility/db";
import { expandRoutes, IRoute, ROUTE, GET, POST, PATCH, routeCRUDGenerator } from "../../utility/routes";
import EndpointPermissions from "../../utility/endpoint-permissions";

import axios from "axios";
import { Environment } from "../../utility/system";

// const routesHostApprovalSubmission: IRoute[] = [...routeCRUDGenerator(Organization)];
const routesUserPrivate: IRoute[] = [
    {
        path: "/users",
        type: GET,
        handler: async (req, res, next) => {
            try {
                const { organizationId } = req.userDetails;
                const parseUserObject = (response: any[]) => {
                    return response.map(({ id, firstName, lastName, email, permissions }) => ({
                        id,
                        firstName,
                        lastName,
                        email,
                        permissions
                    }));
                };

                const response = await DAO.findManyByKeyValue(User.name, User, "organizationId", organizationId).then(
                    (response) => parseUserObject(response)
                );
                res.status(200).json(response);
            } catch (err) {
                next(handleError(err));
            }
        }
    },

    // Gets an organization by id
    // api/organizations/:id
    {
        path: "/:id",
        type: GET,
        permissions: [EndpointPermissions.disableByOrgId],
        handler: async (req, res, next) => {
            try {
                // if (req.params.id !== req.userDetails.organizationId) {
                //     return res.status(401).send({ message: "Not Authorized" });
                // }
                const response: Organization = await DAO.findOneByID(Organization.name, req.params.id);
                res.status(200).json(response);
            } catch (err) {
                next(handleError(err));
            }
        }
    },

    // Creates an organization
    // api/organizations
    {
        path: "/",
        type: POST,
        handler: async (req, res, next) => {
            try {
                const response = await DAO.create(Organization.name, req.body, Organization);

                if (Environment.isProduction) {
                    // Zapier for the win
                    try {
                        console.log(JSON.stringify(req.body));
                        let payload: any = {
                            id: response.id || "",
                            name: response.name || "",
                            website: response.website || "",
                            phone: response.businessPhone || ""
                        };

                        const zapierWebhookUrl = "https://hooks.zapier.com/hooks/catch/4542863/obawecb/";
                        await axios.post(zapierWebhookUrl, payload);
                    } catch (err) {
                        console.log(err);
                    }
                }

                res.status(201).json(response);
            } catch (err) {
                next(handleError(err));
            }
        }
    },

    // Updates an organization's fields
    // api/organizations/:id
    {
        path: "/:id",
        type: PATCH,
        permissions: [EndpointPermissions.disableByOrgId],
        handler: async (req, res, next) => {
            try {
                let objToUpdate = req.body;
                // if (req.params.id !== req.userDetails.organizationId) {
                //     return res.status(401).send({ message: "Not Authorized" });
                // }
                await DAO.updateOneByID(Organization.name, req.params.id, objToUpdate, Organization);
                res.status(207).json({
                    id: req.params.id,
                    ...objToUpdate
                });
            } catch (err) {
                next(handleError(err));
            }
        }
    }
];

export default {
    path: `/organizations`,
    type: ROUTE,
    permissions: [],
    handler: expandRoutes([], routesUserPrivate)
} as IRoute;
