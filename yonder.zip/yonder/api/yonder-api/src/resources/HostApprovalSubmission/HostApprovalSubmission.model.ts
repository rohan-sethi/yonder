import { IsString, IsNumber, IsOptional, IsBoolean } from "class-validator";

import {
    HostApprovalSubmission as IHostApprovalSubmission,
    ExperienceCategories,
    ActivityCountRanges,
    ActivityTypes,
    LocationAddress,
    OrganizationCertificates,
    SustainabilityEfforts,
    ID,
    PropertyManagementHost
} from "@yonder/db";

import { BaseModel } from "../../utility/db";
import { IsYonderEnum } from "../../utility/validators";

export class HostApprovalSubmission extends BaseModel implements IHostApprovalSubmission {
    @IsOptional()
    @IsYonderEnum(ExperienceCategories)
    experienceCategory?: ExperienceCategories;

    @IsOptional()
    @IsNumber()
    overnightStaysCount: number;

    @IsOptional()
    @IsYonderEnum(ActivityCountRanges)
    activityCountRange?: ActivityCountRanges;

    @IsOptional()
    @IsYonderEnum(ActivityTypes)
    activities: ActivityTypes[];

    @IsOptional()
    @IsString({ each: true })
    samplePhotos: ID[];

    @IsOptional()
    location: LocationAddress;

    @IsOptional()
    @IsString()
    description?: string;

    @IsOptional()
    @IsYonderEnum(OrganizationCertificates)
    certificates: OrganizationCertificates[];

    @IsOptional()
    @IsString({ each: true })
    otherCertificates: string[];

    @IsOptional()
    @IsYonderEnum(SustainabilityEfforts)
    sustainabilityEfforts: SustainabilityEfforts[];

    @IsOptional()
    @IsString({ each: true })
    otherSustainabilityEfforts: string[];

    @IsOptional()
    @IsBoolean()
    scoutSetupPermission: boolean;

    @IsOptional()
    @IsString()
    socialLinks?: string;

    @IsOptional()
    propertyManagementHost?: PropertyManagementHost;
}
