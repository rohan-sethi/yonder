import { HostApprovalSubmission } from "./HostApprovalSubmission.model";
import { expandRoutes, IRoute, ROUTE, POST, GET, PATCH, routeCRUDGenerator } from "../../utility/routes";
import { DAO, handleError } from "../../utility/db";
import EndpointPermissions from "../../utility/endpoint-permissions";
import { routesImageAssetsHelper } from "../ImageAsset/ImageAsset.route";

// const routesHostApprovalSubmission: IRoute[] = [...routeCRUDGenerator(HostApprovalSubmission)];

const routesHostApprovalPrivate: IRoute[] = [
    ...routesImageAssetsHelper([EndpointPermissions.enableByHostApprovalSubmission]),
    // Creates a new host approval submission
    // api/host-approval-submissions
    {
        path: "/",
        type: POST,
        handler: async (req, res, next) => {
            try {
                const response = await DAO.create(HostApprovalSubmission.name, req.body, HostApprovalSubmission);
                res.status(201).json(response);
            } catch (err) {
                next(handleError(err));
            }
        }
    },

    // Gets host approval submission
    // api/host-approval-submissions/:id
    {
        path: "/:id",
        permissions: [EndpointPermissions.enableHostApprovalSubmissionByOrgId],
        type: GET,
        handler: async (req, res, next) => {
            try {
                const response: HostApprovalSubmission = await DAO.findOneByID(
                    HostApprovalSubmission.name,
                    req.params.id
                );
                res.status(200).json(response);
            } catch (err) {
                next(handleError(err));
            }
        }
    },

    // Updates host approval submission
    // api/host-approval-submissions/:id
    {
        path: "/:id",
        type: PATCH,
        handler: async (req, res, next) => {
            try {
                let objToUpdate = req.body;
                await DAO.updateOneByID(
                    HostApprovalSubmission.name,
                    req.params.id,
                    objToUpdate,
                    HostApprovalSubmission
                );

                /*
                // Zapier for the win
                try {
                    console.log(JSON.stringify(req.body));
                    let payload: any = {
                        id: req.body.id || '',
                        experienceCategory: req.body.experienceCategory || '',
                        overnightStaysCount: req.body.overnightStaysCount || '',
                        activityCountRange: req.body.activityCountRange || '',
                        activities: (req.body.activities || []).join(", "),
                        address1: (req.body.location || {}).address1 || '',
                        address2: (req.body.location || {}).address2 || '',
                        city: (req.body.location || {}).city || '',
                        state: (req.body.location || {}).state || '',
                        zipCode: (req.body.location || {}).zipCode || '',
                        description: req.body.description || '',
                        certificates: (req.body.certificates || []).join(", "),
                    };

                    console.log(payload);
                    const zapierWebhookUrl = 'https://hooks.zapier.com/hooks/catch/4542863/obagqef/';
                    await axios.post(zapierWebhookUrl, payload);
                } catch (err) {
                }
                */

                res.status(207).json({
                    id: req.params.id,
                    ...objToUpdate
                });
            } catch (err) {
                next(handleError(err));
            }
        }
    }
];

export default {
    path: `/host-approval-submissions`,
    type: ROUTE,
    handler: expandRoutes([], routesHostApprovalPrivate)
} as IRoute;
