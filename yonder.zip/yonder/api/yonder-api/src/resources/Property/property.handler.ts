import { DAO } from "../../utility/db";
import { BaseModel } from "../../utility/db";
import { PropertyDetailFull } from "@yonder/db";
import { Property, ImageAsset } from "../models";
import { User } from "../User/User.model";
import * as Evalues from "@yonder/db/src/enums";

export class PropertyHandler extends BaseModel {

    public static async getPropertyDetails(propertyId: string, userDetails: User) {
        try {

            let properties: Property = await DAO.findOneByID(Property.name, propertyId) || null;
            let output = this.generateMappings();
            properties = this.overlayProvertyWithLabel(properties, output);
            let galleryPhotos: any = null;
            let coverPhoto: any = null;
            let fullDetails: PropertyDetailFull = new PropertyDetailFull();

            if (typeof properties.galleryPhotos != "undefined" && properties.galleryPhotos.length > 0) {
                let photos = await DAO.getMultipleDocById(ImageAsset.name, properties.galleryPhotos)
                galleryPhotos = Object.assign([], photos) || null;
            }

            if (typeof properties.coverPhoto != "undefined" && properties.coverPhoto.length > 0) {
                let coverImg = await DAO.findOneByID(ImageAsset.name, properties.coverPhoto);
                coverPhoto = Object.assign({}, coverImg) || null;
            }

            fullDetails.host = Object.assign({}, userDetails);
            fullDetails.photos = { galleryPhotos, coverPhoto };
            fullDetails.property = properties;
            return fullDetails;
        }
        catch (err) {
            return err;
        }
    }

    private static generateMappings() {
        let currentObj = {};
        let finalObj: any = {};
        let output: any = {}
        Object.entries(Evalues).map(k => {
            if ((typeof k[1]).toLowerCase() === "object" && !(k[1] instanceof Array)) {
                Object.assign(currentObj, k[1])
            }
            if ((typeof k[1]).toLowerCase() === "function") {
                if (k[0].toLowerCase().includes("label")) {
                    Object.values(currentObj).forEach(val => {
                        finalObj[<any>val] = k[1];
                    })
                    Object.assign(output, finalObj)
                    finalObj = {};
                    currentObj = {};
                }
            }
        })
        return output;
    }

    private static overlayProvertyWithLabel(properties, output) {
        Object.entries(properties).forEach(e => {
            try {
                if (e[1] instanceof Array) {
                    let arr: any = [];
                    e[1].forEach(ele => {
                        let k = output[ele];
                        if (typeof k !== "undefined")
                            arr.push(k(ele));
                    })
                    properties[e[0]] = arr;
                }
                else if (e[1] instanceof Object) {
                    let obj: any = {};
                    Object.entries(e[1]).forEach(ele => {
                        let k = output[<any>ele[1]];
                        if (typeof k !== "undefined") {
                            obj[ele[0]] = k(ele[1])
                        }
                        else {
                            obj[ele[0]] = ele[1];
                        }

                    })
                    properties[e[0]] = obj;
                }
                // else {
                //     let k = output[<any>e[1]];
                //     if (typeof k !== "undefined") {
                //         properties[<any>e[0]] = k(e[1]);
                //     }
                // }
            } catch (err) { }
        })
        return properties;
    }
}
