import { IsString, IsOptional, IsNumber, IsArray, IsBoolean } from "class-validator";
import {
    Property as IProperty,
    ID,
    Medals,
    PropertyTypes,
    OfferingCategories,
    Amenities,
    Keywords,
    CurrencyCodes,
    LanguageCodes,
    PropertyPricing,
    PropertyLocation,
    PropertyContent,
    CancellationPolicies,
    ExperienceCategories,
    AvailabilityTimesByHour,
    PropertyBedroom,
    ListingProgress,
    ListingSectionProgresses,
    RoadTypes,
    SustainabilityEfforts,
    TemperatureRanges,
    OrganizationCertificates
} from "@yonder/db";

import { BaseModel } from "../../utility/db";
import { IsYonderEnum } from "../../utility/validators";

export class Property extends BaseModel implements IProperty {
    @IsString()
    @IsOptional()
    name: string;

    @IsOptional()
    location: PropertyLocation;

    @IsString()
    @IsOptional()
    summary?: string;

    @IsString()
    @IsOptional()
    whatWeLove?: string;

    @IsOptional()
    @IsString({ each: true })
    keyThingsToKnow: string[];

    @IsOptional()
    @IsArray()
    content: PropertyContent[];

    @IsOptional()
    @IsString()
    coverPhoto?: ID;

    @IsOptional()
    @IsString({ each: true })
    galleryPhotos: ID[];

    @IsOptional()
    @IsString()
    hostId?: ID;

    @IsOptional()
    @IsArray()
    medals: Medals[];

    @IsOptional()
    @IsYonderEnum(PropertyTypes)
    propertyType: PropertyTypes;

    @IsOptional()
    @IsYonderEnum(ExperienceCategories)
    experienceCategories: ExperienceCategories[];

    @IsOptional()
    category?: OfferingCategories;

    @IsOptional()
    @IsArray()
    bedrooms: PropertyBedroom[];

    @IsOptional()
    @IsArray()
    commonSpaceRooms: PropertyBedroom[];

    @IsOptional()
    @IsNumber()
    guestCapacity: number;

    @IsOptional()
    @IsNumber()
    bedroomCount: number;

    @IsOptional()
    @IsNumber()
    fullBathroomCount: number;

    @IsOptional()
    @IsNumber()
    halfBathroomCount: number;

    @IsArray()
    @IsYonderEnum(Amenities)
    amenities: Amenities[];

    @IsArray()
    @IsYonderEnum(Keywords)
    keywords: Keywords[];

    @IsOptional()
    @IsYonderEnum(CurrencyCodes)
    currency: CurrencyCodes;

    @IsOptional()
    pricing: PropertyPricing;

    @IsOptional()
    @IsYonderEnum(LanguageCodes)
    language?: LanguageCodes;

    @IsOptional()
    @IsNumber()
    minimumStay: number;

    @IsOptional()
    @IsNumber()
    weekendMinimumStay: number;

    @IsOptional()
    @IsNumber()
    overallRating?: number | null;

    @IsOptional()
    @IsNumber()
    squareFootage?: number | null;

    // property rules
    @IsOptional()
    @IsString({ each: true })
    propertyRules: string[];

    @IsOptional()
    @IsBoolean()
    hasRequiredSafetyFeatures: boolean;

    @IsOptional()
    @IsYonderEnum(AvailabilityTimesByHour)
    checkInTime: AvailabilityTimesByHour;

    @IsOptional()
    @IsYonderEnum(AvailabilityTimesByHour)
    checkOutTime: AvailabilityTimesByHour;

    @IsOptional()
    @IsBoolean()
    suitableForChildren: boolean;

    @IsOptional()
    @IsString()
    suitableForChildrenDescription?: string;

    @IsOptional()
    @IsBoolean()
    suitableForInfants: boolean;

    @IsOptional()
    @IsString()
    suitableForInfantsDescription?: string;

    @IsOptional()
    @IsBoolean()
    petsAllowed: boolean;

    @IsOptional()
    @IsString()
    petsAndAnimalsPolicyDescription?: string;

    @IsOptional()
    @IsBoolean()
    handicapAccessible: boolean;

    @IsOptional()
    @IsString()
    handicapAccessibleDescription?: string;

    @IsOptional()
    @IsBoolean()
    smokingAllowed: boolean;

    @IsOptional()
    @IsString()
    smokingPolicyDescription?: string;

    @IsOptional()
    @IsBoolean()
    potentialForNoise: boolean;

    @IsOptional()
    @IsString()
    potentialNoiseDescription?: string;

    @IsOptional()
    @IsBoolean()
    surveillanceOrRecordingDeviceOnProperty: boolean;

    @IsOptional()
    @IsString()
    surveillanceOrRecordingDeviceDescription?: string;

    @IsOptional()
    @IsString({ each: true })
    transportationOptions: string[];

    @IsOptional()
    @IsBoolean()
    ridesharingApps: boolean;

    @IsOptional()
    @IsString()
    nearestAirport?: string;

    @IsOptional()
    @IsNumber()
    milesToNearestAirport?: number | null;

    @IsOptional()
    @IsNumber()
    milesToNearestGroceryStore?: number | null;

    @IsOptional()
    @IsString()
    groceryStoreRecommendation?: string;

    @IsOptional()
    @IsBoolean()
    lessThanMileToNearestGroceryStore: boolean;

    @IsOptional()
    @IsBoolean()
    walkingDistanceToNearestGroceryStore: boolean;

    @IsOptional()
    milesToNearestGasStation?: number | null;

    @IsOptional()
    @IsBoolean()
    lessThanMileToNearestGasStation: boolean;

    @IsOptional()
    @IsBoolean()
    restaurantOnSite: boolean;

    @IsOptional()
    @IsString({ each: true })
    suggestedRestaurantsNearby: string[];

    @IsOptional()
    @IsNumber()
    milesToNearestOffSiteRestaurant?: number | null;

    @IsOptional()
    @IsBoolean()
    lessThanMileToNearestOffSiteRestaurant: boolean;

    @IsOptional()
    @IsBoolean()
    gateEntry: boolean;

    @IsOptional()
    @IsBoolean()
    walkingHikingTrailsAdjacentToProperty: boolean;

    @IsOptional()
    @IsString({ each: true })
    recommendedThingsToDoOnProperty: string[];

    @IsOptional()
    @IsString({ each: true })
    recommendedThingsToDoOffProperty: string[];

    @IsOptional()
    @IsString({ each: true })
    footwearRecommendations: string[];

    @IsOptional()
    @IsYonderEnum(RoadTypes)
    privateRoadType: RoadTypes;

    @IsOptional()
    @IsYonderEnum(TemperatureRanges)
    winterAverageTemperatureFahrenheit: TemperatureRanges;

    @IsOptional()
    @IsYonderEnum(TemperatureRanges)
    summerAverageTemperatureFahrenheit: TemperatureRanges;

    @IsOptional()
    @IsBoolean()
    fourWheelDriveSuggestedToGetToProperty: boolean;

    @IsOptional()
    @IsString()
    animalsOnPropertyPolicy?: string;

    @IsOptional()
    @IsYonderEnum(OrganizationCertificates)
    certificates: OrganizationCertificates[];

    @IsOptional()
    @IsString({ each: true })
    otherCertificates: string[];

    @IsOptional()
    @IsYonderEnum(SustainabilityEfforts)
    sustainabilityEfforts: SustainabilityEfforts[];

    @IsOptional()
    @IsString({ each: true })
    otherSustainabilityEfforts: string[];

    @IsOptional()
    @IsString()
    accessibilityDescription?: string;

    @IsOptional()
    @IsBoolean()
    hostOnProperty: boolean;

    @IsOptional()
    @IsNumber()
    maximumStay: number;

    @IsOptional()
    @IsNumber()
    preparationDays: number;

    @IsOptional()
    @IsYonderEnum(CancellationPolicies)
    cancellationPolicy?: CancellationPolicies;

    @IsOptional()
    @IsArray()
    activitiesAvailable: ID[];

    @IsOptional()
    @IsYonderEnum(ListingProgress)
    listingProgress?: ListingProgress;

    @IsOptional()
    sectionProgress: ListingSectionProgresses;
}
