import { BaseModel } from "../../utility/db";

// TODO remove if still unused
export class ChatHandler extends BaseModel {
    // TODO
}
