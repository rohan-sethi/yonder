import { expandRoutes, IRoute, ROUTE, GET, POST, routeCRUDGenerator } from "../../utility/routes";
import { Listings } from "./Listings.model";
import { DAO, handleError } from "../../utility/db";

const routesListings: IRoute[] = [
    // get featured listings
    // /api/listings/featured
    {
        path: "/featured",
        type: GET,
        handler: async (req: any, res: any, next: any) => {
            try {
                const response = await DAO.findMany(Listings.name, Listings);
                res.status(200).json(response);
            } catch (err) {
                next(handleError(err));
            }
        }
    },
    ...routeCRUDGenerator(Listings)
];

export default {
    path: `/listings`,
    type: ROUTE,
    handler: expandRoutes([], routesListings)
} as IRoute;
