import { IsString, IsOptional, IsArray } from "class-validator";
import { Listings as IListings, SavedSearches, MoreButton, ListingContent } from "@yonder/db";

import { BaseModel } from "../../utility/db";

export class Listings extends BaseModel implements IListings {
    @IsString()
    title: string;

    @IsOptional()
    moreButton?: MoreButton | null;

    @IsArray()
    @IsOptional()
    savedSearches?: SavedSearches[];

    @IsArray()
    @IsOptional()
    listings?: ListingContent[];
}
