import { IsString, IsOptional, IsNumber, IsBoolean, ValidateIf } from "class-validator";
import { TransactionType, CurrencyCodes, PromoCode } from "@yonder/db";

import { BaseModel } from "../../utility/db";

export class Transaction extends BaseModel {
    @IsString()
    transactionId: string;

    transactionType: TransactionType = TransactionType.Booking;

    @IsOptional()
    @IsBoolean()
    isYonderWalletTransaction?: boolean = false;

    @ValidateIf((o) => o.parentTransactionId !== null)
    @IsString()
    @IsOptional()
    parentTransactionId?: string | null = null; // To refund a user via same payment method, Tx id may be needed

    @IsString()
    @IsOptional()
    propertyId?: string;

    @IsString()
    @IsOptional()
    bookingId?: string; // optional due to generic nature of a transaction

    @IsString()
    payerId: string;

    @IsString()
    payeeId: string;

    @IsOptional()
    @IsNumber()
    fees?: number;

    @IsString()
    @IsOptional()
    feesSumamary?: string;

    @IsNumber()
    amount: number;

    @IsString()
    @IsOptional()
    description?: string;

    @IsString()
    @IsOptional()
    transferOn: string; // iso javascript date string

    @IsOptional()
    currency?: CurrencyCodes;

    @IsOptional()
    promoCode?: PromoCode;

    @IsOptional()
    @IsNumber()
    discountAmount?: number;
}
