import { Transaction } from "./Transaction.model";
import { expandRoutes, IRoute, ROUTE, routeCRUDGenerator } from "../../utility/routes";

const routesPaymentMethods: IRoute[] = [...routeCRUDGenerator(Transaction)];

export default {
    path: `/transactions`,
    type: ROUTE,
    handler: expandRoutes(routesPaymentMethods)
} as IRoute;
