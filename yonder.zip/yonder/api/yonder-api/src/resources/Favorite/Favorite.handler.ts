import { DAO } from "../../utility/db";
import { BaseModel } from "../../utility/db";
import { Favorite } from "./Favorite.model";

export class FavoriteHandler extends BaseModel {
    static async updateSettingItem<T extends BaseModel>(item: T, userId: string) {
        let results = await DAO.updateOneByKeyValue(Favorite.name, item, "userId", userId);
        return results;
    }

    static async createNewFavorite(userId: string, listingId: string) {
        let result: Favorite;
        try {
            let newObj: Favorite = new Favorite();

            newObj.userId = userId;
            newObj.listingId = listingId;

            result = await DAO.create(Favorite.name, newObj, Favorite);
        } catch (Err) {
            return new Error(Err.message);
        }
        return result;
    }
}
