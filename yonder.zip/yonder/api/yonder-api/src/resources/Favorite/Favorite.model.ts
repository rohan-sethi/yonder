import { IsString } from "class-validator";

import { BaseModel } from "../../utility/db";

import { Favorite as IFavorite } from "@yonder/db";

export class Favorite extends BaseModel implements IFavorite {
    @IsString()
    userId: string;

    @IsString()
    listingId: string;
}
