import { expandRoutes, IRoute, ROUTE, GET, POST, routeCRUDGenerator } from "../../utility/routes";
import { DAO, handleError } from "../../utility/db";
import EndpointPermissions from '../../utility/endpoint-permissions'
import { Favorite } from "./Favorite.model";
import { Property } from "../Property/Property.model";
import { FavoriteHandler } from "./Favorite.handler";

// const routesFavoritesPublic: IRoute[] = [];

const routesFavoritesPrivate: IRoute[] = [
    // get Favorites for a given userId
    // /api/favorites
    {
        path: "/",
        type: GET,
        handler: async (req: any, res: any, next: any) => {
            try {
                // TODO: remove invalid favs from user's fav collection???
                const { id: userId } = req.userDetails;

                const userFavs = await DAO.findManyByKeyValue(Favorite.name, Favorite, "userId", userId);
                const listings = await DAO.getMultipleDocByIdIfExist(Property.name, userFavs.map((favItem) => favItem.listingId));

                let listingsPreviewById = {};

                listings.forEach((listingItem: Property) => {
                    listingsPreviewById[listingItem.id] = listingItem;
                });

                let favsWithListing = userFavs.map((favItem) => {
                    let fav = { ...favItem, listing: null };

                    if (favItem.listingId in listingsPreviewById) {
                        {
                            fav["listing"] = listingsPreviewById[favItem.listingId];
                        }
                    }

                    return fav;
                });
                const results = favsWithListing;

                res.status(200).json(results);
            } catch (err) {
                next(handleError(err));
            }
        }
    },

    // Get Favorite for a given userId for a given listingId, if it exists
    // /api/favorites/:listingId
    {
        path: "/:id",
        type: GET,
        handler: async (req: any, res: any, next: any) => {
            try {
                const { id: userId } = req.userDetails;
                const { id: listingId } = req.params;

                let retrieveResponse = await DAO.getManyByTwoParams(
                    Favorite.name,
                    Favorite,
                    "listingId",
                    listingId,
                    "userId",
                    userId
                );

                if (retrieveResponse.length > 0) {
                    return res.status(200).json(retrieveResponse[0]);
                }

                res.status(404).json();
            } catch (err) {
                next(handleError(err));
            }
        }
    },

    // Add Favorite for a given userId
    // /api/favorites/:listingId/save
    {
        path: "/:id/save",
        type: POST,
        permissions: [EndpointPermissions.enableAccessIfExists(Property)],
        handler: async (req: any, res: any, next: any) => {
            try {
                const { id: userId } = req.userDetails;
                const { id: listingId } = req.params;

                const retrieveResponse = await DAO.getManyByTwoParams(
                    Favorite.name,
                    Favorite,
                    "listingId",
                    listingId,
                    "userId",
                    userId
                );

                if (retrieveResponse.length) {
                    // console.log('cannot favorite that which has already been favorited.')
                    return res.status(200).json(retrieveResponse[0]);
                }

                const response = await FavoriteHandler.createNewFavorite(userId, listingId);
                if (response instanceof Error) {
                    res.status(422).json({ message: response.message });
                    return;
                } else res.status(200).json(response);
            } catch (err) {
                next(handleError(err));
            }
        }
    },

    // Remove Favorite for a given userId
    // /api/favorites/:listingId/unsave
    {
        path: "/:id/unsave",
        type: POST,
        permissions: [EndpointPermissions.enableAccessIfExists(Property)],
        handler: async (req: any, res: any, next: any) => {
            try {
                const { id: userId } = req.userDetails;
                const { id: listingId } = req.params;

                let retrieveResponse = await DAO.getManyByTwoParams(
                    Favorite.name,
                    Favorite,
                    "listingId",
                    listingId,
                    "userId",
                    userId
                );

                if (retrieveResponse.length === 0) {
                    // console.log('cannot unfavorite that which has not been favorited')
                    return res.status(200).json();
                }

                let deleteResponse = await DAO.deleteByTwoParams(
                    Favorite.name,
                    Favorite,
                    "listingId",
                    listingId,
                    "userId",
                    userId
                );

                if (deleteResponse instanceof Error) {
                    return res.status(422).json({ message: deleteResponse.message });
                }

                return res.status(200).json();
            } catch (err) {
                next(handleError(err));
            }
        }
    }
];

export default {
    path: `/favorites`,
    type: ROUTE,
    handler: expandRoutes([], routesFavoritesPrivate)
} as IRoute;
