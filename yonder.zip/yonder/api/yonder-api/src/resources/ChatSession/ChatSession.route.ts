import { ChatSession } from "./ChatSession.model";
import { History } from "./ChatSession.model";
import { ChatHandler } from "./ChatSession.handler";

import { expandRoutes, IRoute, ROUTE, GET, POST, routeCRUDGenerator } from "../../utility/routes";

import { DAO, handleError } from "../../utility/db";

const routesChatSessionsPublic: IRoute[] = [
    // get all chat sessions for a given user
    // /api/chat/sessions
    {
        path: "/sessions",
        type: GET,
        handler: async (req: any, res: any, next: any) => {
            // NOTE: User UID will be derived from firebase authentication middleware in the future
            let currentUserUid = "tempMockUserUid";

            let userChatSessions = [];

            // TODO: create a new method in the DAO module to findByKeyValue, where it will do a query by a given Key and search for a value. In this case the key will be "sender" and the value will be currentUserUid
            let result = await DAO.findMany("ChatSession", ChatSession);

            res.send(result);
        }
    },
    // add a new chat session for a given user
    // /api/chat/sessions
    {
        path: "/sessions",
        type: POST,
        handler: async (req: any, res: any, next: any) => {
            try {
                const response = await DAO.create(ChatSession.name, req.body, ChatSession);
                res.status(201).json(response);
            } catch (err) {
                next(handleError(err));
            }
        }
    },
    // push a message into a ChatSession
    // /api/chat/push-message
    {
        path: "/sessions/:sessionId/push-message",
        type: POST,
        handler: async (req: any, res: any, next: any) => {
            try {
                let history = new History();

                history.sender = req.body.sender;
                history.text = req.body.text;
                history.id = req.params.sessionId;

                const results = ChatHandler.pushChats(history);

                res.send(results);
            } catch (err) {
                next(handleError(err));
            }
        }
    }
];

const routesChatSessionsPrivate: IRoute[] = []

export default {
    path: `/chat`,
    type: ROUTE,
    handler: expandRoutes(routesChatSessionsPublic, routesChatSessionsPrivate)
} as IRoute;
