import { DAO } from "../../utility/db";
import { BaseModel } from "../../utility/db";

export class ChatHandler extends BaseModel {
    static async createChats<T extends BaseModel>(item: T) {
        let val = await DAO.createSessionRecordByID("ChatSession", item);
        return val;
    }

    static async pushChats<T extends BaseModel>(item: T) {
        let val = await DAO.insertChatByID("ChatSession", item);
        return val;
    }
}
