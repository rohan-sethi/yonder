import { IsString, IsOptional, IsDateString, IsArray } from "class-validator";

import { BaseModel } from "../../utility/db";

export class History extends BaseModel {
    @IsDateString()
    createdAt: Date = new Date();

    @IsString()
    text: string;

    @IsString()
    sender: string;

    set setSender(sender: string) {
        this.sender = sender;
    }
    set setText(text: string) {
        this.text = text;
    }
}

export class ChatSession extends BaseModel {
    @IsString()
    sender: string;

    @IsString()
    receiver: string;

    @IsArray()
    chat: History[] = [];

    //@IsDateString()
    //createdAt: Date = new Date();

    @IsOptional()
    @IsString()
    senderName: string;

    @IsOptional()
    @IsString()
    receiverName: string;

    set setSender(sender: string) {
        this.sender = sender;
    }
    set setReceiver(receiver: string) {
        this.receiver = receiver;
    }
    set setSenderName(senderName: string) {
        this.senderName = senderName;
    }
    set setReceiverName(receiverName: string) {
        this.receiverName = receiverName;
    }
}
