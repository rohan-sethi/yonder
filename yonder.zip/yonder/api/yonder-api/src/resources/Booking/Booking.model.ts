import { IsString, IsOptional, IsNumber, IsDate, IsArray, IsNotEmpty } from "class-validator";

import { BaseModel } from "../../utility/db";

export class Booking extends BaseModel {
    // TODO : Convert input to Date Format

    @IsString()
    property_id: string;

    @IsString()
    user_id: string;

    @IsNotEmpty()
    @IsDate()
    checkInDate: Date;

    @IsNotEmpty()
    @IsDate()
    checkOutDate: Date;

    @IsArray()
    pricePerDay: Array<{ date: Date; price: number }>;

    @IsNumber()
    taxes: number;

    @IsArray()
    fees: Array<{ description: string; cost: number }>;

    @IsNotEmpty()
    @IsDate()
    dateOfBooking: Date;

    @IsNumber()
    adultGuestCount: number;

    @IsNumber()
    childGuestCount: number;

    @IsOptional()
    @IsString()
    guestNote: string;

    @IsString()
    @IsOptional()
    promoCode: string;

    @IsNumber()
    @IsOptional()
    discountAmount: number;
}
