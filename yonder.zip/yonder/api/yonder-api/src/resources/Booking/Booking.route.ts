import { Booking } from "./Booking.model";
import { expandRoutes, IRoute, ROUTE, GET, POST, DELETE } from "../../utility/routes";

import { DAO, handleError } from "../../utility/db";
import { BookingHandler } from "./Booking.handler";

const routesBookingsPublic: IRoute[] = [
    {
        // Returns if booking is possible for the given date range
        // /api/booking/valid-date-range
        path: "/valid-date-range",
        type: GET,
        handler: async (req: any, res: any, next: any) => {
            const { checkInDate, checkOutDate, listingId } = req.body;

            try {
                let result: Boolean = await BookingHandler.rangeValidator(listingId, checkInDate, checkOutDate);
                res.send(result);
            } catch (err) {
                next(handleError(err));
            }

            // try {
            //     let results: Array<Booking> = await DAO.findManyByKeyValue(
            //         Booking.name,
            //         Booking,
            //         "property_id",
            //         req.body.property_id
            //     );
            //     let filterResults: boolean = await DAO.filterByDateRange(
            //         results,
            //         req.body.checkInDate,
            //         req.body.checkOutDate
            //     );
            //     res.status(200).send(filterResults);
            // } catch (err) {
            //     next(handleError(err));
            // }
        }
    },
    // {
    //     // Returns the booking dates for a perticular property-id
    //     // /api/booking/get-avaiable-dates
    //     path: "/get-avaiable-dates/:id",
    //     type: GET,
    //     handler: async (req: any, res: any, next: any) => {
    //         let results: Array<Booking> = await DAO.findManyByKeyValue(
    //             Booking.name,
    //             Booking,
    //             "property_id",
    //             req.params.id
    //         );
    //         let result: any = new Object();
    //         result.data = "Booking Schedule";
    //         result.list = results.map((obj) => {
    //             return {
    //                 from: obj.checkInDate,
    //                 to: obj.checkOutDate
    //             };
    //         });
    //         res.status(200).json(result);
    //     }
    // },
    // {
    //     // Creates a new booking based on parameters
    //     // /api/booking
    //     path: "/",
    //     type: POST,
    //     handler: async (req: any, res: any, next: any) => {
    //         try {
    //             let results: Array<Booking> = await DAO.findManyByKeyValue(
    //                 Booking.name,
    //                 Booking,
    //                 "property_id",
    //                 req.body.property_id
    //             );
    //             let filterResults: boolean = await DAO.filterByDateRange(
    //                 results,
    //                 req.body.checkInDate,
    //                 req.body.checkOutDate
    //             );
    //             if (!filterResults) {
    //                 res.status(409).json({
    //                     error: { message: "Booking not avaiable" }
    //                 });
    //                 return;
    //             }
    //             const response = await BookingHandler.formatAndCreateBooking(req.body);
    //             res.status(201).json(response);
    //         } catch (err) {
    //             console.log(err);
    //             next(handleError(err));
    //         }
    //     }
    // },
    // {
    //     // Gets the fee Array from particular booking
    //     // /api/booking/:bookingId/feess
    //     path: "/:bookingId/fees",
    //     type: GET,
    //     handler: async (req: any, res: any, next: any) => {
    //         try {
    //             const response = await DAO.findOneByID("Booking", req.params.bookingId, Booking);
    //             if (typeof response.fees === "undefined")
    //                 res.status(404).json({ message: "..Not Found: " + req.params.bookingId });
    //             else res.status(200).json(response.fees);
    //         } catch (err) {
    //             next(handleError(err));
    //         }
    //     }
    // },

    // Gets booking for current booking ID and future months
    // /api/avail/:propertyId/:monthsCount
    {
        path: "/avail/:id/:mo",
        type: GET,
        handler: async (req: any, res: any, next: any) => {
            const { id: listingId, mo } = req.params;

            try {
                const availableListings = await BookingHandler.getListingsAvailability(listingId, mo);
                res.send(availableListings);
            } catch (err) {
                next(handleError(err));
            }
        }
    }
    // Gets booking for current booking ID and future months
    // /api/avail/:propertyId/:monthsCount
    // {
    //     path: "/avail/:propertyId/:monthsCount",
    //     type: GET,
    //     handler: async (req: any, res: any, next: any) => {
    //         try {
    //             // -------------  MOCK START ---------------
    //             let mock = req.query.mock;
    //             if (mock === "1") {
    //                 let response = await BookingHandler.getMockBookings(req.params.monthsCount, req.params.propertyId);
    //                 if (response instanceof Error) res.status(422).send({ message: response.message });
    //                 else res.status(200).send(response);
    //             }
    //             // -------------  MOCK END ---------------
    //             else {
    //                 let response = await BookingHandler.createDateReferencesAndFetch(
    //                     req.params.monthsCount,
    //                     req.params.propertyId
    //                 );
    //                 res.status(200).send(response);
    //             }
    //         } catch (err) {
    //             handleError(next(new Error("Something went wrong")));
    //         }
    //     }
    // }
];

const routesBookingsPrivate: IRoute[] = [
    // {
    //     // Returns the booking - property array  for a perticular user-id
    //     // /api/booking/
    //     path: "/",
    //     type: GET,
    //     handler: async (req: any, res: any, next: any) => {
    //         try {
    //             let userId = req.userDetails.id;
    //             let result = await BookingHandler.getBookingSorted(userId);
    //             if (result instanceof Error) {
    //                 res.status(404).json({ message: result.message });
    //                 return;
    //             }
    //             res.status(200).json(result);
    //         } catch (err) {
    //             next(handleError(err));
    //         }
    //     }
    // },

    // Creates a booking availability on specified date
    // /api/avail/:propertyId/:monthsCount

    {
        path: "/avail/:id",
        type: POST,
        handler: async (req: any, res: any, next: any) => {
            const { id: listingId } = req.params;
            const { price, status, date } = req.body;

            const payload = {
                price,
                status,
                date
            };

            try {
                if (date) {
                    const output = await BookingHandler.createBookingAvailability(listingId, payload);
                    res.send(output);
                }
            } catch (err) {
                next(handleError(err));
            }
        }
    }
];

export default {
    path: `/bookings`,
    type: ROUTE,
    handler: expandRoutes(routesBookingsPublic, routesBookingsPrivate)
} as IRoute;
