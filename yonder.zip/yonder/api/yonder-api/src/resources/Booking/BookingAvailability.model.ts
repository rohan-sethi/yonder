import { IsString, IsOptional, IsNumber } from "class-validator";
import { BaseModel } from "../../utility/db";
import { BookingStatus } from "../../enums/BookingStatus";
import moment from "moment";
import { IsYonderEnum } from "../../utility/validators";

export class BookingAvailability extends BaseModel {
    @IsString()
    listingId: string;

    @IsString()
    date: string;

    @IsOptional()
    dateObject?: Date | moment.Moment;

    @IsYonderEnum(BookingStatus)
    bookingStatus: BookingStatus;

    @IsOptional()
    @IsNumber()
    price?: number;

    @IsOptional()
    @IsString()
    bookedByUserId?: string;

    @IsOptional()
    @IsString()
    userId?: string;

    // @IsString()
    // @IsOptional()
    // currency: string;
}
