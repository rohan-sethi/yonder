import { DAO } from "../../utility/db";
import { BaseModel } from "../../utility/db";
import { Booking } from "./Booking.model";
import { BookingStatus } from "../../enums/BookingStatus";
import { BookingAvailability } from "./BookingAvailability.model";
import { Property } from "../Property/Property.model";
import moment from "moment";
import { makeDay, normalizeDate, dateRangeFinder, WEEKENDS } from "../../utility/dates";

const oneDayAvailabilityBuilder = async (listing: Property, day: moment.Moment): Promise<BookingAvailability> => {
    const {
        pricing: { defaultWeekday, defaultWeekend },
        id: listingId
    } = listing;

    const dayAvailability: BookingAvailability = new BookingAvailability();
    const isWeekend: boolean = WEEKENDS.includes(day.format("dd")) ? true : false;

    dayAvailability.listingId = listingId;
    dayAvailability.price = isWeekend ? +defaultWeekend! : +defaultWeekday!;
    dayAvailability.bookingStatus = BookingStatus.Available;
    dayAvailability.date = day.format();
    dayAvailability.dateObject = day.toDate();

    const invalid = await dayAvailability.validate();

    if (!!invalid) {
        throw invalid;
    }

    return dayAvailability;
};

const bookingAvailArrayModelByDates = async (listing: Property, checkInDateObject: Date, checkOutDateObject: Date) => {
    const dayIterator: moment.Moment = moment(checkInDateObject);
    const endDate: moment.Moment = moment(checkOutDateObject);

    const availability: BookingAvailability[] = [];

    while (dayIterator.isBefore(endDate)) {
        const day: BookingAvailability = await oneDayAvailabilityBuilder(listing, dayIterator);
        availability.push(day);
        dayIterator.add(1, "day");
    }

    return availability;
};

const bookingAvailArrayModelByMonths = async (listing: Property, months: number): Promise<BookingAvailability[]> => {
    const dayIterator: moment.Moment = makeDay();
    const endDate: moment.Moment = makeDay().add(months, "M");

    const availability: BookingAvailability[] = [];

    while (dayIterator.isBefore(endDate)) {
        const day: BookingAvailability = await oneDayAvailabilityBuilder(listing, dayIterator);
        availability.push(day);
        dayIterator.add(1, "day");
    }

    return availability;
};

const updateAvailabilityPricing = (
    bookingAvailModel: BookingAvailability[],
    bookingAvailFromProperty: BookingAvailability[]
): BookingAvailability[] => {
    const bookings: BookingAvailability[] = [...bookingAvailModel];

    bookingAvailFromProperty.forEach((updatedBooking) => {
        bookings.forEach((booking) => {
            if (moment(booking.date).isSame(moment(updatedBooking.date))) {
                Object.assign(booking, updatedBooking);
            }
        });
    });

    return bookings;
};

const removeUnavailableDates = (
    bookingAvailModel: BookingAvailability[],
    bookingAvailFromProperty: BookingAvailability[]
): { [allArrarysReturned: string]: BookingAvailability[] } => {
    const bookings: BookingAvailability[] = [...bookingAvailModel];

    const updatedBookingsDate: BookingAvailability[] = bookingAvailFromProperty.filter(
        (doc) => doc.bookingStatus !== BookingStatus.Available
    );

    updatedBookingsDate.forEach((updatedBooking: BookingAvailability) => {
        bookings.forEach((booking: BookingAvailability) => {
            if (moment(booking.date).isSame(moment(updatedBooking.date))) {
                Object.assign(booking, updatedBooking);
            }
        });
    });

    const availableDates = bookings.filter((booking) => booking.bookingStatus === BookingStatus.Available);
    const unavailableDates = bookings.filter((booking) => booking.bookingStatus !== BookingStatus.Available);

    return { availableDates, unavailableDates };
};

const parseWithPropertyParams = (
    listing: Property,
    availBookings: BookingAvailability[],
    unavailBookings: BookingAvailability[]
): BookingAvailability[] => {
    const { minimumStay, preparationDays } = listing;

    if (minimumStay! <= 1) {
        return availBookings;
    }

    const sortedAvailBookings = [...availBookings].sort(
        (first: BookingAvailability, second: BookingAvailability): number => {
            return moment(first.date).format() < moment(second.date).format() ? -1 : 1;
        }
    );

    const { evaluatedAvailability } = sortedAvailBookings.reduce(
        function(state: { [allArrarysReturned: string]: BookingAvailability[] }, current, i, arr): any {
            const { evalStack, evaluatedAvailability } = state;
            const hasNext = arr[i + 1];

            const twoDaysNotSequential = (firstDay: BookingAvailability, secondDay: BookingAvailability): Boolean => {
                return !moment(firstDay.date)
                    .add(1, "d")
                    .isSame(moment(secondDay.date));
            };

            const stackGreaterThanMinStay = (evalStack: BookingAvailability[], minimumStay: number): Boolean => {
                return evalStack.length >= minimumStay!;
            };

            const markDaysAsAvailable = (): void => {
                evaluatedAvailability.push(...evalStack);
            };

            const emptyEvalStack = (): void => {
                evalStack.splice(0, evalStack.length);
            };

            evalStack.push(current);

            if (hasNext) {
                if (twoDaysNotSequential(current, hasNext)) {
                    if (stackGreaterThanMinStay(evalStack, minimumStay!)) {
                        markDaysAsAvailable();
                    }
                    emptyEvalStack();
                }
            } else {
                markDaysAsAvailable();
            }

            return { ...state, current };
        },
        { evalStack: [], evaluatedAvailability: [] }
    );

    return evaluatedAvailability;
};

export class BookingHandler extends BaseModel {
    static async createBookingAvailability(
        listingId: string,
        payload: { price: number; status: BookingStatus.Available; date: string }
    ): Promise<BookingAvailability> {
        // POST handler for path: /avail/:id,

        const { price, status } = payload;
        try {
            const date: string = normalizeDate(payload.date);
            const updatedAvailability: BookingAvailability = new BookingAvailability();

            updatedAvailability.listingId = listingId;
            updatedAvailability.date = moment(date).format();
            updatedAvailability.dateObject = moment(date).toDate();
            updatedAvailability.bookingStatus = status || BookingStatus.Available;
            price && (updatedAvailability.price = price);

            const invalid = await updatedAvailability.validate();

            if (!!invalid) {
                throw invalid;
            }

            await DAO.insertBookingAvailability(BookingAvailability.name, updatedAvailability);
            return updatedAvailability;
        } catch (err) {
            throw err;
        }
    }

    static async getListingsAvailability(id: string, months: number): Promise<BookingAvailability[]> {
        // GET handler for PATH: /avail/:id/:mo

        const checkInDateObject: Date = makeDay().toDate();
        const checkOutDateObject: Date = makeDay()
            .add(months, "months")
            .toDate();

        try {
            const listing: Property = await DAO.findOneByID(Property.name, id);

            const dateScopedBookingAvailFromProperty: BookingAvailability[] = await DAO.getAvailabilitiesBetweenDates(
                BookingAvailability,
                BookingAvailability.name,
                listing.id,
                checkInDateObject,
                checkOutDateObject
            );

            const availabilityModel = await bookingAvailArrayModelByMonths(listing, months);
            const updatedPricing = updateAvailabilityPricing(availabilityModel, dateScopedBookingAvailFromProperty);
            const { availableDates, unavailableDates } = removeUnavailableDates(
                updatedPricing,
                dateScopedBookingAvailFromProperty
            );
            const overlayAvailableFromPropertyParams = parseWithPropertyParams(
                listing,
                availableDates,
                unavailableDates
            );

            return overlayAvailableFromPropertyParams;
        } catch (err) {
            throw err;
        }
    }

    static async rangeValidator(id: string, checkInDate: string, checkOutDate: string): Promise<any> {
        // GET handler for PATH /valid-date-range

        try {
            const checkInDateObject = makeDay(normalizeDate(checkInDate)).toDate();
            const checkOutDateObject = makeDay(normalizeDate(checkOutDate)).toDate();

            const listing: Property = await DAO.findOneByID(Property.name, id);
            const dateScopedBookingAvailFromProperty: BookingAvailability[] = await DAO.getAvailabilitiesBetweenDates(
                BookingAvailability,
                BookingAvailability.name,
                listing.id,
                checkInDateObject,
                checkOutDateObject
            );

            const {
                minimumStay,
                maximumStay,
                pricing: { cleaningFee }
            } = listing;

            const stayLength = dateRangeFinder(checkInDateObject, checkOutDateObject);
            const ignoreMaxStay = maximumStay === 0;

            const canStay = stayLength >= minimumStay! && (stayLength <= maximumStay! || ignoreMaxStay);

            const canBook = dateScopedBookingAvailFromProperty.filter(
                (avail: BookingAvailability) => avail.bookingStatus !== BookingStatus.Available
            ).length
                ? false
                : true;

            if (canBook && canStay) {
                const availabilityModel = await bookingAvailArrayModelByDates(
                    listing,
                    checkInDateObject,
                    checkOutDateObject
                );
                const updatedPricing = updateAvailabilityPricing(availabilityModel, dateScopedBookingAvailFromProperty);

                const { price } = updatedPricing.reduce(
                    (acc: BookingAvailability, current: BookingAvailability): any => ({
                        ...acc,
                        price: acc.price! + current.price!
                    })
                );

                return { bookable: canStay && canBook, stayPricing: price, stayLength, cleaningFee };
            } else {
                return { bookable: canStay && canBook };
            }
        } catch (err) {
            throw err;
        }
    }
}
