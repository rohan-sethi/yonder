import { IsString, IsOptional, IsBoolean } from "class-validator";
import { Settings as ISettings, CurrencyCodes } from "@yonder/db";

import { BaseModel } from "../../utility/db";

export class Settings extends BaseModel implements ISettings {
    // TODO : Change Max Length - userId / fcmToken
    @IsString()
    userId: string;

    @IsString()
    @IsOptional()
    fcmToken?: string;

    @IsBoolean()
    allowPush: boolean = false;

    @IsString()
    @IsOptional()
    defaultCurrency?: CurrencyCodes;
}
