import { CurrencyCodes } from "@yonder/db";

import { DAO, BaseModel } from "../../utility/db";
import { Settings } from "./Settings.model";

enum Keys {
    Token = "fcmToken",
    AllowPushNotification = "allowPush",
    Currency = "defaultCurrency"
}

export class SettingsHandler extends BaseModel {
    static async updateSettingItem<T extends BaseModel>(item: T, userId: string) {
        let results = await DAO.updateOneByKeyValue(Settings.name, item, "userId", userId);
        return results;
    }

    static async createNewSettings(userId: string) {
        let settings: Settings = new Settings();
        settings.userId = userId;
        let err = await settings.validate();
        if (err != undefined) {
            return new Error(err.message);
        }
        let results = await DAO.create(Settings.name, settings, Settings);
        return results;
    }

    static async isValid(item: Object) {
        const [propertyKeysFromItem] = Object.keys(item);
        let resultStatus: any = new Object();
        resultStatus.success = true;
        resultStatus.status = 200;

        switch (propertyKeysFromItem) {
            case Keys.Token:
                if (item[Keys.Token] === "") {
                    resultStatus.success = false;
                    resultStatus.status = 422;
                    resultStatus.msg = "Not Proper FCM token";
                }
                break;
            case Keys.AllowPushNotification:
                if (typeof item[Keys.AllowPushNotification] != "boolean") {
                    resultStatus.success = false;
                    resultStatus.status = 422;
                    resultStatus.msg = "Boolean input expected";
                }
                break;
            case Keys.Currency:
                if (!(item[Keys.Currency] in CurrencyCodes)) {
                    resultStatus.success = false;
                    resultStatus.status = 422;
                    resultStatus.msg = "No matching currency found";
                }
                break;
            default:
                resultStatus.success = false;
                resultStatus.status = 422;
                resultStatus.msg = "Required fields not found";
        }
        return resultStatus;
    }
}
