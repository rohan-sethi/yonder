import { expandRoutes, IRoute, ROUTE, GET, POST, routeCRUDGenerator } from "../../utility/routes";

import { DAO, handleError } from "../../utility/db";
import { Settings } from "./Settings.model";
import { SettingsHandler } from "./Settings.handler";

const standardUpdateHandler = async (req: any, res: any, next: any) => {
    // same func used in fcm-token and default-currency endpoints
    try {
        const { id: userId } = req.userDetails
        const isValid = await SettingsHandler.isValid(req.body);
        if (!isValid.success) {
            res.status(isValid.status).json({ message: isValid.msg });
            return;
        }
        const result = await SettingsHandler.updateSettingItem(req.body, userId);
        res.status(result.status).json(result);
    } catch (err) {
        next(handleError(err));
    }
}
const routesSettings: IRoute[] = [
    // get Settings for a given user-id
    // /api/settings
    {
        path: "/",
        type: GET,
        handler: async (req: any, res: any, next: any) => {
            // NOTE: User UID will be derived from firebase authentication middleware in the future
            try {
                let userId = req.userDetails.id;
                let results = await DAO.findManyByKeyValue(Settings.name, Settings, "userId", userId);
                if (results.length === 0) {
                    let newSettings = await SettingsHandler.createNewSettings(userId);
                    if (newSettings instanceof Error) res.status(422).json({ message: newSettings.message });
                    else res.status(200).json(newSettings);
                } else res.status(200).json(results[0]);
            } catch (err) {
                next(handleError(err));
            }
        }
    },
    // Update Settings[Fcm token] for a given user-id
    // /api/fcm-token
    {
        path: "/fcm-token",
        type: POST,
        handler: standardUpdateHandler
    },

    // Update Settings[default-currency] for a given user-id
    // /api/default-currency
    {
        path: "/default-currency",
        type: POST,
        handler: standardUpdateHandler
    },
    // Update Settings[push-notification] for a given userId
    // /api/notify
    {
        path: "/notify",
        type: POST,
        handler: async (req: any, res: any, next: any) => {
            try {
                let userId = req.userDetails.id;
                let isValid = await SettingsHandler.isValid(req.body);
                if (!isValid.success) {
                    res.status(isValid.status).json({ message: isValid.msg });
                    return;
                }

                let pushSettings: any = { allowPush: req.body.allowPush || false }; // TODO: this is the only outlier and it seems redundant. appears as though it can safely use `standardUpdateHandler`

                let result = await SettingsHandler.updateSettingItem(pushSettings, userId);
                res.status(result.status).json(result);
            } catch (err) {
                next(handleError(err));
            }
        }
    }
];

const routesSettingsPublic: IRoute[] = [];

export default {
    path: `/settings`,
    type: ROUTE,
    handler: expandRoutes([], routesSettings)
} as IRoute;
