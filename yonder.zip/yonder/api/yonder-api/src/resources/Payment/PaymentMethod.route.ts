import { PaymentMethod } from "./PaymentMethod.model";

import { expandRoutes, IRoute, ROUTE, GET, POST, DELETE } from "../../utility/routes";

import { DAO, handleError } from "../../utility/db";
import EndpointPermissions from '../../utility/endpoint-permissions'

const routesPaymentMethodsPublic: IRoute[] = [
    // {
    //     path: "/methods",
    //     type: POST,
    //     handler: async (req: any, res: any, next: any) => {
    //         try {
    //             const response = await DAO.create(PaymentMethod.name, req.body, PaymentMethod);
    //             res.status(201).json(response);
    //         } catch (err) {
    //             next(handleError(err));
    //         }
    //     }
    // },
    // {
    //     path: "/methods/:id",
    //     type: DELETE,
    //     handler: async (req: any, res: any, next: any) => {
    //         try {
    //             await DAO.deleteOneByID(PaymentMethod.name, req.params.id);
    //             res.status(204).json();
    //         } catch (err) {
    //             next(handleError(err));
    //         }
    //     }
    // }
];


const routesPaymentMethods: IRoute[] = [
    {
        path: "/methods",
        type: GET,
        handler: async (req: any, res: any, next: any) => {
            const { id: userId } = req.userDetails;
            let results = await DAO.findManyByKeyValue(PaymentMethod.name, PaymentMethod, "userId", userId);
            results = results.map(function (item) {
                delete item.stripeToken;
                return item;
            });
            res.status(200).json(results);
        }
    },
    {
        path: "/methods",
        type: POST,
        handler: async (req: any, res: any, next: any) => {
            const { id: userId } = req.userDetails;
            const payload = { ...req.body, userId };

            try {
                const response = await DAO.create(PaymentMethod.name, payload, PaymentMethod);
                res.status(201).json(response);
            } catch (err) {
                next(handleError(err));
            }
        }
    },
    {
        path: "/methods/:id",
        type: DELETE,
        permissions: [EndpointPermissions.enableAccessToCollectionAssetById(PaymentMethod)],
        handler: async (req: any, res: any, next: any) => {
            try {
                await DAO.deleteOneByID(PaymentMethod.name, req.params.id);
                res.status(204).json();
            } catch (err) {
                next(handleError(err));
            }
        }
    }
]

export default {
    path: `/pay`,
    type: ROUTE,
    handler: expandRoutes([], routesPaymentMethods)
} as IRoute;
