import { IsString, IsOptional, MaxLength, IsNumber, IsBoolean } from "class-validator";

import { BaseModel } from "../../utility/db";

import { PaymentMethod as IPaymentMethod, PaymentMethods, PaymentMethodCreditCardTypes, ID } from "@yonder/db";

export class PaymentMethod extends BaseModel implements IPaymentMethod {
    @IsString()
    method: PaymentMethods;

    @IsString()
    fingerprint: string;

    @IsBoolean()
    isPrimary: boolean;

    @IsString()
    userId: ID;

    @IsString()
    stripeToken: string;

    @IsOptional()
    @IsString()
    ccType: PaymentMethodCreditCardTypes;

    @IsOptional()
    @IsString()
    ccName: string;

    @IsOptional()
    @IsString()
    @MaxLength(4)
    ccLastDigits: string;

    @IsOptional()
    @IsNumber()
    ccExpireMonth: number;

    @IsOptional()
    @IsNumber()
    ccExpireYear: number;
}
