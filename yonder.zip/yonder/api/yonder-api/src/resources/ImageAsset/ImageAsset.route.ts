import { ImageAsset as IImageAsset } from "@yonder/db";

import { expandRoutes, IRoute, ROUTE, GET, POST, DELETE, PATCH } from "../../utility/routes";
import { DAO, handleError } from "../../utility/db";
import { ImageAsset } from "./ImageAsset.model";
import { AssetHandler } from "./ImageAsset.handler";
import EndpointPermissions, { EndpointPermissionsFunc } from "../../utility/endpoint-permissions";

const routesImageAssetsPublic: IRoute[] = [
    // get assets for assetId
    // /api/assets/{assetId}
    //
    // !!! gets listing's cover photos for public users !!!
    // maybe rename endpoint url from ASSSETS to COVERPHOTOS
    {
        path: "/:assetId",
        type: GET,
        handler: async (req: any, res: any, next: any) => {
            // NOTE: User UID will be derived from firebase authentication middleware in the future
            try {
                const assetId: string = req.params.assetId;
                const results: ImageAsset = await DAO.findOneByID(ImageAsset.name, assetId);
                res.status(200).json(results);
            } catch (err) {
                next(handleError(err));
            }
        }
    }
    // Updates asset
    // /api/assets/{assetId}
    // {
    //     path: "/:assetId",
    //     type: PATCH,
    //     handler: async (req: any, res: any, next: any) => {
    //         try {
    //             let assetId = req.params.assetId;
    //             let response = await AssetHandler.updateAsset(req.body, assetId);
    //             if (response instanceof Error) {
    //                 res.status(422).json({ message: response.message });
    //                 return;
    //             }
    //             res.status(200).json(response);
    //         } catch (err) {
    //             next(handleError(err));
    //         }
    //     }
    // }
];

const routesImageAssetsPrivate: IRoute[] = [
    // get assets for userId
    // /api/assets
    // {
    //     path: "/",
    //     type: GET,
    //     handler: async (req: any, res: any, next: any) => {
    //         try {
    //             // NOTE: User UID will be derived from firebase authentication middleware in the future
    //             let uploadedBy = req.userDetails.id;
    //             let parentId: string = req.query.parentId;
    //             let results = parentId
    //                 ? await DAO.findManyByKeyValue(ImageAsset.name, ImageAsset, "parentId", parentId)
    //                 : await DAO.findManyByKeyValue(ImageAsset.name, ImageAsset, "uploadedBy", uploadedBy);
    //             res.status(200).json(results);
    //         } catch (err) {
    //             next(handleError(err));
    //         }
    //     }
    // },
    // Creates a new asset
    // /api/assets/
    // {
    //     path: "/",
    //     type: POST,
    //     handler: async (req: any, res: any, next: any) => {
    //         try {
    //             // NOTE: User UID will be derived from firebase authentication middleware in the future
    //             let uploadedBy: string = req.userDetails.id;
    //             let parentId: string = req.query.parentId || "1234";
    //             let response = await AssetHandler.createAsset(req.body, uploadedBy, parentId);
    //             if (response instanceof Error) {
    //                 res.status(422).json({ message: response.message });
    //                 return;
    //             } else res.status(200).json(response);
    //         } catch (err) {
    //             next(handleError(err));
    //         }
    //     }
    // },
    // Deletes asset with given assetId
    // /api/assets/{assetId}
    // {
    //     path: "/:assetId",
    //     type: DELETE,
    //     handler: async (req: any, res: any, next: any) => {
    //         try {
    //             // // NOTE: User UID will be derived from firebase authentication middleware in the future
    //             const { id: userId } = req.userDetails;
    //             const assetId = req.params.assetId;
    //             const response = await AssetHandler.removeAsset(assetId);
    //             if (response instanceof Error) {
    //                 res.status(404).json({ message: response.message });
    //                 return;
    //             }
    //             res.status(200).json(response);
    //         } catch (err) {
    //             next(handleError(err));
    //         }
    //     }
    // }
];

export const routesImageAssetsHelper = (
    permissions: EndpointPermissionsFunc[] = [EndpointPermissions.enableByPropertyActivityByOrgId]
): IRoute[] => {
    return [
        {
            path: `/:parentId/assets`,
            type: GET,
            permissions,
            handler: async (req: any, res: any, next: any) => {
                try {
                    const { parentId } = req.params;
                    const results = await AssetHandler.getAssets(parentId);
                    res.status(200).json(results);
                } catch (err) {
                    next(handleError(err));
                }
            }
        },
        {
            path: `/:parentId/assets`,
            type: POST,
            handler: async (req: any, res: any, next: any) => {
                try {
                    const { id: uploadedBy, organizationId } = req.userDetails;
                    const { parentId } = req.params;
                    const response = await AssetHandler.createAsset(req.body, uploadedBy, parentId, organizationId);

                    if (response instanceof Error) {
                        res.status(422).json({ message: response.message });
                        return;
                    } else res.status(200).json(response);
                } catch (err) {
                    next(handleError(err));
                }
            }
        },
        {
            path: `/:parentId/assets/:assetId`,
            type: PATCH,
            permissions,
            handler: async (req: any, res: any, next: any) => {
                try {
                    const { assetId } = req.params;
                    let updates: Partial<ImageAsset> = req.body;

                    await DAO.updateOneByID(ImageAsset.name, assetId, updates, ImageAsset);
                    res.status(207).json({
                        id: assetId,
                        ...updates
                    });
                } catch (err) {
                    next(handleError(err));
                }
            }
        },
        {
            path: `/:parentId/assets/:assetId`,
            type: DELETE,
            permissions,
            handler: async (req: any, res: any, next: any) => {
                try {
                    const { assetId } = req.params;
                    const asset: ImageAsset = await DAO.findOneByID(ImageAsset.name, assetId);
                    if (asset.renders) {
                        const values: IImageAsset[] = Object.values(asset.renders);
                        for (let render of values) {
                            await DAO.deleteFromStorage(render.file);
                        }
                    }
                    await DAO.deleteFromStorage(asset.file);

                    await DAO.deleteOneByID(ImageAsset.name, assetId);
                    res.status(204).json();
                } catch (err) {
                    next(handleError(err));
                }
            }
        }
    ];
};

export default {
    path: `/assets`,
    type: ROUTE,
    handler: expandRoutes(routesImageAssetsPublic)
} as IRoute;
