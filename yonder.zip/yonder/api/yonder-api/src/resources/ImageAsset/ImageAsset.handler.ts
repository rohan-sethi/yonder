import { DAO } from "../../utility/db";
import { BaseModel } from "../../utility/db";
import { ImageAsset } from "./ImageAsset.model";

export class AssetHandler extends BaseModel {
    static async getAssets(parentId: string) {
        // retreives all image assets associated with parentId
        try {
            const results = await DAO.findManyByKeyValue(ImageAsset.name, ImageAsset, "parentId", parentId);
            return results;
        } catch (Err) {
            return new Error(Err.message);
        }
    }

    static async removeAsset(assetId: string) {
        // deletes image asset if user and resource belongs to same org (by id)
        try {
            const response = await DAO.deleteOneByID(ImageAsset.name, assetId);
            return response;
        } catch (Err) {
            return new Error(Err.message);
        }
    }

    static async createAsset(details: any, uploadedBy: string, parentId?: string, organizationId?: string) {
        let result: ImageAsset;
        try {
            let newObj: ImageAsset = new ImageAsset();

            newObj.uploadedBy = uploadedBy;
            newObj.parentId = parentId;
            newObj.organizationId = organizationId;

            Object.assign(newObj, details);

            if (typeof newObj.renders !== "undefined") {
                throw new Error("renders field can only be updated");
            }
            result = await DAO.create(ImageAsset.name, newObj, ImageAsset);
        } catch (Err) {
            return new Error(Err.message);
        }
        return result;
    }

    static async updateAsset(details: Object, assetId: string) {
        let result: any;
        try {
            let newObj: ImageAsset = new ImageAsset();
            Object.assign(newObj, details);
            let err = await newObj.validate();
            if (err != undefined) {
                throw err;
            }
            result = await DAO.updateOneByID(ImageAsset.name, assetId, newObj, ImageAsset);
        } catch (Err) {
            return new Error(Err.message);
        }
        return result;
    }
}
