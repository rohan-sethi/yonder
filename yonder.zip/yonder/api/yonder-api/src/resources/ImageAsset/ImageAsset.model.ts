import { IsString, IsOptional, MaxLength, IsNumber } from "class-validator";
import { ImageAsset as IImageAsset, AssetRendersMap, ID } from "@yonder/db";

import { BaseModel } from "../../utility/db";

export class ImageAsset extends BaseModel implements IImageAsset {
    @IsString()
    uploadedBy: string;

    @IsString()
    name: string;

    @IsNumber()
    size: number;

    @IsString()
    @IsOptional()
    file: string;

    @IsNumber()
    @IsOptional()
    width?: number;

    @IsNumber()
    @IsOptional()
    height?: number;

    @IsString()
    @IsOptional()
    parentId?: ID;

    @IsString()
    @IsOptional()
    organizationId?: string;

    @IsString()
    @IsOptional()
    @MaxLength(36)
    uuid?: string;

    @IsOptional()
    @IsString()
    caption?: string;

    @IsOptional()
    renders?: AssetRendersMap;
}
