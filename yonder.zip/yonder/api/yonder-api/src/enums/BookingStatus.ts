export enum BookingStatus {
    Available = "available",
    Blocked = "blocked",
    BookedInternal = "bookedInternal",
    BookedExternal = "bookedExternal"
}

export class BookingCategory {
    constructor(public id: string, public label: string, public image: string) { }
}

export function getBookingCategoryLabel(bookingId: BookingStatus): string {
    switch (bookingId) {
        case BookingStatus.Available:
            return "Available";
        case BookingStatus.Blocked:
            return "Blocked";
        case BookingStatus.BookedInternal:
            return "BookedInternal";
        case BookingStatus.BookedExternal:
            return "BookedExternal";
    }
    return "undefined";
}

export function getBookingCategoryImageUrl(_bookingId: BookingStatus): string {
    // TODO
    return "";
}

export function getBookingCategory(bookingId: BookingStatus): BookingCategory {
    const label = getBookingCategoryLabel(bookingId);
    const url = getBookingCategoryImageUrl(bookingId);

    return new BookingCategory(bookingId, label, url);
}
