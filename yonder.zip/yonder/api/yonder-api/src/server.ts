// ============================================================================
// Local environment
// ============================================================================
require("dotenv").config();
import { Environment } from "./utility/system";

// tickle tickle
// ============================================================================
// Express Server
// ============================================================================
import Express from "express";
const app = Express();

// ============================================================================
// Favicon
// ============================================================================
import path from "path";
import favicon from "serve-favicon";
const root = path.join(__dirname, "../");
app.use(favicon(root + "public/favicon-32x32.png"));

// ============================================================================
// Body Parser
// ============================================================================
import bodyParser from "body-parser";
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// ============================================================================
// Morgan (Logging)
// ============================================================================
import morgan from "morgan";
app.use(morgan("dev"));

// ============================================================================
// CORS
// ============================================================================
import cors from "cors";
app.use(cors());

// ============================================================================
// Authorization
// ============================================================================
// TBD

// ============================================================================
// Router
// ===========================================================================
import createRoutes from "./routes";
createRoutes(app);

// ============================================================================
// Error Handlers
// ============================================================================
import { IError } from "./utility/db/ErrorHandlers";
app.use((error: IError, req: any, res: any, next: any) => {
    res.status(error.statusCode || 500).json({
        error: {
            status: error.statusCode,
            message: error.message,
            validationErrors: error.validationErrors || undefined
        }
    });
});

// ============================================================================
// Main
// ============================================================================
function main() {
    app.listen(Environment.port, () => {
        console.log(`Yonder api running on port ${Environment.port}`);
    });
}
main();
