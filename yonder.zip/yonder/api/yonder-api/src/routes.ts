import routeHostApprovalSubmission from "./resources/HostApprovalSubmission/HostApprovalSubmission.route";
import routeOrganization from "./resources/Organization/Organization.route";
import routeUser from "./resources/User/User.route";
import routeProperty from "./resources/Property/Property.route";
import routeAssets from "./resources/ImageAsset/ImageAsset.route";
import routeActivities from "./resources/Activity/Activity.route";
import routeAdmin from "./resources/Admin/Admin.route";
import routesHostOverview from "./resources/HostOverview/HostOverview.route";
import routesInviteRequest from "./resources/InviteRequest/InviteRequest.route";
import routeListings from "./resources/Listings/Listings.route";

import routeBooking from "./resources/Booking/Booking.route";
// import routeChatSession from "./resources/ChatSession/ChatSession.route";
// import routePaymentMethods from "./resources/Payment/PaymentMethod.route";
// import routeSettings from "./resources/Settings/Settings.route";
// import routeGuestbookEntry from "./resources/GuestBookEntry/GuestbookEntry.route";
// import routeFavorite from "./resources/Favorite/Favorite.route";
// import routeTransactions from "./resources/Transaction/Transaction.route";

import { handleError, DbError } from "./utility/db";

import { IRoute, GET, expandRoutes } from "./utility/routes";

const allRoutes: IRoute[] = [
    {
        path: "/greet",
        type: GET,
        handler: async (req: any, res: any, next: any) => {
            res.send("Hello there, friend!");
        }
    },
    routeAdmin, // private routes enabled && NO generic routeCRUDGenerator && has permissions midware
    routeOrganization, // private routes enabled && NO generic routeCRUDGenerator && has permissions midware
    routeHostApprovalSubmission, // private routes enabled && NO generic routeCRUDGenerator && has permissions midware
    routeUser, // private routes enabled && NO generic routeCRUDGenerator && has permissions midware
    routesInviteRequest,

    routeProperty, // private routes enabled && NO generic routeCRUDGenerator && has permissions midware
    routeAssets, // UNTESTED private
    routeListings, // private routes enabled
    routeActivities, // private routes enabled && NO generic routeCRUDGenerator has permissions midware

    routesHostOverview, // private routes enabled && NO generic routeCRUDGenerator
    routeBooking
    // routeChatSession,
    // routePaymentMethods,
    // routeGuestbookEntry,
    // routeSettings,
    // routeFavorite,
    // routeTransactions,
];

export default function(app: any) {
    app.use("/api", expandRoutes(allRoutes));

    // Swagger UI in the /docs route
    /*if (Environment.isDevelopment) {
        addSwagger(app, "/docs", "./");
    }*/

    // 404 route
    app.get("*", async (req: any, res: any, next: any) => {
        let err = new Error(DbError.GenericNotFound);
        next(handleError(err));
    });
}
