import axios from "axios";
import { POST, GET, PATCH, DELETE } from "./constants";

const REACT_APP_YONDER_API_URL = process.env.REACT_APP_YONDER_API_URL || process.env["REACT_APP_YONDER_API_URL"];
const YONDER_API_URL = process.env.YONDER_API_URL || process.env["YONDER_API_URL"];

class YonderApi {
    _headers: object = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
    };
    headers: object = this._headers;
    BASEURL = REACT_APP_YONDER_API_URL ? REACT_APP_YONDER_API_URL : YONDER_API_URL;
    baseUrlSet: boolean = false;

    interpolateLocalhost = (outString: string) => {
        if (!this.baseUrlSet && this.BASEURL !== undefined) {
            this.BASEURL = this.BASEURL.replace("localhost", outString);
            this.baseUrlSet = true;
        }
    };

    setAuthBearer = (token?: string) => {
        if (token) {
            this.headers = {
                ...this._headers,
                Authorization: `Bearer ${token}`
            };
        } else {
            this.headers = this._headers;
        }
    };

    validateBaseURL = () => {
        if (this.BASEURL === undefined) {
            throw new Error(
                "@yonder/db: YONDER_API_URL must be defined. (Set environment variable: YONDER_API_URL or REACT_APP_YONDER_API_URL)"
            );
        }
        if (!this.BASEURL.endsWith("/api")) {
            throw new Error(
                "@yonder/db: YONDER_API_URL must end with '/api' defined. (Set environment variable: YONDER_API_URL or REACT_APP_YONDER_API_URL)"
            );
        }
    };

    validateResourcePath = (resourcePath: string): void => {
        this.validateBaseURL();
        if (resourcePath === "") {
            throw new Error("@yonder/db: resourcePath must not be blank");
        }
        if (!resourcePath.startsWith("/")) {
            throw new Error("@yonder/db: resourcePath must start with '/'");
        }
    };

    // Any POST call
    post = async (resourcePath: string, data: object) => {
        try {
            await this.validateResourcePath(resourcePath);

            const url = this.BASEURL + resourcePath;
            const response = await axios({
                url,
                headers: this.headers,
                method: POST,
                data
            });

            return response.data;
        } catch (err) {
            const errorData = err.response.data;
            if (errorData.err) {
                if (errorData.error.validationErrors) {
                    console.log(errorData.error.validationErrors);
                }
            }
            throw err;
        }
    };

    // Any GET call
    get = async (resourcePath: string, params?: object) => {
        try {
            await this.validateResourcePath(resourcePath);

            const url = this.BASEURL + resourcePath;
            const response = await axios({
                url,
                headers: this.headers,
                method: GET,
                params
            });

            if (response.data === false) {
                throw new Error("Requested data was not found on the server");
            }

            return response.data;
        } catch (err) {
            throw err;
        }
    };

    // Any PATCH call
    patch = async (resourcePath: string, updatedData: object) => {
        try {
            await this.validateResourcePath(resourcePath);

            const url = this.BASEURL + resourcePath;
            const response = await axios({
                url,
                headers: this.headers,
                method: PATCH,
                data: updatedData
            });

            return response.data;
        } catch (err) {
            const errorData = err.response.data;
            if (errorData.error) {
                if (errorData.error.validationErrors) {
                    console.log(errorData.error.validationErrors);
                }
            }
            throw err;
        }
    };

    // Fake PUT call
    put = async (resourcePath: string, data: any) => {
        if (data.id !== undefined) {
            return await this.patch(`${resourcePath}/${data.id}`, data);
        } else {
            return await this.post(resourcePath, data);
        }
    };

    // Any DELETE call
    delete = async (resourcePath: string) => {
        try {
            await this.validateResourcePath(resourcePath);

            const url = this.BASEURL + resourcePath;
            const response = await axios({
                url,
                headers: this.headers,
                method: DELETE
            });

            return response.data;
        } catch (err) {
            throw err;
        }
    };
}

const yonderApi = new YonderApi();

export const interpolateLocalhost = yonderApi.interpolateLocalhost;

export const yonderAuthenticate = yonderApi.setAuthBearer;
export const yonderPost = yonderApi.post;
export const yonderGet = yonderApi.get;
export const yonderPatch = yonderApi.patch;
export const yonderPut = yonderApi.put;
export const yonderDelete = yonderApi.delete;
