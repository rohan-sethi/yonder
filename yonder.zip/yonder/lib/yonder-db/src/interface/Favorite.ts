import { BaseModel } from "./BaseModel";

export class Favorite extends BaseModel {
    userId: string;
    listingId: string;
}
