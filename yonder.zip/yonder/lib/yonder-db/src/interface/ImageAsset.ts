import { BaseModel } from "./BaseModel";
import { ID } from "..";

export type AssetRendersMap = {
    [key: string]: ImageAsset;
};

export class ImageAsset extends BaseModel {
    name: string;
    size: number;
    file: string;
    width?: number;
    height?: number;
    parentId?: ID;
    uuid?: string;
    caption?: string;
    renders?: AssetRendersMap;
}
