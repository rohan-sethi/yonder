import { BaseModel } from "./BaseModel";
import { ID } from "..";

export class InviteRequest extends BaseModel {
    email?: string;
    expires?: Date;
    organizationId?: ID;
}
