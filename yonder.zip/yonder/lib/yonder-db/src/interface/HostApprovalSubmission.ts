import { BaseModel } from "./BaseModel";
import {
    ExperienceCategories,
    ActivityTypes,
    ActivityCountRanges,
    OrganizationCertificates,
    SustainabilityEfforts,
    Countries
} from "../enums";
import { LocationAddress } from ".";
import { ID } from "..";

export class PropertyManagementHost {
    overnightStayPropertiesCount: number = 0;
    managementCompanyDescription?: string;
    scoutImportPermission: boolean = false;
    useChannelManagerSoftware: boolean = false;
    channelManagerSoftware?: string;
}

export class HostApprovalSubmission extends BaseModel {
    experienceCategory?: ExperienceCategories;
    overnightStaysCount: number = 0;
    activityCountRange?: ActivityCountRanges;
    activities: ActivityTypes[] = [];
    samplePhotos: ID[] = [];
    location: LocationAddress = {
        country: Countries.USA
    };
    description?: string;
    certificates: OrganizationCertificates[] = [];
    otherCertificates: string[] = [];
    sustainabilityEfforts: SustainabilityEfforts[] = [];
    otherSustainabilityEfforts: string[] = [];
    scoutSetupPermission: boolean = false;
    socialLinks?: string;

    propertyManagementHost?: PropertyManagementHost;
}
