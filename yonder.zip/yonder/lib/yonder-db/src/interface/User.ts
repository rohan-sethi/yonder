import { BaseModel } from "./BaseModel";
import { Genders, LanguageCodes, ID } from "..";
import { UserPermissions } from "../enums/UserPermissions";
import { HostTypes } from "../enums/HostTypes";

export class User extends BaseModel {
    firstName?: string;
    lastName?: string;
    gender?: Genders;
    phoneNumber?: string;
    userLocation?: string;
    organizationId?: ID;
    permissions: UserPermissions;
    hostType?: HostTypes;
    email: string;
    dateOfBirth?: string;
    preferredLanguage?: LanguageCodes;
    about?: string;
    receiveCoupon?: string;
    photoURL?: string;
}
