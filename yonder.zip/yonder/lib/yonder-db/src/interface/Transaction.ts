import { BaseModel } from "./BaseModel";
import { CurrencyCodes, PromoCode, TransactionType } from "..";

export class Transaction extends BaseModel {
    transactionId: string;
    transactionType: TransactionType = TransactionType.Booking;
    isYonderWalletTransaction?: boolean = false;
    parentTransactionId?: string | null = null;
    propertyId?: string;
    bookingId?: string; // optional due to generic nature of a transaction
    payerId: string;
    payeeId: string;
    fees?: number;
    feesSumamary?: string;
    amount: number;
    description?: string;
    transferOn: string; // iso javascript date string
    currency?: CurrencyCodes;
    promoCode?: PromoCode;
    discountAmount?: number;
}