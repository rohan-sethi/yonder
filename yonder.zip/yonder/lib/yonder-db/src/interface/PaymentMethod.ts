import { BaseModel } from "./BaseModel";
import { PaymentMethods, PaymentMethodCreditCardTypes } from "../enums";
import { ID } from "..";

export class PaymentMethod extends BaseModel {
    method: PaymentMethods;
    fingerprint: string;
    isPrimary: boolean;
    userId: ID;
    stripeToken: string;
    ccType: PaymentMethodCreditCardTypes;
    ccName: string;
    ccLastDigits: string;
    ccExpireMonth: number;
    ccExpireYear: number;
}
