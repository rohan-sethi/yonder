import { StatesUS, Countries, ProvincesCanada } from "..";

export interface LocationAddress {
    address1?: string;
    address2?: string;
    city?: string;
    state?: StatesUS | ProvincesCanada | string | null;
    zipCode?: string;
    isProvince?: boolean;
    country?: Countries;
    countryName?: string;
}
