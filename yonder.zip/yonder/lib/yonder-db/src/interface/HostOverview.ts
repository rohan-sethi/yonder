import { BaseModel } from "./BaseModel";

export class HostOverview extends BaseModel {
    overallRating: number;
    organizationId: string;
}
