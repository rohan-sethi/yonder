import { PropertyContent, PropertyLocation, ListingSectionProgresses } from "./";
import { BaseModel } from "./BaseModel";
import {
    ID,
    Medals,
    Amenities,
    Keywords,
    CurrencyCodes,
    LanguageCodes,
    TransportationOptions,
    PropertyTypes,
    OfferingCategories,
    PhysicalActivityLevels,
    AvailabilityTimesByHour,
    ExperienceCategories,
    ActivityTypes,
    CancellationPolicies,
    ListingProgress,
    Countries,
    PricingUnits
} from "..";
import { Price } from "../constants";

export class ActivityItinerary {
    time?: AvailabilityTimesByHour;
    title?: string;
    description?: string;
}

/**
 * Only initialize:
 *   arrays
 *   objects (interfaces, etc)
 *   booleans
 *   numbers if they're used with InputCounter components
 *   enums that require a default value or don't use a "--" option in a SelectInput
 *
 * Initialized values should reflect their default
 */

export class Activity extends BaseModel {
    name: string;
    location: PropertyLocation = {
        country: Countries.USA
    };
    summary?: string;
    whatWeLove?: string;
    keyThingsToKnow: string[] = [];
    content: PropertyContent[] = [];
    coverPhoto?: ID;
    galleryPhotos: ID[] = [];
    hostId?: ID;
    medals: Medals[] = [];
    experienceCategories: ExperienceCategories[] = [];
    activityTypes: ActivityTypes[] = [];
    propertyType?: PropertyTypes;
    category?: OfferingCategories;
    amenities: Amenities[] = [];
    keywords: Keywords[] = [];
    currency?: CurrencyCodes;
    pricing?: Price;
    pricingUnits?: PricingUnits = PricingUnits.perPerson;
    pricingDescription?: string;
    language?: LanguageCodes;
    overallRating?: number | null;

    // specific to activities
    durationCountByHour: number = 1;
    itinerary: ActivityItinerary[] = [];
    physicalActivityLevel?: PhysicalActivityLevels | null;
    guestRequirements: string[] = [];

    // activity rules
    activityRules: string[] = [];
    checkInTime?: AvailabilityTimesByHour;
    checkOutTime?: AvailabilityTimesByHour;
    suitableForChildren: boolean = false;
    suitableForChildrenDescription?: string;
    suitableForInfants: boolean = false;
    suitableForInfantsDescription?: string;
    petsAllowed: boolean = false;
    petsAndAnimalsPolicyDescription?: string;
    handicapAccessible: boolean = false;
    handicapAccessibleDescription?: string;
    smokingAllowed: boolean = false;
    smokingPolicyDescription?: string;
    potentialForNoise: boolean = false;
    potentialNoiseDescription?: string;

    // additional
    transportationOptions: TransportationOptions[] = [];
    milesToNearestAirport?: number | null;
    milesToNearestGroceryStore?: number | null;
    milesToNearestGasStation?: number | null;
    restaurantOnSite: boolean = false;
    suggestedRestaurantsNearby: string[] = [];
    gateEntry: boolean = false;
    keySightseeingPoints: string[] = [];
    walkingHikingTrailsAdjacentToProperty: boolean = false;
    recommendedThingsToDoOnProperty: string[] = [];
    winterAverageTemperatorFahrenheit?: number | null;
    summerAverageTemperatorFahrenheit?: number | null;
    fourWheelDriveSuggestedToGetToProperty: boolean = false;

    cancellationPolicy?: CancellationPolicies;

    listingProgress?: ListingProgress;
    sectionProgress: ListingSectionProgresses = {};
}
