export class OfferingDisplay {
    _id: string;

    name: string;

    content: {
        whatWeLove: string;
        thingsToKnow: string[];
        more: [{ title: string; body: string }];
    };

    featuredImages: {
        desktop: { url: string }[];
        mobile: { url: string }[];
    };

    images: any[];
    location: string;
    locationSummary: string;

    gps: {
        long: string;
        lat: string;
    };

    rating: string;
    summary: { prefix: string; body: string };

    medals: {
        label: string;
        imageUrl: string;
        id: string;
    }[];

    bedArrangements: string[];
    bedCount: number;
    bathroomCount: number;
    amenities: { label: string }[];

    guestbookEntries: {
        rating: number;
        date: string;
        message: string;
        name: string;
    }[];

    price: number;
    baseCurrency: string;
    host: { id: string; name: string; prefix: string; summary: string; imageUrl: "" };

    propertyType: string;
    minimumStay?: number;

    // activities
    thingsToDo: any[];
    nearby: any[];
}
