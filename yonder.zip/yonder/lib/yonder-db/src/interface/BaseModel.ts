export abstract class BaseModel {
    id?: string;
    created?: string;
    modified?: string;
}
