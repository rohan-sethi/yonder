import {
    Medals,
    PropertyTypes,
    OfferingCategories,
    Amenities,
    CurrencyCodes,
    LanguageCodes,
    Keywords,
    PricingRates,
    CancellationPolicies,
    ExperienceCategories,
    AvailabilityTimesByHour,
    BedTypes,
    ListingProgress,
    SectionProgress,
    RoadTypes,
    TemperatureRanges,
    SustainabilityEfforts,
    OrganizationCertificates,
    Countries
} from "../enums";
import { BaseModel } from "./BaseModel";
import { LocationAddress } from "./LocationAddress";
import { ID } from "..";
import { Price } from "../constants";

export interface PropertyContent {
    title: string;
    content: string;
}

export interface PropertyLocation extends LocationAddress {
    long?: string;
    lat?: string;
    description?: string;
}

export interface PropertyPricing {
    defaultWeekday?: Price;
    defaultWeekend?: Price;
    cleaningFee?: Price;
    rate?: PricingRates;
}

export class PropertyBedroom {
    bedTypes: BedTypes[] = [];
    name?: string;
    description?: string;
}
export type ListingSectionProgresses = {
    [key: string]: SectionProgress;
};

/**
 * Only initialize:
 *   arrays
 *   objects (interfaces, etc)
 *   booleans
 *   numbers if they're used with InputCounter components
 *   enums that require a default value or don't use a "--" option in a SelectInput
 *
 * Initialized values should reflect their default
 */

export class Property extends BaseModel {
    name: string;
    location: PropertyLocation = {
        country: Countries.USA
    };
    summary?: string;
    whatWeLove?: string;
    keyThingsToKnow: string[] = [];
    content: PropertyContent[] = [];
    coverPhoto?: ID;
    galleryPhotos: ID[] = [];
    hostId?: ID;
    medals: Medals[] = [];
    experienceCategories: ExperienceCategories[] = [];
    propertyType?: PropertyTypes | null;
    category?: OfferingCategories;
    bedrooms: PropertyBedroom[] = [];
    commonSpaceRooms: PropertyBedroom[] = [];
    guestCapacity: number = 2;
    bedroomCount: number = 1;
    fullBathroomCount: number = 0;
    halfBathroomCount: number = 0;
    amenities: Amenities[] = [];
    keywords: Keywords[] = [];
    currency?: CurrencyCodes | null;
    pricing: PropertyPricing = {};
    language?: LanguageCodes;
    minimumStay: number = 1; //weekday minimum stay
    weekendMinimumStay: number = 1;
    overallRating?: number | null;
    squareFootage?: number | null;

    // property rules
    propertyRules: string[] = [];
    hasRequiredSafetyFeatures: boolean = false;
    checkInTime: AvailabilityTimesByHour = AvailabilityTimesByHour.Slot1500;
    checkOutTime: AvailabilityTimesByHour = AvailabilityTimesByHour.Slot1100;
    suitableForChildren: boolean = false;
    suitableForChildrenDescription?: string;
    suitableForInfants: boolean = false;
    suitableForInfantsDescription?: string;
    petsAllowed: boolean = false;
    petsAndAnimalsPolicyDescription?: string;
    animalsOnPropertyPolicy?: string;
    handicapAccessible: boolean = false;
    handicapAccessibleDescription?: string;
    smokingAllowed: boolean = false;
    smokingPolicyDescription?: string;
    potentialForNoise: boolean = false;
    potentialNoiseDescription?: string;
    surveillanceOrRecordingDeviceOnProperty: boolean = false;
    surveillanceOrRecordingDeviceDescription?: string;
    // additional
    ridesharingApps: boolean = false;
    transportationOptions: string[] = []; //changed
    nearestAirport?: string;
    milesToNearestAirport?: number | null;
    groceryStoreRecommendation?: string;
    milesToNearestGroceryStore?: number | null;
    lessThanMileToNearestGroceryStore: boolean = false;
    milesToNearestGasStation?: number | null;
    lessThanMileToNearestGasStation: boolean = false;
    restaurantOnSite: boolean = false;
    suggestedRestaurantsNearby: string[] = [];
    milesToNearestOffSiteRestaurant?: number | null;
    lessThanMileToNearestOffSiteRestaurant: boolean = false;
    gateEntry: boolean = false;
    walkingHikingTrailsAdjacentToProperty: boolean = false;
    recommendedThingsToDoOnProperty: string[] = [];
    recommendedThingsToDoOffProperty: string[] = [];
    footwearRecommendations: string[] = [];
    privateRoadType: RoadTypes = RoadTypes.Paved;
    winterAverageTemperatureFahrenheit: TemperatureRanges = TemperatureRanges.Slot0To10F;
    summerAverageTemperatureFahrenheit: TemperatureRanges = TemperatureRanges.Slot60To70F;
    fourWheelDriveSuggestedToGetToProperty: boolean = false;
    certificates: OrganizationCertificates[] = [];
    otherCertificates: string[] = [];
    sustainabilityEfforts: SustainabilityEfforts[] = [];
    otherSustainabilityEfforts: string[] = [];
    accessibilityDescription?: string;

    hostOnProperty: boolean = false;
    maximumStay: number = 14;
    preparationDays: number = 1;
    cancellationPolicy?: CancellationPolicies;
    activitiesAvailable: ID[] = [];

    listingProgress?: ListingProgress;
    sectionProgress: ListingSectionProgresses = {};
}
