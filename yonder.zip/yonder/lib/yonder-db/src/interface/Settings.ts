import { BaseModel } from "./BaseModel";
import { CurrencyCodes } from "../enums";

export class Settings extends BaseModel {
    userId: string;
    fcmToken?: string;
    allowPush: boolean;
    defaultCurrency?: CurrencyCodes;
}
