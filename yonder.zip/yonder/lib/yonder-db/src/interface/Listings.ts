import { BaseModel } from "./BaseModel";
import { ImageAsset } from "./ImageAsset";

export interface SavedSearches {
    name: string;

    searchQuery: string;

    imagePreview: {
        landscape: ImageAsset[];
        portrait: ImageAsset[];
    };
}

export interface MoreButton {
    label: string;

    searchQuery: string;
}

export interface ListingContent {
    listingId: string;

    name: string;

    location: string;

    rating: number;

    pricePerNight: number;

    imagePreview: {
        landscape: ImageAsset[];
        portrait: ImageAsset[];
    };
}

export class Listings extends BaseModel {
    title: string;

    moreButton?: MoreButton | null;

    savedSearches?: SavedSearches[];

    listings?: ListingContent[];
}
