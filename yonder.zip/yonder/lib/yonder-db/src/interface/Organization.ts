import { BaseModel } from "./BaseModel";
import { ID } from "..";
import { HostApprovalSubmissionProgress } from "../enums";

export class Organization extends BaseModel {
    name: string;
    businessPhone?: string;
    approvalSubmissionId?: ID;
    approvalSubmissionProgress?: HostApprovalSubmissionProgress;
    website?: string;
    referralWriteIn?: string;
    propertyIds: ID[] = [];
    activityIds: ID[] = [];
}
