import { BaseModel } from "./BaseModel";
import { Property } from "./Property";
import { User } from "./index";
import { CurrencyCodes } from "../enums";

// ============================================================================
// Classes
// ============================================================================

export class Accommodation extends BaseModel {
    name: string;
    roomType: RoomType;
}

export class Booking extends BaseModel {
    property: Property;
    user: User;
    checkInDate: Date;
    checkOutDate: Date;
    pricePerDay: number;
    priceForStay: number;
    taxPaid: number;
    siteFees: number;
    isRefund?: boolean;
    refundPaid?: number;
    transaction?: BookingTransaction;
    effectiveAmount?: number;
    bookingDate?: Date;
}

export class BookingTransaction extends BaseModel {
    property: Property;
    payer: User;
    payee: User;
    guestCount: number;
    siteFees: number;
    amount: number;
    transferOn: Date;
    currency?: CurrencyCodes;
    promoCode?: PromoCode;
    discountAmount?: number;
}

export class GuestbookEntry extends BaseModel {
    property: Property;
    reviewedByUser: User;
    booking: Booking;
    title: string;
    comment?: string;
    rating: number;
}

export class PhotoCategory extends BaseModel {
    name: string;
}

export class PromoCode extends BaseModel {
    name: string;
    description?: string;
    code: string;
    discount: number;
}

export class PropertyCategory extends BaseModel {
    name: string;
    description?: string;
}

export class PropertyPhoto extends BaseModel {
    property: Property;
    category: PropertyCategory;
    addedByUser: User;
    image: string;
}

export class RoomType extends BaseModel {
    name: string;
    image?: string;
}
