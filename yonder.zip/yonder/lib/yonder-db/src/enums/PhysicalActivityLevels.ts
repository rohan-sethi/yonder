export enum PhysicalActivityLevels {
    Slot1 = "01",
    Slot2 = "02",
    Slot3 = "03",
    Slot4 = "04",
    Slot5 = "05",
    Slot6 = "06",
    Slot7 = "07",
    Slot8 = "08",
    Slot9 = "09",
    Slot10 = "10"

    // Low = "low",
    // Moderate = "moderate",
    // High = "high"
}

export function getPhysicalActivityLevel(id: PhysicalActivityLevels): string {
    switch (id) {
        case PhysicalActivityLevels.Slot1:
            return "1";
        case PhysicalActivityLevels.Slot2:
            return "2";
        case PhysicalActivityLevels.Slot3:
            return "3";
        case PhysicalActivityLevels.Slot4:
            return "4";
        case PhysicalActivityLevels.Slot5:
            return "5";
        case PhysicalActivityLevels.Slot6:
            return "6";
        case PhysicalActivityLevels.Slot7:
            return "7";
        case PhysicalActivityLevels.Slot8:
            return "8";
        case PhysicalActivityLevels.Slot9:
            return "9";
        case PhysicalActivityLevels.Slot10:
            return "10";

        // case PhysicalActivityLevels.Low:
        //     return "Low";
        // case PhysicalActivityLevels.Moderate:
        //     return "Moderate";
        // case PhysicalActivityLevels.High:
        //     return "High";
    }
    return "undefined";
}
