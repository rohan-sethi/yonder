export enum PricingRates {
    Night = "night",
    Week = "week"
}
