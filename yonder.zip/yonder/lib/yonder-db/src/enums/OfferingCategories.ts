export enum OfferingCategories {
    Farm = "farm",
    Ranch = "ranch",
    Vineyard = "vineyard",
    Nature = "nature",
    Adventure = "adventure",
    Ecocity = "ecocity"
}

export class OfferingCategory {
    constructor(public id: string, public label: string, public image: string) {}
}

export function getOfferingLabel(id: OfferingCategories): string {
    switch (id) {
        case OfferingCategories.Farm:
            return "Farm";
        case OfferingCategories.Ranch:
            return "Ranch";
        case OfferingCategories.Vineyard:
            return "Vineyard";
        case OfferingCategories.Nature:
            return "Nature";
        case OfferingCategories.Adventure:
            return "Adventure";
        case OfferingCategories.Ecocity:
            return "Ecocity";
    }
    return "undefined";
}

export function getOfferingCategoryImageUrl(_id: OfferingCategories): string {
    // TODO
    return "";
}

export function getOfferingCategory(id: OfferingCategories): OfferingCategory {
    const label = getOfferingLabel(id);
    const url = getOfferingCategoryImageUrl(id);

    return new OfferingCategory(id, label, url);
}
