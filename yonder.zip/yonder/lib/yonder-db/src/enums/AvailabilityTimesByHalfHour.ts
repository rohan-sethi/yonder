export enum AvailabiltyTimesByHalfHour {
    Slot0000 = "00_00",
    Slot0030 = "00_30",
    Slot0100 = "01_00",
    Slot0130 = "01_30",
    Slot0200 = "02_00",
    Slot0230 = "02_30",
    Slot0300 = "03_00",
    Slot0330 = "03_30",
    Slot0400 = "04_00",
    Slot0430 = "04_30",
    Slot0500 = "05_00",
    Slot0530 = "05_30",
    Slot0600 = "06_00",
    Slot0630 = "06_30",
    Slot0700 = "07_00",
    Slot0730 = "07_30",
    Slot0800 = "08_00",
    Slot0830 = "08_30",
    Slot0900 = "09_00",
    Slot0930 = "09_30",
    Slot1000 = "10_00",
    Slot1030 = "10_30",
    Slot1100 = "11_00",
    Slot1130 = "11_30",
    Slot1200 = "12_00",
    Slot1230 = "12_30",
    Slot1300 = "13_00",
    Slot1330 = "13_30",
    Slot1400 = "14_00",
    Slot1430 = "14_30",
    Slot1500 = "15_00",
    Slot1530 = "15_30",
    Slot1600 = "16_00",
    Slot1630 = "16_30",
    Slot1700 = "17_00",
    Slot1730 = "17_30",
    Slot1800 = "18_00",
    Slot1830 = "18_30",
    Slot1900 = "19_00",
    Slot1930 = "19_30",
    Slot2000 = "20_00",
    Slot2030 = "20_30",
    Slot2100 = "21_00",
    Slot2130 = "21_30",
    Slot2200 = "22_00",
    Slot2230 = "22_30",
    Slot2300 = "23_00",
    Slot2330 = "23_30"
}

export class AvailabiltyTimeByHalfHour {
    constructor(public id: string, public label: string) {}
}

export function getAvailabiltyTimeByHalfHourLabel(id: AvailabiltyTimesByHalfHour): string {
    switch (id) {
        case AvailabiltyTimesByHalfHour.Slot0000:
            return "12:00 am";
        case AvailabiltyTimesByHalfHour.Slot0030:
            return "12:30 am";
        case AvailabiltyTimesByHalfHour.Slot0100:
            return "01:00 am";
        case AvailabiltyTimesByHalfHour.Slot0130:
            return "01:30 am";
        case AvailabiltyTimesByHalfHour.Slot0200:
            return "02:00 am";
        case AvailabiltyTimesByHalfHour.Slot0230:
            return "02:30 am";
        case AvailabiltyTimesByHalfHour.Slot0300:
            return "03:00 am";
        case AvailabiltyTimesByHalfHour.Slot0330:
            return "03:30 am";
        case AvailabiltyTimesByHalfHour.Slot0400:
            return "04:00 am";
        case AvailabiltyTimesByHalfHour.Slot0430:
            return "04:30 am";
        case AvailabiltyTimesByHalfHour.Slot0500:
            return "05:00 am";
        case AvailabiltyTimesByHalfHour.Slot0530:
            return "05:30 am";
        case AvailabiltyTimesByHalfHour.Slot0600:
            return "06:00 am";
        case AvailabiltyTimesByHalfHour.Slot0630:
            return "06:30 am";
        case AvailabiltyTimesByHalfHour.Slot0700:
            return "07:00 am";
        case AvailabiltyTimesByHalfHour.Slot0730:
            return "07:30 am";
        case AvailabiltyTimesByHalfHour.Slot0800:
            return "08:00 am";
        case AvailabiltyTimesByHalfHour.Slot0830:
            return "08:30 am";
        case AvailabiltyTimesByHalfHour.Slot0900:
            return "09:00 am";
        case AvailabiltyTimesByHalfHour.Slot0930:
            return "09:30 am";
        case AvailabiltyTimesByHalfHour.Slot1000:
            return "10:00 am";
        case AvailabiltyTimesByHalfHour.Slot1030:
            return "10:30 am";
        case AvailabiltyTimesByHalfHour.Slot1100:
            return "11:00 am";
        case AvailabiltyTimesByHalfHour.Slot1130:
            return "11:30 am";
        case AvailabiltyTimesByHalfHour.Slot1200:
            return "12:00 pm";
        case AvailabiltyTimesByHalfHour.Slot1230:
            return "12:30 pm";
        case AvailabiltyTimesByHalfHour.Slot1300:
            return "01:00 pm";
        case AvailabiltyTimesByHalfHour.Slot1330:
            return "01:30 pm";
        case AvailabiltyTimesByHalfHour.Slot1400:
            return "02:00 pm";
        case AvailabiltyTimesByHalfHour.Slot1430:
            return "02:30 pm";
        case AvailabiltyTimesByHalfHour.Slot1500:
            return "03:00 pm";
        case AvailabiltyTimesByHalfHour.Slot1530:
            return "03:30 pm";
        case AvailabiltyTimesByHalfHour.Slot1600:
            return "04:00 pm";
        case AvailabiltyTimesByHalfHour.Slot1630:
            return "04:30 pm";
        case AvailabiltyTimesByHalfHour.Slot1700:
            return "05:00 pm";
        case AvailabiltyTimesByHalfHour.Slot1730:
            return "05:30 pm";
        case AvailabiltyTimesByHalfHour.Slot1800:
            return "06:00 pm";
        case AvailabiltyTimesByHalfHour.Slot1830:
            return "06:30 pm";
        case AvailabiltyTimesByHalfHour.Slot1900:
            return "07:00 pm";
        case AvailabiltyTimesByHalfHour.Slot1930:
            return "07:30 pm";
        case AvailabiltyTimesByHalfHour.Slot2000:
            return "08:00 pm";
        case AvailabiltyTimesByHalfHour.Slot2030:
            return "08:30 pm";
        case AvailabiltyTimesByHalfHour.Slot2100:
            return "09:00 pm";
        case AvailabiltyTimesByHalfHour.Slot2130:
            return "09:30 pm";
        case AvailabiltyTimesByHalfHour.Slot2200:
            return "10:00 pm";
        case AvailabiltyTimesByHalfHour.Slot2230:
            return "10:30 pm";
        case AvailabiltyTimesByHalfHour.Slot2300:
            return "11:00 pm";
        case AvailabiltyTimesByHalfHour.Slot2330:
            return "11:30 pm";
    }
    return "undefined";
}

export function getAvailabiltyTimeByHalfHour(id: AvailabiltyTimesByHalfHour): AvailabiltyTimeByHalfHour {
    let label = getAvailabiltyTimeByHalfHourLabel(id);

    return new AvailabiltyTimeByHalfHour(id, label);
}

export function getAvailabiltyTimesByHalfHour(ids: AvailabiltyTimesByHalfHour[]): AvailabiltyTimeByHalfHour[] {
    return ids.map(getAvailabiltyTimeByHalfHour);
}
