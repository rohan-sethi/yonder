export enum RoadTypes {
    Dirt = "dirt",
    Gravel = "gravel",
    Paved = "paved"
}

export function getRoadTypeLabel(id: RoadTypes): string {
    switch (id) {
        case RoadTypes.Dirt:
            return "Dirt";
        case RoadTypes.Gravel:
            return "Gravel";
        case RoadTypes.Paved:
            return "Paved";
    }
    return "undefined";
}
