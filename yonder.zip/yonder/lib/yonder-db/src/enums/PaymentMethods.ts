export enum PaymentMethods {
    CC = "cc"
}
