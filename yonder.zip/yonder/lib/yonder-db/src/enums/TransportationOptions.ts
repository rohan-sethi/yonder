export enum TransportationOptions {
    Uber = "uber",
    Lyft = "lyft",
    Taxi = "taxi",
    PrivateCarService = "private_car_service",
    CarRental = "car_rental"
}

export class TransportationOption {
    constructor(public id: string, public label: string, public image: string) {}
}

export function getTransportationOptionLabel(id: TransportationOptions): string {
    switch (id) {
        case TransportationOptions.Uber:
            return "Uber";
        case TransportationOptions.Lyft:
            return "Lyft";
        case TransportationOptions.Taxi:
            return "Taxi";
        case TransportationOptions.PrivateCarService:
            return "Private Car Service";
        case TransportationOptions.CarRental:
            return "Car Rental";
    }
    return "undefined";
}

export function getTransportationOptionImageUrl(_id: TransportationOptions): string {
    // TODO?
    return "";
}

export function getTransportationOption(id: TransportationOptions): TransportationOption {
    let label = getTransportationOptionLabel(id);
    let url = getTransportationOptionImageUrl(id);

    return new TransportationOption(id, label, url);
}

export function getTransportationOptions(ids: TransportationOptions[]): TransportationOption[] {
    return ids.map(getTransportationOption);
}
