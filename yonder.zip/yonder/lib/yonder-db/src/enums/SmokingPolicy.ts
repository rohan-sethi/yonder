export enum SmokingPolicies {
    Yes = "yes",
    No = "no",
    OutsideOnly = "outside_only"
}

export class SmokingPolicy {
    constructor(public id: string, public label: string) {}
}

export function getSmokingPolicyLabel(id: SmokingPolicies): string {
    switch (id) {
        case SmokingPolicies.Yes:
            return "Yes";
        case SmokingPolicies.No:
            return "No";
        case SmokingPolicies.OutsideOnly:
            return "Outside Only";
    }
}
