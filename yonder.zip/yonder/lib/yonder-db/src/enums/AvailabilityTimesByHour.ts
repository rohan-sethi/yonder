export enum AvailabilityTimesByHour {
    Slot0000 = "00_00",
    Slot0100 = "01_00",
    Slot0200 = "02_00",
    Slot0300 = "03_00",
    Slot0400 = "04_00",
    Slot0500 = "05_00",
    Slot0600 = "06_00",
    Slot0700 = "07_00",
    Slot0800 = "08_00",
    Slot0900 = "09_00",
    Slot1000 = "10_00",
    Slot1100 = "11_00",
    Slot1200 = "12_00",
    Slot1300 = "13_00",
    Slot1400 = "14_00",
    Slot1500 = "15_00",
    Slot1600 = "16_00",
    Slot1700 = "17_00",
    Slot1800 = "18_00",
    Slot1900 = "19_00",
    Slot2000 = "20_00",
    Slot2100 = "21_00",
    Slot2200 = "22_00",
    Slot2300 = "23_00"
}

export class AvailabilityTimeByHour {
    constructor(public id: string, public label: string) {}
}

export function getAvailabilityTimeByHourLabel(id: AvailabilityTimesByHour): string {
    switch (id) {
        case AvailabilityTimesByHour.Slot0000:
            return "12:00 am";
        case AvailabilityTimesByHour.Slot0100:
            return "01:00 am";
        case AvailabilityTimesByHour.Slot0200:
            return "02:00 am";
        case AvailabilityTimesByHour.Slot0300:
            return "03:00 am";
        case AvailabilityTimesByHour.Slot0400:
            return "04:00 am";
        case AvailabilityTimesByHour.Slot0500:
            return "05:00 am";
        case AvailabilityTimesByHour.Slot0600:
            return "06:00 am";
        case AvailabilityTimesByHour.Slot0700:
            return "07:00 am";
        case AvailabilityTimesByHour.Slot0800:
            return "08:00 am";
        case AvailabilityTimesByHour.Slot0900:
            return "09:00 am";
        case AvailabilityTimesByHour.Slot1000:
            return "10:00 am";
        case AvailabilityTimesByHour.Slot1100:
            return "11:00 am";
        case AvailabilityTimesByHour.Slot1200:
            return "12:00 pm";
        case AvailabilityTimesByHour.Slot1300:
            return "01:00 pm";
        case AvailabilityTimesByHour.Slot1400:
            return "02:00 pm";
        case AvailabilityTimesByHour.Slot1500:
            return "03:00 pm";
        case AvailabilityTimesByHour.Slot1600:
            return "04:00 pm";
        case AvailabilityTimesByHour.Slot1700:
            return "05:00 pm";
        case AvailabilityTimesByHour.Slot1800:
            return "06:00 pm";
        case AvailabilityTimesByHour.Slot1900:
            return "07:00 pm";
        case AvailabilityTimesByHour.Slot2000:
            return "08:00 pm";
        case AvailabilityTimesByHour.Slot2100:
            return "09:00 pm";
        case AvailabilityTimesByHour.Slot2200:
            return "10:00 pm";
        case AvailabilityTimesByHour.Slot2300:
            return "11:00 pm";
    }
    return "undefined";
}

export function getAvailabilityTimeByHour(id: AvailabilityTimesByHour): AvailabilityTimeByHour {
    let label = getAvailabilityTimeByHourLabel(id);

    return new AvailabilityTimeByHour(id, label);
}

export function getAvailabilityTimesByHour(ids: AvailabilityTimesByHour[]): AvailabilityTimeByHour[] {
    return ids.map(getAvailabilityTimeByHour);
}
