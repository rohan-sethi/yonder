export enum ExperienceCategories {
    Farm = "farm",
    Ranch = "ranch",
    Vineyard = "vineyard",
    Escape = "escape"
}

export class ExperienceCategory {
    constructor(public id: string, public label: string, public image: string) {}
}

export function getExperienceCategoryLabel(id: ExperienceCategories): string {
    switch (id) {
        case ExperienceCategories.Farm:
            return "Farm";
        case ExperienceCategories.Ranch:
            return "Ranch";
        case ExperienceCategories.Vineyard:
            return "Vineyard";
        case ExperienceCategories.Escape:
            return "Escape";
    }
    return "undefined";
}

export function getExperienceCategoryImageUrl(id: ExperienceCategories): string {
    switch (id) {
        case ExperienceCategories.Farm:
            return "/img/farm-square.jpg";
        case ExperienceCategories.Ranch:
            return "/img/ranch-square.jpg";
        case ExperienceCategories.Vineyard:
            return "/img/vineyard-square.jpg";
        case ExperienceCategories.Escape:
            return "/img/escape-square.jpg";
    }
    return "undefined";
}

export function getExperienceCategory(id: ExperienceCategories): ExperienceCategory {
    const label = getExperienceCategoryLabel(id);
    const url = getExperienceCategoryImageUrl(id);

    return new ExperienceCategory(id, label, url);
}

export function getExperienceCategories(ids: ExperienceCategories[]): ExperienceCategory[] {
    return ids.map(getExperienceCategory);
}
