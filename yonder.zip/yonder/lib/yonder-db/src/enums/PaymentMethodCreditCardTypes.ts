export enum PaymentMethodCreditCardTypes {
    VISA = "visa",
    MASTERCARD = "mastercard",
    AMEX = "amex",
    DISCOVER = "discover"
}
