export enum SectionProgress {
    New = "new",
    Started = "started",
    Complete = "complete"
}

export function getSectionProgressLabel(id: SectionProgress): string {
    switch (id) {
        case SectionProgress.New:
            return "New";
        case SectionProgress.Started:
            return "Started";
        case SectionProgress.Complete:
            return "Complete";
    }
    return "undefined";
}

export function getSectionProgressKey(label: string): string {
    return label.toLocaleLowerCase().replace(" ", "_");
}
