export enum HostApprovalSubmissionProgress {
    ThanksForInterest = "thanks_for_interest",
    BusinessPage = "business_page",
    LetsBegin = "lets_begin",
    ExperienceCategory = "experience_category", // Step 1
    OvernightStays = "overnight_stays", // Step 2
    Activities = "activities", // Step 3
    Location = "location", // Step 4
    Description = "description", // Step 5
    Certificate = "certificate", // Step 6
    Photos = "photos", // Step 7
    //
    Completed = "completed",
    // operations
    InReview = "in_review",
    InternationalHold = "international_hold",
    ApprovedAndWaiting = "approved_and_waiting",
    Approved = "approved",
    Denied = "Denied",
    YonderTestingSubmission = "yonder_testing_submission"
}

export function getHostApprovalSubmissionProgressLabel(id: HostApprovalSubmissionProgress): string {
    switch (id) {
        case HostApprovalSubmissionProgress.ThanksForInterest:
            return "Thanks for your interest";
        case HostApprovalSubmissionProgress.BusinessPage:
            return "Business Page";
        case HostApprovalSubmissionProgress.LetsBegin:
            return "Let's Begin";
        case HostApprovalSubmissionProgress.ExperienceCategory:
            return "Experience Category";
        case HostApprovalSubmissionProgress.OvernightStays:
            return "Overnight Stays";
        case HostApprovalSubmissionProgress.Activities:
            return "Activities";
        case HostApprovalSubmissionProgress.Location:
            return "Location";
        case HostApprovalSubmissionProgress.Description:
            return "Description";
        case HostApprovalSubmissionProgress.Certificate:
            return "Certificate";
        case HostApprovalSubmissionProgress.Completed:
            return "Completed";
        case HostApprovalSubmissionProgress.InReview:
            return "In Review";
        case HostApprovalSubmissionProgress.InternationalHold:
            return "International Hold";
        case HostApprovalSubmissionProgress.ApprovedAndWaiting:
            return "Approved and Waiting";
        case HostApprovalSubmissionProgress.Approved:
            return "Approved";
        case HostApprovalSubmissionProgress.Denied:
            return "Denied";
        case HostApprovalSubmissionProgress.YonderTestingSubmission:
            return "Yonder Testing Submission";
    }
    return "undefined";
}
