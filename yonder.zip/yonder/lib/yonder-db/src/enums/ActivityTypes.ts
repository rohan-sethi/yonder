export enum ActivityTypes {
    Archery = "archery",
    ATVRideTour = "atv_ride_tour",
    BbqAndSmoking = "bbq_and_smoking",
    Birdwatching = "birdwatching",
    Bonfire = "bonfire",
    CattleDrive = "cattle_drive",
    Climbing = "climbing",
    Conference = "conference",
    CornAndHayMaze = "corn_and_hay_maze",
    CulinaryClasses = "culinary_classes",
    Dancing = "dancing",
    DeepSeaFishing = "deep_sea_fishing",
    Dining = "dining",
    Diving = "diving",
    Event = "event",
    Fishing = "fishing",
    ForestBathing = "forest_bathing",
    GeocachingAndScavengerHunts = "geocaching_and_scavenger_hunts",
    Gymkhanas = "gymkhanas",
    Harvesting = "harvesting",
    Hiking = "hiking",
    HorseRiding = "horse_riding",
    HotAirBalloon = "hot_air_balloon",
    HowToClasses = "how_to_classes",
    IceFishing = "ice_fishing",
    IceSkating = "ice_skaing",
    KayakingAndCanoeing = "kayaking_and_canoeing",
    LivestockFeeding = "livestock_feeding",
    MountainBiking = "mountain_biking",
    NatureWalkAndTour = "nature_walk_and_tour",
    PackTrips = "pack_trips",
    Photography = "photography",
    Picnic = "picnic",
    PrivateDining = "private_dining",
    PumpkinPatch = "pumpkin_patch",
    RiverRafting = "river_rafting",
    RiverTour = "river_tour",
    Rodeo = "rodeo",
    Sailing = "sailing",
    Seminar = "seminar",
    Skiing = "skiing",
    SleighRides = "slide_rides",
    Snowboarding = "snowboarding",
    Snowmobiling = "snowmobiling",
    Snowshoeing = "snowshoeing",
    SnowSledding = "snowsledding",
    SpiritualRetreat = "spritual_retreat",
    Surfing = "surfing",
    UPickHarvesting = "u_pick_harvesting",
    WineMaking = "wine_making",
    WineTasting = "wine_tasting",
    WineTours = "wine_tours",
    RifleRange = "rifle_range",
    Tours = "tours",
    Venue = "venue",
    WagonRides = "wagon_Rides",
    Wedding = "wedding",
    WorkAlongs = "work_alongs",
    Workshops = "workshops",
    YogaAndMeditation = "yoga_and_meditation",
    ZiplineAndRopesCourse = "zipline_and_ropes_course"
}

export class ActivityType {
    constructor(public id: string, public label: string, public image: string) { }
}

export function getActivityCategories(): string[] {
    return ["Active", "Agriculture", "Animals", "Food", "Outdoor", "Venues", "Wellness", "Winter"];
}

export function getActivityTypesByCategory(category: string): ActivityTypes[] {
    switch (category) {
        case "Active":
            return [
                ActivityTypes.Archery,
                ActivityTypes.ATVRideTour,
                ActivityTypes.Climbing,
                ActivityTypes.Dancing,
                ActivityTypes.Diving,
                ActivityTypes.Hiking,
                ActivityTypes.KayakingAndCanoeing,
                ActivityTypes.MountainBiking,
                ActivityTypes.RifleRange,
                ActivityTypes.RiverRafting,
                ActivityTypes.Sailing,
                ActivityTypes.Surfing,
                ActivityTypes.Tours,
                ActivityTypes.ZiplineAndRopesCourse
            ];
        case "Agriculture":
            return [
                ActivityTypes.CornAndHayMaze,
                ActivityTypes.PumpkinPatch,
                ActivityTypes.WineMaking,
                ActivityTypes.WineTours,
                ActivityTypes.WorkAlongs,
                ActivityTypes.Workshops
            ];
        case "Animals":
            return [
                ActivityTypes.Birdwatching,
                ActivityTypes.CattleDrive,
                ActivityTypes.Gymkhanas,
                ActivityTypes.HorseRiding,
                ActivityTypes.LivestockFeeding,
                ActivityTypes.PackTrips,
                ActivityTypes.Rodeo
            ];
        case "Food":
            return [
                ActivityTypes.BbqAndSmoking,
                ActivityTypes.CulinaryClasses,
                ActivityTypes.Dining,
                ActivityTypes.UPickHarvesting,
                ActivityTypes.WineTasting
            ];
        case "Outdoor":
            return [
                ActivityTypes.Bonfire,
                ActivityTypes.DeepSeaFishing,
                ActivityTypes.Fishing,
                ActivityTypes.GeocachingAndScavengerHunts,
                ActivityTypes.HotAirBalloon,
                ActivityTypes.NatureWalkAndTour,
                ActivityTypes.RiverTour,
                ActivityTypes.WagonRides
            ];
        case "Venues":
            return [ActivityTypes.Event, ActivityTypes.Wedding, ActivityTypes.Conference];
        case "Wellness":
            return [
                ActivityTypes.HowToClasses,
                ActivityTypes.Photography,
                ActivityTypes.Seminar,
                ActivityTypes.SpiritualRetreat,
                ActivityTypes.YogaAndMeditation
            ];
        case "Winter":
            return [
                ActivityTypes.IceFishing,
                ActivityTypes.IceSkating,
                ActivityTypes.Skiing,
                ActivityTypes.SleighRides,
                ActivityTypes.SnowSledding,
                ActivityTypes.Snowboarding,
                ActivityTypes.Snowmobiling,
                ActivityTypes.Snowshoeing
            ];
    }
    return [];
}

export function getActivityLabel(id: ActivityTypes): string {
    switch (id) {
        case ActivityTypes.Archery:
            return "Archery";
        case ActivityTypes.ATVRideTour:
            return "ATV Ride/Tour";
        case ActivityTypes.BbqAndSmoking:
            return "BBQ & Smoking";
        case ActivityTypes.Birdwatching:
            return "Birdwatching";
        case ActivityTypes.Bonfire:
            return "Bonfire";
        case ActivityTypes.CattleDrive:
            return "Cattle Drive";
        case ActivityTypes.Climbing:
            return "Climbing";
        case ActivityTypes.Conference:
            return "Conference";
        case ActivityTypes.CornAndHayMaze:
            return "Corn & Hay Maze";
        case ActivityTypes.CulinaryClasses:
            return "Culinary Classes";
        case ActivityTypes.Dancing:
            return "Dancing";
        case ActivityTypes.DeepSeaFishing:
            return "Deep Sea Fishing";
        case ActivityTypes.Dining:
            return "Dining";
        case ActivityTypes.Diving:
            return "Diving";
        case ActivityTypes.Event:
            return "Event";
        case ActivityTypes.Fishing:
            return "Fishing";
        case ActivityTypes.ForestBathing:
            return "Forest Bathing";
        case ActivityTypes.GeocachingAndScavengerHunts:
            return "Geocaching & Scavenger Hunts";
        case ActivityTypes.Gymkhanas:
            return "Gymkhanas";
        case ActivityTypes.Harvesting:
            return "Harvesting";
        case ActivityTypes.Hiking:
            return "Hiking";
        case ActivityTypes.HorseRiding:
            return "Horse Riding";
        case ActivityTypes.HotAirBalloon:
            return "Hot Air Balloon";
        case ActivityTypes.HowToClasses:
            return "How-To Classes";
        case ActivityTypes.IceFishing:
            return "Ice Fishing";
        case ActivityTypes.IceSkating:
            return "Ice Skating";
        case ActivityTypes.KayakingAndCanoeing:
            return "Kayaking & Canoeing";
        case ActivityTypes.LivestockFeeding:
            return "Livestock Feeding";
        case ActivityTypes.MountainBiking:
            return "Mountain Biking";
        case ActivityTypes.NatureWalkAndTour:
            return "Nature Walk & Tour";
        case ActivityTypes.PackTrips:
            return "Pack Trips";
        case ActivityTypes.Photography:
            return "Photography";
        case ActivityTypes.Picnic:
            return "Picnic";
        case ActivityTypes.PrivateDining:
            return "Private Dining";
        case ActivityTypes.PumpkinPatch:
            return "Pumpkin Patch";
        case ActivityTypes.RiverRafting:
            return "River Rafting";
        case ActivityTypes.RiverTour:
            return "River Tour";
        case ActivityTypes.Rodeo:
            return "Rodeo";
        case ActivityTypes.Sailing:
            return "Sailing";
        case ActivityTypes.Seminar:
            return "Seminar";
        case ActivityTypes.Skiing:
            return "Skiing";
        case ActivityTypes.SleighRides:
            return "Sleigh Rides";
        case ActivityTypes.Snowboarding:
            return "Snowboarding";
        case ActivityTypes.Snowmobiling:
            return "Snowmobiling";
        case ActivityTypes.Snowshoeing:
            return "Snowshoeing";
        case ActivityTypes.SnowSledding:
            return "Snowsledding";
        case ActivityTypes.SpiritualRetreat:
            return "Spritual Retreat";
        case ActivityTypes.Surfing:
            return "Surfing";
        case ActivityTypes.UPickHarvesting:
            return "U-Pick Harvesting";
        case ActivityTypes.WagonRides:
            return "Wagon Rides";
        case ActivityTypes.WineMaking:
            return "Wine Making";
        case ActivityTypes.WineTasting:
            return "Wine Tasting";
        case ActivityTypes.WineTours:
            return "Wine Tours";
        case ActivityTypes.RifleRange:
            return "Rifle Range";
        case ActivityTypes.Tours:
            return "Tours";
        case ActivityTypes.Venue:
            return "Venue";
        case ActivityTypes.Wedding:
            return "Wedding";
        case ActivityTypes.WorkAlongs:
            return "Work Alongs";
        case ActivityTypes.Workshops:
            return "Workshops";
        case ActivityTypes.YogaAndMeditation:
            return "Yoga And Meditation";
        case ActivityTypes.ZiplineAndRopesCourse:
            return "Zipline & Ropes Course";
    }
    return "undefined";
}

export function getActivityImageUrl(_id: ActivityTypes): string {
    // TODO
    return "";
}

export function getActivity(id: ActivityTypes): ActivityType {
    let label = getActivityLabel(id);
    let url = getActivityImageUrl(id);

    return new ActivityType(id, label, url);
}

export function getActivityTypes(ids: ActivityTypes[]): ActivityType[] {
    return ids.map(getActivity);
}
