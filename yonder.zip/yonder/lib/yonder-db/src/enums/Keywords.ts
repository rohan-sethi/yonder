export enum Keywords {
    ATV = "atv",
    Barn = "barn",
    BarnLoft = "barn_loft",
    BBQ = "bbq",
    BeachAccess = "beach_access",
    BeachHouse = "beach_house",
    BeachVolleyball = "beach_volleyball",
    Bikes = "bikes",
    Birdwatching = "bird_watching",
    Climbing = "climbing",
    CookingClasses = "cooking_classes",
    CornMaze = "corn_maze",
    CountryDances = "country_dances",
    Culinary = "culinary",
    DeepSeaFishing = "deep_sea_fishing",
    Diving = "diving",
    Campfire = "campfire",
    CattleDrive = "cattle_drive",
    FarmToTable = "farm_to_table",
    Fishing = "fishing",
    FishingPoles = "fishing_poles",
    HorsebackRiding = "horseback_riding",
    HotAirBalloon = "hot_air_balloon",
    Forest = "forest",
    Geocaching = "geocaching",
    Greenhouse = "greenhouse",
    Gymkhanas = "gymkhanas",
    Harvesting = "harvesting",
    Hiking = "hiking",
    HowToClasses = "how_to_classes",
    Hunting = "hunting",
    InspirationSeminar = "inspiration_seminar",
    InteractiveTours = "interactive_tours",
    Kayaking = "kayaking",
    Lake = "lake",
    LakeHouse = "lake_house",
    LineDancing = "line_dancing",
    LivestockFeeding = "livestock_feeding",
    LivestockViewing = "livestock_viewing",
    Meditation = "meditation",
    MountainBiking = "mountain_biking",
    NaturalEncounters = "natural_encounters",
    NatureTour = "nature_tour",
    NatureWalk = "nature_walk",
    PackTrips = "pack_trips",
    Paddleboat = "paddleboat",
    Parasailing = "parasailing",
    PassiveHouse = "passive_house",
    Pasture = "pasture",
    Permaculture = "permaculture",
    Photography = "photography",
    Pond = "pond",
    Private = "private",
    Refuge = "refuge",
    Regenerative = "regenerative",
    RifleRange = "rifle_range",
    River = "river",
    RiverRafting = "river_rafting",
    RiverTour = "river_tour",
    Rodeo = "rodeo",
    RooftopGarden = "rooftop_garden",
    Sailing = "sailing",
    ScubaDiving = "scuba_diving",
    Sightseeing = "sightseeing",
    Skiing = "skiing",
    SnowSledding = "snow_sledding",
    Snowboarding = "snowboarding",
    Snowmobiling = "snowmobiling",
    Snowshoeing = "snowshoeing",
    SpiritualRetreat = "spiritual_retreat",
    Surfing = "surfing",
    Sustainable = "sustainable",
    SustainableBuilding = "sustainable_building",
    Tennis = "tennis",
    TrapShooting = "trap_shooting",
    UPickHarvesting = "upick_harvesting",
    UrbanFarm = "urban_farm",
    WalkingTrails = "walking_trails",
    WildlifeViewing = "wildlife_viewing",
    WineMaking = "wine_making",
    WineTasting = "wine_tasting",
    WorkAlongs = "work_alongs",
    Yoga = "yoga",
    ZipLining = "zip_lining"
}

export class Keyword {
    constructor(public id: string, public label: string, public image: string) {}
}

export function getKeywordLabel(id: Keywords): string {
    switch (id) {
        case Keywords.ATV:
            return "ATV";
        case Keywords.Barn:
            return "Barn";
        case Keywords.BarnLoft:
            return "Barn Loft";
        case Keywords.BBQ:
            return "BBQ";
        case Keywords.BeachAccess:
            return "Beach Access";
        case Keywords.BeachHouse:
            return "Beach House";
        case Keywords.BeachVolleyball:
            return "Beach Volleyball";
        case Keywords.Bikes:
            return "Bikes";
        case Keywords.Birdwatching:
            return "Birdwatching";
        case Keywords.Climbing:
            return "Climbing";
        case Keywords.CookingClasses:
            return "Cooking Classes";
        case Keywords.CornMaze:
            return "Corn Maze";
        case Keywords.CountryDances:
            return "Country Dances";
        case Keywords.Culinary:
            return "Culinary";
        case Keywords.DeepSeaFishing:
            return "Deep Sea Fishing";
        case Keywords.Diving:
            return "Diving";
        case Keywords.Campfire:
            return "Campfire";
        case Keywords.CattleDrive:
            return "Cattle Drive";
        case Keywords.FarmToTable:
            return "Farm to Table";
        case Keywords.Fishing:
            return "Fishing";
        case Keywords.FishingPoles:
            return "Fishing Poles";
        case Keywords.HorsebackRiding:
            return "Horseback Riding";
        case Keywords.HotAirBalloon:
            return "Hot-Air Balloon";
        case Keywords.Forest:
            return "Forest";
        case Keywords.Geocaching:
            return "Geocaching";
        case Keywords.Greenhouse:
            return "Greenhouse";
        case Keywords.Gymkhanas:
            return "Gymkhanas";
        case Keywords.Harvesting:
            return "Harvesting";
        case Keywords.Hiking:
            return "Hiking";
        case Keywords.HowToClasses:
            return "How-To Classes";
        case Keywords.Hunting:
            return "Hunting";
        case Keywords.InspirationSeminar:
            return "Inspiration Seminar";
        case Keywords.InteractiveTours:
            return "Interactive Tours";
        case Keywords.Kayaking:
            return "Kayaking";
        case Keywords.Lake:
            return "Lake";
        case Keywords.LakeHouse:
            return "Lake House";
        case Keywords.LineDancing:
            return "Line Dancing";
        case Keywords.LivestockFeeding:
            return "Livestock Feeding";
        case Keywords.LivestockViewing:
            return "Livestock Viewing";
        case Keywords.Meditation:
            return "Meditation";
        case Keywords.MountainBiking:
            return "Mountain Biking";
        case Keywords.NaturalEncounters:
            return "Natural Encounters";
        case Keywords.NatureTour:
            return "Nature Tour";
        case Keywords.NatureWalk:
            return "Nature Walk";
        case Keywords.PackTrips:
            return "Pack Trips";
        case Keywords.Paddleboat:
            return "Paddleboat";
        case Keywords.Parasailing:
            return "Parasailing";
        case Keywords.PassiveHouse:
            return "Passive House";
        case Keywords.Pasture:
            return "Pasture";
        case Keywords.Permaculture:
            return "Permaculture";
        case Keywords.Photography:
            return "Photography";
        case Keywords.Pond:
            return "Pond";
        case Keywords.Private:
            return "Private";
        case Keywords.Refuge:
            return "Refuge";
        case Keywords.Regenerative:
            return "Regenerative";
        case Keywords.RifleRange:
            return "Rifle Range";
        case Keywords.River:
            return "River";
        case Keywords.RiverRafting:
            return "River Rafting";
        case Keywords.RiverTour:
            return "River Tour";
        case Keywords.Rodeo:
            return "Rodeo";
        case Keywords.RooftopGarden:
            return "Rooftop Garden";
        case Keywords.Sailing:
            return "Sailing";
        case Keywords.ScubaDiving:
            return "ScubaDiving";
        case Keywords.Sightseeing:
            return "Sightseeing";
        case Keywords.Skiing:
            return "Skiing";
        case Keywords.SnowSledding:
            return "SnowSledding";
        case Keywords.Snowboarding:
            return "Snowboarding";
        case Keywords.Snowmobiling:
            return "Snowmobiling";
        case Keywords.Snowshoeing:
            return "Snowshoeing";
        case Keywords.SpiritualRetreat:
            return "Spiritual Retreat";
        case Keywords.Surfing:
            return "Surfing";
        case Keywords.Sustainable:
            return "Sustainable";
        case Keywords.SustainableBuilding:
            return "Sustainable Building";
        case Keywords.Tennis:
            return "Tennis";
        case Keywords.TrapShooting:
            return "Trap Shooting";
        case Keywords.UPickHarvesting:
            return "UPick Harvesting";
        case Keywords.UrbanFarm:
            return "Urban Farm";
        case Keywords.WalkingTrails:
            return "Walking Trails";
        case Keywords.WildlifeViewing:
            return "Wildlife Viewing";
        case Keywords.WineMaking:
            return "Wine Making";
        case Keywords.WineTasting:
            return "Wine Tasting";
        case Keywords.WorkAlongs:
            return "Work Alongs";
        case Keywords.Yoga:
            return "Yoga";
        case Keywords.ZipLining:
            return "Zip Lining";
    }
    return "undefined";
}

export function getKeywordImageUrl(_id: Keywords): string {
    // TODO
    return "";
}

export function getKeyword(id: Keywords): Keyword {
    const label = getKeywordLabel(id);
    const url = getKeywordImageUrl(id);

    return new Keyword(id, label, url);
}

export function getKeywords(ids: Keywords[]): Keyword[] {
    return ids.map(getKeyword);
}
