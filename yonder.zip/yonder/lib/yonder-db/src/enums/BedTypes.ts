export enum BedTypes {
    King = "bed_king",
    Queen = "bed_queen",
    Full = "bed_full",
    Twin = "bed_twin",
    Futon = "bed_futon",
    SofaBed = "bed_sofa_bed",
    Bunk = "bed_bunk",
    Crib = "bed_crib"
}

export class BedType {
    constructor(public id: string, public label: string) {}
}

export function getBedTypeLabel(id: BedTypes): string {
    switch (id) {
        case BedTypes.King:
            return "King Size Bed";
        case BedTypes.Queen:
            return "Queen Size Bed";
        case BedTypes.Full:
            return "Full Size Bed";
        case BedTypes.Twin:
            return "Twin Size Bed";
        case BedTypes.Futon:
            return "Futon";
        case BedTypes.SofaBed:
            return "Sofa Bed";
        case BedTypes.Bunk:
            return "Bunk Beds";
        case BedTypes.Crib:
            return "Crib";
    }
    return "undefined";
}

export function getBedType(id: BedTypes): BedType {
    const label = getBedTypeLabel(id);

    return new BedType(id, label);
}

export function getBedTypes(ids: BedTypes[]): BedType[] {
    return ids.map(getBedType);
}
