export enum OrganizationCertificates {
    PHIUSCertified = "phius_certified",
    AnimalWelfareApproved = "animal_welfare_approved",
    LandTrustAlliance = "land_trust_alliance",
    NonGMOCertified = "non_gmo_certified",
    USDAOrganic = "usda_organic",
    RegenerativeOrganic = "regenerative_organic",
    SlowFoodPresidia = "slow_food_precidia",
    FairTrade = "fair_trade",
    LEEDHome = "leed_home",
    MSCCertified = "msc_certified",
    CertifiedBCorporation = "certified_b_corporation",
    YogaAllianceCertified = "yoga_alliance_certified",
    InternationalCoachFederation = "international_coach_federation",
    AssociationOfNatureAndForestTherapy = "association_of_nature_and_forest_therapy"
}

export class OrganizationCertificate {
    constructor(public id: string, public label: string, public image: string) {}
}

export function getOrganizationCertificateLabel(id: OrganizationCertificates): string {
    switch (id) {
        case OrganizationCertificates.PHIUSCertified:
            return "PHIUS Certified";
        case OrganizationCertificates.AnimalWelfareApproved:
            return "Animal Welfare Approved";
        case OrganizationCertificates.LandTrustAlliance:
            return "Land Trust Alliance";
        case OrganizationCertificates.NonGMOCertified:
            return "Non-GMO Certified";
        case OrganizationCertificates.USDAOrganic:
            return "USDA Organic";
        case OrganizationCertificates.RegenerativeOrganic:
            return "Regenerative Organic";
        case OrganizationCertificates.AssociationOfNatureAndForestTherapy:
            return "Association of Nature + Forest Therapy";
        case OrganizationCertificates.FairTrade:
            return "Fair Trade";
        case OrganizationCertificates.LEEDHome:
            return "LEED Home";
        case OrganizationCertificates.MSCCertified:
            return "MSC Certified";
        case OrganizationCertificates.CertifiedBCorporation:
            return "Certified B Corporation";
        case OrganizationCertificates.YogaAllianceCertified:
            return "Yoga Alliance Certified";
        case OrganizationCertificates.InternationalCoachFederation:
            return "International Coach Federation";
        case OrganizationCertificates.SlowFoodPresidia:
            return "Slow Food Presidia";
    }
    return "undefined";
}

export function getOrganizationCertificateImageUrl(_id: OrganizationCertificates): string {
    // TODO
    return "";
}

export function getOrganizationCertificate(id: OrganizationCertificates): OrganizationCertificate {
    let label = getOrganizationCertificateLabel(id);
    let url = getOrganizationCertificateImageUrl(id);

    return new OrganizationCertificate(id, label, url);
}

export function getOrganizationCertificates(ids: OrganizationCertificates[]): OrganizationCertificate[] {
    return ids.map(getOrganizationCertificate);
}
