export enum ListingProgress {
    Draft = "draft",
    InReview = "in_review",
    InReviewByHost = "in_review_by_host",
    Ready = "ready"
}

export function getListingProgressLabel(id: ListingProgress): string {
    switch (id) {
        case ListingProgress.Draft:
            return "Draft";
        case ListingProgress.InReview:
            return "Yonder Review";
        case ListingProgress.InReviewByHost:
            return "Host Review";
        case ListingProgress.Ready:
            return "Ready";
    }
    return "undefined";
}

export function getListingProgressDescription(id: ListingProgress): string {
    switch (id) {
        case ListingProgress.Draft:
            return "Great progress, let's finish creating your stay.";
        case ListingProgress.InReview:
            return "Yonder Scouts are reviewing your listing.";
        case ListingProgress.InReviewByHost:
            return "Host is confirming listing details.";
        case ListingProgress.Ready:
            return "Everything in your listing looks great.";
    }
    return "undefined";
}
