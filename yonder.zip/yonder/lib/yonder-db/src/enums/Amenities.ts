export enum Amenities {
    AccessibleHeightBed = "accessible_height_bed",
    AccessibleHeightToilet = "accessible_height_toilet",
    AirConditioning = "air_conditioning",
    AlarmClock = "alarm_clock",
    BabyBath = "baby_bath",
    BabyMonitor = "baby_monitor",
    Backyard = "backyard",
    Balcony = "balcony",
    Bathtub = "bathtub",
    Beachfront = "beachfront",
    BBQGrill = "bbq_grill",
    BlackOutShades = "black_out_shades",
    ChangingTable = "changing_table",
    ChildrensBooksAndToys = "childrens_books_and_toys",
    ChildrensDinnerware = "childrens_dinnerware",
    CoffeeMakerFrenchPress = "coffee_maker_french_press",
    CoffeeMakerPourOver = "coffee_maker_pour_over",
    CoffeeMakerStandard = "coffee_maker_standard",
    CookingBasics = "cooking_Basics",
    Crib = "crib",
    DeskWorkspace = "desk_workspace",
    DisabledParkingSpot = "disabled_parking_spot",
    Dishwasher = "dishwasher",
    Elevator = "elevator",
    EspressoMachine = "espresso_machine",
    EVcharger = "ev_charger",
    ExtraPillowsAndBlankets = "extra_pillows_and_blankets",
    FirePit = "fire_pit",
    FireplaceGuards = "fireplace_guards",
    FireplaceGas = "fireplace_gas",
    FireplaceWood = "fireplace_wood",
    FlatPathToEntrance = "flat_path_to_entrance",
    GameConsole = "game_console",
    Garage = "garage",
    Garden = "garden",
    Greenhouse = "greenhouse",
    Gym = "gym",
    HairDryer = "hair_dryer",
    HandheldShowerHead = "handheld_shower_head",
    Hangers = "hangers",
    Heating = "heating",
    HighChair = "high_chair",
    HotTub = "hot_tub",
    InfantCrib = "infant_crib",
    IronIroningBoard = "iron_ironing_board",
    Jacuzzi = "jacuzzi",
    Kitchenette = "kitchenette",
    LakeAccess = "lake_access",
    LaundryDryer = "laundry_dryer",
    LaundryWasher = "laundry_washer",
    Microwave = "microwave",
    MovieRoom = "movie_room",
    NoStairsOrEntrySteps = "no_stairs_or_entry_steps",
    OutdoorDeck = "outdoor_deck",
    OutletCovers = "outlet_covers",
    Oven = "oven",
    PacknPlay = "packn_play",
    PaidParkingOffPremises = "paid_parking_off_premises",
    PaidParkingOnPremises = "paid_parking_on_premises",
    ParkingSpace = "parking_space",
    Patio = "patio",
    PavedDriveway = "paved_driveway",
    Pool = "pool",
    PoolWithHoist = "pool_with_hoist",
    PrivateParking = "private_parking",
    PrivateEntrance = "private_entrance",
    Refrigerator = "refrigerator",
    RollInShower = "roll_in_shower",
    SecuritySafe = "security_safe",
    ShowerChair = "shower_chair",
    ShowerGrabBars = "shower_grab_bars",
    SingleLevelHome = "single_level_home",
    SkiInSkiOut = "ski_in_ski_out",
    StairGates = "stair_gates",
    StairHoist = "stair_hoist",
    Stove = "stove",
    StreetParking = "street_parking",
    TableCornerGuards = "table_corner_guards",
    ToddlerSafetyGuard = "toddler_safety_guard",
    ToiletGrabBars = "toilet_grab_bars",
    Toiletries = "toiletries",
    TV = "tv",
    TVCableOrSatellite = "tv_cable_or_satellite",
    TVSmart = "tv_smart",
    Waterfront = "waterfront",
    WideEntrance = "wide_entrance",
    WideHallways = "wide_hallways",
    WiFi = "wifi",
    WindowGuards = "window_guards",

    //Activity Essentials
    BeachBlanket = "beach_blanket",
    BeachTowels = "beach_towels",
    Bicycles = "bicycles",
    BoogieBoards = "boogie_boards",
    Canoe = "canoe",
    Cooler = "cooler",
    Firewood = "firewood",
    FishingGear = "fishing_gear",
    FoldingChairs = "folding_chairs",
    Inflatables = "inflatables",
    InsulatedCoolerBags = "insulated_cooler_bags",
    Kayak = "kayak",
    KidsFlotation = "kids_flotation",
    LifeJackets = "life_jackets",
    SandToys = "sand_toys",
    Skies = "skies",
    SnorkelingGear = "snorkeling_gear",
    SnowBoard = "snow_board",
    SnowShoes = "snow_shoes",
    SnowSleds = "snow_sleds",
    SportsGear = "sports_gear",
    SurfBoards = "surf_boards",
    TrekkingPoles = "trekking_poles",
    Umbrella = "umbrella",

    //prior enums for ops
    CoffeeMaker = "coffee_maker",
    Fireplace = "fireplace",
    FirstAidKit = "first_aid_kit",
    GasPropane = "gas_propane",
    HandicapAccessible = "handicap_accessible",
    PetFriendly = "pet_friendly",
    StoveCooking = "stove_cooking"
}

export class Amenity {
    constructor(public id: string, public label: string, public image: string) {}
}

export function getAmenityLabel(id: Amenities): string {
    switch (id) {
        case Amenities.AccessibleHeightBed:
            return "Accessible-height bed";
        case Amenities.AccessibleHeightToilet:
            return "Accessible-height toilet";
        case Amenities.AirConditioning:
            return "Air-conditioning";
        case Amenities.AlarmClock:
            return "Alarm clock";
        case Amenities.BabyBath:
            return "Baby bath";
        case Amenities.BabyMonitor:
            return "Baby monitor";
        case Amenities.Backyard:
            return "Backyard";
        case Amenities.Balcony:
            return "Balcony";
        case Amenities.Bathtub:
            return "Bathtub";
        case Amenities.Beachfront:
            return "Beachfront";
        case Amenities.BBQGrill:
            return "BBQ grill";
        case Amenities.BlackOutShades:
            return "Black out shades";
        case Amenities.ChangingTable:
            return "Changing table";
        case Amenities.ChildrensBooksAndToys:
            return "Children's books and toys";
        case Amenities.ChildrensDinnerware:
            return "Children's dinnerware";
        case Amenities.CoffeeMakerFrenchPress:
            return "Coffee maker - french press";
        case Amenities.CoffeeMakerPourOver:
            return "Coffee maker - pour over";
        case Amenities.CoffeeMakerStandard:
            return "Coffee maker - standard";
        case Amenities.CookingBasics:
            return "Cooking basics - pots, pans, oil, salt, pepper";
        case Amenities.Crib:
            return "Crib";
        case Amenities.DeskWorkspace:
            return "Desk workspace";
        case Amenities.DisabledParkingSpot:
            return "Disabled parking spot";
        case Amenities.Dishwasher:
            return "Dishwasher";
        case Amenities.Elevator:
            return "Elevator";
        case Amenities.EspressoMachine:
            return "Espresso machine";
        case Amenities.EVcharger:
            return "EV charger";
        case Amenities.ExtraPillowsAndBlankets:
            return "Extra pillows and blankets";
        case Amenities.FirePit:
            return "Fire Pit";
        case Amenities.FireplaceGas:
            return "Fireplace gas";
        case Amenities.FireplaceGuards:
            return "Fireplace guards";
        case Amenities.FireplaceWood:
            return "Fireplace wood";
        case Amenities.FlatPathToEntrance:
            return "Flat path to entrance";
        case Amenities.GameConsole: //copy change only
            return "Game room - Tabletop games, board games, etc.";
        case Amenities.Garage:
            return "Garage";
        case Amenities.Garden:
            return "Garden";
        case Amenities.Greenhouse:
            return "Greenhouse";
        case Amenities.Gym:
            return "Gym";
        case Amenities.HairDryer:
            return "Hair dryer";
        case Amenities.HandheldShowerHead:
            return "Handheld shower head";
        case Amenities.Hangers:
            return "Hangers";
        case Amenities.Heating:
            return "Heating";
        case Amenities.HighChair:
            return "High chair";
        case Amenities.HotTub:
            return "Hot tub";
        case Amenities.InfantCrib:
            return "Infant crib";
        case Amenities.IronIroningBoard:
            return "Iron / ironing board";
        case Amenities.Jacuzzi:
            return "Jacuzzi tub";
        case Amenities.Kitchenette:
            return "Kitchenette";
        case Amenities.LakeAccess:
            return "Lake access";
        case Amenities.LaundryDryer:
            return "Laundry – dryer";
        case Amenities.LaundryWasher:
            return "Laundry – washer";
        case Amenities.Microwave:
            return "Microwave";
        case Amenities.MovieRoom:
            return "Movie room";
        case Amenities.NoStairsOrEntrySteps:
            return "No stairs or entry steps";
        case Amenities.OutdoorDeck:
            return "Outdoor deck";
        case Amenities.OutletCovers:
            return "Outlet covers";
        case Amenities.Oven:
            return "Oven";
        case Amenities.PacknPlay:
            return "Pack'n Play - travel crib";
        case Amenities.PaidParkingOffPremises:
            return "Paid parking off premises";
        case Amenities.PaidParkingOnPremises:
            return "Paid parking on premises";
        case Amenities.ParkingSpace:
            return "Parking space";
        case Amenities.Patio:
            return "Patio";
        case Amenities.PavedDriveway:
            return "Paved driveway";
        case Amenities.Pool:
            return "Pool";
        case Amenities.PoolWithHoist:
            return "Pool with hoist";
        case Amenities.PrivateEntrance:
            return "Private entrance";
        case Amenities.PrivateParking:
            return "Private parking";
        case Amenities.Refrigerator:
            return "Refrigerator";
        case Amenities.RollInShower:
            return "Roll-in shower";
        case Amenities.SecuritySafe:
            return "Security safe";
        case Amenities.ShowerChair:
            return "Shower chair";
        case Amenities.ShowerGrabBars:
            return "Shower grab bars";
        case Amenities.SingleLevelHome:
            return "Single level home - no stairs";
        case Amenities.SkiInSkiOut:
            return "Ski-in / ski-out";
        case Amenities.StairGates:
            return "Stair gates";
        case Amenities.StairHoist:
            return "Stair hoist";
        case Amenities.Stove:
            return "Stove";
        case Amenities.StreetParking:
            return "Street parking";
        case Amenities.TableCornerGuards:
            return "Table corner guards";
        case Amenities.ToddlerSafetyGuard:
            return "Toddler safety guard";
        case Amenities.ToiletGrabBars:
            return "Toilet grab bars";
        case Amenities.Toiletries:
            return "Toiletries (May include: soap, shampoo, conditioner, lotion, etc.)";
        case Amenities.TV:
            return "TV";
        case Amenities.TVCableOrSatellite:
            return "TV - cable or satellite";
        case Amenities.TVSmart:
            return "TV - smart";
        case Amenities.Waterfront:
            return "Waterfront";
        case Amenities.WideEntrance:
            return "Wide entrance";
        case Amenities.WideHallways:
            return "Wide hallways";
        case Amenities.WiFi:
            return "WiFi";
        case Amenities.WindowGuards:
            return "Window guards";

        //Activity Essentials
        case Amenities.BeachBlanket:
            return "Beach blanket";
        case Amenities.BeachTowels:
            return "Beach towels";
        case Amenities.Bicycles:
            return "Bicycles";
        case Amenities.BoogieBoards:
            return "Boogie boards";
        case Amenities.Canoe:
            return "Canoe";
        case Amenities.Cooler:
            return "Cooler";
        case Amenities.Firewood:
            return "Firewood";
        case Amenities.FishingGear:
            return "Fishing gear";
        case Amenities.FoldingChairs:
            return "Folding chairs";
        case Amenities.Inflatables:
            return "Inflatables";
        case Amenities.InsulatedCoolerBags:
            return "Insulated cooler bags";
        case Amenities.Kayak:
            return "Kayak";
        case Amenities.KidsFlotation:
            return "Kids floatation";
        case Amenities.LifeJackets:
            return "Life jackets";
        case Amenities.SandToys:
            return "Sand toys";
        case Amenities.Skies:
            return "Skies";
        case Amenities.SnorkelingGear:
            return "Snorkeling gear";
        case Amenities.SnowBoard:
            return "Snow board";
        case Amenities.SnowShoes:
            return "Snow shoes";
        case Amenities.SnowSleds:
            return "Snow sleds";
        case Amenities.SportsGear:
            return "Sports gear - frisbee, football, soccer ball";
        case Amenities.SurfBoards:
            return "Surf boards";
        case Amenities.TrekkingPoles:
            return "Trekking poles - hiking stick";
        case Amenities.Umbrella:
            return "Umbrella";
        //prior enums for op
        // case Amenities.CoffeeMaker:
        //      return "Coffe Maker"
        // case Amenities.Fireplace:
        //     return "Fireplace"
        // case Amenities.FirstAidKit:
        //     return "First aid lit"
        // case Amenities.GasPropane:
        //     return "Gas propane"
        // case Amenities.HandicapAccessible:
        //     return "Handicap accessible"
        // case Amenities.PetFriendly:
        //     return "Pet friendly"
        // case Amenities.StoveCooking:
        //     return "Stove cooking"
    }
    return "undefined";
}

export function getAmenityCategories(): string[] {
    return [
        "Accessibility",
        "Bathroom",
        "Facilities",
        "Family",
        "General Indoor",
        "Kitchen",
        "Outdoor",
        "General Activity Essentials",
        "Beach Activity Essentials",
        "Lake Activity Essentials",
        "Winter Activity Essentials"
    ];
}

export function getAmenitiesByCategory(category: string): Amenities[] {
    switch (category) {
        case "Accessibility":
            return [
                Amenities.AccessibleHeightBed,
                Amenities.AccessibleHeightToilet,
                Amenities.DisabledParkingSpot,
                Amenities.Elevator,
                Amenities.FlatPathToEntrance,
                Amenities.HandheldShowerHead,
                Amenities.NoStairsOrEntrySteps,
                Amenities.PoolWithHoist,
                Amenities.RollInShower,
                Amenities.ShowerChair,
                Amenities.ShowerGrabBars,
                Amenities.StairHoist,
                Amenities.ToiletGrabBars,
                Amenities.WideEntrance,
                Amenities.WideHallways
            ];
        case "Bathroom":
            return [Amenities.Bathtub, Amenities.HairDryer, Amenities.Jacuzzi, Amenities.Toiletries];
        case "Facilities":
            return [
                Amenities.Beachfront,
                Amenities.EVcharger,
                Amenities.Garage,
                Amenities.Gym,
                Amenities.LakeAccess,
                Amenities.PaidParkingOffPremises,
                Amenities.PaidParkingOnPremises,
                Amenities.PavedDriveway,
                Amenities.PrivateEntrance,
                Amenities.PrivateParking,
                Amenities.SingleLevelHome,
                Amenities.SkiInSkiOut,
                Amenities.StreetParking,
                Amenities.Waterfront
            ];
        case "Family":
            return [
                Amenities.BabyBath,
                Amenities.BabyMonitor,
                Amenities.BlackOutShades,
                Amenities.ChangingTable,
                Amenities.ChildrensBooksAndToys,
                Amenities.ChildrensDinnerware,
                Amenities.Crib,
                Amenities.FireplaceGuards,
                Amenities.HighChair,
                Amenities.OutletCovers,
                Amenities.PacknPlay,
                Amenities.StairGates,
                Amenities.TableCornerGuards,
                Amenities.WindowGuards
            ];
        case "General Indoor":
            return [
                Amenities.AirConditioning,
                Amenities.AlarmClock,
                Amenities.DeskWorkspace,
                Amenities.Elevator,
                Amenities.ExtraPillowsAndBlankets,
                Amenities.FireplaceGas,
                Amenities.FireplaceWood,
                Amenities.GameConsole,
                Amenities.Heating,
                Amenities.IronIroningBoard,
                Amenities.LaundryDryer,
                Amenities.LaundryWasher,
                Amenities.MovieRoom,
                Amenities.TV,
                Amenities.TVCableOrSatellite,
                Amenities.TVSmart,
                Amenities.WiFi
            ];
        case "Kitchen":
            return [
                Amenities.CoffeeMakerFrenchPress,
                Amenities.CoffeeMakerPourOver,
                Amenities.CoffeeMakerStandard,
                Amenities.CookingBasics,
                Amenities.Dishwasher,
                Amenities.EspressoMachine,
                Amenities.Kitchenette,
                Amenities.Microwave,
                Amenities.Oven,
                Amenities.Refrigerator,
                Amenities.Stove
            ];
        case "Outdoor":
            return [
                Amenities.Backyard,
                Amenities.Balcony,
                Amenities.BBQGrill,
                Amenities.FirePit,
                Amenities.Garden,
                Amenities.Greenhouse,
                Amenities.HotTub,
                Amenities.OutdoorDeck,
                Amenities.Patio,
                Amenities.Pool
            ];
        case "General Activity Essentials":
            return [
                Amenities.Bicycles,
                Amenities.Cooler,
                Amenities.InsulatedCoolerBags,
                Amenities.SportsGear,
                Amenities.TrekkingPoles
            ];
        case "Beach Activity Essentials":
            return [
                Amenities.BeachBlanket,
                Amenities.BeachTowels,
                Amenities.BoogieBoards,
                Amenities.Firewood,
                Amenities.KidsFlotation,
                Amenities.LifeJackets,
                Amenities.SandToys,
                Amenities.SnorkelingGear,
                Amenities.SurfBoards,
                Amenities.Umbrella
            ];
        case "Lake Activity Essentials":
            return [
                Amenities.Canoe,
                Amenities.FishingGear,
                Amenities.Inflatables,
                Amenities.Kayak,
                Amenities.SnorkelingGear
            ];
        case "Winter Activity Essentials":
            return [Amenities.Skies, Amenities.SnowBoard, Amenities.SnowShoes, Amenities.SnowSleds];
    }
    return [];
}

export function getAmenityImageUrl(_id: Amenities): string {
    // TODO
    return "";
}

export function getAmenity(id: Amenities): Amenity {
    const label = getAmenityLabel(id);
    const url = getAmenityImageUrl(id);

    return new Amenity(id, label, url);
}

export function getAmenities(ids: Amenities[]): Amenity[] {
    return ids.map(getAmenity);
}
