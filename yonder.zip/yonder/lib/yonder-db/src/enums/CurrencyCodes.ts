export enum CurrencyCodes {
    USD = "usd",
    EURO = "euro"
}

export class Currency {
    constructor(public code: string, public label: string, public image: string) {}
}

export function getCurrencyCodeLabel(id: CurrencyCodes): string {
    switch (id) {
        case CurrencyCodes.USD:
            return "USD";
        case CurrencyCodes.EURO:
            return "Euro";
    }
    return "undefined";
}

export function getCurrencyCodeImageUrl(_id: CurrencyCodes): string {
    // TODO
    return "";
}

export function getCurrencyCode(id: CurrencyCodes): Currency {
    let label = getCurrencyCodeLabel(id);
    let url = getCurrencyCodeImageUrl(id);

    return new Currency(id, label, url);
}
