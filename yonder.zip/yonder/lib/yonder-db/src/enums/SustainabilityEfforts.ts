export enum SustainabilityEfforts {
    AllNaturalBedding = "all_natural_bedding",
    Biodynamic = "biodynamic",
    Composting = "composting",
    DrinkingWaterFiltration = "drinking_water_filtration",
    EnergyStarAppliances = "energy_star_appliances",
    EnergyEfficientLighting = "energy_efficient_lighting",
    Gardens = "gardens",
    LowFlowFaucets = "low_flow_faucets",
    LowFlushToilets = "low_flush_toilets",
    LowOrNoVOCinsulation = "low_or_no_voc_insulation",
    LowOrNoVOCproducts = "low_or_no_voc_products",
    MajorAllergenFree = "major_allergen_free",
    MostlyLocalProductUse = "mostly_local_product_use",
    MostlyOrganicProductUse = "mostly_organic_product_use",
    MechanicalAirExchange = "mechanical_air_exchange",
    NoAerosolSprays = "non_aerosol_sprays",
    NonToxicCleaningProducts = "non_toxic_cleaning_products",
    NonToxicPestControlInside = "non_toxic_pest_control_inside",
    NonToxicPestControlOutside = "non_toxic_pest_control_outside",
    NoOneUseCoffee = "no_one_use_coffee",
    NoPlasticBottles = "no_plastic_bottles",
    Organic = "organic",
    OrganicMattresses = "organic_mattresses",
    PermaculturePractices = "permaculture_practices",
    PrivateWell = "private_well",
    RecycledPaperProducts = "recycled_paper_products",
    Recycling = "recycling",
    RegenerativeAgriculture = "regenerative_agriculture",
    SinkMotionSensors = "sink_motion_sensors",
    SolarPower = "solar_power",
    WaterConservingAppliances = "water_conserving_appliances",
    WaterConservingIrrigation = "water_conserving_irrigation",
    WaterlessUrinals = "waterless_urinals",
    WholeHouseWaterFiltration = "whole_house_water_filtration",
    WholeHouseHEPA = "whole_house_hepa",
    WindTurbinePower = "wind_turbine_power"
}

export class SustainabilityEffort {
    constructor(public id: string, public label: string, public image: string) {}
}

export function getSustainabilityEffortLabel(id: SustainabilityEfforts): string {
    switch (id) {
        case SustainabilityEfforts.AllNaturalBedding:
            return "100% natural fiber beding";
        case SustainabilityEfforts.Biodynamic:
            return "Biodynamic agriculture (certified or uncertified)";
        case SustainabilityEfforts.Composting:
            return "Composting";
        case SustainabilityEfforts.DrinkingWaterFiltration:
            return "Drinking-water filtration system";
        case SustainabilityEfforts.EnergyEfficientLighting:
            return "Energy-efficient lighting (LED, CFL, Other)";
        case SustainabilityEfforts.EnergyStarAppliances:
            return "ENERGY STAR® rated home appliances";
        case SustainabilityEfforts.Gardens:
            return "Green roof, rain garden, native garden, xeriscape";
        case SustainabilityEfforts.LowFlowFaucets:
            return "Low-flow faucets and showerheads";
        case SustainabilityEfforts.LowFlushToilets:
            return "Low-flush or dual flush toilets";
        case SustainabilityEfforts.LowOrNoVOCinsulation:
            return "Zero-VOC wall insulation ";
        case SustainabilityEfforts.LowOrNoVOCproducts:
            return "Zero-VOC paint products and adhesives";
        case SustainabilityEfforts.MajorAllergenFree:
            return "Major allergen-free";
        case SustainabilityEfforts.MechanicalAirExchange:
            return "Mechanical air exchange units ";
        case SustainabilityEfforts.MostlyLocalProductUse:
            return "Majority local products used";
        case SustainabilityEfforts.MostlyOrganicProductUse:
            return "Majority organic products used";
        case SustainabilityEfforts.NoAerosolSprays:
            return "Non-aerosol products";
        case SustainabilityEfforts.NoOneUseCoffee:
            return "Reusable coffee pods";
        case SustainabilityEfforts.NoPlasticBottles:
            return "Plastic free bottles";
        case SustainabilityEfforts.NonToxicCleaningProducts:
            return "Non-toxic cleaning products, detergents, and disinfectants ";
        case SustainabilityEfforts.NonToxicPestControlInside:
            return "Non-toxic insecticides";
        case SustainabilityEfforts.NonToxicPestControlOutside:
            return "Non-toxic pest and weed control";
        case SustainabilityEfforts.Organic:
            return "Organic (uncertified) ";
        case SustainabilityEfforts.OrganicMattresses:
            return "Organic / natural mattresses ";
        case SustainabilityEfforts.PermaculturePractices:
            return "Permaculture practices";
        case SustainabilityEfforts.PrivateWell:
            return "Private well";
        case SustainabilityEfforts.RecycledPaperProducts:
            return "Recycled paper products";
        case SustainabilityEfforts.Recycling:
            return "Recycling";
        case SustainabilityEfforts.RegenerativeAgriculture:
            return "Regenerative agriculture";
        case SustainabilityEfforts.SinkMotionSensors:
            return "Touchless faucets";
        case SustainabilityEfforts.SolarPower:
            return "Solar panels / power";
        case SustainabilityEfforts.WaterConservingAppliances:
            return "Water-conserving appliances and fixtures";
        case SustainabilityEfforts.WaterConservingIrrigation:
            return "Water-conserving irrigation (drip emitters, precipitation monitoring)";
        case SustainabilityEfforts.WaterlessUrinals:
            return "Waterless urinals";
        case SustainabilityEfforts.WholeHouseHEPA:
            return "Whole-house HEPA (High-Efficiency Particulate Air) filtration";
        case SustainabilityEfforts.WholeHouseWaterFiltration:
            return "Whole house water filtration system (reverse osmosis, charcoal)";
        case SustainabilityEfforts.WindTurbinePower:
            return "Wind turbine power";
    }
    return "undefined";
}

export function getSustainabilityEffortCategories(): string[] {
    return [
        "Energy Efficiency",
        "Food",
        "Indoor Air Quality / Allergen Awareness",
        "Indoor Water Quality (Bathing and Potable)",
        "Land Management Practices",
        "Supplies / Purchasing / Materials",
        "Waste Reduction and Recycling",
        "Water Conservation and Protection"
    ];
}

export function getSustainabilityEffortsByCategory(category: string): SustainabilityEfforts[] {
    switch (category) {
        case "Energy Efficiency":
            return [
                SustainabilityEfforts.EnergyEfficientLighting,
                SustainabilityEfforts.EnergyStarAppliances,
                SustainabilityEfforts.SolarPower,
                SustainabilityEfforts.WindTurbinePower
            ];
        case "Food":
            return [
                SustainabilityEfforts.MajorAllergenFree,
                SustainabilityEfforts.MostlyLocalProductUse,
                SustainabilityEfforts.MostlyOrganicProductUse
            ];
        case "Indoor Air Quality / Allergen Awareness":
            return [
                SustainabilityEfforts.LowOrNoVOCinsulation,
                SustainabilityEfforts.LowOrNoVOCproducts,
                SustainabilityEfforts.MechanicalAirExchange,
                SustainabilityEfforts.NonToxicPestControlInside,
                SustainabilityEfforts.WholeHouseHEPA
            ];
        case "Indoor Water Quality (Bathing and Potable)":
            return [SustainabilityEfforts.PrivateWell, SustainabilityEfforts.WholeHouseWaterFiltration];
        case "Land Management Practices":
            return [
                SustainabilityEfforts.Biodynamic,
                SustainabilityEfforts.NonToxicPestControlOutside,
                SustainabilityEfforts.Organic,
                SustainabilityEfforts.PermaculturePractices,
                SustainabilityEfforts.RegenerativeAgriculture
            ];
        case "Supplies / Purchasing / Materials":
            return [
                SustainabilityEfforts.AllNaturalBedding,
                SustainabilityEfforts.NoAerosolSprays,
                SustainabilityEfforts.NonToxicCleaningProducts,
                SustainabilityEfforts.OrganicMattresses,
                SustainabilityEfforts.RecycledPaperProducts
            ];
        case "Waste Reduction and Recycling":
            return [
                SustainabilityEfforts.Composting,
                SustainabilityEfforts.NoOneUseCoffee,
                SustainabilityEfforts.NoPlasticBottles,
                SustainabilityEfforts.Recycling
            ];
        case "Water Conservation and Protection":
            return [
                SustainabilityEfforts.DrinkingWaterFiltration,
                SustainabilityEfforts.Gardens,
                SustainabilityEfforts.LowFlowFaucets,
                SustainabilityEfforts.LowFlushToilets,
                SustainabilityEfforts.SinkMotionSensors,
                SustainabilityEfforts.WaterConservingAppliances,
                SustainabilityEfforts.WaterConservingIrrigation,
                SustainabilityEfforts.WaterlessUrinals
            ];
    }
    return [];
}

export function getSustainabilityEffortImageUrl(_id: SustainabilityEfforts): string {
    //TODO
    return "";
}

export function getSustainabilityEffort(id: SustainabilityEfforts): SustainabilityEffort {
    const label = getSustainabilityEffortLabel(id);
    const url = getSustainabilityEffortImageUrl(id);

    return new SustainabilityEffort(id, label, url);
}

export function getSustainabilityEfforts(ids: SustainabilityEfforts[]): SustainabilityEffort[] {
    return ids.map(getSustainabilityEffort);
}
