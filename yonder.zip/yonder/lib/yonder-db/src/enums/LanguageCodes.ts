export enum LanguageCodes {
    EN_US = "en-US",
    ES_US = "es-US"
}
