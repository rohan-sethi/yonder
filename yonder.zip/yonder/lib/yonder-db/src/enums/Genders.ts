export enum Genders {
    Male = "male",
    Female = "female",
    Other = "other",
    NoAnswer = "no_answer"
}

export function getGenderLabel(id: Genders): string {
    switch (id) {
        case Genders.Male:
            return "Male";
        case Genders.Female:
            return "Female";
        case Genders.Other:
            return "Other";
        case Genders.NoAnswer:
            return "No Answer";
    }
    return "undefined";
}
