export enum PricingUnits {
    perPerson = "per_person",
    perGroup = "per_group"
}

export class PricingUnit {
    constructor(public code: string, public label: string) {}
}

export function getPricingUnitLabel(id: PricingUnits): string {
    switch (id) {
        case PricingUnits.perPerson:
            return "Per person";
        case PricingUnits.perGroup:
            return "Per group";
    }
    return "undefined";
}
