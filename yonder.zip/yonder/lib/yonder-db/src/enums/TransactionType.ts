export enum TransactionType {
    Booking = "Booking",
    Refund = "Refund",
    Promo = "Promo",
    Partial = "Partial",
    Other = "Other"
}
