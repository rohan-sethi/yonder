export enum StatesUS {
    AL = "AL",
    AK = "AK",
    AZ = "AZ",
    AR = "AR",
    CA = "CA",
    CO = "CO",
    CT = "CT",
    DE = "DE",
    FL = "FL",
    GA = "GA",
    HI = "HI",
    ID = "ID",
    IL = "IL",
    IN = "IN",
    IA = "IA",
    KS = "KS",
    KY = "KY",
    LA = "LA",
    ME = "ME",
    MD = "MD",
    MA = "MA",
    MI = "MI",
    MN = "MN",
    MS = "MS",
    MO = "MO",
    MT = "MT",
    NE = "NE",
    NV = "NV",
    NH = "NH",
    NJ = "NJ",
    NM = "NM",
    NY = "NY",
    NC = "NC",
    ND = "ND",
    OH = "OH",
    OK = "OK",
    OR = "OR",
    PA = "PA",
    RI = "RI",
    SC = "SC",
    SD = "SD",
    TN = "TN",
    TX = "TX",
    UT = "UT",
    VT = "VT",
    VA = "VA",
    WA = "WA",
    WV = "WV",
    WI = "WI",
    WY = "WY"
}

export function getStateName(id: StatesUS): string {
    switch (id) {
        case StatesUS.AL:
            return "Alabama";
        case StatesUS.AK:
            return "Alaska";
        case StatesUS.AZ:
            return "Arizona";
        case StatesUS.AR:
            return "Arkansas";
        case StatesUS.CA:
            return "California";
        case StatesUS.CO:
            return "Colorado";
        case StatesUS.CT:
            return "Connecticut";
        case StatesUS.DE:
            return "Delaware";
        case StatesUS.FL:
            return "Florida";
        case StatesUS.GA:
            return "Georgia";
        case StatesUS.HI:
            return "Hawaii";
        case StatesUS.ID:
            return "Idaho";
        case StatesUS.IL:
            return "Illinois";
        case StatesUS.IN:
            return "Indiana";
        case StatesUS.IA:
            return "Iowa";
        case StatesUS.KS:
            return "Kansas";
        case StatesUS.KY:
            return "Kentucky";
        case StatesUS.LA:
            return "Louisiana";
        case StatesUS.ME:
            return "Maine";
        case StatesUS.MD:
            return "Maryland";
        case StatesUS.MA:
            return "Massachusetts";
        case StatesUS.MI:
            return "Michigan";
        case StatesUS.MN:
            return "Minnesota";
        case StatesUS.MS:
            return "Mississippi";
        case StatesUS.MO:
            return "Missouri";
        case StatesUS.MT:
            return "Montana";
        case StatesUS.NE:
            return "Nebraska";
        case StatesUS.NV:
            return "Nevada";
        case StatesUS.NH:
            return "New Hampshire";
        case StatesUS.NJ:
            return "New Jersey";
        case StatesUS.NM:
            return "New Mexico";
        case StatesUS.NY:
            return "New York";
        case StatesUS.NC:
            return "North Carolina";
        case StatesUS.ND:
            return "North Dakota";
        case StatesUS.OH:
            return "Ohio";
        case StatesUS.OK:
            return "Oklahoma";
        case StatesUS.OR:
            return "Oregon";
        case StatesUS.PA:
            return "Pennsylvania";
        case StatesUS.RI:
            return "Rhode Island";
        case StatesUS.SC:
            return "South Carolina";
        case StatesUS.SD:
            return "South Dakota";
        case StatesUS.TN:
            return "Tennessee";
        case StatesUS.TX:
            return "Texas";
        case StatesUS.UT:
            return "Utah";
        case StatesUS.VT:
            return "Vermont";
        case StatesUS.VA:
            return "Virginia";
        case StatesUS.WA:
            return "Washington";
        case StatesUS.WV:
            return "West Virginia";
        case StatesUS.WI:
            return "Wisconsin";
        case StatesUS.WY:
            return "Wyoming";
    }
    return "undefined";
}
