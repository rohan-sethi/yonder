export enum HostTypes {
    Normal = "normal",
    PropertyManagement = "property_management",
    Guest = "guest"
}

export class HostType {
    constructor(public id: string, public label: string) {}
}

export function getHostTypeLabel(id: HostTypes): string {
    switch (id) {
        case HostTypes.Normal:
            return "Normal";
        case HostTypes.PropertyManagement:
            return "Property Management";
        case HostTypes.Guest:
            return "Guest";
    }
    return "undefined";
}

export function getHostType(id: HostTypes): HostType {
    let label = getHostTypeLabel(id);

    return new HostType(id, label);
}

export function getHostTypes(ids: HostTypes[]): HostType[] {
    return ids.map(getHostType);
}
