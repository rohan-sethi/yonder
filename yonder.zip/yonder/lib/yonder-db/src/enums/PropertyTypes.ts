export enum PropertyTypes {
    BedAndBreakfast = "bnb",
    BoutiqueHotel = "boutique_hotel",
    Bungalow = "bungalow",
    Cabin = "cabin",
    Chalet = "chalet",
    Condo = "condo",
    ContainerHouse = "container_house",
    Cottage = "cottage",
    DomeHouse = "dome_house",
    EarthHouse = "earth_house",
    Hotel = "hotel",
    House = "house",
    HouseBoat = "house_boat",
    Hut = "hut",
    Lighthouse = "lighthouse",
    Lodge = "lodge",
    Penthouse = "penthouse",
    Resort = "resort",
    SafariTent = "safari_tent",
    TinyHouse = "tiny_house",
    TreeHouse = "tree_house",
    UniqueSpace = "unique_space",
    Villa = "villa",
    Yurt = "yurt",
    // Old
    Barn = "barn",
    Boat = "boat",
    Ranch = "ranch",
    Studio = "studio",
    Townhouse = "townhouse"
}

export class PropertyType {
    constructor(public id: string, public label: string, public image: string) {}
}

export function getPropertyTypeLabel(id: PropertyTypes): string {
    switch (id) {
        case PropertyTypes.BedAndBreakfast:
            return "Bed & Breakfast";
        case PropertyTypes.BoutiqueHotel:
            return "Boutique Hotel";
        case PropertyTypes.Bungalow:
            return "Bungalow";
        case PropertyTypes.Cabin:
            return "Cabin";
        case PropertyTypes.Chalet:
            return "Chalet";
        case PropertyTypes.Condo:
            return "Condo";
        case PropertyTypes.ContainerHouse:
            return "Container House";
        case PropertyTypes.Cottage:
            return "Cottage";
        case PropertyTypes.DomeHouse:
            return "Dome House";
        case PropertyTypes.EarthHouse:
            return "Earth House";
        case PropertyTypes.Hotel:
            return "Hotel";
        case PropertyTypes.House:
            return "House";
        case PropertyTypes.HouseBoat:
            return "House Boat";
        case PropertyTypes.Hut:
            return "Hut";
        case PropertyTypes.Lighthouse:
            return "Lighthouse";
        case PropertyTypes.Lodge:
            return "Lodge";
        case PropertyTypes.Penthouse:
            return "Penthouse";
        case PropertyTypes.Resort:
            return "Resort";
        case PropertyTypes.SafariTent:
            return "Safari Tent";
        case PropertyTypes.TinyHouse:
            return "Tiny House";
        case PropertyTypes.TreeHouse:
            return "Tree House";
        case PropertyTypes.UniqueSpace:
            return "Unique Space";
        case PropertyTypes.Villa:
            return "Villa";
        case PropertyTypes.Yurt:
            return "Yurt";
        // Old
        case PropertyTypes.Barn:
            return "Barn";
        case PropertyTypes.Boat:
            return "Boat";
        case PropertyTypes.Ranch:
            return "Ranch";
        case PropertyTypes.Studio:
            return "Studio";
        case PropertyTypes.Townhouse:
            return "Townhouse";
    }
    return "undefined";
}

export function getPropertyTypeImageUrl(_id: PropertyTypes): string {
    // TODO
    return "";
}

export function getPropertyType(id: PropertyTypes): PropertyType {
    const label = getPropertyTypeLabel(id);
    const url = getPropertyTypeImageUrl(id);

    return new PropertyType(id, label, url);
}
