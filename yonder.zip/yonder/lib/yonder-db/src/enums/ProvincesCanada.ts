export enum ProvincesCanada {
    AB = "AB",
    BC = "BC",
    MB = "MB",
    NB = "NB",
    NL = "NL",
    NS = "NS",
    ON = "ON",
    PE = "PE",
    QC = "QC",
    SK = "SK"
}

export function getProvinceName(id: ProvincesCanada): string {
    switch (id) {
        case ProvincesCanada.AB:
            return "Alberta";
        case ProvincesCanada.BC:
            return "British Columbia";
        case ProvincesCanada.MB:
            return "Manitoba";
        case ProvincesCanada.NB:
            return "New Brunswick";
        case ProvincesCanada.NL:
            return "Newfoundland and Labrador";
        case ProvincesCanada.NS:
            return "Nova Scotia";
        case ProvincesCanada.ON:
            return "Ontario";
        case ProvincesCanada.PE:
            return "Prince Edward Island";
        case ProvincesCanada.QC:
            return "Quebec";
        case ProvincesCanada.SK:
            return "Saskatchewan";
    }
    return "undefined";
}
