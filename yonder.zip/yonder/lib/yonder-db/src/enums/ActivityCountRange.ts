export enum ActivityCountRanges {
    Zero = "zero",
    OneToThree = "one_to_three",
    FourToSix = "four_to_six",
    SevenToNine = "seven_to_nine",
    TenOrMore = "ten_or_more"
}

export class ActivityCountRange {
    constructor(public id: string, public label: string, public image: string) {}
}

export function getActivityCountRangeLabel(id: ActivityCountRanges): string {
    switch (id) {
        case ActivityCountRanges.Zero:
            return "0 activities";
        case ActivityCountRanges.OneToThree:
            return "1 - 3 activities";
        case ActivityCountRanges.FourToSix:
            return "4 - 6 activities";
        case ActivityCountRanges.SevenToNine:
            return "7 - 9 activities";
        case ActivityCountRanges.TenOrMore:
            return "10 or more activities";
    }
    return "undefined";
}

export function getActivityCountRangeImageUrl(_id: ActivityCountRanges): string {
    // TODO
    return "";
}

export function getActivityCountRange(id: ActivityCountRanges): ActivityCountRange {
    let label = getActivityCountRangeLabel(id);
    let url = getActivityCountRangeImageUrl(id);

    return new ActivityCountRange(id, label, url);
}

export function getActivityCountRanges(ids: ActivityCountRanges[]): ActivityCountRange[] {
    return ids.map(getActivityCountRange);
}
