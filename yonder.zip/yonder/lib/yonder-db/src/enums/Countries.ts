export enum Countries {
    USA = "usa",
    Canada = "canada",
    Other = "other"
}

export function getCountryName(id: Countries): string {
    switch (id) {
        case Countries.USA:
            return "United States";
        case Countries.Canada:
            return "Canada";
        case Countries.Other:
            return "Other";
    }
    return "undefined";
}
