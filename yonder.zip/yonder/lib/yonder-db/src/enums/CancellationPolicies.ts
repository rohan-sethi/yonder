export enum CancellationPolicies {
    Relaxed = "relaxed",
    Harmonious = "harmonious",
    Strict = "strict",
    NonRefundable = "non_refundable"
}

export class CancellationPolicy {
    constructor(public id: string, public label: string, public image: string) {}
}

export function getCancellationPolicyLabel(id: CancellationPolicies): string {
    switch (id) {
        case CancellationPolicies.Relaxed:
            return "Relaxed";
        case CancellationPolicies.Harmonious:
            return "Balanced";
        case CancellationPolicies.Strict:
            return "Strict";
        case CancellationPolicies.NonRefundable:
            return "Non-Refundable";
    }
    return "undefined";
}

export function getCancellationPolicyDescription(id: CancellationPolicies): string {
    switch (id) {
        case CancellationPolicies.Relaxed:
            return ": Full refund 2 days prior to arrival";
        case CancellationPolicies.Harmonious:
            return ": Full refund 7 days prior to arrival";
        case CancellationPolicies.Strict:
            return ": Full refund within 2 days of booking";
        case CancellationPolicies.NonRefundable:
            return ": After booking, no refunds can be accepted";
    }
    return "undefined";
}

export function getCancellationPolicyUrl(id: CancellationPolicies): string {
    return `//help.yonder.com/hc/en-us/articles/360033783674-Cancellation-Policies#${id}`;
}

export function getCancellationPolicy(id: CancellationPolicies): CancellationPolicy {
    let label = getCancellationPolicyLabel(id);
    let url = getCancellationPolicyUrl(id);

    return new CancellationPolicy(id, label, url);
}

export function getCancellationPolicys(ids: CancellationPolicies[]): CancellationPolicy[] {
    return ids.map(getCancellationPolicy);
}
