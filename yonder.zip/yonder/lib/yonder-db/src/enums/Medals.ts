export enum Medals {
    EnvironmentalSteward = 0,
    EcologicalDesign = 1,
    GlobalPartner = 2,
    HolisticCultivation = 3
}

export class Medal {
    constructor(public id: number, public label: string, public image: string, public description: string) {}
}

export function getMedalLabel(id: Medals): string {
    switch (id) {
        case Medals.EnvironmentalSteward:
            return "Environmental Steward";
        case Medals.EcologicalDesign:
            return "Ecological Design";
        case Medals.GlobalPartner:
            return "Global Partner";
        case Medals.HolisticCultivation:
            return "Holistic Cultivation";
    }
    return "undefined";
}

export function getMedalImageUrl(id: Medals): string {
    switch (id) {
        case Medals.EnvironmentalSteward:
            return "http://via.placeholder.com/50";
        case Medals.EcologicalDesign:
            return "http://via.placeholder.com/50";
        case Medals.GlobalPartner:
            return "http://via.placeholder.com/50";
        case Medals.HolisticCultivation:
            return "http://via.placeholder.com/50";
    }
    return "undefined";
}

export function getMedalDescription(id: Medals): string {
    switch (id) {
        case Medals.EnvironmentalSteward:
            return "Awarded to Hosts that produce goods and/or services, and/or manage natural environments showcasing an unwavering commitment in promoting vibrant landscapes, healthy ecosystems, and / or the production of nutrient-dense food choices, all the while treading lightly on the Earth.";
        case Medals.EcologicalDesign:
            return "Awarded to Hosts that demonstrate evolving levels of innovation through design, development, and / or the application of tangible or intangible constructs inspiring harmony between inhabitants of the built environment and the natural world.";
        case Medals.GlobalPartner:
            return "Awarded to Hosts that actively champion the growth, independence, and wellbeing of others both within their own communities as well as afar through means of philanthropy, volunteer work, and social activism.";
        case Medals.HolisticCultivation:
            return "Awarded to Hosts offering human and social transformation retreats, classes, and workshops that cultivate an integration of humanity with Nature through embodying harmonious design of natural surroundings, enhancing balance, and enlivening contemplative mindfulness.";
    }
    return "undefined";
}

export function getMedal(id: Medals): Medal {
    const label = getMedalLabel(id);
    const url = getMedalImageUrl(id);
    const description = getMedalDescription(id);

    return new Medal(id, label, url, description);
}

export function getMedals(ids: Medals[]): Medal[] {
    return ids.map(getMedal);
}
