export enum TemperatureRanges {
    Slot0To10F = "0_to_10_F",
    Slot10To20F = "10_to_20_F",
    Slot20To30F = "20_to_30_F",
    Slot30To40F = "30_to_40_F",
    Slot40To50F = "40_to_50_F",
    Slot50To60F = "50_to_60_F",
    Slot60To70F = "60_to_70_F",
    Slot70To80F = "70_to_80_F",
    Slot80To90F = "80_to_90_F",
    Slot90To100F = "90_to_100_F"
}

export function getTemperatureRangeLabel(id: TemperatureRanges): string {
    switch (id) {
        case TemperatureRanges.Slot0To10F:
            return "0°F - 10°F";
        case TemperatureRanges.Slot10To20F:
            return "10°F - 20°F";
        case TemperatureRanges.Slot20To30F:
            return "20°F - 30°F";
        case TemperatureRanges.Slot30To40F:
            return "30°F - 40°F";
        case TemperatureRanges.Slot40To50F:
            return "40°F - 50°F";
        case TemperatureRanges.Slot50To60F:
            return "50°F - 60°F";
        case TemperatureRanges.Slot60To70F:
            return "60°F - 70°F";
        case TemperatureRanges.Slot70To80F:
            return "70°F - 80°F";
        case TemperatureRanges.Slot80To90F:
            return "80°F - 90°F";
        case TemperatureRanges.Slot90To100F:
            return "90°F - 100°F";
    }
    return "undefined";
}
