/**
 * Basic: User has been created, is either not a host or a host who has not initiated the approval process
 * HostOrganizationCreated: User intends to be a host, but has only added their business (completed the "Let us get to know you!" screen)
 * HostApprovalSubmitted: User has completed the "Submission for Approval" flow (their first property listing)
 * Host: User is an approved host and has access to the full dashboard
 * Admin: Yonder Staff, etc.
 */
export enum UserPermissions {
    Basic = "basic",
    Invited = "invited",
    HostOrganizationCreated = "host_organization_created",
    HostApprovalSubmitted = "host_approval_submitted",
    Host = "host",
    Admin = "admin"
}
