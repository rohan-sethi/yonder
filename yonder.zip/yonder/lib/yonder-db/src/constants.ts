export type ID = string;
export type Price = number | string | null;

export enum CallMethod {
    GET = "get",
    POST = "post",
    PUT = "put",
    PATCH = "patch",
    DELETE = "delete",
    OPTIONS = "options",
    HEAD = "head"
}

export const GET = CallMethod.GET;
export const POST = CallMethod.POST;
export const PUT = CallMethod.PUT;
export const PATCH = CallMethod.PATCH;
export const DELETE = CallMethod.DELETE;
export const OPTIONS = CallMethod.OPTIONS;
export const HEAD = CallMethod.HEAD;
