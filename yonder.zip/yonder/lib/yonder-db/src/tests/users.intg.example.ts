import "jest";
import { User } from "../interface";
import { LanguageCodes, UserPermissions } from "../enums";
import { yonderPost, yonderGet, yonderPatch, yonderDelete } from "..";

describe("REST Tests", () => {
    let userId = "";

    it("yonderPost('/users', user)", async () => {
        let user = new User();
        user.firstName = "Bob";
        user.lastName = "Sacamano";
        user.permissions = UserPermissions.Basic;
        user.email = "thebobsacamano@gmail.com";
        user.preferredLanguage = LanguageCodes.EN_US;
        user.dateOfBirth = new Date().toJSON();

        let res: any;
        try {
            res = await yonderPost(`/users`, user);
        } catch (err) {
            throw new Error(err);
        }

        if (res.error) {
            expect(res.error.status).toEqual(409);
        } else {
            expect(res.error).toEqual(undefined);
        }

        userId = res.id;
    });

    it(`yonderGet('/users/${userId}')`, async () => {
        let res: any;
        try {
            res = await yonderGet(`/users/${userId}`);
        } catch (err) {
            res = err.response.data;
        }

        if (res.error) {
            expect(res.error.status).toEqual(409);
        } else {
            expect(res.error).toEqual(undefined);
        }
    });

    it(`yonderPatch('/users/${userId}', data)`, async () => {
        let res: any;
        try {
            res = await yonderPatch(`/users/${userId}`, {
                about: "Serious businessman."
            });
            //console.log(res);
        } catch (err) {
            res = err.response.data;
        }

        if (res.error) {
            expect(res.error.status).toEqual(409);
        } else {
            expect(res.error).toEqual(undefined);
        }
    });

    it("yonderGet('/users')", async () => {
        let res: any;
        try {
            res = await yonderGet("/users");
            //console.log(res);
        } catch (err) {
            res = err.response.data;
            console.log(res);
        }

        if (res.error) {
            expect(res.error.status).toEqual(409);
        } else {
            expect(res.error).toEqual(undefined);
        }
    });

    it(`yonderDelete('/users/${userId}')`, async () => {
        let res: any;
        try {
            res = await yonderDelete(`/users/${userId}`);
            //console.log(res);
        } catch (err) {
            res = err.response.data;
        }

        if (res.error) {
            expect(res.error.status).toEqual(409);
        } else {
            expect(res.error).toEqual(undefined);
        }
    });
});
