import "jest";
import { Property, User /*Language, Location, City, State, Language*/ } from "../interface";

import { yonderPost, yonderGet } from "../ApiRequests";

import { Amenities, Medals, PropertyTypes, OfferingCategories, StatesUS, Countries } from "../enums";

//import { resolve } from "path";

/*
const createHost = async (): Promise<User> => {
    let host = new User();
    host.firstName = "Carol";
    host.lastName = "Davis";
    host.permissions = UserPermissions.Host
    host.email = "caroldavis+1@email.com";
    host.preferredLanguage = Language.EN_US;
    host.dateOfBirth = new Date();
    host.about =
        "Your Host Carol Davis is a Native of Texas, Carol Davis was born and reared on a Warda farm and ranch owned by her family since 1875. Warda is one of the State's many German-American communities, and Carol spoke only German before she started school in a one-room parochial school...";

    let res: any;

    try {
        res = await yonderPost('/users', host);
    } catch (err) {
        res = err.response.data;
        if (res.error.validationErrors) {
            console.log(res.error.validationErrors);
        }
    }

    return res;
};
*/

/*
const removeHost = async (userId: string): Promise<User> => {
    let res: any;

    try {
        res = await yonderDelete(`/users/${userId}`);
        //console.log(res);
    } catch (err) {
        res = err.response.data;
    }

    if (res.error) {
        expect(res.error.status).toEqual(409);
    } else {
        expect(res.error).toEqual(undefined);
    }

    return res;
};
*/

describe("REST Tests", () => {
    let host: User;
    let property: Property;

    beforeAll(async () => {
        //host = await createHost();
    });

    afterAll(async () => {
        if (host.id) {
            //await removeHost(host.id);
        }
    });

    it("yonderPost('/properties', property)", async () => {
        property = new Property();

        property.name = "The Dog Trot House";

        property.location = {
            address1: "13597 Frantz Rd",
            city: "Cat Spring",
            state: StatesUS.TX,
            isProvince: false,
            country: Countries.USA,
            long: "-96.361820",
            lat: "29.836680",
            description:
                "Cat Spring is about an hour and a half east of Austin and about an hour west of Houston. It's a one stop light town. You know, the kind if you blink...you miss. Serene, hospitable, relaxing and amazing."
        };

        property.summary =
            "Blisswood Bed and Breakfast Ranch is an authentic Texas experience like no other. Unwind in the peaceful country setting amidst majestic live oaks, open ranch land, and our fully stocked fishing pond. Enjoy simple life in the calming surroundings of our working Texas Hill Country guest ranch.";

        property.content = [
            {
                title: "What We Love",
                content:
                    "Enjoy the simple life in the calming surroundings of this magnificent Cat Spring, Texas ranch, where animals abound, including horses, cattle, miniature donkeys and even American Bison. Relax with catch & release bass fishing in our stocked lakes. Watch swans, ducks and geese glide by on the pond. Rekindle a romance with romantic getaways in Texas, or have a picnic at the gazebo overlooking the Enchanted Lake. Take a midnight stroll through the meadows and moonbeams, gaze at the stars, do nothing or do it all!"
            },
            {
                title: "Things To Know",
                content:
                    "• A 500-acre working ranch an hour west of Houston\n• Award-winning Carol’s at Cat Spring Restaurant, just minutes from BlissWood\n• Plenty of places for a leisurely hike\n•  Huff Brewing Company is a 20 minute scenic drive away\n• Bikes for rent"
            }
        ];

        property.hostId = "";

        property.medals = [
            Medals.EcologicalDesign,
            Medals.EnvironmentalSteward,
            Medals.GlobalPartner,
            Medals.HolisticCultivation
        ];

        property.propertyType = PropertyTypes.House;
        property.category = OfferingCategories.Ranch;

        property.bedroomCount = 2;
        property.fullBathroomCount = 2;
        property.halfBathroomCount = 1;

        property.amenities = [Amenities.Bathtub, Amenities.AirConditioning, Amenities.BBQGrill];

        property.pricing.defaultWeekday = 259;
        property.pricing.defaultWeekend = 289;
        //property.language = Language.EN_US;
        property.minimumStay = 2;
        property.overallRating = 4.8;

        let res: any;
        try {
            res = await yonderPost("/properties", property);
            property.id = res.id;
        } catch (err) {
            res = err;
        }

        if (res.error) {
            expect(res.error.status).toEqual(409);
        } else {
            expect(res.error).toEqual(undefined);
        }

        expect(property.name).toEqual("The Dog Trot House");
    });

    it("yonderGet('/properties/:id')", async () => {
        let res: any;
        if (!property.id) {
            expect(res).toEqual(undefined);
            return;
        }

        try {
            res = await yonderGet(`/properties/${property.id}`);
            console.log(res);
        } catch (err) {
            res = err;
        }

        if (res.error) {
            expect(res.error.status).toEqual(409);
        } else {
            //console.log('********');
            //console.log(Object.keys(res));
            expect(res.error).toEqual(undefined);
        }
    });
});
