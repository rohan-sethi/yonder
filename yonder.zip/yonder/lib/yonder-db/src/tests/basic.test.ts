import "jest";

describe("Basic Unit Tests", () => {
    it("someTest", async () => {
        let someTest = true;

        expect(someTest).toBeTruthy();
    });
});
