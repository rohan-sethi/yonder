
import * as ical from 'cal-parser';


export default class ICSParser  {

   private icsString:any;
   private icsData:any;

    constructor(icsStringData:string){
      this.icsString = ical.parseString(icsStringData);
    }

    public parseStringFile(content:string) {
        this.icsData = ical.parseString(content);
    }

    public getFullParsedData(){
        return this.icsData;
    }

    public getAllEvents(){
        return this.icsData.events;
    }

    public getCalenderMetadata(){
        return this.icsData.calendarData;
    }

    public getEventsOnDate(date:Date){
        return this.icsData.getEventsOnDate(date);
    }

    public getEventBetweenDates(dateFrom:Date,dateTo:Date){
        return this.icsData.getEventsOnDate(dateFrom,dateTo,true);
    }


}
